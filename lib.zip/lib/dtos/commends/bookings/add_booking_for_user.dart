import 'package:equatable/equatable.dart';

import '../../../featuers/bookings/domain/enums/booking_method_enum.dart';
import '../../../featuers/payments/domain/enums/payment_method_enum.dart';
import '../../../featuers/payments/domain/enums/payment_transaction_type_enum.dart';

class AddBookingForUser extends Equatable {
  final int? serviceId;
  final String? note;
  final BookingMethodEnum? bookingMethodEnum;
  final DateTime? bookingDate;

  /////
  final int? storeWalletId;
  final PaymentMethodEnum? paymentMethodEnum;
  final double? amount;
  final int? transactionNumber;
  final String? transactionImage;
  final PaymentTransactionTypeEnum? paymentTransactionTypeEnum;

  const AddBookingForUser({
    this.serviceId,
    this.note,
    this.bookingMethodEnum,
    this.bookingDate,
    this.paymentMethodEnum,
    this.storeWalletId,
    this.amount,
    this.transactionNumber,
    this.transactionImage,
    this.paymentTransactionTypeEnum,
  });

  @override
  List<Object?> get props => [
        serviceId,
        note,
        bookingMethodEnum,
        bookingDate,
        paymentMethodEnum,
        storeWalletId,
        amount,
        transactionNumber,
        transactionImage,
        paymentTransactionTypeEnum,
      ];
}
