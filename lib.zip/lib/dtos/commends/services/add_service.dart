import 'package:equatable/equatable.dart';

class AddService extends Equatable {
  final String? name;
  final double? price;
  final String? duration;
  final int? peopleCount;
  final int? storeId;
  final String? description;
  final String? includedServices;
  final List<String>? images;

  const AddService({
    this.name,
    this.price,
    this.duration,
    this.peopleCount,
    this.storeId,
    this.description,
    this.includedServices,
    this.images,
  });

  @override
  List<Object?> get props => [
        name,
        price,
        duration,
        peopleCount,
        storeId,
        description,
        includedServices,
        images,
      ];
}
