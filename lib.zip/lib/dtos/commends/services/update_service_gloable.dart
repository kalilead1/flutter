import 'package:equatable/equatable.dart';

class UpdateServiceGloable extends Equatable {
  final int? serviceId;
  final String? description;
  final String? includedServices;

  const UpdateServiceGloable(
      {this.serviceId, this.description, this.includedServices});

  @override
  List<Object?> get props => [serviceId, description, includedServices];
}
