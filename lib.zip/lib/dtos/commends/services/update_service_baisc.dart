import 'package:equatable/equatable.dart';

class UpdateServiceBaisc extends Equatable {
  final int? serviceId;
  final String? name;
  final double? price;
  final String? duration;
  final int? peopleCount;

  const UpdateServiceBaisc(
      {this.serviceId, this.name, this.price, this.duration, this.peopleCount});

  @override
  List<Object?> get props => [serviceId, name, price, duration, peopleCount];
}
