import 'package:equatable/equatable.dart';

class UpdateStoreGloable extends Equatable {
  final int? id;
  final int? directorateId;
  final String? addressDetails;
  final String? locationCoordinates;

  const UpdateStoreGloable({
    this.id,
    this.directorateId,
    this.addressDetails,
    this.locationCoordinates,
  });

  @override
  List<Object?> get props =>
      [id, directorateId, addressDetails, locationCoordinates];
}
