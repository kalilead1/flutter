import 'package:booking_v1/featuers/stores/domain/entities/store_policy.dart';
import 'package:booking_v1/featuers/stores/domain/entities/store_wallet.dart';
import 'package:equatable/equatable.dart';

import '../../../featuers/stores/domain/entities/store_social_account.dart';

class AddStore extends Equatable {
  final String? name;
  final String? phone;
  final String? logo;

  final int? categoryId;
  final int? directorateId;
  final String? addressDetails;
  final String? locationCoordinates;

  final List<StoreSocialAccount>? storeSocials;
  final List<StoreWallet>? storeWallets;
  final List<StorePolicy>? storePolicies;
  final List<String>? storeDocuments;

  const AddStore({
    this.name,
    this.phone,
    this.logo,
    this.categoryId,
    this.directorateId,
    this.addressDetails,
    this.locationCoordinates,
    this.storeSocials,
    this.storeWallets,
    this.storePolicies,
    this.storeDocuments,
  });

  @override
  List<Object?> get props => [
        name,
        phone,
        logo,
        categoryId,
        directorateId,
        addressDetails,
        locationCoordinates,
        storeSocials,
        storeWallets,
        storePolicies,
        storeDocuments,
      ];
}
