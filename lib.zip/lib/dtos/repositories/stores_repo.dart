import 'package:booking_v1/dtos/commends/stores/add_store.dart';
import 'package:booking_v1/dtos/commends/stores/update_store_baisc.dart';
import 'package:booking_v1/dtos/commends/stores/update_store_gloable.dart';
import 'package:booking_v1/dtos/commends/stores/update_store_state.dart';
import 'package:booking_v1/dtos/queries/stores/get_store_details_for_provider.dart';
import 'package:booking_v1/dtos/queries/stores/get_store_details_for_user.dart';
import 'package:booking_v1/dtos/queries/stores/get_store_social_accounts.dart';
import 'package:booking_v1/dtos/queries/stores/get_store_wallets.dart';
import 'package:booking_v1/dtos/queries/stores/get_stores_by_user.dart';
import 'package:booking_v1/dtos/queries/stores/get_stores_verifer.dart';
import 'package:booking_v1/featuers/stores/domain/entities/store_report.dart';
import 'package:booking_v1/featuers/stores/domain/entities/store_social_account.dart';
import 'package:booking_v1/featuers/stores/domain/entities/store_wallet.dart';
import 'package:dartz/dartz.dart';

abstract class StoresRepo {
  ///////////////////////////////////////////////////////////////////////////
  ///////////////////////////// commands ////////////////////////////////////
  ///////////////////////////////////////////////////////////////////////////
  Future<Unit> addStore(AddStore addStore);
  Future<Unit> updateStoreBaisc(UpdateStoreBaisc updateStoreBaisc);
  Future<Unit> updateStoreGloable(UpdateStoreGloable updateStoreGloable);
  Future<Unit> updateStoreState(UpdateStoreState updateStoreState);

  ///
  Future<Unit> addStoreWallet(StoreWallet storeWallet);
  Future<Unit> deleteStoreWallet(int storeWalletId);

  ///
  Future<Unit> addStoreSocialAccount(StoreSocialAccount storeSocialAccount);
  Future<Unit> deleteStoreSocialAccount(int storeSocialAccountId);

  ///
  Future<Unit> addStoreReport(StoreReport storeReport);

  ///////////////////////////////////////////////////////////////////////////
  ////////////////////////////// queries ////////////////////////////////////
  ///////////////////////////////////////////////////////////////////////////
  Future<List<GetStores>> getStoresVerifer();
  Future<List<GetStores>> getStoresByCategory(int? categoryId);
  Future<List<GetStoresByUser>> getStoresByUser(int userId);
  Future<GetStoreDetailsForUser> getStoreDetailsForUser(int storeId);
  Future<GetStoreDetailsForProvider> getStoreDetailsForProvider(int storeId);

  ///
  Future<List<GetStoreWallets>> getStoreWallets(int storeId);
  Future<List<GetStoreSocialAccounts>> getStoreSocialAccounts(int storeId);
}
