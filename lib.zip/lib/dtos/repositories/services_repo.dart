import 'package:booking_v1/dtos/commends/services/add_service.dart';
import 'package:booking_v1/dtos/commends/services/update_service_gloable.dart';
import 'package:booking_v1/dtos/entities/service_image.dart';
import 'package:booking_v1/dtos/queries/services/get_service_details_for_provider.dart';
import 'package:booking_v1/dtos/queries/services/get_service_details_for_user.dart';
import 'package:booking_v1/dtos/queries/services/get_services_by_store.dart';
import 'package:booking_v1/dtos/queries/services/get_services_with_lazy_loading.dart';
import 'package:dartz/dartz.dart';

import '../commends/services/update_service_baisc.dart';
import '../queries/services/get_services.dart';

abstract class ServicesRepo {
  ///////////////////////////////////////////////////////////////////////////
  ///////////////////////////// commands ////////////////////////////////////
  ///////////////////////////////////////////////////////////////////////////
  Future<Unit> addService(AddService addService);
  Future<Unit> updateServiceBaisc(UpdateServiceBaisc updateServiceBaisc);
  Future<Unit> updateServiceGloable(UpdateServiceGloable updateServiceGloable);
  Future<Unit> deleteService(int id);

  ///
  Future<Unit> addFavoritService(int serviceId);

  ///
  Future<Unit> addServiceImage(ServiceImage serviceImage);
  Future<Unit> deleteServiceImage(int serviceImageId);

  ///////////////////////////////////////////////////////////////////////////
  ////////////////////////////// queries ////////////////////////////////////
  ///////////////////////////////////////////////////////////////////////////
  Future<GetServicesWithLazyLoading> getAllServices(); // مع الليزي لودينق
  Future<List<GetServices>> getServicesByCategory(int categoryId);
  Future<List<GetServicesByStore>> getServicesByStore(int storeId);
  Future<GetServiceDetailsForUser> getServiceDetailsForUser(int serviceId);
  Future<GetServiceDetailsForProvider> getServiceDetailsForProvider(
      int serviceId);

  ///
  Future<List<ServiceImage>> getServiceImages(int serviceId);
}
