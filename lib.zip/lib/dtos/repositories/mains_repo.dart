import 'package:booking_v1/dtos/entities/complaint_and_suggestion.dart';
import 'package:booking_v1/featuers/main/domain/entities/app_offer.dart';
import 'package:booking_v1/featuers/main/domain/entities/category.dart';
import 'package:booking_v1/featuers/main/domain/entities/city.dart';
import 'package:booking_v1/featuers/main/domain/entities/directorate.dart';
import 'package:booking_v1/featuers/main/domain/entities/package.dart';
import 'package:booking_v1/featuers/main/domain/entities/social_account.dart';
import 'package:booking_v1/featuers/main/domain/entities/wallet.dart';
import 'package:dartz/dartz.dart';

abstract class MainsRepo {
  ///////////////////////////////////////////////////////////////////////////
  ///////////////////////////// commands ////////////////////////////////////
  ///////////////////////////////////////////////////////////////////////////
  Future<Unit> addComplaintOrSuggestion(
      ComplaintOrSuggestion addComplaintOrSuggestion);

  ///////////////////////////////////////////////////////////////////////////
  ////////////////////////////// queries ////////////////////////////////////
  ///////////////////////////////////////////////////////////////////////////
  Future<List<Category>> getCategories();
  Future<List<Category>> getCategoriesByPackage(int packageId);
  Future<List<City>> getCities();
  Future<List<Directorate>> getDirectorates(int cityId);
  Future<List<Wallet>> getWallets();
  Future<List<SocialAccount>> getSocialAccounts();

  ///
  Future<List<AppOffer>> getAppOffers();
  Future<List<Package>> getPackages();
}
