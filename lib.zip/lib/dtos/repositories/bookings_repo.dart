import 'package:booking_v1/dtos/commends/bookings/add_booking_for_user.dart';
import 'package:booking_v1/dtos/queries/bookings/get_booking_details.dart';
import 'package:booking_v1/dtos/queries/bookings/get_bookings_by_provider.dart';
import 'package:booking_v1/dtos/queries/bookings/get_bookings_by_user.dart';
import 'package:dartz/dartz.dart';

abstract class BookingsRepo {
  ///////////////////////////////////////////////////////////////////////////
  ///////////////////////////// commands ////////////////////////////////////
  ///////////////////////////////////////////////////////////////////////////
  Future<Unit> addBookingForUser(AddBookingForUser addBookingForUser);

  ///////////////////////////////////////////////////////////////////////////
  ////////////////////////////// queries ////////////////////////////////////
  ///////////////////////////////////////////////////////////////////////////
  Future<List<GetBookingsByUser>> getBookingsByUser(int userId);
  Future<List<GetBookingsByProvider>> getBookingsByStore(int storeId);
  Future<List<GetBookingsByProvider>> getBookingsByService(int serviceId);
  Future<GetBookingDetails> getBookingDetails(int bookingId);

  ///
  Future<List<DateTime>> getDatesBookings(int serviceId);
}
