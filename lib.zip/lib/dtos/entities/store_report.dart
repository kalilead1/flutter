import 'package:equatable/equatable.dart';

import '../../featuers/stores/domain/enums/store_report_enum.dart';

class StoreReport extends Equatable {
  final int? storeId;
  final StoreReportEnum? reason;
  final String? comment;

  const StoreReport({
    this.storeId,
    this.reason,
    this.comment,
  });

  @override
  List<Object?> get props => [
        storeId,
        reason,
        comment,
      ];
}
