import 'package:equatable/equatable.dart';

class StoreDocument extends Equatable {
  final String? file;
  final String? documentType;

  const StoreDocument({this.file, this.documentType});

  @override
  List<Object?> get props => [file, documentType];
}
