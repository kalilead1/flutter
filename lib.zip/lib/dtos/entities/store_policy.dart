import 'package:equatable/equatable.dart';

class StorePolicy extends Equatable {
  final int? id;
  final int? storeId;
  final int? policyId;

  const StorePolicy({
    this.id,
    this.storeId,
    this.policyId,
  });

  @override
  List<Object?> get props => [id, storeId, policyId];
}
