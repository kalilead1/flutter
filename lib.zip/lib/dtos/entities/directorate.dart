import 'package:equatable/equatable.dart';

class Directorate extends Equatable {
  final int? id;
  final String? name;

  const Directorate({this.id, this.name});

  @override
  List<Object?> get props => [id, name];
}
