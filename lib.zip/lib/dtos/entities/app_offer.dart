import 'package:equatable/equatable.dart';

class AppOffer extends Equatable {
  final int? id;
  final String? image;
  final String? title;
  final String? description;

  const AppOffer({
    this.id,
    this.image,
    this.title,
    this.description,
  });

  @override
  List<Object?> get props => [
        id,
        image,
        title,
        description,
      ];
}
