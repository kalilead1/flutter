import 'package:equatable/equatable.dart';

import '../../featuers/main/domain/enums/complaint_and_suggestion_enum.dart';

class ComplaintOrSuggestion extends Equatable {
  final int? id;
  final String? message;
  final ComplaintAndSuggestionEnum? typeMessage;

  const ComplaintOrSuggestion({
    this.id,
    this.message,
    this.typeMessage,
  });

  @override
  List<Object?> get props => [
        id,
        message,
        typeMessage,
      ];
}
