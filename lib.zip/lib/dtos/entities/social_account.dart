import 'package:equatable/equatable.dart';

class SocialAccount extends Equatable {
  final int? id;
  final String? name;
  final String? logo;

  const SocialAccount({this.id, this.name, this.logo});

  @override
  List<Object?> get props => [id, name, logo];
}
