import 'package:equatable/equatable.dart';

class Package extends Equatable {
  final int? id;
  final String? name;
  final String? logo;

  const Package({
    this.id,
    this.name,
    this.logo,
  });

  @override
  List<Object?> get props => [id, name, logo];
}
