import 'package:equatable/equatable.dart';

class StoreSocialAccount extends Equatable {
  final int? id;
  final int? storeId;
  final int? socialAccountId;
  final String? url;

  const StoreSocialAccount(
      {this.id, this.storeId, this.socialAccountId, this.url});

  @override
  List<Object?> get props => [id, storeId, socialAccountId, url];
}
