import 'package:equatable/equatable.dart';

class ServiceImage extends Equatable {
  final int? id;
  final int? serviceId;
  final String? image;

  const ServiceImage({
    this.id,
    this.serviceId,
    this.image,
  });

  @override
  List<Object?> get props => [id, serviceId, image];
}
