import 'package:equatable/equatable.dart';

class StoreWallet extends Equatable {
  final int? id;
  final int? storeId;
  final int? walletId;
  final int? accountNumber;

  const StoreWallet({this.id, this.storeId, this.walletId, this.accountNumber});

  @override
  List<Object?> get props => [id, storeId, walletId, accountNumber];
}
