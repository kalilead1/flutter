import 'package:equatable/equatable.dart';

class GetStores extends Equatable {
  final int? storeId;
  final String? image;
  final String? name;
  final String? categoryName;

  const GetStores({this.storeId, this.image, this.name, this.categoryName});

  @override
  List<Object?> get props => [storeId, image, name, categoryName];
}
