import 'package:equatable/equatable.dart';

class GetStoreSocialAccounts extends Equatable {
  final int? id;
  final String? socialName;
  final String? socialUrl;

  const GetStoreSocialAccounts({this.id, this.socialName, this.socialUrl});

  @override
  List<Object?> get props => [id, socialName, socialUrl];
}
