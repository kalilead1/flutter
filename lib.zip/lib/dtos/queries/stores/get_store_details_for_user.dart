import 'package:booking_v1/featuers/stores/domain/enums/store_state_enum.dart';
import 'package:equatable/equatable.dart';

class GetStoreDetailsForUser extends Equatable {
  final int? id;
  final String? name;
  final String? phone;
  final String? logo;
  final String? categoryName;
  final StoreStateEnum? stateEnum;

  ///
  final String? cityName;
  final String? directorateName;
  final String? addressDetails;
  final String? locationCoordinates;

  const GetStoreDetailsForUser({
    this.id,
    this.name,
    this.phone,
    this.logo,
    this.categoryName,
    this.stateEnum,

    ///
    this.cityName,
    this.directorateName,
    this.addressDetails,
    this.locationCoordinates,
  });

  @override
  List<Object?> get props => [
        id,
        name,
        phone,
        logo,
        categoryName,
        stateEnum,

        ///
        cityName,
        directorateName,
        addressDetails,
        locationCoordinates,
      ];
}
