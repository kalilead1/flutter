import 'package:equatable/equatable.dart';

class GetStoreWallets extends Equatable {
  final int? id;
  final String? walletName;
  final String? walletAccount;

  const GetStoreWallets({this.id, this.walletName, this.walletAccount});

  @override
  List<Object?> get props => [id, walletName, walletAccount];
}
