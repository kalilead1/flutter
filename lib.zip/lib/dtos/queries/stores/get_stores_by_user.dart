import 'package:booking_v1/featuers/stores/domain/enums/store_state_enum.dart';
import 'package:equatable/equatable.dart';

class GetStoresByUser extends Equatable {
  final int? id;
  final String? image;
  final String? name;
  final String? categoryName;
  final StoreStateEnum? stateEnum;

  const GetStoresByUser({
    this.id,
    this.image,
    this.name,
    this.categoryName,
    this.stateEnum,
  });

  @override
  List<Object?> get props => [
        id,
        image,
        name,
        categoryName,
        stateEnum,
      ];
}
