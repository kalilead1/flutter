import 'package:booking_v1/featuers/stores/domain/enums/store_state_enum.dart';
import 'package:equatable/equatable.dart';

class GetStoreDetailsForProvider extends Equatable {
  final int? id;
  final String? name;
  final String? phone;
  final String? logo;
  final String? categoryName;
  final StoreStateEnum? stateEnum;

  ///
  final int? cityId;
  final int? directorateId;
  final String? addressDetails;
  final String? locationCoordinates;

  ///
  final int? countBookings;
  final int? countServices;
  final int? visitorsCount;
  final bool? isVerified;

  const GetStoreDetailsForProvider({
    this.id,
    this.name,
    this.phone,
    this.logo,
    this.categoryName,
    this.stateEnum,

    ///
    this.cityId,
    this.directorateId,
    this.addressDetails,
    this.locationCoordinates,

    ///
    this.countBookings,
    this.countServices,
    this.visitorsCount,
    this.isVerified,
  });

  @override
  List<Object?> get props => [
        id,
        name,
        phone,
        logo,
        categoryName,
        stateEnum,

        ///
        cityId,
        directorateId,
        addressDetails,
        locationCoordinates,

        ///
        countBookings,
        countServices,
        visitorsCount,
        isVerified,
      ];
}
