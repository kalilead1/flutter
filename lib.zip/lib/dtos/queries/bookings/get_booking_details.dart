import 'package:booking_v1/featuers/bookings/domain/enums/bookings_statues_enum.dart';
import 'package:equatable/equatable.dart';

class GetBookingDetails extends Equatable {
  final int? bookingId;

  final int? serviceId;
  final String? serviceName;
  final String? serviceImage;
  final int? storeId;
  final String? storeLogo;
  final String? storeName;
  final String? categoryName;
  final String? cityName;
  final String? directorateName;

  final double? total; // الاجمالي = سعر الخدمة
  final double? deposit; // المدفوع
  final double? rememing; // المتبقي

  final String? duration;
  final int? peopleCount;

  final String? userName;
  final String? userPhone;

  final BookingsStatuesEnum? stateEnum;
  final String? note;
  final DateTime? dateBooking;
  final DateTime? createAtBooking;

  const GetBookingDetails({
    this.bookingId,
    this.serviceId,
    this.serviceName,
    this.serviceImage,
    this.storeId,
    this.storeLogo,
    this.storeName,
    this.categoryName,
    this.cityName,
    this.directorateName,

    ///
    this.total,
    this.deposit,
    this.rememing,

    ///
    this.duration,
    this.peopleCount,

    ///
    this.userName,
    this.userPhone,
    this.stateEnum,
    this.note,
    this.dateBooking,
    this.createAtBooking,
  });

  @override
  List<Object?> get props => [
        bookingId,
        serviceId,
        serviceName,
        serviceImage,
        storeId,
        storeLogo,
        storeName,
        categoryName,
        cityName,
        directorateName,

        ///
        total,
        deposit,
        rememing,

        ///
        duration,
        peopleCount,

        ///
        userName,
        userPhone,
        stateEnum,
        note,
        dateBooking,
        createAtBooking,
      ];
}
