import 'package:booking_v1/featuers/bookings/domain/enums/bookings_statues_enum.dart';
import 'package:equatable/equatable.dart';

class GetBookingsByProvider extends Equatable {
  final int? id;
  final String? serviceName;
  final String? userName;
  final BookingsStatuesEnum? stateEnum;
  final DateTime? dateBooking;

  const GetBookingsByProvider({
    this.id,
    this.serviceName,
    this.userName,
    this.stateEnum,
    this.dateBooking,
  });

  @override
  List<Object?> get props =>
      [id, serviceName, userName, stateEnum, dateBooking];
}
