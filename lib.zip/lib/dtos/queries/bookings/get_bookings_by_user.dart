import 'package:booking_v1/featuers/bookings/domain/enums/bookings_statues_enum.dart';
import 'package:equatable/equatable.dart';

class GetBookingsByUser extends Equatable {
  final int? id;
  final String? serviceImage;
  final String? serviceName;
  final String? categoryName;
  final int? storeId;
  final String? storeLogo;
  final String? storeName;
  final String? cityName;
  final String? directorateName;
  final BookingsStatuesEnum? stateEnum;
  final DateTime? dateBooking;

  const GetBookingsByUser({
    this.id,
    this.serviceImage,
    this.serviceName,
    this.categoryName,
    this.storeId,
    this.storeLogo,
    this.storeName,
    this.cityName,
    this.directorateName,
    this.stateEnum,
    this.dateBooking,
  });

  @override
  List<Object?> get props => [
        id,
        serviceImage,
        serviceName,
        categoryName,
        storeId,
        storeLogo,
        storeName,
        cityName,
        directorateName,
        stateEnum,
        dateBooking,
      ];
}
