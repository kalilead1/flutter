import 'package:equatable/equatable.dart';

class GetServicesByStore extends Equatable {
  final int? serviceId;
  final String? image;
  final String? name;
  final double? price;
  final String? duration;
  final int? peopleCount;

  const GetServicesByStore({
    this.serviceId,
    this.image,
    this.name,
    this.price,
    this.duration,
    this.peopleCount,
  });

  @override
  List<Object?> get props => [
        serviceId,
        image,
        name,
        price,
        duration,
        peopleCount,
      ];
}
