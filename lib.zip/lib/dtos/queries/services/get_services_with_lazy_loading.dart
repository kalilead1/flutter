import 'package:booking_v1/dtos/queries/services/get_services.dart';
import 'package:equatable/equatable.dart';

class GetServicesWithLazyLoading extends Equatable {
  final List<GetServices>? services;
  final int? totalCount;
  final int? pageNumber;
  final int? pageSize;
  final int? totalPages;
  final bool? hasPreviousPage;
  final bool? hasNextPage;

  const GetServicesWithLazyLoading({
    this.services,
    this.totalCount,
    this.pageNumber,
    this.pageSize,
    this.totalPages,
    this.hasPreviousPage,
    this.hasNextPage,
  });

  @override
  List<Object?> get props => [
        services,
        totalCount,
        pageNumber,
        pageSize,
        totalPages,
        hasPreviousPage,
        hasNextPage,
      ];
}
