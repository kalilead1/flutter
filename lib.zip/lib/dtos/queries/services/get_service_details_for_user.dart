import 'package:equatable/equatable.dart';

class GetServiceDetailsForUser extends Equatable {
  final int? serviceId;
  final String? name;
  final double? price;
  final double? deposit;
  final String? duration;
  final int? peopleCount;
  final String? description;
  final String? includedServices;
  final int? storeId;
  final String? storeName;
  final String? storePhone;
  final String? categoryName;
  final String? cityName;
  final String? directorateName;

  const GetServiceDetailsForUser({
    this.serviceId,
    this.name,
    this.price,
    this.deposit,
    this.duration,
    this.peopleCount,
    this.description,
    this.includedServices,
    this.storeId,
    this.storeName,
    this.storePhone,
    this.categoryName,
    this.cityName,
    this.directorateName,
  });

  @override
  List<Object?> get props => [
        serviceId,
        name,
        price,
        deposit,
        duration,
        peopleCount,
        description,
        includedServices,
        storeId,
        storeName,
        storePhone,
        categoryName,
        cityName,
        directorateName,
      ];
}

// class GetServiceDetailsForUser extends Equatable {
//   final int? serviceId;
//   final List<String>? images;
//   final String? name;
//   final double? price;
//   final double? deposit;
//   final String? duration;
//   final int? peopleCount;
//   final String? description;
//   final String? includedServices;
//   final int? storeId;
//   final int? storeName;
//   final int? storePhone;
//   final int? category;
//   final int? cityName;
//   final int? directorateName;
//   final List<DateTime>? datesBookings;
//   // final List<>? polices;

//   const GetServiceDetailsForUser({
//     this.serviceId,
//     this.images,
//     this.name,
//     this.price,
//     this.deposit,
//     this.duration,
//     this.peopleCount,
//     this.description,
//     this.includedServices,
//     this.storeId,
//     this.storeName,
//     this.storePhone,
//     this.category,
//     this.cityName,
//     this.directorateName,
//     this.datesBookings,
//     // this.polices,
//   });

//   @override
//   List<Object?> get props => [
//         serviceId,
//         images,
//         name,
//         price,
//         deposit,
//         duration,
//         peopleCount,
//         description,
//         includedServices,
//         storeId,
//         storeName,
//         storePhone,
//         category,
//         cityName,
//         directorateName,
//         datesBookings,
//         // polices,
//       ];
// }
