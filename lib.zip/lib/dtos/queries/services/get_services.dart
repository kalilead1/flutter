import 'package:equatable/equatable.dart';

class GetServices extends Equatable {
  final int? serviceId;
  final String? image;
  final String? name;
  final double? price;
  final int? storeId;
  final String? storeLogo;
  final String? storeName;
  final String? categoryName;
  final String? cityName;
  final String? directorateName;

  const GetServices({
    this.serviceId,
    this.image,
    this.name,
    this.price,
    this.storeId,
    this.storeLogo,
    this.storeName,
    this.categoryName,
    this.cityName,
    this.directorateName,
  });

  @override
  List<Object?> get props => [
        serviceId,
        image,
        name,
        price,
        storeId,
        storeLogo,
        storeName,
        categoryName,
        cityName,
        directorateName,
      ];
}
