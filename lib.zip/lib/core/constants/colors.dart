import 'package:flutter/material.dart';

//  light mode colors
const Color lightPrimaryColor = Color(0xFF4680AE); //1
// const Color lightPrimaryColor = Color(0xFF5595C9); //2
//  const Color lightGreyColor = Color(0xFFF2F5F7);

const Color lightSecondaryColor = Color(0xFFF2F5F6); //2
//  const Color lightSecondaryColor = Color(0xFFF4F7F9); //1

const Color lightTertiaryColor = Color(0xFF4C5E73);

const Color lightBackgroundColor = Color(0xFFFFFFFF);

const Color lightTitleTextColor = Color(0xFF000000);
const Color lightBodyTextColor = Color(0xFF4C5E73);
const Color lightDisplayTextColor = Color(0xFF4680AE);
// const Color lightDisplayTextColor = Color(0xFF569CD2);
const Color lightLabelTextColor = Color(0xFF929EA9);

const Color lightBorderColor = Color(0xFFD7DFE6);

//////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////
//  dark mode colors
const Color darkPrimaryColor = Color(0xFF61ABE3);
const Color darkSecondaryColor = Color(0xFF323E4B);
// const Color darkTertiaryColor = Color(0xFF4C5E73); //1
// const Color darkTertiaryColor = Color(0xFF57697D); //2
// const Color darkTertiaryColor = Color(0xFFF2F5F7); //3
const Color darkTertiaryColor = Color(0xFFE5E9EB); //4

//  const Color darkBackgroundColor = Color(0xFF11161C); //1
const Color darkBackgroundColor = Color(0xFF151B23); //2

const Color darkTitleTextColor = Color(0xFFFFFFFF);
const Color darkBodyTextColor = Color(0xFFC9CFD4);
const Color darkDisplayTextColor = Color(0xFF84CAFF);
const Color darkLabelTextColor = Color(0xFF929EA9);

const Color darkBorderColor = Color(0xFF4F5964);

//////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////
// settings colors
const Color successColor = Color(0xFF2ED573);
const Color warningColor = Color(0xFFFFBE21);
const Color errorColor = Color(0xFFEA5B5B);
