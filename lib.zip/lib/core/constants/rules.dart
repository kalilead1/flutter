const int maxImagesForService = 6;
const int minImagesForService = 1;

const int maxDocumentsForStore = 6;
const int minDocumentsForStore = 3;

// const int maxWalletsForStore = 6;
const int minWalletsForStore = 1;

// const int maxDocumentsForStore = 6;
// const int minDocumentsForStore = 3;
