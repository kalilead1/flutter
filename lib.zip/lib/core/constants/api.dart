const String url = "http://10.182.175.60:5036";
const String baseUrl = "$url/api/";

const String baseUrlServiceImagesFolder = "$url/Images/ServicesImages/";
const String baseUrlStoreImagesFolder = "$url/Images/StoresImages/";
const String baseUrlPaymentImagesFolder = "$url/Images/PaymentsImages/";
