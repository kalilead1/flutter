const String fontFamily = "HACEN";

const String baseUrlApp = "https://www.yemenbooking.com/share/";
const String subjectShared =
    "مرحبا.\nقم بزيارة متجرنا؛ لمعرفة خدماتنا وتفاصيلها\n\n\n";
const String appNameShared = "\nتطبيق يمن حجز.";

const double defaultPadding = 16.0;
const double defaultBorderRadious = 12.0;
const Duration defaultDuration = Duration(milliseconds: 300);

const double defaultSpacing = 15;

const String validateFileSizeErrorText = "الملف أكبر من";
const String maximumPhotosErrorText = "وصلت الحد الأقصى للصور";

const String unknownFailuerText = "خطاء غير معروف";

const String textFieldIsEmptyMessage = "الحقل فارغ.. يجب تحديد ";

const String unknownFailureMessage = "خطاء غير معروف";
const String serverFailureMessage = "هناك مشكلة في السرفر الرجاء الاعادة لاحقا";
const String emptyCacheFailureMessage = "لا يوجد بيانات";
const String addedOperationFailureMessage = "فشل اضافة العملية";
const String updatedOperationFailureMessage = "فشل تعديل العملية";
const String deletedOperationFailureMessage = "فشل حذف العملية";
const String noLoginFailureMessage = "انت لست مسجل دخول";
const String offlineFailureMessage =
    "لا يوجد اتصال بالانترنت الرجاء التحقق من اتصالك بالشبكة";

// final passwordValidator = MultiValidator([
//   RequiredValidator(errorText: 'Password is required'),
//   MinLengthValidator(8, errorText: 'password must be at least 8 digits long'),
//   PatternValidator(r'(?=.*?[#?!@$%^&*-])',
//       errorText: 'passwords must have at least one special character')
// ]);

// final emaildValidator = MultiValidator([
//   RequiredValidator(errorText: 'Email is required'),
//   EmailValidator(errorText: "Enter a valid email address"),
// ]);
