import 'package:booking_v1/core/themes/input_decoration_theme.dart';
import 'package:booking_v1/core/themes/theme_data.dart';
import 'package:flutter/material.dart';

import '../constants/colors.dart';
import '../constants/strings.dart';

class AppTheme {
  // lightTheme --------------------------------------------------------------
  static final ThemeData lightTheme = ThemeData(
    fontFamily: fontFamily,
    brightness: Brightness.light,
    primaryColor: lightPrimaryColor,
    scaffoldBackgroundColor: lightBackgroundColor,
    appBarTheme: appBarLightTheme,
    bottomNavigationBarTheme: bottomNavigationBarLightTheme,
    tabBarTheme: tabBarLightTheme,
    elevatedButtonTheme: elevatedButtonLightThemeData,
    inputDecorationTheme: lightInputDecorationTheme,
    outlinedButtonTheme: outlinedButtonLightThemeData,
    textTheme: textLightTheme,
    colorScheme: colorSchemeLight,
    radioTheme: radioLightTheme,
    iconTheme: iconLightThemeData,
    bottomSheetTheme: bottomSheetLightThemeData,
    dividerTheme: dividerLightThemeData,
  );

  // darkTheme --------------------------------------------------------------
  static final ThemeData darkTheme = ThemeData(
    fontFamily: fontFamily,
    brightness: Brightness.dark,
    primaryColor: darkPrimaryColor,
    scaffoldBackgroundColor: darkBackgroundColor,
    appBarTheme: appBarDarkTheme,
    bottomNavigationBarTheme: bottomNavigationBarDarkTheme,
    tabBarTheme: tabBarDarkTheme,
    elevatedButtonTheme: elevatedButtonDarkThemeData,
    inputDecorationTheme: darkInputDecorationTheme,
    outlinedButtonTheme: outlinedButtonDarkThemeData,
    textTheme: textDarkTheme,
    colorScheme: colorSchemeDark,
    radioTheme: radioDarkTheme,
    iconTheme: iconDarkThemeData,
    scrollbarTheme: scrollbarThemeData,
    bottomSheetTheme: bottomSheetDarkThemeData,
    dividerTheme: dividerDarkThemeData,
  );
}
