import 'package:flutter/material.dart';

import '../constants/colors.dart';
import '../constants/strings.dart';

// App Bar Theme ----------------------------------------------------------
const AppBarTheme appBarLightTheme = AppBarTheme(
  backgroundColor: lightBackgroundColor,
  surfaceTintColor: lightBackgroundColor,
  elevation: 0,
);

const AppBarTheme appBarDarkTheme = AppBarTheme(
  backgroundColor: darkBackgroundColor,
  surfaceTintColor: darkBackgroundColor,
  elevation: 0,
);

ScrollbarThemeData scrollbarThemeData = ScrollbarThemeData(
  trackColor: MaterialStateProperty.all(darkPrimaryColor),
);

// Bottom Navigation Bar Theme Data ----------------------------------------------------------
const BottomNavigationBarThemeData bottomNavigationBarLightTheme =
    BottomNavigationBarThemeData(
  unselectedItemColor: Color(0xFFC5D3DF),
  unselectedIconTheme: IconThemeData(
    color: Color(0xFFC5D3DF),
  ),
  selectedItemColor: lightPrimaryColor,
  selectedLabelStyle: TextStyle(fontSize: 12),
  selectedIconTheme: IconThemeData(
    color: lightPrimaryColor,
  ),
);

const BottomNavigationBarThemeData bottomNavigationBarDarkTheme =
    BottomNavigationBarThemeData(
  unselectedItemColor: Color(0xFF707C86),
  unselectedIconTheme: IconThemeData(
    color: Color(0xFF707C86),
  ),
  selectedLabelStyle: TextStyle(fontSize: 12),
  selectedItemColor: darkPrimaryColor,
  selectedIconTheme: IconThemeData(
    color: darkPrimaryColor,
  ),
  backgroundColor: Colors.transparent,
  elevation: 0,
);

// Tab Bar Theme ----------------------------------------------------------
const TabBarTheme tabBarLightTheme = TabBarTheme(
  //  padding: EdgeInsets.only(bottom: defaultPadding / 4),
  tabAlignment: TabAlignment.start,
  labelStyle: TextStyle(
      color: lightDisplayTextColor, fontSize: 15, fontFamily: fontFamily),
  unselectedLabelStyle: TextStyle(
      color: lightLabelTextColor, fontSize: 14, fontFamily: fontFamily),
  dividerColor: Colors.transparent,
);

const TabBarTheme tabBarDarkTheme = TabBarTheme(
  tabAlignment: TabAlignment.start,
  labelStyle: TextStyle(
      color: darkDisplayTextColor, fontSize: 15, fontFamily: fontFamily),
  unselectedLabelStyle: TextStyle(
      color: darkLabelTextColor, fontSize: 14, fontFamily: fontFamily),
  dividerColor: Colors.transparent,
);

// Text Theme ----------------------------------------------------------
const TextTheme textLightTheme = TextTheme(
  titleLarge: TextStyle(color: lightTitleTextColor, fontSize: 20),
  titleMedium: TextStyle(color: lightTitleTextColor, fontSize: 16),
  titleSmall: TextStyle(color: lightTitleTextColor, fontSize: 14),
  bodyLarge: TextStyle(color: lightBodyTextColor, fontSize: 14),
  bodyMedium: TextStyle(color: lightBodyTextColor, fontSize: 12),
  bodySmall: TextStyle(color: lightBodyTextColor, fontSize: 10),
  displayLarge: TextStyle(color: lightDisplayTextColor, fontSize: 20),
  displayMedium: TextStyle(color: lightDisplayTextColor, fontSize: 16),
  displaySmall: TextStyle(color: lightDisplayTextColor, fontSize: 14),
  labelLarge: TextStyle(color: lightLabelTextColor, fontSize: 14),
  labelMedium: TextStyle(color: lightLabelTextColor, fontSize: 12),
  labelSmall: TextStyle(color: lightLabelTextColor, fontSize: 10),
  // titleLarge: TextStyle(color: lightTitleTextColor, fontSize: 20),
  // titleMedium: TextStyle(color: lightTitleTextColor, fontSize: 16),
  // titleSmall: TextStyle(color: lightTitleTextColor, fontSize: 14),
  // bodyLarge: TextStyle(color: lightBodyTextColor, fontSize: 16),
  // bodyMedium: TextStyle(color: lightBodyTextColor, fontSize: 14),
  // bodySmall: TextStyle(color: lightBodyTextColor, fontSize: 12),
  // displayLarge: TextStyle(color: lightDisplayTextColor, fontSize: 20),
  // displayMedium: TextStyle(color: lightDisplayTextColor, fontSize: 16),
  // displaySmall: TextStyle(color: lightDisplayTextColor, fontSize: 14),
  // labelLarge: TextStyle(color: lightLabelTextColor, fontSize: 16),
  // labelMedium: TextStyle(color: lightLabelTextColor, fontSize: 14),
  // labelSmall: TextStyle(color: lightLabelTextColor, fontSize: 12),
);

const TextTheme textDarkTheme = TextTheme(
  titleLarge: TextStyle(color: darkTitleTextColor, fontSize: 20),
  titleMedium: TextStyle(color: darkTitleTextColor, fontSize: 16),
  titleSmall: TextStyle(color: darkTitleTextColor, fontSize: 14),
  bodyLarge: TextStyle(color: darkBodyTextColor, fontSize: 14),
  bodyMedium: TextStyle(color: darkBodyTextColor, fontSize: 12),
  bodySmall: TextStyle(color: darkBodyTextColor, fontSize: 10),
  displayLarge: TextStyle(color: darkDisplayTextColor, fontSize: 20),
  displayMedium: TextStyle(color: darkDisplayTextColor, fontSize: 16),
  displaySmall: TextStyle(color: darkDisplayTextColor, fontSize: 14),
  labelLarge: TextStyle(color: darkLabelTextColor, fontSize: 14),
  labelMedium: TextStyle(color: darkLabelTextColor, fontSize: 12),
  labelSmall: TextStyle(color: darkLabelTextColor, fontSize: 10),
);

// Color Scheme ----------------------------------------------------------
ColorScheme colorSchemeLight = ColorScheme.fromSwatch().copyWith(
  primary: lightPrimaryColor,
  secondary: lightSecondaryColor,
  tertiary: lightTertiaryColor,
  primaryContainer: lightSecondaryColor,
  onPrimaryContainer: lightBorderColor,
  onSecondary: lightLabelTextColor,
);

ColorScheme colorSchemeDark =
    ColorScheme.fromSwatch(brightness: Brightness.dark).copyWith(
  primary: darkPrimaryColor,
  secondary: darkSecondaryColor,
  tertiary: darkTertiaryColor,
  primaryContainer: darkSecondaryColor,
  onPrimaryContainer: darkBorderColor,
  onSecondary: darkLabelTextColor,
);

// Radio Theme Data ----------------------------------------------------------
RadioThemeData radioLightTheme = RadioThemeData(
  fillColor: WidgetStateProperty.all(lightPrimaryColor),
);

RadioThemeData radioDarkTheme = RadioThemeData(
  fillColor: WidgetStateProperty.all(darkPrimaryColor),
);

// BoxDecoration lightBoxDecoration1 = BoxDecoration(
//   borderRadius: BorderRadius.circular(defaultBorderRadious),
//   border: Border.all(color: lightBorder1),
// );
// BoxDecoration lightBoxDecoration2 = BoxDecoration(
//   borderRadius: BorderRadius.circular(defaultBorderRadious),
//   border: Border.all(color: lightBorder2),
// );
// BoxDecoration darkBoxDecoration1 = BoxDecoration(
//   borderRadius: BorderRadius.circular(defaultBorderRadious),
//   border: Border.all(color: darkBorder1),
// );

// Icon Theme Data ----------------------------------------------------------
IconThemeData iconLightThemeData = IconThemeData(size: 26, color: Colors.black);
IconThemeData iconDarkThemeData = IconThemeData(size: 26, color: Colors.white);

// Elevated Button Theme Data ----------------------------------------------------------
ElevatedButtonThemeData elevatedButtonLightThemeData = ElevatedButtonThemeData(
  style: ElevatedButton.styleFrom(
    minimumSize: const Size(double.infinity, 48),
    // fixedSize: const Size(double.maxFinite, 50),
    textStyle: TextStyle(fontSize: 16, fontFamily: fontFamily),
    foregroundColor: Colors.white,
    shape: const RoundedRectangleBorder(
      borderRadius: BorderRadius.all(Radius.circular(defaultBorderRadious)),
    ),
  ),
);

ElevatedButtonThemeData elevatedButtonDarkThemeData = ElevatedButtonThemeData(
  style: ElevatedButton.styleFrom(
    minimumSize: const Size(double.infinity, 48),
    // fixedSize: const Size(double.maxFinite, 50),
    textStyle: TextStyle(fontSize: 16, fontFamily: fontFamily),
    foregroundColor: Colors.black,
    shape: const RoundedRectangleBorder(
      borderRadius: BorderRadius.all(Radius.circular(defaultBorderRadious)),
    ),
  ),
);

// Outlined Button Theme Data ----------------------------------------------------------
OutlinedButtonThemeData outlinedButtonLightThemeData = OutlinedButtonThemeData(
  style: OutlinedButton.styleFrom(
    fixedSize: const Size(double.maxFinite, 48),
    textStyle: TextStyle(fontSize: 16, fontFamily: fontFamily),
    side: BorderSide(color: Colors.black),
    foregroundColor: Colors.black,
    shape: const RoundedRectangleBorder(
      borderRadius: BorderRadius.all(
        Radius.circular(defaultBorderRadious),
      ),
    ),
  ),
);
OutlinedButtonThemeData outlinedButtonDarkThemeData = OutlinedButtonThemeData(
  style: OutlinedButton.styleFrom(
    fixedSize: const Size(double.maxFinite, 48),
    textStyle: TextStyle(fontSize: 16, fontFamily: fontFamily),
    side: BorderSide(color: Colors.white),
    foregroundColor: Colors.white,
    shape: const RoundedRectangleBorder(
      borderRadius: BorderRadius.all(
        Radius.circular(defaultBorderRadious),
      ),
    ),
  ),
);

// Bottom Sheet Theme Data ----------------------------------------------------------
BottomSheetThemeData bottomSheetLightThemeData = BottomSheetThemeData(
  backgroundColor: lightBackgroundColor,
  modalBackgroundColor: lightBackgroundColor,
  modalBarrierColor: lightTertiaryColor.withOpacity(0.5),
  shape: const RoundedRectangleBorder(
    borderRadius:
        BorderRadius.vertical(top: Radius.circular(defaultBorderRadious * 2)),
  ),
);
BottomSheetThemeData bottomSheetDarkThemeData = BottomSheetThemeData(
  backgroundColor: darkBackgroundColor,
  modalBackgroundColor: darkBackgroundColor,
  modalBarrierColor: darkTertiaryColor.withOpacity(0.5),
  constraints: BoxConstraints(),
  shape: const RoundedRectangleBorder(
    borderRadius:
        BorderRadius.vertical(top: Radius.circular(defaultBorderRadious * 2)),
  ),
);

// Divider Theme Data ----------------------------------------------------------
DividerThemeData dividerLightThemeData = DividerThemeData(
  color: lightBorderColor,
);
DividerThemeData dividerDarkThemeData = DividerThemeData(
  color: darkBorderColor,
);
