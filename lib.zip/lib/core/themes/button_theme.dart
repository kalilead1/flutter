// import 'package:flutter/material.dart';

// import '../constants/strings.dart';
// import '../constants/colors.dart';

// ElevatedButtonThemeData elevatedButtonLightThemeData = ElevatedButtonThemeData(
//   style: ElevatedButton.styleFrom(
//     padding: const EdgeInsets.all(defaultPadding),
//     backgroundColor: lightPrimary,
//     foregroundColor: Colors.white,
//     minimumSize: const Size(double.infinity, 32),
//     shape: const RoundedRectangleBorder(
//       borderRadius: BorderRadius.all(Radius.circular(defaultBorderRadious)),
//     ),
//   ),
// );

// ElevatedButtonThemeData elevatedButtonDarkThemeData = ElevatedButtonThemeData(
//   style: ElevatedButton.styleFrom(
//     padding: const EdgeInsets.all(defaultPadding),
//     backgroundColor: darkPrimary,
//     foregroundColor: Colors.white,
//     minimumSize: const Size(double.infinity, 32),
//     textStyle: TextStyle(fontSize: 18),
//     shape: const RoundedRectangleBorder(
//       borderRadius: BorderRadius.all(Radius.circular(defaultBorderRadious)),
//     ),
//   ),
// );
// // OutlinedButtonThemeData outlinedButtonTheme(
// //     {Color borderColor = blackColor10}) {
// //   return OutlinedButtonThemeData(
// //     style: OutlinedButton.styleFrom(
// //       padding: const EdgeInsets.all(defaultPadding),
// //       minimumSize: const Size(double.infinity, 32),
// //       side: BorderSide(width: 1.5, color: borderColor),
// //       shape: const RoundedRectangleBorder(
// //         borderRadius: BorderRadius.all(Radius.circular(defaultBorderRadious)),
// //       ),
// //     ),
// //   );
// // }

// // final textButtonThemeData = TextButtonThemeData(
// //   style: TextButton.styleFrom(foregroundColor: primaryColor),
// // );
