import 'package:flutter/material.dart';

import '../constants/colors.dart';
import '../constants/strings.dart';

const InputDecorationTheme lightInputDecorationTheme = InputDecorationTheme(
  // fillColor: lightSecondaryColor,
  filled: true,
  // labelStyle: TextStyle(color: lightLabelTextColor),
  hintStyle: TextStyle(color: lightLabelTextColor),
  border: OutlineInputBorder(
    borderRadius: BorderRadius.all(Radius.circular(defaultBorderRadious)),
    borderSide: BorderSide(
      color: lightBorderColor,
    ),
  ),
  enabledBorder: OutlineInputBorder(
    borderRadius: BorderRadius.all(Radius.circular(defaultBorderRadious)),
    borderSide: BorderSide(
      color: lightBorderColor,
    ),
  ),
  focusedBorder: OutlineInputBorder(
    borderRadius: BorderRadius.all(Radius.circular(defaultBorderRadious)),
    borderSide: BorderSide(color: lightPrimaryColor),
  ),
  errorBorder: errorOutlineInputBorder,
);

const InputDecorationTheme darkInputDecorationTheme = InputDecorationTheme(
  fillColor: darkBackgroundColor,
  filled: true,
  hintStyle: TextStyle(color: darkLabelTextColor),
  border: OutlineInputBorder(
    borderRadius: BorderRadius.all(Radius.circular(defaultBorderRadious)),
    borderSide: BorderSide(
      color: darkBorderColor,
    ),
  ),
  enabledBorder: OutlineInputBorder(
    borderRadius: BorderRadius.all(Radius.circular(defaultBorderRadious)),
    borderSide: BorderSide(
      color: darkBorderColor,
    ),
  ),
  focusedBorder: OutlineInputBorder(
    borderRadius: BorderRadius.all(Radius.circular(defaultBorderRadious)),
    borderSide: BorderSide(color: darkPrimaryColor),
  ),
  errorBorder: errorOutlineInputBorder,
);

const OutlineInputBorder outlineInputBorder = OutlineInputBorder(
  borderRadius: BorderRadius.all(Radius.circular(defaultBorderRadious)),
  borderSide: BorderSide(
    color: lightBorderColor,
  ),
);

const OutlineInputBorder errorOutlineInputBorder = OutlineInputBorder(
  borderRadius: BorderRadius.all(Radius.circular(defaultBorderRadious)),
  borderSide: BorderSide(
    color: errorColor,
  ),
);

OutlineInputBorder secodaryOutlineInputBorder(BuildContext context) {
  return OutlineInputBorder(
    borderRadius: const BorderRadius.all(Radius.circular(defaultBorderRadious)),
    borderSide: BorderSide(
      color: Theme.of(context).textTheme.bodyLarge!.color!.withOpacity(0.15),
    ),
  );
}
