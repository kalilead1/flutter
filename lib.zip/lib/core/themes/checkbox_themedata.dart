// import 'package:flutter/material.dart';
// import 'package:testttt/constants.dart';

// // import '../constants.dart';

// CheckboxThemeData checkboxThemeData = CheckboxThemeData(
//   checkColor: MaterialStateProperty.all(Colors.white),
//   shape: const RoundedRectangleBorder(
//     borderRadius: BorderRadius.all(
//       Radius.circular(defaultBorderRadious / 2),
//     ),
//   ),
//   side: const BorderSide(color: whileColor40),
// );
