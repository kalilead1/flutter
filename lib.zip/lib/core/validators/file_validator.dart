class FileValidator {
  static const int maxSizeInMB = 8;

  static bool isFileTooLarge(int bytes) {
    final sizeInMB = bytes / (1024 * 1024);
    return sizeInMB > maxSizeInMB;
  }

  static bool isMaxReached(int current, int maxAllowed) {
    return current >= maxAllowed;
  }
}
