import 'package:booking_v1/core/errors/exception.dart';
import 'package:booking_v1/core/errors/failures.dart';
import 'package:booking_v1/core/network/network_info.dart';
import 'package:booking_v1/dependency_injection/initial.dart';
import 'package:dartz/dartz.dart';

final NetworkInfo networkInfo = getIt<NetworkInfo>();

class GetData<T> {
  // final T object;
  // final Function() getAll;
  // final NetworkInfo networkInfo;

  GetData(
      // required this.object,
      // required this.getAll,
      // this.networkInfo = ,
      );

  Future<Either<Failure, T>> call(T Function() d) async {
    if (await networkInfo.isConnected) {
      try {
        final remote = d();
        if (remote == null) {
          return Left(EmptyCacheFailure());
        } else {
          return Right(remote);
        }
      } on ServerException {
        return Left(ServerFailure());
      }
    } else {
      return Left(OfflineFailure());
    }
  }
}

// Future<Either<Failure, List<Object>>> call(List Function() d) async {
//   if (await networkInfo.isConnected) {
//     try {
//       final remote = d();
//       return Right(remote);
//     } on ServerException {
//       return Left(ServerFailure());
//     }
//   } else {
//     return Left(EmptyCacheFailure());
//   }
// }
