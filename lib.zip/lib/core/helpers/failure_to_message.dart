import 'package:booking_v1/core/constants/strings.dart';
import 'package:booking_v1/core/errors/failures.dart';

String failureToMessage(Failure failure) {
  switch (failure.runtimeType) {
    case const (OfflineFailure):
      return offlineFailureMessage;
    case const (EmptyCacheFailure):
      return emptyCacheFailureMessage;
    case const (ServerFailure):
      return serverFailureMessage;
    case const (AddedOperationFailure):
      return addedOperationFailureMessage;
    case const (UpdatedOperationFailure):
      return updatedOperationFailureMessage;
    case const (DeletedOperationFailure):
      return deletedOperationFailureMessage;
    case const (NoLoginFailure):
      return noLoginFailureMessage;
    default:
      return unknownFailureMessage;
  }
}
