import 'dart:async';

import 'app_event.dart';

class AppEventBus {
  AppEventBus._(); // private constructor
  static final AppEventBus instance = AppEventBus._();

  final StreamController<AppEvent> _controller =
      StreamController<AppEvent>.broadcast();

  // اطلاق اي حدث
  void fire(AppEvent event) {
    if (!_controller.isClosed) {
      _controller.add(event);
    }
  }

  // الاسنماع لنوع محدد من الحدث
  Stream<T> on<T extends AppEvent>() {
    return _controller.stream.where((event) => event is T).cast<T>();
  }

  // اغلاق EventBus (اختياري)
  Future<void> dispose() async {
    await _controller.close();
  }
}
