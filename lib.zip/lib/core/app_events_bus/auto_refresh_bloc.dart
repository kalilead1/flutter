import 'dart:async';
import 'package:flutter_bloc/flutter_bloc.dart';

import 'app_event.dart';
import 'app_event_bus.dart';

mixin AutoRefreshBloc<EventType extends Object, StateType>
    on Bloc<EventType, StateType> {
  EventType? _lastQuery; // تخزين اخر حدث
  late final StreamSubscription _sub; // الاستماع للحدث

  void setupAutoRefresh<T extends AppEvent>() {
    // الخطاء هنا
    _sub = AppEventBus.instance.on<T>().listen((event) {
      if (_lastQuery != null) {
        add(_lastQuery!);
      }
    });
  }

  void addAndRemember(EventType event) {
    _lastQuery = event;
    add(event);
  }

  @override
  Future<void> close() async {
    await _sub.cancel();
    return super.close();
  }
}
