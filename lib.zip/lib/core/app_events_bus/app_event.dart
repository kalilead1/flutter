abstract class AppEvent {}

class UserChangedEvent extends AppEvent {}

class ServiceChangedEvent extends AppEvent {}

class StoreChangedEvent extends AppEvent {}

class BookingChangedEvent extends AppEvent {}

class PaymentChangedEvent extends AppEvent {}

class NotificationChangedEvent extends AppEvent {}
