import 'package:equatable/equatable.dart';

abstract class Failure extends Equatable {
  @override
  List<Object?> get props => [];
}

// خطا لا يوجد اتصال بالانترنت
class OfflineFailure extends Failure {}

// خطا في السرفر
class ServerFailure extends Failure {}

// خطا لا يوجد بيانات
class EmptyCacheFailure extends Failure {}

// خطا: ادخال بيانات خاطئة
class WrongDataFailure extends Failure {}

// خطا: فشل اضافة العملية
class AddedOperationFailure extends Failure {}

// خطا: فشل تعديل العملية
class UpdatedOperationFailure extends Failure {}

// خطا: فشل حذف العملية
class DeletedOperationFailure extends Failure {}

// خطا: فشل العملية
class NoLoginFailure extends Failure {}

/////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////
class PermissionDeniedFailure extends Failure {}

class PlatformNotSupportedFailure extends Failure {}

class UnknownFailure extends Failure {
  final String message;
  UnknownFailure(this.message);

  @override
  List<Object?> get props => [message];
}
