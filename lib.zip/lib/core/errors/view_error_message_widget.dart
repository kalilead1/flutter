import 'package:flutter/material.dart';

import '../constants/colors.dart';
import '../constants/strings.dart';
import '../widgets/container_widgets.dart';

class ViewErrorMessageWidget extends StatelessWidget {
  final String errorMessage;
  const ViewErrorMessageWidget({super.key, required this.errorMessage});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(defaultPadding),
      child: SecondaryContainer(
        child: Column(
          spacing: defaultSpacing,
          children: [
            // if(errorMessage == offlineFailureMessage) return
            //   Icon(Icons.network_check , size: 40, color: errorColor,);,
            //  else if (errorMessage == serverFailureMessage) {

            // }
            errorMessage == offlineFailureMessage
                ? Icon(
                    Icons.network_check,
                    size: 40,
                    color: errorColor,
                  )
                : errorMessage == serverFailureMessage
                    ? Icon(
                        Icons.storage_rounded,
                        size: 40,
                        color: errorColor,
                      )
                    : errorMessage == emptyCacheFailureMessage
                        ? Icon(
                            Icons.hourglass_empty,
                            size: 40,
                            color: warningColor,
                          )
                        : Icon(
                            Icons.close_sharp,
                            size: 40,
                            color: errorColor,
                          ),

            Center(
              child: Text(errorMessage),
            ),
          ],
        ),
      ),
    );
  }
}
