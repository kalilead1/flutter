import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';

class AppLogoPrimary extends StatelessWidget {
  final double height;
  const AppLogoPrimary({super.key, this.height = 120});

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Stack(
          children: [
            SvgPicture.asset(
              "assets/logos/logoP2.svg",
              colorFilter: ColorFilter.mode(
                Theme.of(context).colorScheme.tertiary,
                BlendMode.srcIn,
              ),
              height: height,
              // width: 100,
            ),
            SvgPicture.asset(
              "assets/logos/logoP1.svg",
              colorFilter: ColorFilter.mode(
                Theme.of(context).colorScheme.primary,
                BlendMode.srcIn,
              ),
              height: height,
              // width: 100,
            ),
          ],
        ),
        // Text(
        //   "Yemen Booking",
        //   style: Theme.of(context).textTheme.displayLarge,
        // ),
        // Text(
        //   "في تطبيق يمن حجز",
        //   style: Theme.of(context).textTheme.displayLarge,
        // ),
      ],
    );
  }
}

class AppLogoSecondary extends StatelessWidget {
  final Color? color;
  final double height;
  const AppLogoSecondary({super.key, this.color, this.height = 70});

  @override
  Widget build(BuildContext context) {
    return SvgPicture.asset(
      "assets/logos/logo4.svg",
      colorFilter: ColorFilter.mode(
        color ?? Theme.of(context).colorScheme.tertiary.withValues(alpha: 0.7),
        BlendMode.srcIn,
      ),
      height: height,
    );
  }
}
