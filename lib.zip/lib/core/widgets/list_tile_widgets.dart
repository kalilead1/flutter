// import 'package:flutter/material.dart';
// import 'package:testttt/core/constants/strings.dart';

import 'package:flutter/material.dart';

class PrimaryListTile extends StatelessWidget {
  final Widget? leading;
  final Widget? trailing;
  final String primaryTitle;
  final String? secondaryTitle;

  const PrimaryListTile({
    required this.primaryTitle,
    this.trailing,
    this.leading,
    this.secondaryTitle,
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      // padding: EdgeInsets.all(defaultPadding - 5),
      decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(14),
          color: Theme.of(context).colorScheme.primaryContainer,
          border: Border.all(
              color: Theme.of(context).colorScheme.onPrimaryContainer)
          // color: Theme.of(context).colorScheme.secondary,
          ),
      child: secondaryTitle != null
          ? ListTile(
              leading: leading,
              title: Text(
                primaryTitle,
                style: Theme.of(context).textTheme.titleMedium,
              ),
              subtitle: Text(secondaryTitle!,
                  style: Theme.of(context).textTheme.labelLarge),
              trailing: trailing,
            )
          : ListTile(
              leading: leading,
              title: Text(
                primaryTitle,
                style: Theme.of(context).textTheme.titleMedium,
              ),
              trailing: trailing,
            ),
    );
  }
}

class SecondaryListTile extends StatelessWidget {
  final Widget? leading;
  final Widget? trailing;
  final String primaryTitle;
  final String? secondaryTitle;
  final String? tertiaryTitle;

  const SecondaryListTile({
    required this.primaryTitle,
    this.trailing,
    this.leading,
    this.secondaryTitle,
    this.tertiaryTitle,
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      // padding: EdgeInsets.all(defaultPadding - 5),
      decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(14),
          color: Theme.of(context).colorScheme.primaryContainer,
          border: Border.all(
              color: Theme.of(context).colorScheme.onPrimaryContainer)
          // color: Theme.of(context).colorScheme.secondary,
          ),
      child: secondaryTitle != null && tertiaryTitle != null
          ? ListTile(
              leading: leading,
              title: Text(
                primaryTitle,
                style: Theme.of(context).textTheme.titleMedium,
              ),
              subtitle: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(secondaryTitle!,
                      style: Theme.of(context).textTheme.titleSmall),
                  Text(tertiaryTitle!,
                      style: Theme.of(context).textTheme.bodySmall),
                ],
              ),
              trailing: trailing,
              isThreeLine: true,
            )
          : secondaryTitle != null && tertiaryTitle == null
              ? ListTile(
                  leading: leading,
                  title: Text(
                    primaryTitle,
                    style: Theme.of(context).textTheme.titleMedium,
                  ),
                  subtitle: Text(secondaryTitle!,
                      style: Theme.of(context).textTheme.bodyMedium),
                  trailing: trailing,
                  isThreeLine: true,
                )
              : secondaryTitle == null && tertiaryTitle == null
                  ? ListTile(
                      leading: leading,
                      title: Text(
                        primaryTitle,
                        style: Theme.of(context).textTheme.titleMedium,
                      ),
                      trailing: trailing,
                    )
                  : SizedBox(),
    );
  }
}
