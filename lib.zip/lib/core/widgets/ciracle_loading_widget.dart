import 'package:flutter/material.dart';

import 'app_logo.dart';

class CiracleLoadingWidget extends StatefulWidget {
  final String size;
  const CiracleLoadingWidget({super.key, this.size = "l"});

  @override
  State<CiracleLoadingWidget> createState() => _CiracleLoadingWidgetState();
}

class _CiracleLoadingWidgetState extends State<CiracleLoadingWidget>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<Color?> _colorAnim;

  @override
  void initState() {
    super.initState();

    _controller = AnimationController(
      animationBehavior: AnimationBehavior.normal,
      // lowerBound: 0.5,
      vsync: this,
      duration: const Duration(milliseconds: 1100),
    )..repeat(reverse: true);

    _colorAnim = ColorTween(
      end: Colors.white,
      begin: const Color.fromARGB(255, 141, 141, 141),
      // begin: darkPrimaryColor,
    ).animate(_controller);
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      // color: Colors.black.withOpacity(0.3),
      child: Center(
        child: AnimatedBuilder(
          animation: _colorAnim,
          builder: (_, __) {
            return Stack(
              children: [
                AppLogoSecondary(
                  color: _colorAnim.value,
                  height: widget.size == 'm'
                      ? 60
                      : widget.size == 's'
                          ? 40
                          : 70,
                ),
                Positioned(
                  top: widget.size == 'm'
                      ? 12
                      : widget.size == 's'
                          ? 8
                          : 16,
                  right: widget.size == 'm'
                      ? 8
                      : widget.size == 's'
                          ? 6
                          : 10,
                  child: CircularProgressIndicator(
                    // backgroundColor:
                    //     Theme.of(context).brightness == Brightness.light
                    //         ? Colors.white
                    //         : Colors.white,
                    strokeAlign: widget.size == 'm'
                        ? 12
                        : widget.size == 's'
                            ? 20
                            : 16,
                  ),
                ),
                // SvgPicture.asset(
                //   "assets/logos/logo4.svg",
                //   colorFilter: ColorFilter.mode(
                //     _colorAnim.value!,
                //     BlendMode.srcIn,
                //   ),
                //   height: 70,
                // ),
              ],
            );
            // return Column(
            //   spacing: defaultSpacing,
            //   mainAxisAlignment: MainAxisAlignment.center,
            //   children: [
            //     SvgPicture.asset(
            //       "assets/logos/logo4.svg",
            //       colorFilter: ColorFilter.mode(
            //         _colorAnim.value!,
            //         BlendMode.srcIn,
            //       ),
            //       height: 100,
            //     ),
            //     CircularProgressIndicator(
            //       backgroundColor: Colors.white,
            //       // strokeAlign: 17,
            //     ),
            //   ],
            // );
          },
        ),
      ),
    );
  }
}
