import 'package:flutter/material.dart';

import '../constants/strings.dart';

class PrimaryTitle extends StatelessWidget {
  final String title;
  final Function()? onTap;
  const PrimaryTitle({required this.title, this.onTap, super.key});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: defaultPadding),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            title,
            style: Theme.of(context).textTheme.titleLarge,
          ),
          if (onTap != null)
            InkWell(
              onTap: () {
                onTap;
              },
              child: Text(
                "المزيد",
                style: Theme.of(context).textTheme.labelSmall,
              ),
            ),
        ],
      ),
    );
  }
}

class ExpandableText extends StatefulWidget {
  const ExpandableText({super.key, required this.text, this.trimLength = 80});

  final String text;
  final int trimLength;

  @override
  State<ExpandableText> createState() => _ExpandableTextState();
}

class _ExpandableTextState extends State<ExpandableText> {
  bool isExpanded = false;
  @override
  Widget build(BuildContext context) {
    final bool shoudTrim = widget.text.length > widget.trimLength;
    String displayText = (!isExpanded && shoudTrim)
        ? widget.text.substring(0, widget.trimLength) + "..."
        : widget.text;
    return GestureDetector(
      onTap: () {
        setState(() {
          isExpanded = !isExpanded;
        });
      },
      child: AnimatedSize(
        duration: Duration(milliseconds: 300),
        curve: Curves.easeInOut,
        child: Text(
          displayText,
          style: Theme.of(context).textTheme.bodyLarge,
        ),
      ),
    );
  }
}
