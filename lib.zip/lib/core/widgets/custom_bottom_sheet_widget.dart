import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../../core/constants/strings.dart';

class CustomBottomSheetWidget extends StatelessWidget {
  final String appTitle;
  final Widget body;
  final void Function()? onPressedReplay;
  const CustomBottomSheetWidget({
    super.key,
    required this.appTitle,
    required this.body,
    this.onPressedReplay,
  });

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Padding(
        padding: const EdgeInsets.all(defaultPadding),
        child: Scaffold(
          appBar: PreferredSize(
            preferredSize: Size.fromHeight(90),
            child: AppBar(
              leading: IconButton(
                onPressed: () {
                  context.pop();
                },
                icon: Icon(Icons.close),
              ),
              // foregroundColor: Theme.of(context).colorScheme.primary,
              title: Text(appTitle),
              centerTitle: true,
              actions: [
                IconButton(
                  onPressed: onPressedReplay,
                  icon: Icon(Icons.replay),
                  // icon: Icon(Icons.replay_circle_filled),
                ),
              ],
            ),
          ),
          body: body,
        ),
      ),
    );
  }
}
