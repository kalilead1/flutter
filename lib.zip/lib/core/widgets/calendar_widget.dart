import 'package:flutter/material.dart';
import 'package:table_calendar/table_calendar.dart';

class BookingCalendar extends StatefulWidget {
  final List<DateTime>? bookedDates;
  final bool selectable; // true = يمكن الاختيار، false = عرض فقط
  final Function(DateTime)? onDaySelected;

  const BookingCalendar({
    super.key,
    this.bookedDates,
    this.selectable = false,
    this.onDaySelected,
  });

  @override
  State<BookingCalendar> createState() => _BookingCalendarState();
}

class _BookingCalendarState extends State<BookingCalendar> {
  DateTime? selectedDay;
  final DateTime today = DateTime.now();

  bool isSameDate(DateTime a, DateTime b) =>
      a.year == b.year && a.month == b.month && a.day == b.day;

  bool isBooked(DateTime day) {
    if (widget.bookedDates == null) return false;
    return widget.bookedDates!.any((d) => isSameDate(d, day));
  }

  bool isBeforeToday(DateTime day) {
    final t = DateTime(today.year, today.month, today.day);
    final d = DateTime(day.year, day.month, day.day);
    return d.isBefore(t);
  }

  bool isSelectable(DateTime day) {
    return widget.selectable && !isBooked(day) && !isBeforeToday(day);
  }

  @override
  Widget build(BuildContext context) {
    return TableCalendar(
      focusedDay: today,
      firstDay: DateTime(today.year, today.month),
      lastDay: DateTime(today.year + 1, today.month),
      enabledDayPredicate: (_) => true, // جميع الأيام مفعلة للعرض

      selectedDayPredicate: (day) =>
          selectedDay != null && isSameDate(selectedDay!, day),

      onDaySelected: (selected, focused) {
        if (!isSelectable(selected)) return;
        setState(() => selectedDay = selected);
        if (widget.onDaySelected != null) widget.onDaySelected!(selected);
      },

      calendarBuilders: CalendarBuilders(
        defaultBuilder: (context, day, _) {
          // اليوم الحالي
          if (isSameDate(day, today)) {
            if (isBooked(day)) {
              // اليوم محجوز = دائرة زرقاء ممتلئة
              return _dayCircle(
                  day: day,
                  filled: true,
                  color: Theme.of(context).colorScheme.primary,
                  textColor: Colors.white);
            } else {
              // اليوم متاح = دائرة فارغة بحد أزرق
              return _dayCircle(
                  day: day,
                  filled: false,
                  color: Colors.transparent,
                  borderColor: Theme.of(context).colorScheme.primary,
                  textColor: Theme.of(context).textTheme.titleLarge!.color!);
            }
          }

          // الأيام المحجوزة السابقة أو القادمة (غير اليوم)
          if (isBooked(day)) {
            return _dayCircle(
                day: day,
                filled: true,
                color: Theme.of(context).colorScheme.primary,
                textColor: Colors.white);
          }

          // الأيام السابقة
          if (isBeforeToday(day)) {
            return _dayCircle(
                day: day,
                filled: false,
                color: Colors.transparent,
                borderColor: Colors.transparent,
                textColor: Colors.grey);
          }

          // الأيام المتاحة بعد اليوم الحالي
          return _dayCircle(
              day: day,
              filled: false,
              color: Colors.transparent,
              borderColor: Colors.transparent,
              textColor: Theme.of(context).textTheme.titleLarge!.color!);
        },
        selectedBuilder: (context, day, _) {
          if (isBooked(day)) {
            // الأيام المحجوزة تظهر دائمًا باللون الأزرق
            return _dayCircle(
                day: day,
                filled: true,
                color: Theme.of(context).colorScheme.primary,
                textColor: Theme.of(context).textTheme.titleLarge!.color!);
          }

          // اليوم المختار
          return _dayCircle(
              day: day,
              filled: true,
              color: Colors.green,
              textColor: Theme.of(context).textTheme.titleLarge!.color!);
        },
      ),
    );
  }

  Widget _dayCircle({
    required DateTime day,
    required bool filled,
    required Color color,
    Color? borderColor,
    Color textColor = Colors.black,
  }) {
    return Container(
      margin: const EdgeInsets.all(6),
      alignment: Alignment.center,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: filled ? color : Colors.transparent,
        border: Border.all(color: borderColor ?? Colors.transparent, width: 2),
      ),
      child: Text('${day.day}', style: TextStyle(color: textColor)),
    );
  }
}

// bool isSameDate(DateTime a, DateTime b) {
//   return a.year == b.year && a.month == b.month && a.day == b.day;
// }

// bool isBeforeToday(DateTime day) {
//   final today = DateTime.now();
//   return DateTime(day.year, day.month, day.day)
//       .isBefore(DateTime(today.year, today.month, today.day));
// }

// bool isBooked(DateTime day, List<DateTime> bookedDates) {
//   return bookedDates.any((d) => isSameDate(d, day));
// }

// ////////////////////////////////////////////////////////////////////////////
// ////////////////////////////////////////////////////////////////////////////
// class BookingCalendarViewOnly extends StatelessWidget {
//   BookingCalendarViewOnly({super.key});

//   final DateTime today = DateTime.now();

  // final List<DateTime> bookedDates = [
  //   DateTime(2026, 1, 17),
  //   DateTime(2026, 1, 19),
  //   DateTime(2026, 2, 17),
  //   DateTime(2026, 1, 20),
  //   DateTime(2026, 1, 22),
  // ];

//   @override
//   Widget build(BuildContext context) {
//     return TableCalendar(
//       focusedDay: today,
//       firstDay: DateTime(today.year, today.month),
//       lastDay: DateTime(today.year + 2, today.month),

//       // ❌ منع الاختيار كليًا
//       enabledDayPredicate: (_) => true,

//       calendarBuilders: CalendarBuilders(
//         defaultBuilder: (context, day, _) {
//           if (isBooked(day, bookedDates)) {
//             return _dayBox(day, Theme.of(context).colorScheme.primary, Theme.of(context).textTheme.titleLarge!.color!);
//           }

//           if (isBeforeToday(day)) {
//             return _dayBox(
//               day,
//               Colors.transparent,
//               Colors.grey,
//             );
//           }

//           return _dayBox(
//             day,
//             Colors.transparent,
//             Colors.white,
//           );
//         },
//       ),
//     );
//   }
// }

// ////////////////////////////////////////////////////////////////////////////
// ////////////////////////////////////////////////////////////////////////////

// class BookingCalendarSelectable extends StatefulWidget {
//   const BookingCalendarSelectable({super.key});

//   @override
//   State<BookingCalendarSelectable> createState() =>
//       _BookingCalendarSelectableState();
// }

// class _BookingCalendarSelectableState extends State<BookingCalendarSelectable> {
//   DateTime? selectedDay;
//   final DateTime today = DateTime.now();

//   final List<DateTime> bookedDates = [
//     DateTime(2026, 1, 17),
//     DateTime(2026, 1, 20),
//     DateTime(2026, 1, 22),
//   ];

//   @override
//   Widget build(BuildContext context) {
//     return TableCalendar(
//       focusedDay: bookedDates.first,
//       firstDay: DateTime(today.year, today.month),
//       lastDay: DateTime(today.year + 2, today.month),

//       // ✅ السماح فقط بالأيام المتاحة
//       enabledDayPredicate: (day) {
//         return !isBooked(day, bookedDates) && !isBeforeToday(day);
//       },

//       selectedDayPredicate: (day) {
//         return selectedDay != null && isSameDate(selectedDay!, day);
//       },

//       onDaySelected: (selected, focused) {
//         setState(() {
//           selectedDay = selected;
//         });
//       },

//       calendarBuilders: CalendarBuilders(
//         defaultBuilder: (context, day, _) {
//           if (isBooked(day, bookedDates)) {
//             return _dayBox(day, Colors.orange, Colors.blue);
//           }

//           // if (isBeforeToday(day)) {
//           //   return _dayBox(
//           //     day,
//           //     Colors.yellow,
//           //     Colors.red.withOpacity(0.3),
//           //   );
//           // }

//           return _dayBox(day, Colors.transparent, Colors.white);
//         },
//         selectedBuilder: (context, day, _) {
//           return _dayBox(day, Colors.green, Colors.white);
//         },
//       ),
//     );
//   }
// }

// ////////////////////////////////////////////////////////////////////////////
// ////////////////////////////////////////////////////////////////////////////

// Widget _dayBox(DateTime day, Color bgColor, Color textColor) {
//   return Container(
//     margin: const EdgeInsets.all(6),
//     alignment: Alignment.center,
//     decoration: BoxDecoration(
//       color: bgColor,
//       borderRadius: BorderRadius.circular(8),
//       // border: Border.all(color: Colors.grey.shade300),
//     ),
//     child: Text(
//       '${day.day}',
//       style: TextStyle(color: textColor),
//     ),
//   );
// }
