import 'package:flutter/material.dart';

class ViewImageCiracleWidget extends StatelessWidget {
  final String? imageURL;
  final double size;
  const ViewImageCiracleWidget(
      {super.key, required this.imageURL, this.size = 40});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
          shape: BoxShape.circle,
          border: Border.all(
            color: Theme.of(context).colorScheme.tertiary,
          )),
      child: ClipOval(
        child: imageURL != null
            ? Image.network(imageURL!, fit: BoxFit.cover)
            : Image.asset("assets/logos/logo4.svg", fit: BoxFit.cover),
      ),
    );
  }
}
