import 'package:flutter/material.dart';
import 'package:share_plus/share_plus.dart';

import '../constants/strings.dart';

class ShareLink {
  ShareLink._();

  static void shareStore(int storeId) {
    String share = 'stores/$storeId';
    Share.share(
      '$subjectShared$baseUrlApp$share$appNameShared',
    );
  }

  static void shareService(int serviceId) {
    String share = 'services/$serviceId';
    Share.share(
      '$subjectShared$baseUrlApp$share$appNameShared',
    );
  }

  static void shareBooking(int bookingId) {
    String share = 'bookings/$bookingId';
    Share.share(
      '$subjectShared$baseUrlApp$share$appNameShared',
    );
  }

  static void shareApp() {
    String share = 'yemen_booking';
    Share.share(
      '$subjectShared$baseUrlApp$share$appNameShared',
    );
  }
}

class ShareStoreIconWidget extends StatelessWidget {
  final int storeId;
  const ShareStoreIconWidget({super.key, required this.storeId});

  @override
  Widget build(BuildContext context) {
    return IconButton(
      onPressed: () {
        ShareLink.shareStore(storeId);
      },
      icon: Icon(Icons.share),
    );
  }
}

class ShareServiceIconWidget extends StatelessWidget {
  final int serviceId;
  const ShareServiceIconWidget({super.key, required this.serviceId});

  @override
  Widget build(BuildContext context) {
    return IconButton(
      onPressed: () {
        ShareLink.shareService(serviceId);
      },
      icon: Icon(Icons.share),
    );
  }
}

class ShareBookingIconWidget extends StatelessWidget {
  final int bookingId;
  const ShareBookingIconWidget({super.key, required this.bookingId});

  @override
  Widget build(BuildContext context) {
    return IconButton(
      onPressed: () {
        ShareLink.shareBooking(bookingId);
      },
      icon: Icon(Icons.share),
    );
  }
}

class ShareAppIconWidget extends StatelessWidget {
  const ShareAppIconWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return IconButton(
      onPressed: () {
        ShareLink.shareApp();
      },
      icon: Icon(Icons.share),
    );
  }
}
