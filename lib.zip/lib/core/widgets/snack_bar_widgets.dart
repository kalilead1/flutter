import 'package:flutter/material.dart';

import '../constants/colors.dart';
import '../constants/strings.dart';

// SnackBar errorSnackBar({required String erorr}) {
//   return SnackBar(
//     backgroundColor: Colors.transparent,
//     elevation: 0,
//     content: Container(
//       decoration: BoxDecoration(
//         color: errorColor,
//         borderRadius: BorderRadius.circular(defaultBorderRadious),
//       ),
//       child: ListTile(
//         leading: Icon(
//           Icons.error,
//           color: Colors.white,
//         ),
//         title: Text(
//           erorr,
//           style: TextStyle(fontSize: 16, color: Colors.white),
//         ),
//       ),
//     ),
//   );
// }

// SnackBar successSnackBar({required String success}) {
//   return SnackBar(
//     backgroundColor: Colors.transparent,
//     elevation: 0,
//     content: Container(
//       decoration: BoxDecoration(
//         color: successColor,
//         borderRadius: BorderRadius.circular(defaultBorderRadious),
//       ),
//       child: ListTile(
//         leading: Icon(
//           Icons.check_circle,
//           color: Colors.white,
//         ),
//         title: Text(
//           success,
//           style: TextStyle(fontSize: 16, color: Colors.white),
//         ),
//       ),
//     ),
//   );
// }

void showSnackBarError({required BuildContext context, required String error}) {
  ScaffoldMessenger.of(context).showSnackBar(
    SnackBar(
      // width: MediaQuery.of(context).size.width,
      backgroundColor: Colors.transparent,
      elevation: 0,
      content: Container(
        decoration: BoxDecoration(
          color: errorColor,
          borderRadius: BorderRadius.circular(defaultBorderRadious),
        ),
        child: ListTile(
          dense: true,
          leading: Icon(
            Icons.error,
            color: Colors.white,
          ),
          title: Text(
            error,
            style: TextStyle(fontSize: 12, color: Colors.white),
          ),
        ),
      ),
    ),
  );
}

void showSnackBarSuccess(
    {required BuildContext context, required String success}) {
  ScaffoldMessenger.of(context).showSnackBar(
    SnackBar(
      // width: MediaQuery.of(context).size.width,
      backgroundColor: Colors.transparent,
      elevation: 0,
      content: Container(
        decoration: BoxDecoration(
          color: successColor,
          borderRadius: BorderRadius.circular(defaultBorderRadious),
        ),
        child: ListTile(
          dense: true,
          leading: Icon(
            Icons.check_circle,
            color: Colors.white,
          ),
          title: Text(
            success,
            style: TextStyle(fontSize: 12, color: Colors.white),
          ),
        ),
      ),
    ),
  );
}

void showSnackBarWarning(
    {required BuildContext context, required String warning}) {
  ScaffoldMessenger.of(context).showSnackBar(
    SnackBar(
      backgroundColor: Colors.transparent,
      elevation: 0,
      content: Container(
        decoration: BoxDecoration(
          color: warningColor,
          borderRadius: BorderRadius.circular(defaultBorderRadious),
        ),
        child: ListTile(
          dense: true,
          leading: Icon(
            Icons.warning_rounded,
            color: Colors.white,
          ),
          title: Text(
            warning,
            style: TextStyle(fontSize: 14, color: Colors.white),
          ),
        ),
      ),
    ),
  );
}
