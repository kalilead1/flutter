import 'dart:io';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

import '../../constants/strings.dart';
import '../snack_bar_widgets.dart';

// const int defaultMaxFileSizeMB = 8;
// const int defaultMaxItems = 10;

bool isImageFilePath(String path) {
  final p = path.toLowerCase();
  return p.endsWith('.jpg') ||
      p.endsWith('.jpeg') ||
      p.endsWith('.png') ||
      p.endsWith('.gif') ||
      p.endsWith('.webp');
}

Future<File?> pickImageFromCamera(BuildContext ctx) async {
  final picker = ImagePicker();
  final picked = await picker.pickImage(source: ImageSource.camera);
  if (picked == null) return null;
  return File(picked.path);
}

Future<List<File>> pickImagesFromGallery(BuildContext ctx,
    {bool allowMultiple = true}) async {
  final result = await FilePicker.platform.pickFiles(
    type: FileType.image,
    allowMultiple: allowMultiple,
  );
  if (result == null) return [];
  return result.files
      .where((f) => f.path != null)
      .map((f) => File(f.path!))
      .toList();
}

Future<List<File>> pickAnyFiles(BuildContext ctx,
    {bool allowMultiple = true}) async {
  final result = await FilePicker.platform.pickFiles(
    type: FileType.any,
    allowMultiple: allowMultiple,
  );
  if (result == null) return [];
  return result.files
      .where((f) => f.path != null)
      .map((f) => File(f.path!))
      .toList();
}

bool validateFileSize(BuildContext context, File file, int maxMB) {
  final size = file.lengthSync();
  if (size > maxMB * 1024 * 1024) {
    showSnackBarError(
        context: context, error: "$validateFileSizeErrorText $maxMB MB");
    return false;
  }
  return true;
}

/////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////

void addFileToList({
  required BuildContext context,
  required List<File> uploadedFiles,
  required List<File> storgeFile,
  required int maxFileSizeMB,
  required int maxImages,
  Function(List<File>)? onChanged,
}) {
  if (uploadedFiles.isEmpty) return;
  final valid = <File>[];
  for (final f in uploadedFiles) {
    if (validateFileSize(context, f, maxFileSizeMB)) valid.add(f);
  }
  if (valid.isEmpty) return;

  final left = maxImages - storgeFile.length;
  if (left <= 0) {
    showSnackBarWarning(
      context: context,
      warning: "$maximumPhotosErrorText ($maxImages)",
    );
    return;
  }
  storgeFile.addAll(valid.take(left));

  onChanged?.call(List.unmodifiable(storgeFile));
}

void removeFileFromList({
  required int idx,
  required List<File> storageImages,
  Function(List<File>)? onChanged,
}) {
  storageImages.removeAt(idx);
  onChanged?.call(List.unmodifiable(storageImages));
}

/////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////
