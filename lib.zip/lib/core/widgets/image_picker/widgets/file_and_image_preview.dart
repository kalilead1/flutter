import 'dart:io';
import 'package:booking_v1/core/constants/colors.dart';
import 'package:booking_v1/core/constants/strings.dart';
import 'package:booking_v1/core/widgets/container_widgets.dart';
import 'package:flutter/material.dart';

class ImagePreview extends StatefulWidget {
  const ImagePreview({
    super.key,
    // required this.images,
    required this.image,
    required this.onRemove,

    // this.onChanged,
  });
  // final List<File> images;
  final File image;
  final Function() onRemove;
  // final Function(List<File>)? onChanged;

  @override
  State<ImagePreview> createState() => _ImagePreviewState();
}

class _ImagePreviewState extends State<ImagePreview> {
  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(8),
            border: Border.all(
                color: Theme.of(context).colorScheme.onPrimaryContainer),
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(8),
            child: Image.file(widget.image,
                fit: BoxFit.cover,
                width: double.infinity,
                height: double.infinity),
          ),
        ),
        Positioned(
          top: 4,
          right: 4,
          child: InkWell(
            onTap: widget.onRemove,
            child: Container(
              decoration:
                  BoxDecoration(color: Colors.black45, shape: BoxShape.circle),
              child: const Icon(Icons.close, color: Colors.white, size: 20),
            ),
          ),
        ),
      ],
    );
  }
}

class FilePreview extends StatefulWidget {
  const FilePreview({
    super.key,
    required this.file,
    required this.onRemove,

    // this.onChanged,
  });
  final File file;
  final Function() onRemove;
  // final Function(List<File>)? onChanged;

  @override
  State<FilePreview> createState() => _FilePreviewState();
}

class _FilePreviewState extends State<FilePreview> {
  @override
  Widget build(BuildContext context) {
    return PrimaryContainer(
      paddingVertical: defaultPadding / 2,
      child: Row(
        children: [
          const Icon(Icons.insert_drive_file),
          const SizedBox(width: 12),
          Expanded(
              child: Text(widget.file.path.split('/').last,
                  overflow: TextOverflow.ellipsis)),
          IconButton(
            onPressed: widget.onRemove,
            icon: const Icon(Icons.delete, color: errorColor),
          )
        ],
      ),
    );
  }
}
