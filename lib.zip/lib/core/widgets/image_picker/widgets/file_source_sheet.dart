import 'dart:io';

import 'package:booking_v1/core/widgets/container_widgets.dart';
import 'package:booking_v1/core/widgets/image_picker/utils.dart';
import 'package:booking_v1/core/widgets/snack_bar_widgets.dart';
import 'package:booking_v1/dependency_injection/initial.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:go_router/go_router.dart';

import '../../../../featuers/main/persentation/blocs/app_permissions/app_permission_bloc.dart';

class ImagesPickerBottomSheet extends StatelessWidget {
  final bool allowFiles;
  final bool allowMultipleImages;
  final Function(File) onCamera;
  final Function(List<File>) onGallery;
  final Function(List<File>)? onFiles;

  const ImagesPickerBottomSheet({
    super.key,
    required this.allowFiles,
    this.allowMultipleImages = true,
    required this.onCamera,
    required this.onGallery,
    this.onFiles,
  });

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (context) =>
          getIt<PermissionBloc>()..add(RequestPermissionsEvent()),
      child: BlocConsumer<PermissionBloc, PermissionState>(
        listener: (context, state) {
          if (state is PermissionGranted) {
            // انتقل إلى شاشة اختيار الصور أو فتح الكاميرا
          } else if (state is PermissionDenied) {
            showSnackBarError(context: context, error: 'تم رفض الإذن');
          } else if (state is PermissionError) {
            showSnackBarError(context: context, error: 'خطأ: ${state.message}');
          }
        },
        builder: (context, state) {
          return SizedBox(
            height: 160,
            child: Padding(
              padding: EdgeInsets.symmetric(horizontal: 20, vertical: 30),
              child: Row(
                spacing: 10,
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  Expanded(
                    child: GestureDetector(
                      onTap: allowFiles
                          ? () async {
                              // Navigator.pushNamed(context, homeScreenRoute);
                              context.pop();
                              final files = await pickAnyFiles(context,
                                  allowMultiple: allowMultipleImages);
                              onFiles!(files);
                            }
                          : null,
                      child: ItemPicker(
                        icons: Icons.insert_drive_file,
                        label: "الملفات",
                        isActive: allowFiles ? true : false,
                      ),
                    ),
                  ),
                  Expanded(
                    child: GestureDetector(
                      onTap: () async {
                        context.pop();
                        final files = await pickImagesFromGallery(context,
                            allowMultiple: allowMultipleImages);
                        onGallery(files);
                      },
                      child: ItemPicker(
                          icons: Icons.photo_library_rounded, label: "المعرض"),
                    ),
                  ),
                  Expanded(
                    child: GestureDetector(
                      onTap: () async {
                        context
                            .read<PermissionBloc>()
                            .add(RequestPermissionsEvent());
                        context.pop();
                        final f = await pickImageFromCamera(context);
                        if (f == null) return;
                        onCamera(f);
                      },
                      child: ItemPicker(
                          icons: Icons.camera_alt_rounded, label: "كاميرا"),
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}

class ItemPicker extends StatelessWidget {
  final IconData icons;
  final String label;
  final bool isActive;
  const ItemPicker({
    super.key,
    required this.icons,
    required this.label,
    this.isActive = true,
  });

  @override
  Widget build(BuildContext context) {
    return PrimaryContainer(
      paddingVertical: 0,
      paddingHorizontal: 0,
      child: Padding(
        padding: const EdgeInsets.all(15),
        child: Column(
          spacing: 5,
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            Icon(icons, size: 30, color: isActive ? null : Colors.grey),
            Text(
              label,
              style:
                  TextStyle(color: isActive ? null : Colors.grey, fontSize: 16),
            ),
          ],
        ),
      ),
    );
  }
}
