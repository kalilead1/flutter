import 'dart:io';

import 'package:booking_v1/core/constants/strings.dart';
import 'package:booking_v1/core/widgets/botton_widghts.dart';
import 'package:booking_v1/core/widgets/image_picker/utils.dart';
import 'package:booking_v1/core/widgets/image_picker/widgets/file_and_image_preview.dart';
import 'package:booking_v1/core/widgets/image_picker/widgets/file_source_sheet.dart';
import 'package:flutter/material.dart';

class ImageUploaderWidghet extends StatefulWidget {
  final int maxImages;
  final bool allowMultipleImages;
  final int maxFileSizeMB;
  final ValueChanged<List<File>>? onChanged;
  final String addButtonLabel;

  const ImageUploaderWidghet({
    super.key,
    this.maxImages = 10,
    this.allowMultipleImages = true,
    this.maxFileSizeMB = 8,
    this.onChanged,
    this.addButtonLabel = "إضافة صور",
  });

  @override
  State<ImageUploaderWidghet> createState() => _ImageUploaderWidghetState();
}

class _ImageUploaderWidghetState extends State<ImageUploaderWidghet> {
  final List<File> _images = [];
  void _openPickerSheet() {
    showModalBottomSheet(
      context: context,
      builder: (_) => SafeArea(
        child: ImagesPickerBottomSheet(
          allowMultipleImages: widget.allowMultipleImages,
          allowFiles: false,
          onCamera: (p0) {
            setState(() {
              addFileToList(
                context: context,
                uploadedFiles: [p0],
                storgeFile: _images,
                maxFileSizeMB: widget.maxFileSizeMB,
                maxImages: widget.maxImages,
                onChanged: widget.onChanged,
              );
            });
          },
          onGallery: (p0) {
            setState(() {
              addFileToList(
                context: context,
                uploadedFiles: p0,
                storgeFile: _images,
                maxFileSizeMB: widget.maxFileSizeMB,
                maxImages: widget.maxImages,
                onChanged: widget.onChanged,
              );
            });
          },
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      spacing: 10,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          spacing: defaultSpacing,
          children: [
            Expanded(
              child: SecondaryElevatedButton(
                  onPressed: _openPickerSheet, text: widget.addButtonLabel),
            ),
            if (_images.isNotEmpty) ...[
              Container(
                constraints: BoxConstraints(
                  minWidth: 50,
                  maxWidth: 90,
                ),
                child: CancelElevatedButton(
                    onPressed: () {
                      setState(() {
                        _images.clear();
                      });
                    },
                    text: "مسح"),
              )
            ],
          ],
        ),
        Text(
          "الحد الأقصى: ${widget.maxImages} عناصر • حجم كل ملف ≤ ${widget.maxFileSizeMB} MB",
          style: Theme.of(context).textTheme.labelSmall,
        ),

        // صور (Grid)
        if (_images.isNotEmpty) ...[
          Text("الصور (${_images.length})",
              style: Theme.of(context).textTheme.bodyLarge),
          GridView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemCount: _images.length,
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 3,
              crossAxisSpacing: 8,
              mainAxisSpacing: 8,
              childAspectRatio: 1,
            ),
            itemBuilder: (context, i) {
              final f = _images[i];
              final globalIndex = _images.indexOf(f);
              return ImagePreview(
                image: f,
                onRemove: () {
                  setState(() {
                    removeFileFromList(
                        idx: globalIndex,
                        storageImages: _images,
                        onChanged: widget.onChanged);
                  });
                },
              );
            },
          ),
          // ImagesPreviewGrid(
          //   images: _images,
          //   onRemove: (p0) {
          //     // setState(() {
          //     //   removeFileFromList(
          //     //       idx: p0,
          //     //       storageImages: _images,
          //     //       onChanged: widget.onChanged);
          //     // });
          //     print(p0.toString());
          //   },
          // ),
          const SizedBox(),
        ],
      ],
    );
  }
}
