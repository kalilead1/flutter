import 'dart:io';

import 'package:booking_v1/core/constants/strings.dart';
import 'package:booking_v1/core/widgets/container_widgets.dart';
import 'package:booking_v1/core/widgets/image_picker/utils.dart';
import 'package:booking_v1/core/widgets/image_picker/widgets/file_source_sheet.dart';
import 'package:flutter/material.dart';

class SingleImagePicker extends StatefulWidget {
  final double size;
  final int maxFileSizeMB;
  final String? initialImage;
  final ValueChanged<File?>? onChanged;
  final String label;

  const SingleImagePicker({
    super.key,
    this.size = 110,
    this.maxFileSizeMB = 8,
    this.initialImage,
    this.onChanged,
    this.label = "رفع صورة",
  });

  @override
  State<SingleImagePicker> createState() => _SingleImagePickerState();
}

class _SingleImagePickerState extends State<SingleImagePicker> {
  File? _image;

  // @override
  // void initState() {
  //   _image = widget.initialImage;
  //   super.initState();
  // }

  void _openPickerSheet() {
    showModalBottomSheet(
      context: context,
      builder: (_) => SafeArea(
        child: ImagesPickerBottomSheet(
          allowFiles: false,
          allowMultipleImages: false,
          onCamera: (p0) {
            setState(() {
              _trySet(p0);
            });
            // widget.onChanged!(_image);
          },
          onGallery: (p0) {
            if (p0.isNotEmpty) {
              setState(() {
                _trySet(p0.first);
              });
            }

            // widget.onChanged!(_image);
          },
        ),
      ),
    );
    // widget.onChanged!(_image);
  }

  void _trySet(File f) {
    if (!validateFileSize(context, f, widget.maxFileSizeMB)) return;
    setState(() => _image = f);
    widget.onChanged?.call(_image);
  }

  @override
  Widget build(BuildContext context) {
    return SecondaryContainer(
      paddingVertical: defaultPadding / 3,
      child: GestureDetector(
        onTap: _openPickerSheet,
        child: Center(
          child: Column(
            spacing: defaultSpacing,
            children: [
              SizedBox(),
              Container(
                width: widget.size,
                height: widget.size,
                decoration: BoxDecoration(
                    color: Theme.of(context)
                        .colorScheme
                        .tertiary
                        .withValues(alpha: 0.5),
                    shape: BoxShape.circle,
                    border: Border.all(
                      color: Theme.of(context).colorScheme.tertiary,
                    )),
                child: ClipOval(
                  child: widget.initialImage == null
                      ? _image != null
                          ? Image.file(_image!, fit: BoxFit.cover)
                          : Icon(Icons.add_a_photo,
                              size: widget.size * .36,
                              color: Theme.of(context).colorScheme.tertiary)
                      : Image.network(widget.initialImage!, fit: BoxFit.cover),
                ),
              ),
              Text(
                widget.label,
                style: Theme.of(context).textTheme.titleSmall,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
