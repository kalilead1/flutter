import 'dart:io';

import 'package:booking_v1/core/constants/strings.dart';
import 'package:booking_v1/core/widgets/botton_widghts.dart';
import 'package:booking_v1/core/widgets/image_picker/utils.dart';
import 'package:booking_v1/core/widgets/image_picker/widgets/file_and_image_preview.dart';
import 'package:booking_v1/core/widgets/image_picker/widgets/file_source_sheet.dart';
import 'package:flutter/material.dart';

class MultiUploaderWidget extends StatefulWidget {
  final int maxItems;
  final int maxFileSizeMB;
  final ValueChanged<List<File>>? onChanged;
  final String addButtonLabel;

  const MultiUploaderWidget({
    super.key,
    this.maxItems = 8,
    this.maxFileSizeMB = 8,
    this.onChanged,
    this.addButtonLabel = "إضافة ملف/صورة",
  });

  @override
  State<MultiUploaderWidget> createState() => _MultiUploaderWidgetState();
}

class _MultiUploaderWidgetState extends State<MultiUploaderWidget> {
  final List<File> _items = [];

  void _openPickerSheet() {
    showModalBottomSheet(
      context: context,
      builder: (_) => SafeArea(
        child: ImagesPickerBottomSheet(
          allowFiles: true,
          onCamera: (p0) {
            setState(() {
              addFileToList(
                context: context,
                uploadedFiles: [p0],
                storgeFile: _items,
                maxFileSizeMB: widget.maxFileSizeMB,
                maxImages: widget.maxItems,
                onChanged: widget.onChanged,
              );
            });
          },
          onGallery: (p0) {
            setState(() {
              addFileToList(
                context: context,
                uploadedFiles: p0,
                storgeFile: _items,
                maxFileSizeMB: widget.maxFileSizeMB,
                maxImages: widget.maxItems,
                onChanged: widget.onChanged,
              );
            });
          },
          onFiles: (p0) {
            setState(() {
              addFileToList(
                context: context,
                uploadedFiles: p0,
                storgeFile: _items,
                maxFileSizeMB: widget.maxFileSizeMB,
                maxImages: widget.maxItems,
                onChanged: widget.onChanged,
              );
            });
          },
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final images = _items.where((f) => isImageFilePath(f.path)).toList();
    final others = _items.where((f) => !isImageFilePath(f.path)).toList();

    return Column(
      spacing: 10,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          spacing: defaultSpacing,
          children: [
            Expanded(
              child: SecondaryElevatedButton(
                  onPressed: _openPickerSheet, text: widget.addButtonLabel),
            ),
            if (_items.isNotEmpty) ...[
              Container(
                constraints: BoxConstraints(
                  minWidth: 50,
                  maxWidth: 90,
                ),
                child: CancelElevatedButton(
                    onPressed: () {
                      setState(() {
                        _items.clear();
                      });
                    },
                    text: "مسح"),
              )
            ],
          ],
        ),
        Text(
          "الحد الأقصى: ${widget.maxItems} عناصر • حجم كل ملف ≤ ${widget.maxFileSizeMB} MB",
          style: Theme.of(context).textTheme.labelSmall,
        ),

        // صور (Grid)
        if (images.isNotEmpty) ...[
          Text(
            "الصور (${images.length})",
            style: Theme.of(context).textTheme.bodyLarge,
          ),
          GridView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemCount: images.length,
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 3,
              crossAxisSpacing: 8,
              mainAxisSpacing: 8,
              childAspectRatio: 1,
            ),
            itemBuilder: (context, i) {
              final f = images[i];
              final globalIndex = _items.indexOf(f);
              return ImagePreview(
                image: f,
                onRemove: () {
                  setState(() {
                    removeFileFromList(
                        idx: globalIndex,
                        storageImages: _items,
                        onChanged: widget.onChanged);
                  });
                },
              );
            },
          ),
          const SizedBox(),
        ],

        // ملفات غير صور (List)
        if (others.isNotEmpty) ...[
          Text("الملفات (${others.length})",
              style: Theme.of(context).textTheme.bodyLarge),
          // const SizedBox(height: 8),

          ListView.separated(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemCount: others.length,
            separatorBuilder: (_, __) => const SizedBox(height: 8),
            itemBuilder: (context, i) {
              final f = others[i];
              final globalIndex = _items.indexOf(f);
              return FilePreview(
                file: f,
                onRemove: () {
                  setState(() {
                    removeFileFromList(
                        idx: globalIndex,
                        storageImages: _items,
                        onChanged: widget.onChanged);
                  });
                },
              );
            },
          ),
        ],
      ],
    );
  }
}
