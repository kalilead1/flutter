import 'package:flutter/material.dart';

import '../constants/strings.dart';

class PrimaryContainer extends StatelessWidget {
  final Widget child;
  final double paddingHorizontal;
  final double paddingVertical;
  const PrimaryContainer(
      {required this.child,
      this.paddingHorizontal = defaultPadding,
      this.paddingVertical = defaultPadding,
      super.key});

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Container(
        constraints:
            BoxConstraints(minWidth: MediaQuery.of(context).size.width),
        padding: EdgeInsets.symmetric(
            horizontal: paddingHorizontal, vertical: paddingVertical),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(defaultBorderRadious),
          color: Theme.of(context).colorScheme.primaryContainer,
          border: Border.all(
              color: Theme.of(context).colorScheme.onPrimaryContainer),
        ),
        child: child,
      ),
    );
  }
}

class SecondaryContainer extends StatelessWidget {
  final Widget child;
  final double paddingHorizontal;
  final double paddingVertical;
  const SecondaryContainer({
    required this.child,
    this.paddingHorizontal = defaultPadding,
    this.paddingVertical = defaultPadding,
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Container(
        constraints:
            BoxConstraints(minWidth: MediaQuery.of(context).size.width),
        padding: EdgeInsets.symmetric(
            horizontal: paddingHorizontal, vertical: paddingVertical + 2),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(defaultBorderRadious),
          border: Border.all(
              color: Theme.of(context).colorScheme.onPrimaryContainer),
        ),
        child: child,
      ),
    );
  }
}

class TertiaryContainer extends StatelessWidget {
  final Widget child;
  final double? minWidth;
  final double paddingHorizontal;
  final double paddingVertical;
  const TertiaryContainer({
    required this.child,
    this.minWidth,
    this.paddingHorizontal = defaultPadding,
    this.paddingVertical = defaultPadding,
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Container(
        // padding: EdgeInsets.all(defaultPadding),
        // alignment: Alignment.centerRight,
        constraints: BoxConstraints(
            minWidth: minWidth ?? MediaQuery.of(context).size.width),
        padding: EdgeInsets.symmetric(
            horizontal: paddingHorizontal, vertical: paddingVertical + 2),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(defaultBorderRadious),
          color: Theme.of(context).colorScheme.tertiary,
          border: Border.all(
              color: Theme.of(context).colorScheme.onPrimaryContainer),
        ),
        child: child,
      ),
    );
  }
}
