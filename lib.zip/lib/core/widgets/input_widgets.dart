import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../constants/strings.dart';
import 'container_widgets.dart';

///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////

class InputPhoneNumberWidget extends StatefulWidget {
  final String label;
  final TextEditingController textController;

  const InputPhoneNumberWidget({
    super.key,
    required this.label,
    required this.textController,
  });

  @override
  State<InputPhoneNumberWidget> createState() => _InputPhoneNumberWidgetState();
}

class _InputPhoneNumberWidgetState extends State<InputPhoneNumberWidget> {
  String? errorText;

  @override
  // void _validate(String value) {
  //   if (value.length != 9) {
  //     setState(() => errorText = "الرقم ليس مكتمل");
  //     return;
  //   }
  //   final phone = PhoneNumber.parse(value, destinationCountry: IsoCode.YE);
  //   if (phone.isValid()) {
  //     setState(() => errorText = null);
  //   } else {
  //     setState(() => errorText = "الرقم ليس مكتمل");
  //   }
  // }

  // void _validate2(String value) {
  //   if (value.length < 9) {
  //     setState(() => errorText = "الرقم ليس مكتمل");
  //   } else {
  //     setState(() => errorText = null);
  //   }
  // }

  Widget build(BuildContext context) {
    return TextFormField(
      keyboardType: TextInputType.number,
      textAlign: TextAlign.left,
      inputFormatters: [
        FilteringTextInputFormatter.digitsOnly,
        LengthLimitingTextInputFormatter(9),
        PhoneFormatter(),
      ],
      style: TextStyle(letterSpacing: 1),
      decoration: InputDecoration(
        label: Text(widget.label),
        suffix: Text("   967+"),
        // errorText: errorText,
      ),
      controller: widget.textController,
      onSaved: (newValue) {
        setState(() {
          widget.textController.text = newValue!;
        });
      },
      autovalidateMode: AutovalidateMode.onUserInteraction,
      // onChanged: _validate2,
      validator: (value) {
        if (value == null || value.length != 9) {
          // errorText = ;
          return "الرقم ليس مكتمل";
        } else {
          // errorText = null;
          return null;
        }
      },
    );
  }
}

class PhoneFormatter extends TextInputFormatter {
  final List<String> allowedPerfixes = ['77', '78', '71', '73', '70'];

  @override
  TextEditingValue formatEditUpdate(
      TextEditingValue oldValue, TextEditingValue newValue) {
    // if (oldValue) {
    if (newValue.text.length >= 2) {
      final perfix = newValue.text.substring(0, 2);
      if (!allowedPerfixes.contains(perfix)) {
        return oldValue;
      }
      // }
    }
    return newValue;
  }
}

///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////

class CustomInputFieldWidget extends StatefulWidget {
  final String label;
  final TextEditingController textController;
  final Widget? suffix;
  final TextInputType? textInputType;
  final int? maxLength;
  final int? maxLines;
  final int? minLines;

  const CustomInputFieldWidget({
    super.key,
    required this.label,
    required this.textController,
    this.suffix,
    this.textInputType,
    this.maxLength,
    this.maxLines,
    this.minLines,
  });

  @override
  State<CustomInputFieldWidget> createState() => _CustomInputFieldWidgetState();
}

class _CustomInputFieldWidgetState extends State<CustomInputFieldWidget> {
  @override
  Widget build(BuildContext context) {
    return TextFormField(
      maxLength: widget.maxLength,
      maxLines: widget.maxLines,
      minLines: widget.minLines,
      keyboardType: widget.textInputType,
      style: TextStyle(letterSpacing: 0),
      decoration:
          InputDecoration(label: Text(widget.label), suffix: widget.suffix),
      controller: widget.textController,
      onSaved: (newValue) {
        setState(() {
          widget.textController.text = newValue!;
        });
      },
      validator: (value) =>
          value!.isEmpty ? textFieldIsEmptyMessage + widget.label : null,
    );
  }
}

///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////

class CustomInputSeletctedWidget extends StatefulWidget {
  final List list;
  final String label;
  final TextEditingController textController;
  const CustomInputSeletctedWidget({
    super.key,
    required this.list,
    required this.label,
    required this.textController,
  });

  @override
  State<CustomInputSeletctedWidget> createState() =>
      _CustomInputSeletctedWidgetState();
}

class _CustomInputSeletctedWidgetState
    extends State<CustomInputSeletctedWidget> {
  @override
  Widget build(BuildContext context) {
    return TextFormField(
      style: TextStyle(letterSpacing: 0),
      decoration: InputDecoration(
        label: Text(widget.label),
        suffixIcon: Icon(Icons.keyboard_arrow_down_outlined),
      ),
      controller: widget.textController,
      onSaved: (newValue) {
        setState(() {
          widget.textController.text = newValue!;
        });
      },
      validator: (value) =>
          value!.isEmpty ? textFieldIsEmptyMessage + widget.label : null,
      readOnly: true,
      onTap: () => showModalBottomSheet(
        context: context,
        builder: (context) => Padding(
          padding: EdgeInsets.all(defaultPadding),
          child: ListView.separated(
            itemBuilder: (context, index) {
              return GestureDetector(
                onTap: () {
                  setState(() {
                    widget.textController.text = widget.list[index];
                  });
                  Navigator.pop(context);
                },
                child: SecondaryContainer(
                  child: Text(
                    "${index + 1}.  ${widget.list[index]}",
                    style: Theme.of(context).textTheme.titleMedium,
                  ),
                ),
              );
            },
            separatorBuilder: (context, index) =>
                SizedBox(height: defaultSpacing),
            itemCount: widget.list.length,
          ),
        ),
      ),
    );
  }
}

///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////

// class CustomSeletctedByIndexWidget extends StatefulWidget {
//   final List<Category> list;
//   final String label;
//   final TextEditingController textIndexController;
//   const CustomSeletctedByIndexWidget({
//     super.key,
//     required this.list,
//     required this.label,
//     required this.textIndexController,
//   });

//   @override
//   State<CustomSeletctedByIndexWidget> createState() =>
//       _CustomSeletctedByIndexWidgetState();
// }

// class _CustomSeletctedByIndexWidgetState
//     extends State<CustomSeletctedByIndexWidget> {
//   final TextEditingController textController = TextEditingController();
//   @override
//   Widget build(BuildContext context) {
//     return TextFormField(
//       style: TextStyle(letterSpacing: 0),
//       decoration: InputDecoration(
//         label: Text(widget.label),
//         suffixIcon: Icon(Icons.keyboard_arrow_down_outlined),
//       ),
//       controller: textController,
//       onSaved: (newValue) {
//         setState(() {
//           // textController.text = newValue!;
//           // final s = widget.list
//           //     .where((element) => element.name == newValue ? element : null)
//           //     .toList();
//         });
//       },
//       validator: (value) =>
//           value!.isEmpty ? textFieldIsEmptyMessage + widget.label : null,
//       readOnly: true,
//       onTap: () => showModalBottomSheet(
//         context: context,
//         builder: (context) => Padding(
//           padding: EdgeInsets.all(defaultPadding),
//           child: ListView.separated(
//             itemBuilder: (context, index) {
//               return GestureDetector(
//                 onTap: () {
//                   setState(() {
//                     // widget.textController.text = widget.list[index].name!;
//                     // widget.categoryId = widget.list[index].id;
//                     textController.text = widget.list[index].name!;
//                     widget.textIndexController.text =
//                         widget.list[index].id.toString();
//                     // widget.textController.selection =
//                     //     widget.list[index].id;
//                   });
//                   Navigator.pop(context);
//                 },
//                 child: SecondaryContainer(
//                   child: Text(
//                     "${index + 1}.  ${widget.list[index].name}",
//                     style: Theme.of(context).textTheme.titleMedium,
//                   ),
//                 ),
//               );
//             },
//             separatorBuilder: (context, index) =>
//                 SizedBox(height: defaultSpacing),
//             itemCount: widget.list.length,
//           ),
//         ),
//       ),
//     );
//   }
// }
