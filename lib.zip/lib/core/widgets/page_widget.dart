import 'package:flutter/material.dart';

class PageWidget extends StatelessWidget {
  const PageWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}
