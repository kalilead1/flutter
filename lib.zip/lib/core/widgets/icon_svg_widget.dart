import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';

class IconSvg extends StatelessWidget {
  final String iconName;
  final Color? color;
  final double size;
  const IconSvg(
      {required this.iconName, this.color, this.size = 22, super.key});

  @override
  Widget build(BuildContext context) {
    return SvgPicture.asset(
      "assets/icons/$iconName.svg",
      colorFilter: ColorFilter.mode(
        color ?? Theme.of(context).iconTheme.color!,
        BlendMode.srcIn,
      ),
      height: size,
    );
  }
}

class IconSvgPrimary extends StatelessWidget {
  final String iconName;
  const IconSvgPrimary({required this.iconName, super.key});

  @override
  Widget build(BuildContext context) {
    return SvgPicture.asset(
      "assets/icons/$iconName.svg",
      colorFilter: ColorFilter.mode(
        Theme.of(context).colorScheme.primary,
        BlendMode.srcIn,
      ),
      height: 22,
    );
  }
}
