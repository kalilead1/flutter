import 'package:flutter/material.dart';

import '../constants/strings.dart';

class CustomContainerStepsAddWidget extends StatelessWidget {
  const CustomContainerStepsAddWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 15,
      height: 4,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(defaultBorderRadious),
        color: Theme.of(context).colorScheme.primary,
      ),
    );
  }
}

class CustomCircleStepsAddWidget extends StatelessWidget {
  final double radius;
  const CustomCircleStepsAddWidget({super.key, this.radius = 3});

  @override
  Widget build(BuildContext context) {
    return CircleAvatar(
      radius: radius,
      backgroundColor:
          Theme.of(context).colorScheme.tertiary.withValues(alpha: 0.4),
    );
  }
}
