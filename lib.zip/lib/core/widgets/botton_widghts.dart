import 'package:flutter/material.dart';

import '../constants/colors.dart';

////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////

class PrimaryElevatedButton extends StatelessWidget {
  final Function() onPressed;
  final String text;
  const PrimaryElevatedButton(
      {required this.onPressed, required this.text, super.key});

  @override
  Widget build(BuildContext context) {
    return ElevatedButton(
      style: ElevatedButton.styleFrom(
        backgroundColor: Theme.of(context).colorScheme.primary,
        foregroundColor: Colors.white,
      ),
      onPressed: onPressed,
      child: Text(text),
    );
  }
}

class SecondaryElevatedButton extends StatelessWidget {
  final Function() onPressed;
  final String text;
  const SecondaryElevatedButton(
      {required this.onPressed, required this.text, super.key});

  @override
  Widget build(BuildContext context) {
    return ElevatedButton(
      style: ElevatedButton.styleFrom(
          backgroundColor: Theme.of(context).colorScheme.tertiary),
      onPressed: onPressed,
      child: Text(text),
    );
  }
}

class CancelElevatedButton extends StatelessWidget {
  final Function() onPressed;
  final String text;
  const CancelElevatedButton(
      {required this.onPressed, required this.text, super.key});

  @override
  Widget build(BuildContext context) {
    return ElevatedButton(
      style: ElevatedButton.styleFrom(
        backgroundColor: errorColor,
        foregroundColor: Colors.white,
      ),
      onPressed: onPressed,
      child: Text(
        text,
      ),
    );
  }
}
