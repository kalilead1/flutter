import 'package:flutter/material.dart';

import '../constants/strings.dart';
import 'botton_widghts.dart';

class AppDialog {
  static Future<void> showCustomDialog({
    required BuildContext context,
    String? title,
    String? content,
    Widget? childAction,
    bool barrierDismissible = false,
  }) {
    return showDialog(
      context: context,
      barrierDismissible: barrierDismissible,
      builder: (context) {
        return Padding(
          padding: const EdgeInsets.symmetric(horizontal: defaultPadding / 2),
          child: Dialog(
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(defaultBorderRadious),
            ),
            backgroundColor: Theme.of(context).scaffoldBackgroundColor,
            insetPadding: EdgeInsets.all(defaultPadding),
            insetAnimationCurve: Curves.elasticInOut,
            child: Container(
              decoration: BoxDecoration(
                border: Border.all(
                    color: Theme.of(context)
                        .colorScheme
                        .tertiary
                        .withValues(alpha: 0.2)),
                borderRadius: BorderRadius.circular(defaultBorderRadious),
              ),
              child: Padding(
                padding: EdgeInsets.all(defaultPadding),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    if (title != null)
                      Center(
                        child: Text(title,
                            style: Theme.of(context).textTheme.titleLarge),
                      ),
                    if (content != null) ...[
                      const SizedBox(height: defaultSpacing),
                      Center(
                        child: Text(content,
                            style: Theme.of(context).textTheme.bodyLarge),
                      ),
                    ],
                    const SizedBox(height: defaultSpacing * 3),
                    Row(
                      spacing: defaultSpacing,
                      children: [
                        Expanded(
                          child: SecondaryElevatedButton(
                              onPressed: () {
                                Navigator.pop(context);
                              },
                              text: "الغاء"),
                        ),
                        if (childAction != null) Expanded(child: childAction),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ),
        );
      },
    );
  }
  // static Future<void> showCustomDialog(
  //     {required BuildContext context,
  //     String? title,
  //     String? content,
  //     List<Widget>? action,
  //     bool barrierDismissible = true}) {
  //   return showDialog(
  //     context: context,
  //     barrierDismissible: barrierDismissible,
  //     builder: (context) {
  //       return Dialog(
  //         shape: RoundedRectangleBorder(
  //           borderRadius: BorderRadius.circular(defaultBorderRadious),
  //         ),
  //         backgroundColor: Theme.of(context).scaffoldBackgroundColor,
  //         insetPadding: EdgeInsets.all(defaultPadding),
  //         child: Padding(
  //           padding: EdgeInsets.all(defaultPadding),
  //           child: Column(
  //             mainAxisSize: MainAxisSize.min,
  //             children: [
  //               if (title != null)
  //                 Center(
  //                   child: Text(title,
  //                       style: Theme.of(context).textTheme.titleLarge),
  //                 ),
  //               if (content != null) ...[
  //                 const SizedBox(height: defaultSpacing),
  //                 Center(
  //                   child: Text(content,
  //                       style: Theme.of(context).textTheme.bodyLarge),
  //                 ),
  //               ],
  //               if (action != null) ...[
  //                 const SizedBox(height: defaultSpacing * 3),
  //                 Row(
  //                   spacing: defaultSpacing,
  //                   children: action,
  //                 ),
  //               ]
  //             ],
  //           ),
  //         ),
  //       );
  //     },
  //   );
  // }

  static void showErrorMessageDialog(
      {required BuildContext context,
      String? title,
      String? content,
      bool barrierDismissible = true}) {
    showDialog(
      context: context,
      barrierDismissible: barrierDismissible,
      builder: (context) {
        return Padding(
          padding: const EdgeInsets.symmetric(horizontal: defaultPadding),
          child: Dialog(
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(defaultBorderRadious),
            ),
            backgroundColor: Theme.of(context).scaffoldBackgroundColor,
            insetPadding: EdgeInsets.all(defaultPadding),
            child: Container(
              decoration: BoxDecoration(
                border: Border.all(
                    color: Theme.of(context)
                        .colorScheme
                        .tertiary
                        .withValues(alpha: 0.5)),
                borderRadius: BorderRadius.circular(defaultBorderRadious),
              ),
              child: Padding(
                padding: EdgeInsets.all(defaultPadding),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    if (title != null)
                      Center(
                        child: Text(title,
                            style: Theme.of(context).textTheme.titleLarge),
                      ),
                    if (content != null) ...[
                      const SizedBox(height: defaultSpacing),
                      Center(
                        child: Text(content,
                            style: Theme.of(context).textTheme.bodyLarge),
                      ),
                    ],
                    const SizedBox(height: defaultSpacing * 3),
                    SecondaryElevatedButton(
                        onPressed: () {
                          Navigator.pop(context);
                        },
                        text: "الغاء")
                  ],
                ),
              ),
            ),
          ),
        );
      },
    );
  }

  static Future<void> showExitFromAppDialog({required BuildContext context}) {
    return showDialog(
      context: context,
      builder: (context) {
        return Padding(
          padding: const EdgeInsets.symmetric(horizontal: defaultPadding),
          child: Dialog(
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(defaultBorderRadious),
            ),
            backgroundColor: Theme.of(context).scaffoldBackgroundColor,
            shadowColor:
                Theme.of(context).colorScheme.tertiary.withOpacity(0.20),
            // surfaceTintColor:
            //     Theme.of(context).colorScheme.tertiary.withOpacity(0.1),
            elevation: 0,
            insetAnimationCurve: Curves.elasticInOut,
            insetAnimationDuration: Duration(seconds: 5),
            insetPadding: EdgeInsets.all(defaultPadding),
            child: Container(
              decoration: BoxDecoration(
                border: Border.all(
                    color: Theme.of(context)
                        .colorScheme
                        .tertiary
                        .withValues(alpha: 0.5)),
                borderRadius: BorderRadius.circular(defaultBorderRadious),
              ),
              child: Padding(
                padding: EdgeInsets.all(defaultPadding),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Center(
                      child: Text("تسجيل الخروج",
                          style: Theme.of(context).textTheme.titleLarge),
                    ),
                    const SizedBox(height: defaultSpacing),
                    Center(
                      child: Text("هل انت متاكد من تسجيل الخروج",
                          style: Theme.of(context).textTheme.bodyLarge),
                    ),
                    const SizedBox(height: defaultSpacing * 3),
                    Row(
                      spacing: defaultSpacing,
                      children: [
                        Expanded(
                          child: SecondaryElevatedButton(
                            onPressed: () {
                              Navigator.pop(context);
                            },
                            text: "الغاء",
                          ),
                        ),
                        Expanded(
                          child: PrimaryElevatedButton(
                            onPressed: () {},
                            text: "خروج",
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ),
        );
      },
    );
  }
}
