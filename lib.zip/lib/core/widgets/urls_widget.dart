import 'package:url_launcher/url_launcher.dart';

class Urls {
  static Future<void> urlPhone(String phoneNumber) async {
    final Uri _url = Uri(scheme: 'tel', path: phoneNumber);
    await launchUrl(_url);
  }

  static Future<void> urlMessage(String phoneNumber) async {
    final Uri _url = Uri(scheme: 'sms', path: phoneNumber);
    await launchUrl(_url);
  }

  static Future<void> urlSocialMedia(String url) async {
    final Uri _url = Uri.parse(url);
    if (!await launchUrl(_url, mode: LaunchMode.externalApplication)) {
      throw "لا يمكن فتح الرابط";
    }
  }
}
