import 'package:flutter/material.dart';

import '../constants/strings.dart';

class SingleBottomItem extends StatelessWidget {
  final Widget child;

  const SingleBottomItem({required this.child, super.key});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 75,
      child: Padding(
        padding: EdgeInsets.symmetric(
          vertical: defaultPadding / 2,
          horizontal: defaultPadding,
        ),
        child: child,
      ),
    );
  }
}

class TwoBottomItems extends StatelessWidget {
  final Widget child1;
  final Widget? child2;

  const TwoBottomItems({required this.child1, this.child2, super.key});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      child: Padding(
        padding: EdgeInsets.only(
          // vertical: defaultPadding,
          right: defaultPadding,
          left: defaultPadding,
          bottom: defaultPadding,
        ),
        child: Row(
          spacing: defaultSpacing,
          children: [
            Expanded(child: child1),
            if (child2 != null) Expanded(child: child2!),
          ],
        ),
      ),
    );
  }
}
