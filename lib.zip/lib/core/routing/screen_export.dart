export '../../entry_point.dart';

/////////////////////////////// Auth Feature //////////////////////////////////
export '../../featuers/auth/persentation/pages/login_page.dart';
export '../../featuers/auth/persentation/pages/profile_user_page.dart';
export '../../featuers/auth/persentation/pages/otp_verification_page.dart';
export '../../featuers/auth/persentation/pages/register_account_page.dart';

/////////////////////////////// Main Feature //////////////////////////////////
export '../../featuers/main/persentation/pages/home_page.dart';
export '../../featuers/main/persentation/pages/favorites_page.dart';
export '../../featuers/main/persentation/pages/search_page.dart';
export '../../featuers/main/persentation/pages/my_booking_page.dart';
export '../../featuers/main/persentation/pages/settings_page.dart';

export '../../featuers/main/persentation/pages/splash_page.dart';
export '../../featuers/main/persentation/pages/error_screen_page.dart';
export '../../featuers/main/persentation/pages/complaint_and_suggestion_page.dart';

////////////////////////////// Store Feature //////////////////////////////////
export '../../featuers/stores/persentation/pages/view_store_details_page.dart';
export '../../featuers/stores/persentation/pages/store_settings_page.dart';
export '../../featuers/stores/persentation/pages/stores_owner_page.dart';
export '../../featuers/stores/persentation/pages/add_store_report_page.dart';

export '../../featuers/stores/persentation/pages/add_store/add_update_store_baisc_info_page.dart';
export '../../featuers/stores/persentation/pages/add_store/add_update_store_location_page.dart';
export '../../featuers/stores/persentation/pages/add_store/add_store_social_account_page.dart';
export '../../featuers/stores/persentation/pages/add_store/add_store_wallets_page.dart';
export '../../featuers/stores/persentation/pages/add_store/add_store_documents_page.dart';
export '../../featuers/stores/persentation/pages/add_store/add_approval_of_politics_page.dart';
export '../../featuers/stores/persentation/pages/add_store/confirm_add_store_page.dart';

export '../../featuers/stores/persentation/pages/update_store/update_store_social_account_page.dart';
export '../../featuers/stores/persentation/pages/update_store/update_store_wallets_page.dart';

///////////////////////////// Service Feature /////////////////////////////////
export '../../featuers/services/persentation/pages/view_service_detail_page.dart';
export '../../featuers/services/persentation/pages/service_settings_page.dart';
export '../../featuers/services/persentation/pages/services_owner_page.dart';

export '../../featuers/services/persentation/pages/add_update_service/add_update_service_baisc_info_page.dart';
export '../../featuers/services/persentation/pages/add_update_service/add_update_service_gloable_info_page.dart';
export '../../featuers/services/persentation/pages/add_update_service/add_service_images_page.dart';
export '../../featuers/services/persentation/pages/add_update_service/confirm_add_service_page.dart';

export '../../featuers/services/persentation/pages/add_update_service/update_service_images_page.dart';

///////////////////////////// Booking Feature /////////////////////////////////
export '../../featuers/bookings/persentation/pages/add_online/add_details_booking_online_page.dart';
export '../../featuers/bookings/persentation/pages/add_online/check_add_booking_online_page.dart';
export '../../featuers/bookings/persentation/pages/view_store_bookings_page.dart';
export '../../featuers/bookings/persentation/pages/view_service_bookings_page.dart';
export '../../featuers/bookings/persentation/pages/view_booking_details_page.dart';

///////////////////////////// Payment Feature /////////////////////////////////
export '../../featuers/payments/persentation/pages/payment_booking_online_page.dart';
export '../../featuers/payments/persentation/pages/payment_details_page.dart';

///////////////////////////// Payment Feature /////////////////////////////////
export '../../featuers/notifications/persentation/pages/notification_page.dart';
