import 'package:go_router/go_router.dart';

import '../../featuers/bookings/persentation/pages/args/view_booking_details_args.dart';
import '../../featuers/services/persentation/pages/args/add_pages_args.dart';
import '../../featuers/stores/domain/entities/store.dart';
import '../../featuers/stores/persentation/pages/args/add_pages_args.dart';
import 'app_routes.dart';
import 'screen_export.dart';

class AppRouter {
  static final router = GoRouter(
    initialLocation: splashPageRoute,
    routes: [
      ///////////////////////////////////////////////////////////////////////
      ///////////////////////////////////////////////////////////////////////
      GoRoute(
        path: entryPointRoute,
        builder: (context, state) {
          final args = state.extra as int;
          return EntryPoint(index: args);
        },
      ),
      GoRoute(
        path: splashPageRoute,
        builder: (_, __) => const SplashPage(),
      ),
      GoRoute(
        path: complaintAndSuggestionRoute,
        builder: (_, __) => const ComplaintAndSuggestionPage(),
      ),
      ///////////////////////////////////////////////////////////////////////
      ///////////////////// Auth Feature Routing ////////////////////////////
      ///////////////////////////////////////////////////////////////////////
      GoRoute(
        path: logInRoute,
        builder: (_, __) => const LoginPage(),
      ),
      GoRoute(
        path: registerAccountRoute,
        builder: (_, __) => const RegisterAccountPage(),
      ),
      GoRoute(
        path: otpVerificationRoute,
        builder: (_, __) => const OtpVerificationPage(),
      ),
      GoRoute(
        path: profileUserRoute,
        builder: (context, state) {
          final args = state.extra as int;
          return ProfileUserPage(userId: args);
        },
      ),

      ///////////////////////////////////////////////////////////////////////
      //////////////////// Store Feature Routing ////////////////////////////
      ///////////////////////////////////////////////////////////////////////
      GoRoute(
        path: storeDetailsRoute,
        builder: (context, state) {
          final args = state.extra as int;
          return ViewStoreDetailsPage(storeId: args);
        },
      ),
      GoRoute(
        path: storeOwnerRoute,
        builder: (context, state) {
          final args = state.extra as int;
          return StoresOwnerPage(ownerId: args);
        },
      ),
      GoRoute(
        path: storeSettingRoute,
        builder: (context, state) {
          final args = state.extra as int;
          return StoreSettingsPage(storeId: args);
        },
      ),
      GoRoute(
        path: addStoreReportRoute,
        builder: (context, state) {
          final args = state.extra as Store;
          return AddStoreReportPage(store: args);
        },
      ),

      ///
      ///
      ///
      GoRoute(
        path: addUpdateStoreBaiscRoute,
        builder: (context, state) {
          final args = state.extra as AddUpdateStoreBaiscAndLocationArgs;
          return AddUpdateStoreBaiscInfoPage(
            store: args.store,
            isUpdateStore: args.isUpdateStore,
          );
        },
      ),
      GoRoute(
        path: addUpdateStoreLocationRoute,
        builder: (context, state) {
          final args = state.extra as AddUpdateStoreBaiscAndLocationArgs;
          return AddUpdateStoreLocationPage(
            store: args.store,
            isUpdateStore: args.isUpdateStore,
          );
        },
      ),
      GoRoute(
        path: addStoreSocialRoute,
        builder: (_, __) => const AddStoreSocialAccountPage(),
      ),
      GoRoute(
        path: addStoreWalletRoute,
        builder: (_, __) => const AddStoreWalletsPage(),
      ),

      GoRoute(
        path: addStoreDocumentRoute,
        builder: (_, __) => const AddStoreDocumentsPage(),
      ),
      GoRoute(
        path: addStoreApprovalPoliticsRoute,
        builder: (_, __) => const AddApprovalOfPoliticsPage(),
      ),
      GoRoute(
        path: confirmAddStoreRoute,
        builder: (_, __) => const ConfirmAddStorePage(),
      ),

      ///
      ///

      GoRoute(
        path: updateStoreWalletRoute,
        builder: (context, state) {
          final args = state.extra as int;
          return UpdateStoreWalletsPage(storeId: args);
        },
      ),
      GoRoute(
        path: updateStoreSocialRoute,
        builder: (context, state) {
          final args = state.extra as int;
          return UpdateStoreSocialAccountPage(storeId: args);
        },
      ),

      ///////////////////////////////////////////////////////////////////////
      //////////////////// Service Feature Routing //////////////////////////
      ///////////////////////////////////////////////////////////////////////
      GoRoute(
        path: serviceDetailsRoute,
        builder: (context, state) {
          final args = state.extra as int;
          return ViewServiceDetailPage(serviceId: args);
        },
      ),
      GoRoute(
        path: serviceOwnerRoute,
        builder: (context, state) {
          final args = state.extra as int;
          return ServicesOwnerPage(storeId: args);
        },
      ),
      GoRoute(
        path: serviceSettingRoute,
        builder: (context, state) {
          final args = state.extra as int;
          return ServiceSettingsPage(
            serviceId: args,
          );
        },
      ),
      GoRoute(
        path: addUpdateServiceBaiscRoute,
        builder: (context, state) {
          final args = state.extra as AddUpdateServiceArgs;
          return AddUpdateServiceBaiscInfoPage(
            service: args.service,
            isUpdateService: args.isUpdateService,
          );
        },
      ),
      GoRoute(
        path: addUpdateServiceGloableRoute,
        builder: (context, state) {
          final args = state.extra as AddUpdateServiceArgs;
          return AddUpdateServiceGloableInfoPage(
            service: args.service,
            isUpdateService: args.isUpdateService,
          );
        },
      ),
      GoRoute(
        path: addServiceImageRoute,
        builder: (context, state) {
          final args = state.extra as AddUpdateServiceImagesArgs;
          return AddServiceImagesPage(
            serviceId: args.serviceId,
            isUpdateService: args.isUpdateService,
          );
        },
      ),
      GoRoute(
        path: updateServiceImageRoute,
        builder: (context, state) {
          final args = state.extra as int;
          return UpdateServiceImagesPage(serviceId: args);
        },
      ),
      GoRoute(
        path: confirmAddServiceRoute,
        builder: (_, __) => const ConfirmAddServicePage(),
      ),

      ///////////////////////////////////////////////////////////////////////
      //////////////////// Booking Feature Routing //////////////////////////
      ///////////////////////////////////////////////////////////////////////
      GoRoute(
        path: addDetailsBookingRoute,
        builder: (context, state) {
          return AddDetailsBookingOnlinePage();
        },
      ),
      GoRoute(
        path: checkAddBookingRoute,
        builder: (context, state) {
          return CheckAddBookingOnlinePage();
        },
      ),
      GoRoute(
        path: viewStoreBookingsRoute,
        builder: (context, state) {
          final args = state.extra as int;
          return ViewStoreBookingsPage(storeId: args);
        },
      ),
      GoRoute(
        path: viewServiceBookingsRoute,
        builder: (context, state) {
          final args = state.extra as int;
          return ViewServiceBookingsPage(serviceId: args);
        },
      ),
      GoRoute(
        path: viewBookingDetailsRoute,
        builder: (context, state) {
          final args = state.extra as ViewBookingDetailsArgs;
          return ViewBookingDetailsPage(args: args
              // bookingId: args.bookingId,
              // forStore: args.forStore,
              );
        },
      ),
      // GoRoute(
      //   path: addDetailsBookingRoute,
      //   builder: (context, state) {
      //     final args = state.extra as Service;
      //     return AddDetailsBookingOnlinePage(service: args);
      //   },
      // ),
      // GoRoute(
      //   path: checkAddBookingRoute,
      //   builder: (context, state) {
      //     final args = state.extra as Service;
      //     return CheckAddBookingOnlinePage(service: args);
      //   },
      // ),

      ///////////////////////////////////////////////////////////////////////
      //////////////////// Payment Feature Routing //////////////////////////
      ///////////////////////////////////////////////////////////////////////
      GoRoute(
        path: paymentBookingOnlineRoute,
        builder: (_, __) => const PaymentBookingOnlinePage(),
      ),
      GoRoute(
        path: paymentDetailsRoute,
        builder: (context, state) {
          final args = state.extra as int;
          return PaymentDetailsPage(bookingId: args);
        },
      ),
      // GoRoute(
      //   path: paymentBookingOnlineRoute,
      //   builder: (context, state) {
      //     final args = state.extra as PaymentBookingOnlinePageArgs;
      //     return PaymentBookingOnlinePage(
      //       storeId: args.storeId,
      //       deposit: args.deposit,
      //       total: args.total,
      //       remaining: args.remaining,
      //     );
      //   },
      // ),

      ///////////////////////////////////////////////////////////////////////
      //////////////////// Payment Feature Routing //////////////////////////
      ///////////////////////////////////////////////////////////////////////
      GoRoute(
        path: notificationRoute,
        builder: (context, state) {
          return NotificationPage();
        },
      ),
    ],
  );
}
