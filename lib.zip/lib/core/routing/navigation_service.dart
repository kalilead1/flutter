//
// عمل تنقل بدون استخدام (context)
// يتم استخدامة في bloc

import 'package:go_router/go_router.dart';

import 'app_router.dart';

class NavigationService {
  static GoRouter get _router => AppRouter.router;
  static final List<String> _stack = [];

  // دالة تعمل على تبديل الصفحة دون رجوع
  static void replace(String path, {Object? extra}) {
    if (_stack.isNotEmpty) {
      _stack.removeLast();
      _stack.add(path);
      _router.go(path, extra: extra);
    }
  }

  // دالة تعمل على انتقال مع رجوع
  static void push(String path, {Object? extra}) {
    _stack.add(path);
    _router.push(path, extra: extra);
  }

  // دالة تعمل على الرجوع الى صفحة محددة
  static void popUntil(String path) {
    while (_stack.isNotEmpty && _stack.last != path) {
      _stack.removeLast();
      if (_router.canPop()) {
        _router.pop();
      }
    }
  }

  // دالة تعمل على الرجوع
  static void pop() {
    if (_stack.isNotEmpty) {
      _stack.removeLast();
      if (_router.canPop()) {
        _router.pop();
      }
    }
  }

  static List<String> get cru => List.from(_stack);
}
