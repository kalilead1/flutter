//
// عمل تنقل مع استخدام (context)
// يتم استخدامة في UI

import 'package:booking_v1/core/routing/navigation_service.dart';
import 'package:flutter/material.dart';

extension RouterX on BuildContext {
  // دالة تعمل على تبديل الصفحة دون رجوع
  void goTo(String path, {Object? extra}) {
    // GoRouter.of(this).go(path, extra: extra);
    NavigationService.replace(path, extra: extra);
  }

  // دالة تعمل على انتقال مع رجوع
  void pushTo(String path, {Object? extra}) {
    // GoRouter.of(this).push(path, extra: extra);
    NavigationService.push(path, extra: extra);
  }

  // دالة تعمل على الرجوع الى صفحة محددة
  void backTo(String path) {
    NavigationService.popUntil(path);
  }

  // دالة تعمل على الرجوع
  void back() {
    NavigationService.pop();
  }
}
