const String entryPointRoute = "/sentry_point";
const String splashPageRoute = "/splash_page";

///////////////////////////// Auth Feature /////////////////////////////////
const String logInRoute = "/login";
const String registerAccountRoute = "/register_account";
const String otpVerificationRoute = "/otp_verification";
const String profileUserRoute = "/profile_user";

///////////////////////////// Main Feature /////////////////////////////////
const String homeRoute = "/home";
const String favoritesRoute = "/favorites";
const String searchRoute = "/search";
const String myBookingRoute = "/my_booking";
const String settingRoute = "/settings";

const String errorPageRoute = "/error_page";
const String complaintAndSuggestionRoute = "/complaint_and_suggestion";

///////////////////////////// Store Feature /////////////////////////////////
const String storeDetailsRoute = "/store_details";
const String storeOwnerRoute = "/store_owner";
const String storeSettingRoute = "/store_setting";
const String addStoreReportRoute = "/add_store_report";

const String addUpdateStoreBaiscRoute = "/add_store_baisc";
const String addUpdateStoreLocationRoute = "/add_store_location";
const String addStoreSocialRoute = "/add_store_social";
const String addStoreWalletRoute = "/add_store_wallet";
const String addStoreDocumentRoute = "/add_store_document";
const String addStoreApprovalPoliticsRoute = "/add_store_approval_of_politics";
const String confirmAddStoreRoute = "/confirm_add_store";

const String updateStoreBaiscRoute = "/update_store_baisc";
const String updateStoreLocationRoute = "/update_store_location";
const String updateStoreSocialRoute = "/update_store_social";
const String updateStoreWalletRoute = "/update_store_wallet";

///////////////////////////// Service Feature /////////////////////////////////
const String serviceDetailsRoute = "/service_details";
const String serviceOwnerRoute = "/service_owner";
const String serviceSettingRoute = "/service_setting";

const String addUpdateServiceBaiscRoute = "/add_update_service_baisc";
const String addUpdateServiceGloableRoute = "/add_update_service_gloable";
const String addServiceImageRoute = "/add_service_image";
const String confirmAddServiceRoute = "/confirm_add_service";

const String updateServiceImageRoute = "/update_service_image";

///////////////////////////// Booking Feature /////////////////////////////////
const String addDetailsBookingRoute = "/add_details_booking";
const String checkAddBookingRoute = "/check_add_booking";
const String viewStoreBookingsRoute = "/view_store_bookings";
const String viewServiceBookingsRoute = "/view_service_bookings";
const String viewBookingDetailsRoute = "/view_booking_details";

///////////////////////////// Payment Feature /////////////////////////////////
const String paymentBookingOnlineRoute = "/payment_booking_online";
const String paymentDetailsRoute = "/payment_details";

///////////////////////////// Notification Feature /////////////////////////////////
const String notificationRoute = "/notification";
