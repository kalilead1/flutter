import 'package:booking_v1/core/themes/app_theme.dart';
import 'package:booking_v1/dependency_injection/initial.dart';
import 'package:booking_v1/featuers/bookings/persentation/bloc/bookings_command/bookings_command_bloc.dart';
import 'package:booking_v1/featuers/main/persentation/blocs/theme/theme_bloc.dart';
import 'package:booking_v1/featuers/main/persentation/blocs/theme/theme_event.dart';
import 'package:booking_v1/featuers/main/persentation/blocs/theme/theme_state.dart';
import 'package:booking_v1/featuers/stores/persentation/bloc/store_wallets/store_wallets_bloc.dart';
import 'package:flutter/material.dart';

import 'package:flutter_bloc/flutter_bloc.dart';

import 'core/routing/app_router.dart';
import 'featuers/auth/persentation/bloc/auth_command/auth_command_bloc.dart';
import 'featuers/main/persentation/blocs/complaint_and_suggestion/complaint_and_suggestion_bloc.dart';
import 'featuers/services/persentation/bloc/add_update_delete_service/add_update_delete_service_bloc.dart';
import 'featuers/services/persentation/bloc/services/services_bloc.dart';
import 'featuers/stores/persentation/bloc/command_store/command_store_bloc.dart';
import 'featuers/stores/persentation/bloc/store_report/store_report_bloc.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await initial();

  final themeBloc = getIt<ThemeBloc>();
  themeBloc.add(LoadThemeEvent());

  runApp(MainApp(themeBloc: themeBloc));
}

class MainApp extends StatelessWidget {
  final ThemeBloc themeBloc;
  const MainApp({super.key, required this.themeBloc});

  @override
  Widget build(BuildContext context) {
    return MultiBlocProvider(
      providers: [
        BlocProvider.value(value: themeBloc),
        BlocProvider(create: (_) => getIt<CommandStoreBloc>()),
        BlocProvider(create: (_) => getIt<AddUpdateDeleteServiceBloc>()),
        BlocProvider(create: (_) => getIt<ServicesBloc>()),
        BlocProvider(create: (_) => getIt<BookingsCommandBloc>()),
        BlocProvider(create: (_) => getIt<StoreWalletsBloc>()),
        BlocProvider(create: (_) => getIt<ComplaintAndSuggestionBloc>()),
        BlocProvider(create: (_) => getIt<StoreReportBloc>()),
        BlocProvider(create: (_) => getIt<AuthCommandBloc>()),
      ],
      child: BlocBuilder<ThemeBloc, ThemeState>(
        builder: (context, state) {
          return MaterialApp.router(
            debugShowCheckedModeBanner: false,
            themeMode: state.themeMode,
            theme: AppTheme.lightTheme,
            darkTheme: AppTheme.darkTheme,
            routerConfig: AppRouter.router,
          );
        },
      ),
    );
    // return BlocProvider.value(
    //   value: themeBloc,
    //   child: BlocBuilder<ThemeBloc, ThemeState>(
    //     builder: (context, state) {
    //       return MaterialApp(
    //         debugShowCheckedModeBanner: false,
    //         themeMode: state.themeMode,
    //         theme: AppTheme.lightTheme,
    //         darkTheme: AppTheme.darkTheme,
    //         // home: GetAllWalletTestPage(),
    //         onGenerateRoute: router.generateRoute,
    //         initialRoute: entryPointScreenRoute,
    //       );
    //     },
    //   ),
    // );
  }
}
