import '../../featuers/stores/data/datasources/store_wallet_remote_data_source.dart';
import '../../featuers/stores/data/repositories/store_wallet_repository_impl.dart';
import '../../featuers/stores/domain/repositories/store_wallet_repository.dart';
import '../../featuers/stores/domain/usecases/store_wallet_usecase.dart';
import '../../featuers/stores/persentation/bloc/store_wallets/store_wallets_bloc.dart';
import '../initial.dart';

Future<void> initialStoreWallets() async {
  /// Bloc
  getIt.registerFactory(() => StoreWalletsBloc(
        getStoreWalletsUsecase: getIt(),
        addStoreWalletUsecase: getIt(),
        deleteStoreWalletUsecase: getIt(),
      ));

  // Use Cases
  getIt.registerLazySingleton(() => AddStoreWalletUsecase(getIt()));
  getIt.registerLazySingleton(() => GetStoreWalletsUsecase(getIt()));
  getIt.registerLazySingleton(() => DeleteStoreWalletUsecase(getIt()));

  // Repository
  getIt.registerLazySingleton<StoreWalletRepository>(
      () => StoreWalletRepositoryImpl(
            remoteDataSource: getIt(),
            networkInfo: getIt(),
          ));

  // Data Sources
  getIt.registerLazySingleton<StoreWalletRemoteDataSource>(
      () => StoreWalletRemoteDataSourceImpl(client: getIt()));
}
