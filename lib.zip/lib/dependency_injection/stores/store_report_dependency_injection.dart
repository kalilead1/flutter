import '../../featuers/stores/data/datasources/store_report_remote_data_source.dart';
import '../../featuers/stores/data/repositories/store_report_repository_impl.dart';
import '../../featuers/stores/domain/repositories/store_report_repository.dart';
import '../../featuers/stores/domain/usecases/store_report_usecase.dart';
import '../../featuers/stores/persentation/bloc/store_report/store_report_bloc.dart';
import '../initial.dart';

Future<void> initialStoreReport() async {
  /// Bloc
  getIt.registerFactory(() => StoreReportBloc(addStoreReportUsecase: getIt()));

  // Use Cases
  getIt.registerLazySingleton(() => AddStoreReportUsecase(getIt()));

  // Repository
  getIt.registerLazySingleton<StoreReportRepository>(
      () => StoreReportRepositoryImpl(
            remoteDataSource: getIt(),
            networkInfo: getIt(),
          ));

  // Data Sources
  getIt.registerLazySingleton<StoreReportRemoteDataSource>(
      () => StoreReportRemoteDataSourceImpl(client: getIt()));
}
