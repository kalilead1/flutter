import '../../featuers/stores/data/datasources/store_social_account_remote_data_source.dart';
import '../../featuers/stores/data/repositories/store_social_account_repository_impl.dart';
import '../../featuers/stores/domain/repositories/store_social_account_repository.dart';
import '../../featuers/stores/domain/usecases/store_social_account_usecase.dart';
import '../../featuers/stores/persentation/bloc/store_social_accounts/store_social_accounts_bloc.dart';
import '../initial.dart';

Future<void> initialStoreSocialAccounts() async {
  /// Bloc
  getIt.registerFactory(() => StoreSocialAccountsBloc(
        getStoreSocialUsecase: getIt(),
        addStoreSocialUsecase: getIt(),
        deleteStoreSocialUsecase: getIt(),
      ));

  // Use Cases
  getIt.registerLazySingleton(() => AddStoreSocialAccountUsecase(getIt()));
  getIt.registerLazySingleton(() => GetStoreSocialAccountsUsecase(getIt()));
  getIt.registerLazySingleton(() => DeleteStoreSocialAccountUsecase(getIt()));

  // Repository
  getIt.registerLazySingleton<StoreSocialAccountRepository>(
      () => StoreSocialAccountRepositoryImpl(
            remoteDataSource: getIt(),
            networkInfo: getIt(),
          ));

  // Data Sources
  getIt.registerLazySingleton<StoreSocialAccountRemoteDataSource>(
      () => StoreSocialAccountRemoteDataSourceImpl(client: getIt()));
}
