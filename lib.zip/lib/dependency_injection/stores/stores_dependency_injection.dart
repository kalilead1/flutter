import '../../featuers/stores/data/datasources/stores_remote_data_source.dart';
import '../../featuers/stores/data/repositories/stores_repository_impl.dart';
import '../../featuers/stores/domain/repositories/stores_repository.dart';
import '../../featuers/stores/domain/usecases/stores_usecase.dart';
import '../../featuers/stores/persentation/bloc/command_store/command_store_bloc.dart';
import '../../featuers/stores/persentation/bloc/stores/stores_bloc.dart';
import '../initial.dart';

Future<void> initialStores() async {
  /// Bloc
  getIt.registerFactory(
    () => StoresBloc(
      getAllStoresUsecase: getIt(),
      getStoreByIdUsecase: getIt(),
      getStoreByOwnerIdUsecase: getIt(),
    ),
  );

  getIt.registerFactory(() => CommandStoreBloc(addNewStoreUsecase: getIt()));

  // Use Cases
  getIt.registerLazySingleton(() => GetAllStoresUsecase(getIt()));
  getIt.registerLazySingleton(() => GetStoreByIdUsecase(getIt()));
  getIt.registerLazySingleton(() => GetStoreByOwnerIdUsecase(getIt()));
  getIt.registerLazySingleton(() => AddStoreUsecase(getIt()));
  getIt.registerLazySingleton(() => UpdateStoreUsecase(getIt()));

  // Repository
  getIt.registerLazySingleton<StoresRepository>(() => StoresRepositoryImpl(
        remoteDataSource: getIt(),
        storeSocialRemoteDataSource: getIt(),
        networkInfo: getIt(),
      ));

  // Data Sources
  getIt.registerLazySingleton<StoresRemoteDataSource>(
      () => StoresRemoteDataSourceImpl(client: getIt()));
}
