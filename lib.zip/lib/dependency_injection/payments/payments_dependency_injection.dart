import '../../featuers/payments/data/datasources/payments_remote_data_source.dart';
import '../../featuers/payments/data/repositories/payments_repository_impl.dart';
import '../../featuers/payments/domain/repositories/payments_repository.dart';
import '../../featuers/payments/domain/usecases/payments_usecase.dart';
import '../../featuers/payments/persentation/bloc/payments_query/payments_query_bloc.dart';
import '../initial.dart';

Future<void> initialPayments() async {
  /// Bloc
  getIt.registerFactory(
      () => PaymentsQueryBloc(getPaymentsByBookingIdUsecase: getIt()));
  // Use Cases
  getIt.registerLazySingleton(() => GetPaymentsByBookingIdUsecase(getIt()));
  getIt.registerLazySingleton(() => AddPaymentUsecase(getIt()));

  // Repository
  getIt.registerLazySingleton<PaymentsRepository>(() => PaymentsRepositoryImpl(
        remoteDataSource: getIt(),
        networkInfo: getIt(),
      ));

  // Data Sources
  getIt.registerLazySingleton<PaymentsRemoteDataSource>(
      () => PaymentsRemoteDataSourceImpl(client: getIt()));
}
