import '../../featuers/bookings/data/datasources/bookings_remote_data_source.dart';
import '../../featuers/bookings/data/repositories/bookings_repository_impl.dart';
import '../../featuers/bookings/domain/repositories/bookings_repository.dart';
import '../../featuers/bookings/domain/usecases/bookings_usecase.dart';
import '../../featuers/bookings/persentation/bloc/bookings_command/bookings_command_bloc.dart';
import '../../featuers/bookings/persentation/bloc/bookings_query/bookings_query_bloc.dart';
import '../initial.dart';

Future<void> initialBookings() async {
  /// Bloc
  getIt.registerFactory(
    () => BookingsCommandBloc(
      getBookingDateByServiceIdUsecase: getIt(),
      getStoreWalletsUsecase: getIt(),
      addBookingUsecase: getIt(),
      addPaymentUsecase: getIt(),
    ),
  );
  getIt.registerFactory(
    () => BookingsQueryBloc(
      getBookingsByUserIdUsecase: getIt(),
      getBookingsByStoreIdUsecase: getIt(),
      getBookingsByServiceIdUsecase: getIt(),
      getBookingByIdUsecase: getIt(),
      getBookingsDatesByServiceIdUsecase: getIt(),
    ),
  );
  // getIt.registerFactory(() => GetBookingsByStoreIdUsecase(getIt()));

  // Use Cases
  getIt.registerLazySingleton(() => GetBookingsByUserIdUsecase(getIt()));
  getIt.registerLazySingleton(() => GetBookingsByStoreIdUsecase(getIt()));
  getIt.registerLazySingleton(() => GetBookingsByServiceIdUsecase(getIt()));
  getIt.registerLazySingleton(() => GetBookingByIdUsecase(getIt()));
  getIt
      .registerLazySingleton(() => GetBookingsDatesByServiceIdUsecase(getIt()));
  getIt.registerLazySingleton(() => AddBookingUsecase(getIt()));

  // Repository
  getIt.registerLazySingleton<BookingsRepository>(() => BookingsRepositoryImpl(
        bookingsRemoteDataSource: getIt(),
        networkInfo: getIt(),
      ));

  // Data Sources
  getIt.registerLazySingleton<BookingsRemoteDataSource>(
      () => BookingsRemoteDataSourceImpl(client: getIt()));
}
