import 'package:booking_v1/featuers/auth/data/datasources/auth_local_data_source.dart';
import 'package:booking_v1/featuers/auth/domain/repositories/auth_repository.dart';
import 'package:booking_v1/featuers/auth/domain/usecases/auth_usecase.dart';
import 'package:booking_v1/featuers/auth/persentation/bloc/auth_command/auth_command_bloc.dart';

import '../../featuers/auth/data/datasources/auth_remote_data_source.dart';
import '../../featuers/auth/data/repositories/auth_repository_impl.dart';
import '../initial.dart';

Future<void> initialAuth() async {
  /// Bloc
  getIt.registerFactory(
    () => AuthCommandBloc(
      sendOtpUsecase: getIt(),
      verifyPhoneUsecase: getIt(),
      registerUsecase: getIt(),
    ),
  );

  // Use Cases
  getIt.registerLazySingleton(() => SendOtpUsecase(getIt()));
  getIt.registerLazySingleton(() => VerifyPhoneUsecase(getIt()));
  getIt.registerLazySingleton(() => RegisterUsecase(getIt()));

  // Repository
  getIt.registerLazySingleton<AuthRepository>(() => AuthRepositoryImpl(
        authLocalDataSource: getIt(),
        authRemoteDataSource: getIt(),
        networkInfo: getIt(),
      ));

  // Data Sources
  getIt.registerLazySingleton<AuthRemoteDataSource>(
      () => AuthRemoteDataSourceImpl(client: getIt()));
  getIt.registerLazySingleton<AuthLocalDataSource>(
      () => AuthLocalDataSourceImpl());
}
