import 'package:booking_v1/core/network/network_info.dart';
import 'package:http/http.dart' as http;
import 'package:get_it/get_it.dart';
import 'package:internet_connection_checker/internet_connection_checker.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'auth/auth_dependency_injection.dart';
import 'bookings/bookings_dependency_injection.dart';
import 'main/app_permission_dependency_injection.dart';
import 'main/cities_dependency_injection.dart';
import 'main/complaint_and_suggestion_dependency_injection.dart';
import 'main/directorates_dependency_injection.dart';
import 'main/social_accounts_dependency_injection.dart';
import 'payments/payments_dependency_injection.dart';
import 'services/service_images_dependency_injection.dart';
import 'stores/store_report_dependency_injection.dart';
import 'stores/store_social_accounts_dependency_injection.dart';
import 'stores/store_wallets_dependency_injection.dart';
import 'stores/stores_dependency_injection.dart';
import 'main/theme_initial.dart';
import 'services/services_dependency_injection.dart';
import 'main/wallets_dependency_injection.dart';
import 'main/categories_dependency_injection.dart';

final getIt = GetIt.instance;

Future<void> initial() async {
  await initialExternal();
  await initialCore();
  await initialTheme();

  await initialAuth();

  await initialWallets();
  await initialCategories();
  await initialDirectorates();
  await initialCities();
  await initialComplaintAndSuggestion();
  await initialSocialAccounts();
  await initialAppPermission();

  await initialServices();
  await initialServiceImages();

  await initialStores();
  await initialStoreReport();
  await initialStoreWallets();
  await initialStoreSocialAccounts();

  await initialBookings();

  await initialPayments();
}

Future<void> initialCore() async {
  getIt.registerLazySingleton<NetworkInfo>(() => NetworkInfoImpl(getIt()));
}

Future<void> initialExternal() async {
  final sharedPreferences = await SharedPreferences.getInstance();
  getIt.registerLazySingleton(() => sharedPreferences);
  getIt.registerLazySingleton(() => http.Client());
  getIt.registerLazySingleton(() => InternetConnectionChecker.createInstance());
}
