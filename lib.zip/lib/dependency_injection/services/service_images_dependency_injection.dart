import '../../featuers/services/data/datasources/service_images_remote_data_source.dart';
import '../../featuers/services/data/repositories/service_images_repository_impl.dart';
import '../../featuers/services/domain/repositories/service_images_repository.dart';
import '../../featuers/services/domain/usecases/service_images_usecase.dart';
import '../../featuers/services/persentation/bloc/service_images/service_images_bloc.dart';
import '../initial.dart';

Future<void> initialServiceImages() async {
  /// Bloc
  getIt.registerFactory(
    () => ServiceImagesBloc(
      getAllServiceImagesUsecase: getIt(),
      getServiceImageByIdUsecase: getIt(),
      addServiceImageUsecase: getIt(),
      deleteServiceImageUsecase: getIt(),
    ),
  );

  // Use Cases
  getIt.registerLazySingleton(
      () => GetAllServiceImagesByServiceIdUsecase(getIt()));
  getIt.registerLazySingleton(() => GetServiceImageByIdUsecase(getIt()));
  getIt.registerLazySingleton(() => AddServiceImageUsecase(getIt()));
  getIt.registerLazySingleton(() => DeleteServiceImageUsecase(getIt()));

  // Repository
  getIt.registerLazySingleton<ServiceImagesRepository>(
      () => ServiceImagesRepositoryImpl(
            serviceImagesRemoteDataSource: getIt(),
            networkInfo: getIt(),
          ));

  // Data Sources
  getIt.registerLazySingleton<ServiceImagesRemoteDataSource>(
      () => ServiceImagesRemoteDataSourceImpl(client: getIt()));
}
