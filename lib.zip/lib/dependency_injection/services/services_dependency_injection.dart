import '../../featuers/services/data/datasources/services_remote_data_source.dart';
import '../../featuers/services/data/repositories/services_repository_impl.dart';
import '../../featuers/services/domain/repositories/services_repository.dart';
import '../../featuers/services/domain/usecases/services_usecase.dart';
import '../../featuers/services/persentation/bloc/add_update_delete_service/add_update_delete_service_bloc.dart';
import '../../featuers/services/persentation/bloc/services/services_bloc.dart';
import '../initial.dart';

Future<void> initialServices() async {
  /// Bloc
  getIt.registerFactory(
    () => ServicesBloc(
      getAllServicesUsecase: getIt(),
      getServiceByIdUsecase: getIt(),
      getServiceByStoreIdUsecase: getIt(),
    ),
  );
  getIt.registerFactory(
    () => AddUpdateDeleteServiceBloc(
      addServiceImageUsecase: getIt(),
      addServiceUsecase: getIt(),
      updateServiceBaiscInfo: getIt(),
      updateServiceGloableInfo: getIt(),
    ),
  );

  // Use Cases
  getIt.registerLazySingleton(() => GetAllServicesUsecase(getIt()));
  getIt.registerLazySingleton(() => GetServiceByIdUsecase(getIt()));
  getIt.registerLazySingleton(() => GetServiceByStoreIdUsecase(getIt()));

  getIt.registerLazySingleton(() => AddServiceUsecase(getIt()));
  getIt.registerLazySingleton(() => UpdateServiceBaiscInfoUsecase(getIt()));
  getIt.registerLazySingleton(() => UpdateServiceGloableInfoUsecase(getIt()));

  // Repository
  getIt.registerLazySingleton<ServicesRepository>(() => ServicesRepositoryImpl(
      servicesRemoteDataSource: getIt(), networkInfo: getIt()));

  // Data Sources
  getIt.registerLazySingleton<ServicesRemoteDataSource>(
      () => ServicesRemoteDataSourceImpl(client: getIt()));
}
