import '../../featuers/main/data/datasources/cities_remote_data_source.dart';
import '../../featuers/main/data/repositories/cities_repository_impl.dart';
import '../../featuers/main/domain/repositories/cities_repository.dart';
import '../../featuers/main/domain/usecases/cities_usecase.dart';
import '../../featuers/main/persentation/blocs/cities/cities_bloc.dart';
import '../initial.dart';

Future<void> initialCities() async {
  /// Bloc
  getIt.registerFactory(
    () => CitiesBloc(getAllCitiesUsecase: getIt()),
  );

  // Use Cases
  getIt.registerLazySingleton(() => GetAllCitiesUsecase(getIt()));

  // Repository
  getIt.registerLazySingleton<CitiesRepository>(() => CitiesRepositoryImpl(
        citiesRemoteDataSource: getIt(),
        networkInfo: getIt(),
      ));

  // Data Sources
  getIt.registerLazySingleton<CitiesRemoteDataSource>(
      () => CitiesRemoteDataSourceImpl(client: getIt()));
}
