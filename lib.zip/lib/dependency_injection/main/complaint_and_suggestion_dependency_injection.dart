import '../../featuers/main/data/datasources/complaint_and_suggestion_remote_data_source.dart';
import '../../featuers/main/data/repositories/complaint_and_suggestion_repository_impl.dart';
import '../../featuers/main/domain/repositories/complaint_and_suggestion_repository.dart';
import '../../featuers/main/domain/usecases/complaint_and_suggestion_usecase.dart';
import '../../featuers/main/persentation/blocs/complaint_and_suggestion/complaint_and_suggestion_bloc.dart';
import '../initial.dart';

Future<void> initialComplaintAndSuggestion() async {
  /// Bloc
  getIt.registerFactory(() => ComplaintAndSuggestionBloc(addUsecase: getIt()));

  // Use Cases
  getIt.registerLazySingleton(() => AddComplaintAndSuggestionUsecase(getIt()));

  // Repository
  getIt.registerLazySingleton<ComplaintAndSuggestionRepository>(
      () => ComplaintAndSuggestionRepositoryImpl(
            remoteDataSource: getIt(),
            networkInfo: getIt(),
          ));

  // Data Sources
  getIt.registerLazySingleton<ComplaintAndSuggestionRemoteDataSource>(
      () => ComplaintAndSuggestionRemoteDataSourceImpl(client: getIt()));
}
