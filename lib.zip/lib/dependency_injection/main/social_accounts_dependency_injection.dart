import '../../featuers/main/data/datasources/social_accounts_remote_data_source.dart';
import '../../featuers/main/data/repositories/social_accounts_repository_impl.dart';
import '../../featuers/main/domain/repositories/social_accounts_repository.dart';
import '../../featuers/main/domain/usecases/social_accounts_usecase.dart';
import '../../featuers/main/persentation/blocs/social_accounts/social_accounts_bloc.dart';
import '../initial.dart';

Future<void> initialSocialAccounts() async {
  /// Bloc
  getIt.registerFactory(
    () => SocialAccountsBloc(
      getAllSocialAccountsUsecase: getIt(),
    ),
  );

  // Use Cases
  getIt.registerLazySingleton(() => GetAllSocialAccountsUsecase(getIt()));

  // Repository
  getIt.registerLazySingleton<SocialAccountsRepository>(
      () => SocialAccountsRepositoryImpl(
            remoteDataSource: getIt(),
            networkInfo: getIt(),
          ));

  // Data Sources
  getIt.registerLazySingleton<SocialAccountsRemoteDataSource>(
      () => SocialAccountsRemoteDataSourceImpl(client: getIt()));
}
