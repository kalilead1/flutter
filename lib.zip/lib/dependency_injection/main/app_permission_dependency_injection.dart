import '../../featuers/main/data/repositories/app_permission_repository_impl.dart';
import '../../featuers/main/domain/repositories/app_permission_repository.dart';
import '../../featuers/main/domain/usecases/app_permissions_usecase.dart';
import '../../featuers/main/persentation/blocs/app_permissions/app_permission_bloc.dart';
import '../initial.dart';

Future<void> initialAppPermission() async {
  /// Bloc
  getIt.registerFactory(
    () => PermissionBloc(useCase: getIt()),
  );

  // Use Cases
  getIt.registerLazySingleton(() => RequestPermissionsUseCase(getIt()));

  // Repository
  getIt.registerLazySingleton<AppPermissionRepository>(
      () => AppPermissionRepositoryImpl());

  // Data Sources
}
