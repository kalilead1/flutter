import '../../featuers/main/data/datasources/wallets_remote_data_source.dart';
import '../../featuers/main/data/repositories/wallets_repository_impl.dart';
import '../../featuers/main/domain/repositories/wallets_repository.dart';
import '../../featuers/main/domain/usecases/wallets_usecase.dart';
import '../../featuers/main/persentation/blocs/wallets/wallets_bloc.dart';
import '../initial.dart';

Future<void> initialWallets() async {
  /// Bloc
  getIt.registerFactory(
    () => WalletsBloc(getAllWalletUsecase: getIt()),
  );

  // Use Cases
  getIt.registerLazySingleton(() => GetAllWalletsUsecase(getIt()));

  // Repository
  getIt.registerLazySingleton<WalletsRepository>(() => WalletsRepositoryImpl(
        walletsRemoteDataSource: getIt(),
        networkInfo: getIt(),
      ));

  // Data Sources
  getIt.registerLazySingleton<WalletsRemoteDataSource>(
      () => WalletsRemoteDataSourceImpl(client: getIt()));
}
