import '../../featuers/main/data/datasources/categories_remote_data_source.dart';
import '../../featuers/main/data/repositories/categories_repository_impl.dart';
import '../../featuers/main/domain/repositories/categories_repository.dart';
import '../../featuers/main/domain/usecases/categories_usecase.dart';
import '../../featuers/main/persentation/blocs/categories/categories_bloc.dart';
import '../initial.dart';

Future<void> initialCategories() async {
  /// Bloc
  getIt.registerFactory(
    () => CategoriesBloc(getAllCategoriesUsecase: getIt()),
  );

  // Use Cases
  getIt.registerLazySingleton(() => GetAllCategoriesUsecase(getIt()));

  // Repository
  getIt.registerLazySingleton<CategoriesRepository>(
      () => CategoriesRepositoryImpl(
            categoriesRemoteDataSource: getIt(),
            networkInfo: getIt(),
          ));

  // Data Sources
  getIt.registerLazySingleton<CategoriesRemoteDataSource>(
      () => CategoriesRemoteDataSourceImpl(client: getIt()));
}
