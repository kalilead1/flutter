import '../../featuers/main/data/datasources/directorates_remote_data_source.dart';
import '../../featuers/main/data/repositories/directorates_repository_impl.dart';
import '../../featuers/main/domain/repositories/directorates_repository.dart';
import '../../featuers/main/domain/usecases/directorates_usecase.dart';
import '../../featuers/main/persentation/blocs/directorates/directorates_bloc.dart';
import '../initial.dart';

Future<void> initialDirectorates() async {
  /// Bloc
  getIt.registerFactory(
    () => DirectoratesBloc(getAllDirectoratesUsecase: getIt()),
  );

  // Use Cases
  getIt.registerLazySingleton(() => GetAllDirectoratesUsecase(getIt()));

  // Repository
  getIt.registerLazySingleton<DirectoratesRepository>(
      () => DirectoratesRepositoryImpl(
            directoratesRemoteDataSource: getIt(),
            networkInfo: getIt(),
          ));

  // Data Sources
  getIt.registerLazySingleton<DirectoratesRemoteDataSource>(
      () => DirectoratesRemoteDataSourceImpl(client: getIt()));
}
