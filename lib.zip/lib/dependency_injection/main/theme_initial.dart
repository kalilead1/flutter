import '../../featuers/main/data/datasources/theme_local_data_source.dart';
import '../../featuers/main/data/repositories/theme_erpository_impl.dart';
import '../../featuers/main/domain/repositories/theme_repository.dart';
import '../../featuers/main/persentation/blocs/theme/theme_bloc.dart';
import '../initial.dart';

Future<void> initialTheme() async {
  // Bloc
  getIt.registerFactory(() => ThemeBloc(getIt()));

  // Repository
  getIt.registerLazySingleton<ThemeRepository>(
    () => ThemeRepositoryImpl(getIt()),
  );

  // Data Source
  getIt.registerLazySingleton(() => ThemeLocalDataSource());
}
