import 'package:booking_v1/core/errors/exception.dart';
import 'package:booking_v1/core/errors/failures.dart';
import 'package:booking_v1/core/network/network_info.dart';
import 'package:booking_v1/featuers/auth/data/models/user_model.dart';
import 'package:dartz/dartz.dart';

import '../../domain/entities/user.dart';
import '../../domain/repositories/auth_repository.dart';
import '../datasources/auth_local_data_source.dart';
import '../datasources/auth_remote_data_source.dart';

class AuthRepositoryImpl implements AuthRepository {
  final AuthRemoteDataSource authRemoteDataSource;
  final AuthLocalDataSource authLocalDataSource;
  final NetworkInfo networkInfo;

  AuthRepositoryImpl({
    required this.authRemoteDataSource,
    required this.authLocalDataSource,
    required this.networkInfo,
  });

  @override
  Future<Either<Failure, Unit>> sendOtp(String phoneNumber) async {
    // if (await networkInfo.isConnected) {
    try {
      final remoteSource = await authRemoteDataSource.sendOtp(phoneNumber);
      return Right(remoteSource);
    } on ServerException {
      return Left(ServerFailure());
    }
    // } else {
    //   return Left(OfflineFailure());
    // }
  }

  @override
  Future<Either<Failure, User?>> verifyPhone(
      String phoneNumber, int code) async {
    // if (await networkInfo.isConnected) {
    try {
      final remoteSource =
          await authRemoteDataSource.verifyPhone(phoneNumber, code);

      return Right(remoteSource);
    } on ServerException {
      return Left(ServerFailure());
    }
    // } else {
    //   return Left(OfflineFailure());
    // }
  }

  @override
  Future<Either<Failure, User>> register(User user) async {
    // if (await networkInfo.isConnected) {
    try {
      final dataUser = UserModel(
        name: user.name,
        image: user.image,
        directorateId: user.directorateId,
        phoneNumber: user.phoneNumber,
        roleId: user.roleId,
      );
      final remoteSource = await authRemoteDataSource.register(dataUser);

      return Right(remoteSource);
    } on ServerException {
      return Left(ServerFailure());
    }
    // } else {
    //   return Left(OfflineFailure());
    // }
  }

  @override
  Future<Either<Failure, User>> updateUser(User user) async {
    // if (await networkInfo.isConnected) {
    try {
      final dataUser = UserModel(
        // id: user.id,
        name: user.name,
        image: user.image,
        directorateId: user.directorateId,
        phoneNumber: user.phoneNumber,
        roleId: user.roleId,
      );
      final remoteSource = await authRemoteDataSource.updateUser(dataUser);

      return Right(remoteSource);
    } on ServerException {
      return Left(ServerFailure());
    }
    // } else {
    //   return Left(OfflineFailure());
    // }
  }

  @override
  Future<Either<Failure, Unit>> logout() async {
    // if (await networkInfo.isConnected) {
    try {
      final remoteSource = await authRemoteDataSource.logout();
      return Right(remoteSource);
    } on ServerException {
      return Left(ServerFailure());
    }
    // } else {
    //   return Left(OfflineFailure());
    // }
  }
}
