import '../../domain/entities/user.dart';

class UserModel extends User {
  const UserModel({
    super.id,
    super.name,
    super.phoneNumber,
    super.image,
    super.roleId,
    super.directorateId,
  });

  factory UserModel.fromJson(Map<String, dynamic> json) {
    return UserModel(
      id: json['id'],
      name: json['name'],
      phoneNumber: json['phoneNumber'],
      image: json['image'],
      roleId: json['roleId'],
      directorateId: json['directorateId'],
    );
  }
  Map<String, dynamic> toJson() => {
        "name": name,
        "phoneNumber": phoneNumber,
        "image": image,
        "roleId": roleId,
        "directorateId": directorateId,
      };
}
