import 'package:booking_v1/featuers/auth/domain/entities/user.dart';
import 'package:dartz/dartz.dart';

abstract class AuthLocalDataSource {
  Future<User?> getUser();
  Future<Unit> saveUser(User user);
  Future<Unit> updateUser(User user);
  Future<Unit> deleteUser();
}

class AuthLocalDataSourceImpl implements AuthLocalDataSource {
  AuthLocalDataSourceImpl();

  @override
  Future<User?> getUser() async {
    // TODO: implement getUser
    throw UnimplementedError();
  }

  @override
  Future<Unit> saveUser(User user) async {
    // TODO: implement saveUser
    throw UnimplementedError();
  }

  @override
  Future<Unit> updateUser(User user) async {
    // TODO: implement updateUser
    throw UnimplementedError();
  }

  @override
  Future<Unit> deleteUser() async {
    // TODO: implement deleteUser
    throw UnimplementedError();
  }
}
