import 'dart:convert';

import 'package:booking_v1/featuers/auth/data/models/user_model.dart';
import 'package:booking_v1/featuers/auth/domain/entities/user.dart';
import 'package:dartz/dartz.dart';
import 'package:http/http.dart' as http;

import '../../../../core/constants/api.dart';
import '../../../../core/errors/exception.dart';

abstract class AuthRemoteDataSource {
  Future<Unit> sendOtp(String phoneNumber);
  Future<User?> verifyPhone(String phoneNumber, int code);
  Future<User> register(UserModel userModel);
  Future<User> updateUser(UserModel userModel);
  Future<Unit> logout();
}

const String authUrl = "Auth/";

class AuthRemoteDataSourceImpl implements AuthRemoteDataSource {
  final http.Client client;

  AuthRemoteDataSourceImpl({required this.client});

  @override
  Future<Unit> sendOtp(String phoneNumber) async {
    final String url = "send-otp";
    final data = {"phoneNumber": phoneNumber};
    final response = await client.post(Uri.parse(baseUrl + authUrl + url),
        headers: {"Content-Type": "application/json"}, body: data);
    if (response.statusCode == 201 || response.statusCode == 200) {
      return Future.value(unit);
    } else {
      throw ServerException();
    }
  }

  @override
  Future<User?> verifyPhone(String phoneNumber, int code) async {
    final String url = "verify-phone_Login";
    final data = {"phoneNumber": phoneNumber, "code": code};
    final response = await client.post(Uri.parse(baseUrl + authUrl + url),
        headers: {"Content-Type": "application/json"}, body: data);
    if (response.statusCode == 201 || response.statusCode == 200) {
      return UserModel.fromJson(json.decode(response.body));
    } else {
      throw ServerException();
    }
  }

  @override
  Future<User> register(UserModel userModel) async {
    final String url = "register";
    final data = jsonEncode(userModel.toJson());
    final response = await client.post(Uri.parse(baseUrl + authUrl + url),
        headers: {"Content-Type": "application/json"}, body: data);
    if (response.statusCode == 201 || response.statusCode == 200) {
      return UserModel.fromJson(json.decode(response.body));
    } else {
      throw ServerException();
    }
  }

  @override
  Future<User> updateUser(UserModel userModel) async {
    final String url = "updated";
    final data = jsonEncode(userModel.toJson());
    final response = await client.put(Uri.parse(baseUrl + authUrl + url),
        headers: {"Content-Type": "application/json"}, body: data);
    if (response.statusCode == 201 || response.statusCode == 200) {
      return UserModel.fromJson(json.decode(response.body));
    } else {
      throw ServerException();
    }
  }

  @override
  Future<Unit> logout() async {
    final String url = "logout";
    final response = await client.post(Uri.parse(baseUrl + authUrl + url),
        headers: {"Content-Type": "application/json"});
    if (response.statusCode == 201 || response.statusCode == 200) {
      return Future.value(unit);
    } else {
      throw ServerException();
    }
  }
}
