import 'package:booking_v1/featuers/auth/domain/entities/user.dart';
import 'package:equatable/equatable.dart';

abstract class AuthCommandState extends Equatable {
  const AuthCommandState();
  @override
  List<Object?> get props => [];
}

class InitialAuthState extends AuthCommandState {}

class LoadingAuthState extends AuthCommandState {}

class SuccessfullyAuthState extends AuthCommandState {
  final String message;

  const SuccessfullyAuthState({required this.message});

  @override
  List<Object?> get props => [message];
}

class ErrorAuthState extends AuthCommandState {
  final String message;

  const ErrorAuthState({required this.message});

  @override
  List<Object?> get props => [message];
}

class EditingLoginState extends AuthCommandState {
  final String? phoneNumber;
  final int? code;
  final User? user;
  // final String? image;
  // final String? name;
  // final int? directorateId;

  const EditingLoginState({this.phoneNumber, this.code, this.user});

  @override
  List<Object?> get props => [phoneNumber, code, user];
}
