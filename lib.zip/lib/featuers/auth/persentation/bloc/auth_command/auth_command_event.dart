import 'package:booking_v1/featuers/auth/domain/entities/user.dart';
import 'package:equatable/equatable.dart';

abstract class AuthCommandEvent extends Equatable {
  const AuthCommandEvent();
  @override
  List<Object?> get props => [];
}

class SendOtpEvent extends AuthCommandEvent {
  final String phoneNumber;
  const SendOtpEvent({required this.phoneNumber});

  @override
  List<Object?> get props => [phoneNumber];
}

class VerifyPhoneEvent extends AuthCommandEvent {
  final int code;

  const VerifyPhoneEvent({required this.code});

  @override
  List<Object?> get props => [code];
}

class RegisterEvent extends AuthCommandEvent {
  final User user;

  const RegisterEvent({required this.user});

  @override
  List<Object?> get props => [user];
}
