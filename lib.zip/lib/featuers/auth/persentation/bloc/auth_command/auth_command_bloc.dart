import 'package:booking_v1/featuers/auth/domain/entities/user.dart';
import 'package:booking_v1/featuers/auth/domain/usecases/auth_usecase.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../../../../core/routing/app_routes.dart';
import '../../../../../core/routing/navigation_service.dart';
import 'auth_command_event.dart';
import 'auth_command_state.dart';

class AuthCommandBloc extends Bloc<AuthCommandEvent, AuthCommandState> {
  final SendOtpUsecase? sendOtpUsecase;
  final VerifyPhoneUsecase? verifyPhoneUsecase;
  final RegisterUsecase? registerUsecase;

  String? phoneNumber;
  int? code;
  User? user;

  AuthCommandBloc({
    this.sendOtpUsecase,
    this.verifyPhoneUsecase,
    this.registerUsecase,
  }) : super(InitialAuthState()) {
    on<SendOtpEvent>((event, emit) async {
      emit(LoadingAuthState());

      phoneNumber = event.phoneNumber;
      emit(_commandState());
      NavigationService.push(otpVerificationRoute);
    });
    on<VerifyPhoneEvent>((event, emit) async {
      emit(LoadingAuthState());

      code = event.code;

      emit(_commandState());

      if (code == 111111) {
        NavigationService.replace(entryPointRoute, extra: 3);
        emit(SuccessfullyAuthState(message: "تم تسجيل الدخول"));
      } else if (code == 000000) {
        NavigationService.push(registerAccountRoute);
      } else {
        emit(ErrorAuthState(message: "رمز الكود خطاء"));
        emit(_commandState());
      }
    });
    on<RegisterEvent>((event, emit) async {
      emit(LoadingAuthState());

      user = event.user;
      emit(_commandState());
      emit(SuccessfullyAuthState(
          message: "مرحبا ${user!.name}، تم تسجيل الدخول"));
      NavigationService.replace(entryPointRoute, extra: 0);
    });
  }

  AuthCommandState _commandState() {
    return EditingLoginState(
      phoneNumber: phoneNumber,
      code: code,
      user: user,
    );
  }
}
