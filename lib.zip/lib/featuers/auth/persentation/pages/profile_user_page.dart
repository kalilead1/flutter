import 'package:booking_v1/core/routing/router_extensions.dart';
import 'package:flutter/material.dart';

import '../../../../core/widgets/bottom_items.dart';
import '../../../../core/widgets/botton_widghts.dart';
import '../../../../core/constants/strings.dart';
import '../../../../core/widgets/image_picker/widgets/single_image_picker_widget.dart';
import '../../../../core/widgets/input_widgets.dart';
import '../../../main/data/repositories/directorates_repository_impl.dart';
import '../../../main/persentation/widgets/selections/selection_category_widget.dart';
import '../../../main/persentation/widgets/selections/selection_city_widget.dart';
import '../../../main/persentation/widgets/selections/selection_directorate_widget.dart';

class ProfileUserPage extends StatefulWidget {
  final int userId;
  const ProfileUserPage({super.key, required this.userId});

  @override
  State<ProfileUserPage> createState() => _ProfileUserPageState();
}

class _ProfileUserPageState extends State<ProfileUserPage> {
  final TextEditingController _userNameEditingController =
      TextEditingController();
  // final TextEditingController _walletEditingController =
  //     TextEditingController(text: "1");
  final TextEditingController _categoryEditingController =
      TextEditingController(text: "12");
  int? cityId;
  // final TextEditingController _cityEditingController = TextEditingController();
  final TextEditingController _directorateEditingController =
      TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          title: const Text("تعديل الحساب"),
        ),
        body: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.all(defaultPadding),
            child: Form(
              child: Column(
                spacing: defaultSpacing,
                children: [
                  SingleImagePicker(),

                  CustomInputFieldWidget(
                    label: "اسم المستخدم",
                    textController: _userNameEditingController,
                  ),
                  SelectionCategoriesWidget(
                    // initCategoryId: 12,
                    onSelected: (categoryId) {
                      setState(() {
                        _categoryEditingController.text = categoryId;
                      });
                    },
                  ),
                  Text("category id : ${_categoryEditingController.text}"),

                  ////////////////////////////////////////////////////////////
                  ////////////////////////////////////////////////////////////

                  SelectionCityWidget(
                    onSelected: (cityId) {
                      setState(() {
                        cityId = cityId;
                        cacheDirectoratesList = [];
                        // _directorateEditingController.text = '';
                      });
                    },
                  ),
                  Text("city id : $cityId"),

                  ////////////////////////////////////////////////////////////
                  ////////////////////////////////////////////////////////////

                  SelectionDirectorateWidget(
                    cityId: cityId,
                    onSelected: (directorateId) {
                      final temp = cityId;
                      if (temp != cityId) {
                        setState(() {
                          _directorateEditingController.text = directorateId;
                          cityId = null;
                        });
                      }
                      setState(() {
                        _directorateEditingController.text = directorateId;
                      });
                    },
                  ),
                  Text(
                      "directorate id : ${_directorateEditingController.text}"),

                  ////////////////////////////////////////////////////////////
                  ////////////////////////////////////////////////////////////
                ],
              ),
            ),
          ),
        ),
        bottomNavigationBar: TwoBottomItems(
          child1: PrimaryElevatedButton(
            onPressed: () {},
            text: "حفظ",
          ),
          child2: SecondaryElevatedButton(
            onPressed: () {
              context.back();
            },
            text: "الغاء",
          ),
        ),
      ),
    );
  }
}
