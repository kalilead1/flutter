import 'package:booking_v1/core/widgets/botton_widghts.dart';
import 'package:booking_v1/core/widgets/snack_bar_widgets.dart';
import 'package:booking_v1/featuers/main/persentation/widgets/theme_bottom_sheet.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../../../core/constants/strings.dart';
import '../bloc/auth_command/auth_command_bloc.dart';
import '../bloc/auth_command/auth_command_event.dart';
import '../bloc/auth_command/auth_command_state.dart';
import '../widgets/forms/otp_verification_form.dart';

// class OtpVerificationPage extends StatelessWidget {
//   final String phoneNumper;
//   const OtpVerificationPage({super.key, required this.phoneNumper});

//   @override
//   Widget build(BuildContext context) {
//     return Directionality(
//       textDirection: TextDirection.rtl,
//       child: Scaffold(
//         appBar: AppBar(
//           title: Text("التحقق من الكود"),
//         ),
//         body: SingleChildScrollView(
//           child: Padding(
//             padding: EdgeInsets.all(defaultPadding),
//             child: Column(
//               spacing: defaultSpacing,
//               crossAxisAlignment: CrossAxisAlignment.start,
//               children: [
//                 Column(
//                   crossAxisAlignment: CrossAxisAlignment.start,
//                   children: [
//                     Text(
//                       "سيتم ارسال الكود الى:",
//                       style: Theme.of(context).textTheme.bodyLarge,
//                     ),
//                     Row(
//                       spacing: defaultSpacing,
//                       children: [
//                         Directionality(
//                           textDirection: TextDirection.ltr,
//                           child: Text(
//                             "+967 $phoneNumper",
//                             style: Theme.of(context).textTheme.titleMedium,
//                           ),
//                         ),
//                         TextButton(
//                           onPressed: () {},
//                           child: Text(
//                             "تغيير رقم الهاتف؟",
//                             style: Theme.of(context).textTheme.displaySmall,
//                           ),
//                         ),
//                       ],
//                     ),
//                   ],
//                 ),
//                 SizedBox(),
//                 OtpVerificationForm()
//               ],
//             ),
//           ),
//         ),
//       ),
//     );
//   }
// }

class OtpVerificationPage extends StatefulWidget {
  const OtpVerificationPage({super.key});

  @override
  State<OtpVerificationPage> createState() => _OtpVerificationPageState();
}

class _OtpVerificationPageState extends State<OtpVerificationPage> {
  final _formKey = GlobalKey<FormState>();
  final List<TextEditingController> _controllers =
      List.generate(6, (_) => TextEditingController());

  @override
  void dispose() {
    for (var c in _controllers) {
      c.dispose();
    }
    super.dispose();
  }

  String _getCode() => _controllers.map((c) => c.text).join();

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          title: const Text("التحقق من الكود"),
          actions: [
            IconButton(
              onPressed: () => showThemeSheet(context),
              icon: Icon(
                Theme.of(context).brightness == Brightness.dark
                    ? Icons.dark_mode_rounded
                    : Icons.wb_sunny_rounded,
              ),
            )
          ],
        ),
        body: BlocConsumer<AuthCommandBloc, AuthCommandState>(
          listener: (context, state) {
            if (state is SuccessfullyAuthState) {
              return showSnackBarSuccess(
                  context: context, success: state.message);
            }
            if (state is ErrorAuthState) {
              for (var c in _controllers) {
                c.clear();
              }
              return showSnackBarError(context: context, error: state.message);
            }
          },
          builder: (context, state) {
            if (state is LoadingAuthState) {
              return Center(child: CircularProgressIndicator());
            } else if (state is EditingLoginState) {
              return Form(
                key: _formKey,
                child: Column(
                  children: [
                    Expanded(
                      child: SingleChildScrollView(
                        padding: const EdgeInsets.all(defaultPadding),
                        child: Column(
                          spacing: 16,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            // نص المعلومات
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text("سيتم ارسال الكود الى:",
                                    style:
                                        Theme.of(context).textTheme.bodyLarge),
                                Row(
                                  spacing: 8,
                                  children: [
                                    Directionality(
                                      textDirection: TextDirection.ltr,
                                      child: Text("+967 ${state.phoneNumber}",
                                          style: Theme.of(context)
                                              .textTheme
                                              .titleMedium),
                                    ),
                                    TextButton(
                                      onPressed: () {},
                                      child: Text("تغيير رقم الهاتف؟",
                                          style: Theme.of(context)
                                              .textTheme
                                              .displaySmall),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                            // حقول OTP
                            OtpVerificationForm(controllers: _controllers),
                          ],
                        ),
                      ),
                    ),
                    // الزر في الأسفل
                    Padding(
                      padding: const EdgeInsets.all(defaultPadding),
                      child: PrimaryElevatedButton(
                        onPressed: () {
                          if (_formKey.currentState!.validate()) {
                            context.read<AuthCommandBloc>().add(
                                VerifyPhoneEvent(code: int.parse(_getCode())));
                          }
                        },
                        text: "تحقق",
                      ),
                    ),
                  ],
                ),
              );
            } else {
              return Center(child: Text(unknownFailureMessage));
            }
          },
        ),
      ),
    );
  }
}
