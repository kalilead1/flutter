import 'package:booking_v1/core/constants/strings.dart';
import 'package:booking_v1/core/widgets/botton_widghts.dart';
import 'package:booking_v1/core/widgets/image_picker/widgets/single_image_picker_widget.dart';
import 'package:booking_v1/core/widgets/input_widgets.dart';
import 'package:booking_v1/featuers/auth/domain/entities/user.dart';
import 'package:booking_v1/featuers/main/data/repositories/directorates_repository_impl.dart';
import 'package:booking_v1/featuers/main/persentation/widgets/selections/selection_city_widget.dart';
import 'package:booking_v1/featuers/main/persentation/widgets/selections/selection_directorate_widget.dart';
import 'package:booking_v1/featuers/main/persentation/widgets/theme_bottom_sheet.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../../../core/widgets/snack_bar_widgets.dart';
import '../bloc/auth_command/auth_command_bloc.dart';
import '../bloc/auth_command/auth_command_event.dart';
import '../bloc/auth_command/auth_command_state.dart';

class RegisterAccountPage extends StatefulWidget {
  const RegisterAccountPage({super.key});

  @override
  State<RegisterAccountPage> createState() => _RegisterAccountPageState();
}

class _RegisterAccountPageState extends State<RegisterAccountPage> {
  final keyForm = GlobalKey<FormState>();
  final TextEditingController _userNameController = TextEditingController();
  int? cityId;
  int? directorateId;
  String? image;

  void regester() {
    if (keyForm.currentState!.validate()) {
      context.read<AuthCommandBloc>().add(
            RegisterEvent(
                user: User(
              image: image,
              name: _userNameController.text,
              directorateId: directorateId,
            )),
          );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          title: const Text("انشاء حساب"),
          actions: [
            IconButton(
              onPressed: () => showThemeSheet(context),
              icon: Icon(
                Theme.of(context).brightness == Brightness.dark
                    ? Icons.dark_mode_rounded
                    : Icons.wb_sunny_rounded,
              ),
            )
          ],
        ),
        body: BlocConsumer<AuthCommandBloc, AuthCommandState>(
          listener: (context, state) {
            if (state is SuccessfullyAuthState) {
              return showSnackBarSuccess(
                  context: context, success: state.message);
            }
            if (state is ErrorAuthState) {
              return showSnackBarError(context: context, error: state.message);
            }
          },
          builder: (context, state) {
            if (state is LoadingAuthState) {
              return Center(child: CircularProgressIndicator());
            } else if (state is EditingLoginState) {
              return Padding(
                padding: const EdgeInsets.all(defaultPadding),
                child: Form(
                  key: keyForm,
                  child: Column(
                    children: [
                      Expanded(
                        child: SingleChildScrollView(
                          padding: const EdgeInsets.only(bottom: 5),
                          child: Column(
                            spacing: defaultSpacing,
                            children: [
                              SingleImagePicker(
                                label: "",
                                onChanged: (value) => setState(() {
                                  image = value!.path;
                                }),
                              ),
                              ////////////////////////////////////////////////////////////
                              CustomInputFieldWidget(
                                label: "اسم المستخدم",
                                textController: _userNameController,
                                textInputType: TextInputType.name,
                              ),
                              ////////////////////////////////////////////////////////////
                              Row(
                                spacing: defaultSpacing,
                                children: [
                                  Expanded(
                                    child: SelectionCityWidget(
                                      onSelected: (value) {
                                        setState(() {
                                          cityId = value;
                                          cacheDirectoratesList = [];
                                        });
                                      },
                                    ),
                                  ),
                                  Expanded(
                                    child: SelectionDirectorateWidget(
                                      cityId: cityId,
                                      onSelected: (value) {
                                        setState(() {
                                          directorateId = value;
                                        });
                                      },
                                    ),
                                  ),
                                ],
                              ),
                              ////////////////////////////////////////////////////////////
                            ],
                          ),
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(top: 6),
                        child: PrimaryElevatedButton(
                          onPressed: () {
                            regester();
                          },
                          text: "انشاء حساب",
                        ),
                      ),
                    ],
                  ),
                ),
              );
            } else {
              return Center(child: Text(unknownFailureMessage));
            }
          },
        ),
      ),
    );
  }
}
