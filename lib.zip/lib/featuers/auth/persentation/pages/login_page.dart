import 'package:booking_v1/featuers/auth/persentation/bloc/auth_command/auth_command_event.dart';
import 'package:booking_v1/featuers/main/persentation/widgets/theme_bottom_sheet.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../../../core/constants/strings.dart';
import '../../../../core/widgets/app_logo.dart';
import '../../../../core/widgets/botton_widghts.dart';
import '../bloc/auth_command/auth_command_bloc.dart';
import '../widgets/forms/login_form.dart';

class LoginPage extends StatelessWidget {
  const LoginPage({super.key});

  @override
  Widget build(BuildContext context) {
    final keyForm = GlobalKey<FormState>();
    TextEditingController phoneController = TextEditingController();
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          title: const Text("تسجيل الدخول"),
          actions: [
            IconButton(
              onPressed: () => showThemeSheet(context),
              icon: Icon(
                Theme.of(context).brightness == Brightness.dark
                    ? Icons.dark_mode_rounded
                    : Icons.wb_sunny_rounded,
              ),
            )
          ],
        ),
        body: Column(
          children: [
            Expanded(
              child: SingleChildScrollView(
                padding: EdgeInsets.all(defaultPadding),
                child: Column(
                  spacing: defaultSpacing,
                  children: [
                    AppLogoPrimary(),
                    SizedBox(),
                    Column(
                      children: [
                        Text(
                          "مرحبا بك",
                          style: TextStyle(
                              fontSize: 26,
                              color: Theme.of(context)
                                  .textTheme
                                  .titleLarge!
                                  .color),
                        ),
                        Text(
                          "في تطبيق يمن حجز",
                          style: Theme.of(context).textTheme.bodyLarge,
                        ),
                      ],
                    ),
                    SizedBox(),
                    SizedBox(),
                    LoginForm(
                        keyForm: keyForm, phoneController: phoneController),
                  ],
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(defaultPadding),
              child: PrimaryElevatedButton(
                onPressed: () {
                  if (keyForm.currentState!.validate()) {
                    context
                        .read<AuthCommandBloc>()
                        .add(SendOtpEvent(phoneNumber: phoneController.text));
                  }
                },
                text: "تسجيل",
              ),
            ),
          ],
        ),
      ),
    );
  }
}
