import 'package:booking_v1/core/routing/app_routes.dart';
import 'package:booking_v1/core/routing/router_extensions.dart';
import 'package:flutter/material.dart';

import '../../../../core/constants/strings.dart';
import '../../../../core/widgets/botton_widghts.dart';

class ViewLoginWidget extends StatelessWidget {
  const ViewLoginWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        // crossAxisAlignment: CrossAxisAlignment.center,
        mainAxisAlignment: MainAxisAlignment.center,
        spacing: defaultSpacing,
        children: [
          Icon(
            Icons.no_accounts,
            size: 70,
            color: Theme.of(context).colorScheme.tertiary,
          ),
          SizedBox(height: defaultSpacing),
          Text(
            noLoginFailureMessage,
            style: TextStyle(fontSize: 14),
          ),
          SizedBox(
            width: 200,
            child: SecondaryElevatedButton(
              onPressed: () {
                context.pushTo(logInRoute);
              },
              text: "تسجيل الدخول",
            ),
          ),
        ],
      ),
    );
  }
}

// void ViewLoginBottomSheetWidget({required BuildContext context}) {
//   showModalBottomSheet(
//     scrollControlDisabledMaxHeightRatio: 0.44,
//     context: context,
//     builder: (context) {
//       return CustomBottomSheetWidget(
//         appTitle: "تسجيل الدخول",
//         body: Column(
//           spacing: defaultSpacing,
//           mainAxisAlignment: MainAxisAlignment.spaceBetween,
//           children: [
//             Icon(
//               Icons.no_accounts,
//               size: 80,
//               color: warningColor.withValues(alpha: 0.7),
//             ),
//             Text(
//               "يجب عليك تسجيل الدخول",
//               style: Theme.of(context).textTheme.bodyLarge,
//             ),
//             SizedBox(),
//             PrimaryElevatedButton(
//               onPressed: () {
//                 context.back();
//                 context.pushTo(logInRoute);
//               },
//               text: "تسجيل الدخول",
//             ),
//           ],
//         ),
//       );
//     },
//   );
// }
