import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class OtpVerificationForm extends StatelessWidget {
  final List<TextEditingController> controllers;
  const OtpVerificationForm({super.key, required this.controllers});

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.ltr,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: List.generate(
            6, (index) => _input(context, controller: controllers[index])),
      ),
    );
  }

  Widget _input(BuildContext context,
      {required TextEditingController controller}) {
    return SizedBox(
      height: 68,
      width: 50,
      child: TextFormField(
        autovalidateMode: AutovalidateMode.onUserInteraction,
        controller: controller,
        onChanged: (value) {
          if (value.length == 1) {
            FocusScope.of(context).nextFocus();
          }
        },
        validator: (value) => value!.isEmpty ? "" : null,
        style: Theme.of(context).textTheme.titleLarge,
        decoration: const InputDecoration(hintText: "0"),
        keyboardType: TextInputType.number,
        textAlign: TextAlign.center,
        inputFormatters: [
          LengthLimitingTextInputFormatter(1),
          FilteringTextInputFormatter.digitsOnly,
        ],
      ),
    );
  }
}
