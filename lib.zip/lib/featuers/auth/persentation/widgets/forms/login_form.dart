import 'package:flutter/material.dart';

import '../../../../../core/constants/strings.dart';
import '../../../../../core/widgets/input_widgets.dart';

class LoginForm extends StatelessWidget {
  final GlobalKey<FormState> keyForm;
  final TextEditingController phoneController;
  const LoginForm({
    super.key,
    required this.keyForm,
    required this.phoneController,
  });

  @override
  Widget build(BuildContext context) {
    return Form(
      key: keyForm,
      child: Column(
        spacing: defaultSpacing,
        children: [
          InputPhoneNumberWidget(
            label: "رقم الهاتف",
            textController: phoneController,
          ),
          SizedBox(),
        ],
      ),
    );
  }
}
