import 'package:equatable/equatable.dart';

class Role extends Equatable {
  final int? id;
  final String? name;

  const Role({
    this.id,
    this.name,
  });

  @override
  List<Object?> get props => [id, name];
}
