import 'package:equatable/equatable.dart';

class PermissionRole extends Equatable {
  final int? id;
  final int? roleId;
  final int? permissionId;

  const PermissionRole({
    this.id,
    this.roleId,
    this.permissionId,
  });

  @override
  List<Object?> get props => [id, roleId, permissionId];
}
