import 'package:equatable/equatable.dart';

class Favorit extends Equatable {
  final int? id;
  final int? serviceId;
  final int? userId;

  const Favorit({
    this.id,
    this.serviceId,
    this.userId,
  });

  @override
  List<Object?> get props => [id, serviceId, userId];
}
