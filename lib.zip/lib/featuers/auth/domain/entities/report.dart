import 'package:equatable/equatable.dart';

class Report extends Equatable {
  final int? id;
  final int? storeId;
  final int? userId;
  final String? reportType;
  final String? message;

  const Report({
    this.id,
    this.storeId,
    this.userId,
    this.reportType,
    this.message,
  });

  @override
  List<Object?> get props => [id, storeId, userId, reportType, message];
}
