import 'package:equatable/equatable.dart';

class User extends Equatable {
  final int? id;
  final String? name;
  final String? image;
  final String? phoneNumber;
  final int? roleId;
  final int? directorateId;

  const User({
    this.id,
    this.name,
    this.image,
    this.phoneNumber,
    this.roleId,
    this.directorateId,
  });

  @override
  List<Object?> get props =>
      [id, name, image, roleId, phoneNumber, directorateId];
}
