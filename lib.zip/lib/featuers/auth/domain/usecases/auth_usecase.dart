import 'package:dartz/dartz.dart';

import '../../../../../core/errors/failures.dart';
import '../entities/user.dart';
import '../repositories/auth_repository.dart';
// Future<Unit> sendOtp(String phoneNumber);
//   Future<User?> verifyPhone(String phoneNumber, int code);
//   Future<User> register(UserModel userModel);
//   Future<User> updateUser(UserModel userModel);
//   Future<Unit> logout();

class SendOtpUsecase {
  final AuthRepository repository;

  SendOtpUsecase(this.repository);

  Future<Either<Failure, Unit>> call(String phoneNumber) async {
    return await repository.sendOtp(phoneNumber);
  }
}

class VerifyPhoneUsecase {
  final AuthRepository repository;

  const VerifyPhoneUsecase(this.repository);

  Future<Either<Failure, User?>> call(String phoneNumber, int code) async {
    return await repository.verifyPhone(phoneNumber, code);
  }
}

class RegisterUsecase {
  final AuthRepository repository;

  const RegisterUsecase(this.repository);

  Future<Either<Failure, User>> call(User user) async {
    return await repository.register(user);
  }
}

class UpdateUserUsecase {
  final AuthRepository repository;

  const UpdateUserUsecase(this.repository);

  Future<Either<Failure, User>> call(User user) async {
    return await repository.updateUser(user);
  }
}

class LogoutUsecase {
  final AuthRepository repository;

  LogoutUsecase(this.repository);

  Future<Either<Failure, Unit>> call() async {
    return await repository.logout();
  }
}
