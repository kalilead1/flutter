import 'package:dartz/dartz.dart';

import '../../../../core/errors/failures.dart';
import '../entities/user.dart';

abstract class AuthRepository {
  Future<Either<Failure, Unit>> sendOtp(String phoneNumber);
  Future<Either<Failure, User?>> verifyPhone(String phoneNumber, int code);
  Future<Either<Failure, User>> register(User user);
  Future<Either<Failure, User>> updateUser(User user);
  Future<Either<Failure, Unit>> logout();
}
