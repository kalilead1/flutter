import 'dart:convert';

import 'package:booking_v1/featuers/payments/domain/enums/payment_method_enum.dart';
import 'package:booking_v1/featuers/payments/domain/enums/payment_transaction_type_enum.dart';
import 'package:dartz/dartz.dart';
import 'package:http/http.dart' as http;

import '../../../../core/constants/api.dart';
import '../../../../core/errors/exception.dart';
import '../../domain/entities/payment.dart';
import '../models/payment_model.dart';

abstract class PaymentsRemoteDataSource {
  Future<List<Payment>> getPaymentsByBookingId(int bookingId);
  Future<Unit> addPayment(PaymentModel paymentModel);
}

const String paymentsUrl = "Payments/";

class PaymentsRemoteDataSourceImpl implements PaymentsRemoteDataSource {
  final http.Client client;

  PaymentsRemoteDataSourceImpl({required this.client});

  @override
  Future<List<Payment>> getPaymentsByBookingId(int bookingId) async {
    final String url = "ByBookingId/$bookingId";
    final response = await client.get(Uri.parse(baseUrl + paymentsUrl + url));
    if (response.statusCode == 200) {
      List jsonResponse = json.decode(response.body) as List;
      return jsonResponse.map((get) => PaymentModel.fromJson(get)).toList();
    } else {
      throw ServerException();
    }
  }

  @override
  Future<Unit> addPayment(PaymentModel paymentModel) async {
    var request =
        http.MultipartRequest('POST', Uri.parse(baseUrl + paymentsUrl));
    request.fields['bookingId'] = paymentModel.bookingId.toString();
    if (paymentModel.walletId != null) {
      request.fields['walletId'] = paymentModel.walletId.toString();
    }
    request.fields['paymentMethod'] =
        paymentModel.paymentMethodEnum!.value.toString();
    request.fields['amount'] = paymentModel.amount.toString();
    request.fields['transactionNumber'] =
        paymentModel.transactionNumber.toString();
    request.fields['transactionType'] =
        paymentModel.paymentTransactionTypeEnum!.value.toString();

    if (paymentModel.transactionImage != null) {
      request.files.add(await http.MultipartFile.fromPath(
          "transactionImage", paymentModel.transactionImage!));
    }

    final response = await request.send();
    if (response.statusCode == 200 || response.statusCode == 201) {
      // final responseBody = await response.stream.bytesToString();
      // final data = json.decode(responseBody);
      // return data['id'];
      return Future.value(unit);
    } else {
      throw ServerException();
    }
  }
}
