import 'package:booking_v1/core/errors/exception.dart';
import 'package:booking_v1/core/errors/failures.dart';
import 'package:booking_v1/core/network/network_info.dart';
import 'package:dartz/dartz.dart';

import '../../domain/entities/payment.dart';
import '../../domain/repositories/payments_repository.dart';
import '../datasources/payments_remote_data_source.dart';
import '../models/payment_model.dart';

class PaymentsRepositoryImpl implements PaymentsRepository {
  final PaymentsRemoteDataSource remoteDataSource;
  final NetworkInfo networkInfo;

  PaymentsRepositoryImpl({
    required this.remoteDataSource,
    required this.networkInfo,
  });

  @override
  Future<Either<Failure, List<Payment>>> getPaymentsByBookingId(
      int bookingId) async {
    // if (await networkInfo.isConnected) {
    try {
      final remoteStore =
          await remoteDataSource.getPaymentsByBookingId(bookingId);
      if (remoteStore.isEmpty) {
        return Left(EmptyCacheFailure());
      } else {
        return Right(remoteStore);
      }
    } on ServerException {
      return Left(ServerFailure());
    }
    // } else {
    //   return Left(OfflineFailure());
    // }
  }

  @override
  Future<Either<Failure, Unit>> addPayment(Payment payment) async {
    try {
      final paymentData = PaymentModel(
        id: 0,
        bookingId: payment.bookingId,
        walletId: payment.walletId,
        amount: payment.amount,
        transactionImage: payment.transactionImage,
        transactionNumber: payment.transactionNumber,
        paymentMethodEnum: payment.paymentMethodEnum,
        paymentTransactionTypeEnum: payment.paymentTransactionTypeEnum,
      );
      final remoteStore = await remoteDataSource.addPayment(paymentData);
      return Right(remoteStore);
    } on ServerException {
      return Left(ServerFailure());
    }
  }
}
