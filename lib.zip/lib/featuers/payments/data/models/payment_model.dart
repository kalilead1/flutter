import 'package:booking_v1/featuers/payments/domain/entities/payment.dart';

import '../../../bookings/data/models/booking_model.dart';
import '../../../main/data/models/wallet_model.dart';
import '../../domain/enums/payment_method_enum.dart';
import '../../domain/enums/payment_transaction_type_enum.dart';

class PaymentModel extends Payment {
  const PaymentModel({
    super.id,
    super.bookingId,
    super.booking,
    super.walletId,
    super.wallet,
    super.paymentMethodEnum,
    super.amount,
    super.transactionNumber,
    super.transactionImage,
    super.paymentTransactionTypeEnum,
  });

  @override
  List<Object?> get props => [
        id,
        bookingId,
        booking,
        walletId,
        wallet,
        paymentMethodEnum,
        amount,
        transactionNumber,
        transactionImage,
        paymentTransactionTypeEnum,
      ];

  factory PaymentModel.fromJson(Map<String, dynamic> json) {
    return PaymentModel(
      id: json['id'],
      bookingId: json['bookingId'],
      booking: json['booking'] != null
          ? BookingModel.fromJson(json['booking'])
          : null,
      walletId: json['walletId'],
      wallet:
          json['wallet'] != null ? WalletModel.fromJson(json['wallet']) : null,
      paymentMethodEnum:
          PaymentMethodEnumExtension.fromValue(json['paymentMethod']),
      amount: json['amount'],
      transactionNumber: json['transactionNumber'],
      transactionImage: json['transactionImage'],
      paymentTransactionTypeEnum: PaymentTransactionTypeEnumExtension.fromValue(
          json['transactionType']),
    );
  }
}
