enum PaymentMethodEnum {
  walletDeposit, // ايداع الى محفظة
  bankTransfer, // تحويل عادي
  cash, // دفع نقد
}

extension PaymentMethodEnumExtension on PaymentMethodEnum {
  String get arabicName {
    switch (this) {
      case PaymentMethodEnum.walletDeposit:
        return 'ايداع الى محفظة';
      case PaymentMethodEnum.bankTransfer:
        return 'تحويل عادي';
      case PaymentMethodEnum.cash:
        return 'دفع نقد';
    }
  }

  int get value {
    switch (this) {
      case PaymentMethodEnum.walletDeposit:
        return 1;
      case PaymentMethodEnum.bankTransfer:
        return 2;
      case PaymentMethodEnum.cash:
        return 3;
    }
  }

  static PaymentMethodEnum fromValue(int value) {
    switch (value) {
      case 1:
        return PaymentMethodEnum.walletDeposit;
      case 2:
        return PaymentMethodEnum.bankTransfer;
      case 3:
        return PaymentMethodEnum.cash;
      default:
        throw Exception('لا يوجد طريقة للدفع');
    }
  }
}
