enum PaymentTransactionTypeEnum {
  depositPayment, // دفع مبلغ العربون
  remainingPayment, // دفع المبلغ المتبقي
  depositRefund, // ارجاع مبلغ العربون
}

extension PaymentTransactionTypeEnumExtension on PaymentTransactionTypeEnum {
  String get arabicName {
    switch (this) {
      case PaymentTransactionTypeEnum.depositPayment:
        return 'دفع مبلغ العربون';
      case PaymentTransactionTypeEnum.remainingPayment:
        return 'دفع المبلغ المتبقي';
      case PaymentTransactionTypeEnum.depositRefund:
        return 'ارجاع مبلغ العربون';
    }
  }

  int get value {
    switch (this) {
      case PaymentTransactionTypeEnum.depositPayment:
        return 1;
      case PaymentTransactionTypeEnum.remainingPayment:
        return 2;
      case PaymentTransactionTypeEnum.depositRefund:
        return 3;
    }
  }

  static PaymentTransactionTypeEnum fromValue(int value) {
    switch (value) {
      case 1:
        return PaymentTransactionTypeEnum.depositPayment;
      case 2:
        return PaymentTransactionTypeEnum.remainingPayment;
      case 3:
        return PaymentTransactionTypeEnum.depositRefund;
      default:
        throw Exception('لا يوجد نوع للعملية');
    }
  }
}
