import 'package:dartz/dartz.dart';

import '../../../../core/errors/failures.dart';
import '../entities/payment.dart';
import '../repositories/payments_repository.dart';

class GetPaymentsByBookingIdUsecase {
  final PaymentsRepository repository;

  GetPaymentsByBookingIdUsecase(this.repository);

  Future<Either<Failure, List<Payment>>> call(int bookingId) async {
    return await repository.getPaymentsByBookingId(bookingId);
  }
}

class AddPaymentUsecase {
  final PaymentsRepository repository;

  AddPaymentUsecase(this.repository);

  Future<Either<Failure, Unit>> call(Payment payment) async {
    return await repository.addPayment(payment);
  }
}
