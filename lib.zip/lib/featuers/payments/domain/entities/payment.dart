import 'package:booking_v1/featuers/payments/domain/enums/payment_method_enum.dart';
import 'package:booking_v1/featuers/payments/domain/enums/payment_transaction_type_enum.dart';
import 'package:equatable/equatable.dart';

import '../../../bookings/domain/entities/booking.dart';
import '../../../main/domain/entities/wallet.dart';

class Payment extends Equatable {
  final int? id;
  final int? bookingId;
  final Booking? booking;
  final int? walletId;
  final Wallet? wallet;
  final PaymentMethodEnum? paymentMethodEnum;
  final double? amount;
  final int? transactionNumber;
  final String? transactionImage;
  final PaymentTransactionTypeEnum? paymentTransactionTypeEnum;

  const Payment({
    this.id,
    this.bookingId,
    this.booking,
    this.walletId,
    this.wallet,
    this.paymentMethodEnum,
    this.amount,
    this.transactionNumber,
    this.transactionImage,
    this.paymentTransactionTypeEnum,
  });

  @override
  List<Object?> get props => [
        id,
        bookingId,
        booking,
        walletId,
        wallet,
        paymentMethodEnum,
        amount,
        transactionNumber,
        transactionImage,
        paymentTransactionTypeEnum,
      ];
}
