import 'package:dartz/dartz.dart';

import '../../../../core/errors/failures.dart';
import '../entities/payment.dart';

abstract class PaymentsRepository {
  Future<Either<Failure, List<Payment>>> getPaymentsByBookingId(int bookingId);
  Future<Either<Failure, Unit>> addPayment(Payment payment);
}
