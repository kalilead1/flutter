import 'package:booking_v1/core/routing/router_extensions.dart';
import 'package:booking_v1/core/widgets/image_picker/widgets/image_uploader_widget.dart';
import 'package:booking_v1/core/widgets/input_widgets.dart';
import 'package:booking_v1/featuers/payments/domain/enums/payment_method_enum.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../../../../core/constants/strings.dart';
import '../../../../../core/widgets/botton_widghts.dart';
import '../../../../../core/widgets/ciracle_loading_widget.dart';
import '../../../../../core/widgets/snack_bar_widgets.dart';
import '../../../../bookings/persentation/bloc/bookings_command/bookings_command_bloc.dart';
import '../../../../bookings/persentation/bloc/bookings_command/bookings_command_event.dart';
import '../../../../bookings/persentation/bloc/bookings_command/bookings_command_state.dart';

class AddPaymentOnlineForm extends StatefulWidget {
  final int? walletId;
  final String? walletLogo;
  final String walletName;
  final int walletAccount;
  final PaymentMethodEnum paymentMethodEnum;
  const AddPaymentOnlineForm({
    super.key,
    this.walletId,
    this.walletLogo,
    required this.walletName,
    required this.walletAccount,
    required this.paymentMethodEnum,
  });

  @override
  State<AddPaymentOnlineForm> createState() => _AddPaymentOnlineFormState();
}

class _AddPaymentOnlineFormState extends State<AddPaymentOnlineForm> {
  TextEditingController controller = TextEditingController();
  String? transactionImage;
  final formKey = GlobalKey<FormState>();

  void formValid() {
    if (transactionImage == null) {
      showSnackBarWarning(
          context: context, warning: "يحب ارفاق صورة اشعار الدفع");
    } else {
      if (formKey.currentState!.validate()) {
        BlocProvider.of<BookingsCommandBloc>(context)
            .add(SubmitAddBookingOnlineEvent(
          walletId: widget.walletId,
          paymentMethodEnum: widget.paymentMethodEnum,
          transcationImage: transactionImage!,
          transcationNumber: int.parse(controller.text),
        ));
        context.back();
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return BlocConsumer<BookingsCommandBloc, BookingsCommandState>(
      listener: (context, state) {
        if (state is SuccessfullyState) {
          return showSnackBarSuccess(
              context: context, success: "تم اضافة حجزك بنجاح");
        } else if (state is ErrorState) {
          return showSnackBarError(context: context, error: state.message);
        }
      },
      builder: (context, state) {
        // if (state is LoadingState) {
        //   return CiracleLoadingWidget();
        // } else
        if (state is ErrorState) {
          return Center(
            child: Text(state.message),
          );
        } else if (state is EditingAddBookingOnlineState) {
          return SingleChildScrollView(
            child: Directionality(
              textDirection: TextDirection.rtl,
              child: Form(
                key: formKey,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    CircleAvatar(
                      backgroundColor: Colors.amber,
                      radius: 40,
                    ),
                    Text(widget.walletName,
                        style: Theme.of(context).textTheme.titleMedium),
                    Wrap(
                      spacing: 5,
                      runAlignment: WrapAlignment.end,
                      crossAxisAlignment: WrapCrossAlignment.center,
                      children: [
                        Text(
                          widget.walletAccount.toString(),
                          style: Theme.of(context).textTheme.displaySmall,
                        ),
                        Icon(
                          Icons.copy,
                          size: 18,
                          color: Theme.of(context).colorScheme.primary,
                        ),
                      ],
                    ),
                    SizedBox(height: 20),
                    CustomInputFieldWidget(
                      label: "رقم العملية",
                      textController: controller,
                      textInputType: TextInputType.number,
                    ),
                    SizedBox(height: 12),
                    ImageUploaderWidghet(
                      maxImages: 1,
                      allowMultipleImages: false,
                      onChanged: (value) {
                        setState(() {
                          transactionImage = value.first.path;
                        });
                      },
                    ),
                    SizedBox(height: 20),
                    Row(
                      spacing: defaultSpacing,
                      children: [
                        Expanded(
                          child: PrimaryElevatedButton(
                            onPressed: () {
                              formValid();
                            },
                            text: "تاكيد الحجز",
                          ),
                        ),
                        Expanded(
                          child: SecondaryElevatedButton(
                            onPressed: () {
                              showModalBottomSheet(
                                context: context,
                                builder: (context) {
                                  return Padding(
                                    padding: EdgeInsets.all(16),
                                    child: Column(
                                      spacing: 10,
                                      children: [
                                        Text("الحجز"),
                                        Text(state.walletId.toString()),
                                        // Text("الدفع"),
                                        // Text(state.transcationImage.toString()),
                                        // Text(
                                        //     state.transcationNumber.toString()),
                                        // Text(
                                        //     state.paymentMethodEnum.toString()),
                                      ],
                                    ),
                                  );
                                },
                              );
                              // context.back();
                            },
                            text: "الغاء",
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          );
        } else {
          return CiracleLoadingWidget();
        }
      },
    );
  }
}
