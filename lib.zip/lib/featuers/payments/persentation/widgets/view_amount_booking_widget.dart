import 'package:flutter/material.dart';

import '../../../../core/widgets/container_widgets.dart';

class ViewAmountBookingWidget extends StatelessWidget {
  final double total;
  final double deposit;
  final double remaining;
  const ViewAmountBookingWidget({
    super.key,
    required this.total,
    required this.deposit,
    required this.remaining,
  });

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: PrimaryContainer(
        paddingHorizontal: 5,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            _column(context, amount: total, lable: "الاجمالي"),
            _column(context, amount: deposit, lable: "العربون"),
            _column(context, amount: remaining, lable: "المتبقي"),
          ],
        ),
      ),
    );
  }

  Widget _column(BuildContext context,
      {required double amount, required String lable}) {
    return Column(
      children: [
        Text(
          amount.toString(),
          style: Theme.of(context).textTheme.displayLarge,
        ),
        Text(
          lable,
          style: Theme.of(context).textTheme.labelSmall,
        ),
      ],
    );
  }
}
