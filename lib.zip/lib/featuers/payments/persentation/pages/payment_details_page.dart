import 'package:booking_v1/core/constants/strings.dart';
import 'package:booking_v1/core/widgets/container_widgets.dart';
import 'package:booking_v1/dependency_injection/initial.dart';
import 'package:booking_v1/featuers/payments/domain/enums/payment_method_enum.dart';
import 'package:booking_v1/featuers/payments/domain/enums/payment_transaction_type_enum.dart';
import 'package:booking_v1/featuers/payments/persentation/bloc/payments_query/payments_query_event.dart';
import 'package:booking_v1/tests/loading_test.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_svg/flutter_svg.dart';

import '../../../../core/constants/api.dart';
import '../bloc/payments_query/payments_query_bloc.dart';
import '../bloc/payments_query/payments_query_state.dart';

class PaymentDetailsPage extends StatelessWidget {
  final int bookingId;
  const PaymentDetailsPage({super.key, required this.bookingId});

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (context) => getIt<PaymentsQueryBloc>()
        ..add(GetPaymentsByBookingIdEvent(bookingId: bookingId)),
      child: Directionality(
        textDirection: TextDirection.rtl,
        child: Scaffold(
          appBar: AppBar(title: Text("تفاصيل الدفع")),
          body: BlocBuilder<PaymentsQueryBloc, PaymentsQueryState>(
            builder: (context, state) {
              if (state is LoadingState) {
                return Center(child: CircularProgressIndicator());
              } else if (state is ErrorState) {
                return Center(child: Text(state.message));
              } else if (state is LoadedState) {
                final payments = state.payments;
                return CustomRefresh(
                  onRefresh: () async {},
                  child: Padding(
                    padding: const EdgeInsets.all(defaultPadding),
                    child: ListView.separated(
                      itemCount: payments.length,
                      separatorBuilder: (context, index) {
                        return SizedBox(height: defaultSpacing);
                      },
                      itemBuilder: (context, index) {
                        final payment = payments[index];
                        return SecondaryContainer(
                          paddingHorizontal: 8,
                          paddingVertical: 8,
                          child: Column(
                            children: [
                              Container(
                                constraints: BoxConstraints(
                                  minWidth: MediaQuery.of(context).size.width,
                                  minHeight: 160,
                                ),
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(
                                      defaultBorderRadious),
                                  border: Border.all(
                                      color: Theme.of(context)
                                          .colorScheme
                                          .onPrimaryContainer
                                          .withValues(alpha: 0.5)),
                                  color: Theme.of(context)
                                      .colorScheme
                                      .primaryContainer,
                                  image: payment.transactionImage != null
                                      ? DecorationImage(
                                          // image: AssetImage("assets/images/image2.jpg"),
                                          image: NetworkImage(
                                              baseUrlPaymentImagesFolder +
                                                  payment.transactionImage!),
                                          fit: BoxFit.cover,
                                        )
                                      : null,
                                ),
                                child: payment.transactionImage == null
                                    ? Center(
                                        child: SvgPicture.asset(
                                          "assets/logos/logo4.svg",
                                          colorFilter: ColorFilter.mode(
                                            Theme.of(context)
                                                .colorScheme
                                                .tertiary
                                                .withValues(alpha: 0.7),
                                            BlendMode.srcIn,
                                          ),
                                          height: 50,
                                        ),
                                      )
                                    : null,
                              ),
                              SizedBox(height: 8),
                              _listTile(
                                context: context,
                                title: "نوع العملية",
                                info: payment
                                    .paymentTransactionTypeEnum!.arabicName,
                              ),
                              _listTile(
                                context: context,
                                title: "طريقة الدفع",
                                info: payment.paymentMethodEnum!.arabicName,
                              ),
                              if (payment.paymentMethodEnum ==
                                  PaymentMethodEnum.walletDeposit) ...[
                                _listTile(
                                  context: context,
                                  title: "اسم المحفظة",
                                  info: payment.wallet!.name!,
                                )
                              ],
                              _listTile(
                                context: context,
                                title: "المبلغ المدفوع",
                                info: payment.amount.toString(),
                              ),
                              _listTile(
                                  context: context,
                                  title: "رقم العملية",
                                  info: payment.amount.toString()),
                            ],
                          ),
                        );
                      },
                    ),
                  ),
                );
              } else {
                return Center(child: Text(unknownFailuerText));
              }
            },
          ),
        ),
      ),
    );
  }

  Widget _listTile({
    required BuildContext context,
    required String info,
    required String title,
  }) {
    return Container(
      margin: const EdgeInsets.all(6),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            title,
            style: Theme.of(context).textTheme.labelMedium,
          ),
          Expanded(
            child: Text(
              info,
              softWrap: true,
              textAlign: TextAlign.end,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: Theme.of(context).textTheme.titleSmall,
            ),
          ),
        ],
      ),
    );
  }
}
