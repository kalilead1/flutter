class PaymentBookingOnlinePageArgs {
  final int storeId;
  final double total;
  final double deposit;
  final double remaining;

  PaymentBookingOnlinePageArgs({
    required this.storeId,
    required this.total,
    required this.deposit,
    required this.remaining,
  });
}
