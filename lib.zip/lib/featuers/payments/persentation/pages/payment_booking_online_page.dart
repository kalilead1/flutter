import 'package:booking_v1/core/constants/colors.dart';
import 'package:booking_v1/core/constants/strings.dart';
import 'package:booking_v1/core/widgets/ciracle_loading_widget.dart';
import 'package:booking_v1/featuers/payments/persentation/widgets/forms/add_payment_online_form.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../../../core/widgets/bottom_items.dart';
import '../../../../core/widgets/botton_widghts.dart';
import '../../../../core/widgets/container_widgets.dart';
import '../../../bookings/persentation/bloc/bookings_command/bookings_command_bloc.dart';
import '../../../bookings/persentation/bloc/bookings_command/bookings_command_event.dart';
import '../../../bookings/persentation/bloc/bookings_command/bookings_command_state.dart';
import '../../domain/enums/payment_method_enum.dart';
import '../widgets/view_amount_booking_widget.dart';

class PaymentBookingOnlinePage extends StatelessWidget {
  // final int storeId;
  // final double total;
  // final double deposit;
  // final double remaining;
  const PaymentBookingOnlinePage({
    super.key,
    // required this.storeId,
    // required this.total,
    // required this.deposit,
    // required this.remaining,
  });

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          title: Text("الدفع"),
        ),
        body: Padding(
          padding: const EdgeInsets.all(defaultPadding),
          child: BlocBuilder<BookingsCommandBloc, BookingsCommandState>(
            builder: (context, state) {
              if (state is LoadingState) {
                return CiracleLoadingWidget();
              } else if (state is ErrorState) {
                return Center(
                  child: Text(state.message),
                );
              } else if (state is EditingAddBookingOnlineState) {
                final double total = state.service!.price!;
                final double deposit = total * 0.30;
                final double remaining = total - deposit;
                return Column(
                  spacing: defaultSpacing,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    ViewAmountBookingWidget(
                        total: total, deposit: deposit, remaining: remaining),
                    Text(
                      "ملاحظة: لا يمكن ارجاع العربون عند الغاء الحجز!",
                      style:
                          TextStyle(color: warningColor.withValues(alpha: 0.8)),
                    ),
                    Text(
                      "اختار طريقة دفع:",
                      style: Theme.of(context).textTheme.titleMedium,
                    ),
                    _wallet(
                      context: context,
                      walletName: "تحويل",
                      account: 7745877,
                      description: "يمكنك ارسال حوالة عبر اي شبكة تحويل",
                      onTap: () {
                        showDialog(
                          useSafeArea: true,
                          context: context,
                          builder: (context) {
                            return Dialog(
                              shape: RoundedRectangleBorder(
                                borderRadius:
                                    BorderRadius.circular(defaultBorderRadious),
                              ),
                              backgroundColor:
                                  Theme.of(context).scaffoldBackgroundColor,
                              insetPadding: EdgeInsets.all(defaultPadding),
                              child: SecondaryContainer(
                                child: AddPaymentOnlineForm(
                                  walletId: null,
                                  walletName: "تحويل عبر شبكة",
                                  walletAccount: 77787874,
                                  paymentMethodEnum:
                                      PaymentMethodEnum.bankTransfer,
                                ),
                              ),
                            );
                          },
                        );
                      },
                    ),
                    state.storeWallets != null
                        ? Expanded(
                            child: ListView.separated(
                              itemBuilder: (context, index) {
                                final storeWallet = state.storeWallets![index];
                                return _wallet(
                                  context: context,
                                  walletName:
                                      "محفظة ${storeWallet.wallet!.name!}",
                                  account: storeWallet.accountNumber!,
                                  onTap: () {
                                    showDialog(
                                      useSafeArea: true,
                                      context: context,
                                      builder: (context) {
                                        return Dialog(
                                          shape: RoundedRectangleBorder(
                                            borderRadius: BorderRadius.circular(
                                                defaultBorderRadious),
                                          ),
                                          backgroundColor: Theme.of(context)
                                              .scaffoldBackgroundColor,
                                          insetPadding:
                                              EdgeInsets.all(defaultPadding),
                                          child: SecondaryContainer(
                                            child: AddPaymentOnlineForm(
                                              walletId: storeWallet.walletId,
                                              walletName:
                                                  "محفظة ${storeWallet.wallet!.name!}",
                                              walletAccount:
                                                  storeWallet.accountNumber!,
                                              paymentMethodEnum:
                                                  PaymentMethodEnum
                                                      .walletDeposit,
                                            ),
                                          ),
                                        );
                                      },
                                    );
                                  },
                                );
                              },
                              separatorBuilder: (context, index) =>
                                  SizedBox(height: defaultSpacing),
                              itemCount: state.storeWallets!.length,
                            ),
                          )
                        : Center(
                            child: Text(
                                "لايوجد محافظ يمكنك دفع العربون عن طريق تحويل عبر اي شبكة"),
                          ),
                  ],
                );
              } else {
                return CiracleLoadingWidget();
              }
            },
          ),
        ),
        bottomNavigationBar: TwoBottomItems(
          child1: SecondaryElevatedButton(
            onPressed: () {
              BlocProvider.of<BookingsCommandBloc>(context)
                  .add(CancelAddBookingOnlineEvent());
            },
            text: "الغاء",
          ),
        ),
      ),
    );
  }

  Widget _wallet({
    required BuildContext context,
    // String? walletLogo,
    String? description,
    required String walletName,
    required int account,
    void Function()? onTap,
  }) {
    return SecondaryContainer(
      paddingHorizontal: 0,
      paddingVertical: 0,
      child: ListTile(
        onTap: onTap,
        title: Text(walletName),
        subtitle: description != null
            ? Text(description, style: Theme.of(context).textTheme.bodySmall)
            : null,
        trailing: Wrap(
          spacing: 5,
          runAlignment: WrapAlignment.end,
          crossAxisAlignment: WrapCrossAlignment.center,
          children: [
            Text(
              account.toString(),
              style: Theme.of(context).textTheme.displaySmall,
            ),
            Icon(
              Icons.copy,
              size: 18,
              color: Theme.of(context).colorScheme.primary,
            ),
          ],
        ),
      ),
    );
  }
}
