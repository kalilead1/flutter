import 'package:booking_v1/featuers/payments/domain/entities/payment.dart';
import 'package:equatable/equatable.dart';

abstract class PaymentsQueryState extends Equatable {
  const PaymentsQueryState();
  @override
  List<Object?> get props => [];
}

class InitialState extends PaymentsQueryState {}

class LoadingState extends PaymentsQueryState {}

class LoadedState extends PaymentsQueryState {
  final List<Payment> payments;

  const LoadedState({required this.payments});

  @override
  List<Object?> get props => [payments];
}

class ErrorState extends PaymentsQueryState {
  final String message;

  const ErrorState({required this.message});

  @override
  List<Object?> get props => [message];
}
