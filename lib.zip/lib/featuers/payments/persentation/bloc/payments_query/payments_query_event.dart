import 'package:equatable/equatable.dart';

abstract class PaymentsQueryEvent extends Equatable {
  const PaymentsQueryEvent();
  @override
  List<Object?> get props => [];
}

class GetPaymentsByBookingIdEvent extends PaymentsQueryEvent {
  final int bookingId;
  const GetPaymentsByBookingIdEvent({required this.bookingId});

  @override
  List<Object?> get props => [bookingId];
}

class RefreshPaymentsByBookingIdEvent extends PaymentsQueryEvent {
  final int bookingId;
  const RefreshPaymentsByBookingIdEvent({required this.bookingId});

  @override
  List<Object?> get props => [bookingId];
}
