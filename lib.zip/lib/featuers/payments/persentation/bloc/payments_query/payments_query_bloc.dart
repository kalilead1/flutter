import 'package:booking_v1/core/errors/failures.dart';
import 'package:booking_v1/core/helpers/failure_to_message.dart';
import 'package:dartz/dartz.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../../../../core/app_events_bus/app_event.dart';
import '../../../../../core/app_events_bus/auto_refresh_bloc.dart';
import '../../../domain/entities/payment.dart';
import '../../../domain/usecases/payments_usecase.dart';
import 'payments_query_event.dart';
import 'payments_query_state.dart';

class PaymentsQueryBloc extends Bloc<PaymentsQueryEvent, PaymentsQueryState>
    with AutoRefreshBloc<PaymentsQueryEvent, PaymentsQueryState> {
  final GetPaymentsByBookingIdUsecase? getPaymentsByBookingIdUsecase;

  PaymentsQueryBloc({this.getPaymentsByBookingIdUsecase})
      : super(InitialState()) {
    setupAutoRefresh<PaymentChangedEvent>();

    on<GetPaymentsByBookingIdEvent>((event, emit) async {
      emit(LoadingState());

      final failureOrPayments =
          await getPaymentsByBookingIdUsecase!(event.bookingId);
      emit(_mapFailureOrGetPayments(failureOrPayments));
    });
    on<RefreshPaymentsByBookingIdEvent>((event, emit) async {
      emit(LoadingState());

      final failureOrPayments =
          await getPaymentsByBookingIdUsecase!(event.bookingId);
      emit(_mapFailureOrGetPayments(failureOrPayments));
    });
  }

  PaymentsQueryState _mapFailureOrGetPayments(
      Either<Failure, List<Payment>> either) {
    return either.fold(
      (failure) => ErrorState(message: failureToMessage(failure)),
      (payments) => LoadedState(payments: payments),
    );
  }

  // PaymentsQueryState _mapFailureOrGetPaymentById(
  //     Either<Failure, Payment> either) {
  //   return either.fold(
  //     (failure) => ErrorState(message: failureToMessage(failure)),
  //     (payment) => LoadedByIdState(payment: payment),
  //   );
  // }
}
