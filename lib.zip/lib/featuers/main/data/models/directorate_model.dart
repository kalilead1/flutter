import '../../domain/entities/directorate.dart';
import 'city_model.dart';

class DirectorateModel extends Directorate {
  const DirectorateModel({
    super.id,
    super.name,
    super.cityId,
    super.city,
  });

  factory DirectorateModel.fromJson(Map<String, dynamic> json) {
    return DirectorateModel(
      id: json['id'],
      name: json['name'],
      cityId: json['cityId'],
      city: json['city'] != null ? CityModel.fromJson(json['city']) : null,
    );
  }
}
