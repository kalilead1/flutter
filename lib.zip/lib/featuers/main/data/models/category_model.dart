import 'package:booking_v1/featuers/main/domain/entities/category.dart';

class CategoryModel extends Category {
  const CategoryModel({
    super.id,
    super.name,
    super.logo,
  });

  factory CategoryModel.fromJson(Map<String, dynamic> json) {
    return CategoryModel(
      id: json['id'],
      name: json['name'],
      logo: json['logo'],
    );
  }
}
