import 'package:booking_v1/featuers/main/domain/entities/policy.dart';

class PolicyModel extends Policy {
  const PolicyModel({
    super.id,
    super.policyTypeEnum,
    super.description,
  });

  factory PolicyModel.fromJson(Map<String, dynamic> json) {
    return PolicyModel(
      id: json['id'],
      policyTypeEnum: json['policyTypeEnum'],
      description: json['description'],
    );
  }
}
