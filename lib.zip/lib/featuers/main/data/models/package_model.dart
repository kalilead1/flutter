import 'package:booking_v1/featuers/main/domain/entities/package.dart';

class PackageModel extends Package {
  const PackageModel({
    super.id,
    super.name,
    super.logo,
  });

  factory PackageModel.fromJson(Map<String, dynamic> json) {
    return PackageModel(
      id: json['id'],
      name: json['name'],
      logo: json['logo'],
    );
  }
}
