import 'package:booking_v1/featuers/main/domain/entities/wallet.dart';

class WalletModel extends Wallet {
  const WalletModel({
    super.id,
    super.name,
    super.logo,
  });

  factory WalletModel.fromJson(Map<String, dynamic> json) {
    return WalletModel(
      id: json['id'],
      name: json['name'],
      logo: json['logo'],
    );
  }
}
