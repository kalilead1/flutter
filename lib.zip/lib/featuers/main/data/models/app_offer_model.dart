import 'package:booking_v1/featuers/main/domain/entities/app_offer.dart';

class AppOfferModel extends AppOffer {
  const AppOfferModel({
    super.id,
    super.image,
    super.title,
    super.description,
  });

  factory AppOfferModel.fromJson(Map<String, dynamic> json) {
    return AppOfferModel(
      id: json['id'],
      image: json['image'],
      title: json['title'],
      description: json['description'],
    );
  }
}
