import 'package:booking_v1/featuers/main/domain/entities/social_account.dart';

class SocialAccountModel extends SocialAccount {
  const SocialAccountModel({
    super.id,
    super.name,
  });

  factory SocialAccountModel.fromJson(Map<String, dynamic> json) {
    return SocialAccountModel(
      id: json['id'],
      name: json['name'],
    );
  }
}
