import 'package:booking_v1/featuers/main/domain/entities/package_category.dart';

class PackageCategoryModel extends PackageCategory {
  const PackageCategoryModel({
    super.id,
    super.categoryId,
    super.packageId,
  });

  factory PackageCategoryModel.fromJson(Map<String, dynamic> json) {
    return PackageCategoryModel(
      id: json['id'],
      categoryId: json['categoryId'],
      packageId: json['packageId'],
    );
  }
}
