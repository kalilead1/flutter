import '../../domain/entities/city.dart';

class CityModel extends City {
  const CityModel({
    super.id,
    super.name,
  });

  factory CityModel.fromJson(Map<String, dynamic> json) {
    return CityModel(
      id: json['id'],
      name: json['name'],
    );
  }
}
