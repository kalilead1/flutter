import '../../domain/entities/complaint_and_suggestion.dart';
import '../../domain/enums/complaint_and_suggestion_enum.dart';

class ComplaintAndSuggestionModel extends ComplaintAndSuggestion {
  const ComplaintAndSuggestionModel({
    super.id,
    super.message,
    super.typeMessage,
  });

  factory ComplaintAndSuggestionModel.fromJson(Map<String, dynamic> json) {
    return ComplaintAndSuggestionModel(
      id: json['id'],
      message: json['message'],
      typeMessage:
          ComplaintAndSuggestionEnumExtension.fromValue(json['typeMessage']),
    );
  }
  Map<String, dynamic> toJson() =>
      {"id": id, 'message': message, 'typeMessage': typeMessage!.value};
}
