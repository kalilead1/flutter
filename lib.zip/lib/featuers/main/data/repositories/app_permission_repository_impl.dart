import 'package:booking_v1/core/errors/failures.dart';
import 'package:dartz/dartz.dart';
import 'dart:io' show Platform;
import 'package:device_info_plus/device_info_plus.dart';
import 'package:permission_handler/permission_handler.dart';
import '../../domain/repositories/app_permission_repository.dart';

class AppPermissionRepositoryImpl implements AppPermissionRepository {
  final DeviceInfoPlugin _deviceInfo = DeviceInfoPlugin();

  @override
  Future<Either<Failure, bool>> requestCameraAndStoragePermissions() async {
    try {
      // تحديد الأذونات المطلوبة حسب النظام الأساسي
      List<Permission> permissions = [];

      if (Platform.isAndroid) {
        // أذونات أندرويد: الكاميرا + التخزين (حسب الإصدار)
        permissions.add(Permission.camera);

        // معرفة إصدار الأندرويد لاستخدام الإذن المناسب
        final androidInfo = await _deviceInfo.androidInfo;
        if (androidInfo.version.sdkInt >= 33) {
          // أندرويد 13+: استخدام أذونات الوسائط (صور وفيديو)
          permissions.add(Permission.photos);
        } else {
          // الأندرويد الأقدم: إذن التخزين العام
          permissions.add(Permission.storage);
        }
      } else if (Platform.isIOS) {
        // أذونات iOS: الكاميرا + مكتبة الصور
        permissions.add(Permission.camera);
        permissions.add(Permission.photos);
      } else {
        return Left(PlatformNotSupportedFailure());
      }

      // طلب الأذونات (إذا كانت ممنوحة مسبقاً، لا يظهر أي حوار)
      final statuses = await permissions.request();

      // التحقق من أن جميع الأذونات ممنوحة
      bool allGranted = statuses.values.every((status) => status.isGranted);

      if (allGranted) {
        return const Right(true);
      } else {
        // إذا رفض المستخدم أي إذن
        return Left(PermissionDeniedFailure());
      }
    } catch (e) {
      return Left(UnknownFailure(e.toString()));
    }
  }
}
