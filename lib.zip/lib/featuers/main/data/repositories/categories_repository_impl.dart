import 'package:booking_v1/core/errors/exception.dart';
import 'package:booking_v1/core/errors/failures.dart';
import 'package:booking_v1/core/network/network_info.dart';
import 'package:booking_v1/featuers/main/data/datasources/categories_remote_data_source.dart';
import 'package:booking_v1/featuers/main/domain/entities/category.dart';
import 'package:booking_v1/featuers/main/domain/repositories/categories_repository.dart';
import 'package:dartz/dartz.dart';

List<Category> cacheCategoriesList = [];

class CategoriesRepositoryImpl implements CategoriesRepository {
  final CategoriesRemoteDataSource categoriesRemoteDataSource;
  final NetworkInfo networkInfo;

  CategoriesRepositoryImpl({
    required this.categoriesRemoteDataSource,
    required this.networkInfo,
  });

  @override
  Future<Either<Failure, List<Category>>> getAllCategories() async {
    if (cacheCategoriesList.isEmpty) {
      try {
        final remoteCategory =
            await categoriesRemoteDataSource.getAllCategories();
        cacheCategoriesList = remoteCategory;

        // return Right(remoteWallet);
        if (remoteCategory.isEmpty) {
          return Left(EmptyCacheFailure());
        } else {
          return Right(cacheCategoriesList);
        }
      } on ServerException {
        return Left(ServerFailure());
      }
    } else {
      return Right(cacheCategoriesList);
    }

    // if (await networkInfo.isConnected) {
    //   try {
    //     final remoteCategory =
    //         await categoriesRemoteDataSource.getAllCategories();
    //     // return Right(remoteWallet);
    //     if (remoteCategory.isEmpty) {
    //       return Left(EmptyCacheFailure());
    //     } else {
    //       return Right(remoteCategory);
    //     }
    //   } on ServerException {
    //     return Left(ServerFailure());
    //   }
    // } else {
    //   return Left(OfflineFailure());
    // }
  }
}
