import 'package:booking_v1/core/errors/exception.dart';
import 'package:booking_v1/core/errors/failures.dart';
import 'package:booking_v1/core/network/network_info.dart';
import 'package:dartz/dartz.dart';

import '../../domain/entities/complaint_and_suggestion.dart';
import '../../domain/repositories/complaint_and_suggestion_repository.dart';
import '../datasources/complaint_and_suggestion_remote_data_source.dart';
import '../models/complaint_and_suggestion_model.dart';

class ComplaintAndSuggestionRepositoryImpl
    implements ComplaintAndSuggestionRepository {
  final ComplaintAndSuggestionRemoteDataSource remoteDataSource;
  final NetworkInfo networkInfo;

  ComplaintAndSuggestionRepositoryImpl({
    required this.remoteDataSource,
    required this.networkInfo,
  });

  @override
  Future<Either<Failure, Unit>> addComplaintAndSuggestion(
      ComplaintAndSuggestion complaintAndSuggestion) async {
    // if (await networkInfo.isConnected) {
    try {
      final data = ComplaintAndSuggestionModel(
        id: 0,
        message: complaintAndSuggestion.message,
        typeMessage: complaintAndSuggestion.typeMessage,
      );
      final remoteStore =
          await remoteDataSource.addComplaintAndSuggestion(data);
      return Right(remoteStore);
    } on ServerException {
      return Left(ServerFailure());
    }
    // } else {
    //   return Left(OfflineFailure());
    // }
  }
}
