import 'package:dartz/dartz.dart';

import '../../../../core/errors/exception.dart';
import '../../../../core/errors/failures.dart';
import '../../../../core/network/network_info.dart';
import '../../domain/entities/directorate.dart';
import '../../domain/repositories/directorates_repository.dart';
import '../datasources/directorates_remote_data_source.dart';

List<Directorate> cacheDirectoratesList = [];

class DirectoratesRepositoryImpl implements DirectoratesRepository {
  final DirectoratesRemoteDataSource directoratesRemoteDataSource;
  final NetworkInfo networkInfo;

  DirectoratesRepositoryImpl({
    required this.directoratesRemoteDataSource,
    required this.networkInfo,
  });

  @override
  Future<Either<Failure, List<Directorate>>> getAllDirectorates(
      int? cityId) async {
    if (cacheDirectoratesList.isEmpty) {
      try {
        final remoteDirectorates =
            await directoratesRemoteDataSource.getAllDirectorates(cityId);
        cacheDirectoratesList = remoteDirectorates;

        // return Right(remoteWallet);
        if (remoteDirectorates.isEmpty) {
          return Left(EmptyCacheFailure());
        } else {
          return Right(cacheDirectoratesList);
        }
      } on ServerException {
        return Left(ServerFailure());
      }
    } else {
      return Right(cacheDirectoratesList);
    }

    // if (await networkInfo.isConnected) {
    //   try {
    //     final remoteDirectorate =
    //         await directoratesRemoteDataSource.getAllCategories();
    //     // return Right(remoteWallet);
    //     if (remoteDirectorate.isEmpty) {
    //       return Left(EmptyCacheFailure());
    //     } else {
    //       return Right(remoteDirectorate);
    //     }
    //   } on ServerException {
    //     return Left(ServerFailure());
    //   }
    // } else {
    //   return Left(OfflineFailure());
    // }
  }
}
