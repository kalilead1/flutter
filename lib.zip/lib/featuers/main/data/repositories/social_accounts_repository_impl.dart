import 'package:booking_v1/core/errors/exception.dart';
import 'package:booking_v1/core/errors/failures.dart';
import 'package:booking_v1/core/network/network_info.dart';
import 'package:dartz/dartz.dart';

import '../../domain/entities/social_account.dart';
import '../../domain/repositories/social_accounts_repository.dart';
import '../datasources/social_accounts_remote_data_source.dart';

List<SocialAccount> cacheSocialAccountsList = [];

class SocialAccountsRepositoryImpl implements SocialAccountsRepository {
  final SocialAccountsRemoteDataSource remoteDataSource;
  final NetworkInfo networkInfo;

  SocialAccountsRepositoryImpl({
    required this.remoteDataSource,
    required this.networkInfo,
  });

  @override
  Future<Either<Failure, List<SocialAccount>>> getAllSocialAccounts() async {
    if (cacheSocialAccountsList.isEmpty) {
      // if (await networkInfo.isConnected) {
      try {
        final remoteWallet = await remoteDataSource.getAllSocialAccounts();
        // return Right(remoteWallet);
        if (remoteWallet.isEmpty) {
          return Left(EmptyCacheFailure());
        } else {
          return Right(remoteWallet);
        }
      } on ServerException {
        return Left(ServerFailure());
      }
      // } else {
      //   return Left(OfflineFailure());
      // }
    } else {
      return Right(cacheSocialAccountsList);
    }
  }
}
