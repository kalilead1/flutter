import 'package:dartz/dartz.dart';

import '../../../../core/errors/exception.dart';
import '../../../../core/errors/failures.dart';
import '../../../../core/network/network_info.dart';
import '../../domain/entities/city.dart';
import '../../domain/repositories/cities_repository.dart';
import '../datasources/cities_remote_data_source.dart';

List<City> cacheCitiesList = [];

class CitiesRepositoryImpl implements CitiesRepository {
  final CitiesRemoteDataSource citiesRemoteDataSource;
  final NetworkInfo networkInfo;

  CitiesRepositoryImpl({
    required this.citiesRemoteDataSource,
    required this.networkInfo,
  });

  @override
  Future<Either<Failure, List<City>>> getAllCities() async {
    if (cacheCitiesList.isEmpty) {
      try {
        final remoteCity = await citiesRemoteDataSource.getAllCities();
        cacheCitiesList = remoteCity;

        // return Right(remoteWallet);
        if (remoteCity.isEmpty) {
          return Left(EmptyCacheFailure());
        } else {
          return Right(cacheCitiesList);
        }
      } on ServerException {
        return Left(ServerFailure());
      }
    } else {
      return Right(cacheCitiesList);
    }

    // if (await networkInfo.isConnected) {
    //   try {
    //     final remoteCity =
    //         await citiesRemoteDataSource.getAllCategories();
    //     // return Right(remoteWallet);
    //     if (remoteCity.isEmpty) {
    //       return Left(EmptyCacheFailure());
    //     } else {
    //       return Right(remoteCity);
    //     }
    //   } on ServerException {
    //     return Left(ServerFailure());
    //   }
    // } else {
    //   return Left(OfflineFailure());
    // }
  }
}
