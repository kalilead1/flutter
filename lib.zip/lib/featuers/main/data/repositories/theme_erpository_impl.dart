import 'package:booking_v1/featuers/main/data/datasources/theme_local_data_source.dart';
import 'package:booking_v1/featuers/main/domain/enums/app_theme_mode.dart';
import 'package:booking_v1/featuers/main/domain/repositories/theme_repository.dart';

class ThemeRepositoryImpl implements ThemeRepository {
  final ThemeLocalDataSource local;

  ThemeRepositoryImpl(this.local);

  @override
  Future<void> saveTheme(AppThemeMode mode) async {
    await local.saveTheme(mode);
  }

  @override
  Future<AppThemeMode> loadTheme() async {
    return await local.loadTheme();
  }
}
