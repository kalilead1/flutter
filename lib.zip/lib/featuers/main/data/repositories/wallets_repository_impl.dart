import 'package:booking_v1/core/errors/exception.dart';
import 'package:booking_v1/core/errors/failures.dart';
import 'package:booking_v1/core/network/network_info.dart';
import 'package:booking_v1/featuers/main/data/datasources/wallets_remote_data_source.dart';
import 'package:booking_v1/featuers/main/domain/entities/wallet.dart';
import 'package:booking_v1/featuers/main/domain/repositories/wallets_repository.dart';
import 'package:dartz/dartz.dart';

List<Wallet> cacheWalletsList = [];

class WalletsRepositoryImpl implements WalletsRepository {
  final WalletsRemoteDataSource walletsRemoteDataSource;
  final NetworkInfo networkInfo;

  WalletsRepositoryImpl({
    required this.walletsRemoteDataSource,
    required this.networkInfo,
  });

  @override
  Future<Either<Failure, List<Wallet>>> getAllWallets() async {
    if (cacheWalletsList.isEmpty) {
      // if (await networkInfo.isConnected) {
      try {
        final remoteWallet = await walletsRemoteDataSource.getAllWallets();
        // return Right(remoteWallet);
        if (remoteWallet.isEmpty) {
          return Left(EmptyCacheFailure());
        } else {
          return Right(remoteWallet);
        }
      } on ServerException {
        return Left(ServerFailure());
      }
      // } else {
      //   return Left(OfflineFailure());
      // }
    } else {
      return Right(cacheWalletsList);
    }
  }
}
