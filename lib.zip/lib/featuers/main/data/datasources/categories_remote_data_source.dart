import 'dart:convert';

import 'package:booking_v1/core/constants/api.dart';
import 'package:booking_v1/core/errors/exception.dart';
import 'package:booking_v1/featuers/main/data/models/category_model.dart';
import 'package:booking_v1/featuers/main/domain/entities/category.dart';
import 'package:http/http.dart' as http;

abstract class CategoriesRemoteDataSource {
  Future<List<Category>> getAllCategories();
}

const String categoryUrl = "Categories";

class CategoriesRemoteDataSourceImpl implements CategoriesRemoteDataSource {
  final http.Client client;

  CategoriesRemoteDataSourceImpl({required this.client});

  @override
  Future<List<Category>> getAllCategories() async {
    final response = await client.get(Uri.parse(baseUrl + categoryUrl));
    if (response.statusCode == 200) {
      List jsonResponse = json.decode(response.body);
      return jsonResponse.map((get) => CategoryModel.fromJson(get)).toList();
      // return json.decode(response.body) as List;
    } else {
      throw ServerException();
    }
  }
}
