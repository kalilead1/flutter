import 'dart:convert';

import 'package:booking_v1/core/constants/api.dart';
import 'package:booking_v1/core/errors/exception.dart';
import 'package:booking_v1/featuers/main/data/models/wallet_model.dart';
import 'package:booking_v1/featuers/main/domain/entities/wallet.dart';
import 'package:http/http.dart' as http;

abstract class WalletsRemoteDataSource {
  Future<List<Wallet>> getAllWallets();
}

const String walletUrl = "Wallets/";

class WalletsRemoteDataSourceImpl implements WalletsRemoteDataSource {
  final http.Client client;

  WalletsRemoteDataSourceImpl({required this.client});

  @override
  Future<List<Wallet>> getAllWallets() async {
    final response = await client.get(Uri.parse(baseUrl + walletUrl));
    if (response.statusCode == 200) {
      List jsonResponse = json.decode(response.body);
      return jsonResponse.map((get) => WalletModel.fromJson(get)).toList();
    } else {
      throw ServerException();
    }
  }
}
