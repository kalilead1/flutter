import 'dart:convert';

import 'package:http/http.dart' as http;

import '../../../../core/constants/api.dart';
import '../../../../core/errors/exception.dart';
import '../../domain/entities/directorate.dart';
import '../models/directorate_model.dart';

abstract class DirectoratesRemoteDataSource {
  Future<List<Directorate>> getAllDirectorates(int? cityId);
}

const String directorateUrl = "Directorates/";

class DirectoratesRemoteDataSourceImpl implements DirectoratesRemoteDataSource {
  final http.Client client;

  DirectoratesRemoteDataSourceImpl({required this.client});

  @override
  Future<List<Directorate>> getAllDirectorates(int? cityId) async {
    final response = await client
        .get(Uri.parse('${baseUrl}${directorateUrl}ByCityId/$cityId'));
    if (response.statusCode == 200) {
      List jsonResponse = json.decode(response.body);
      return jsonResponse.map((get) => DirectorateModel.fromJson(get)).toList();
    } else {
      throw ServerException();
    }
  }
}
