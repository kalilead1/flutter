// import 'dart:convert';

// import 'package:booking_v1/core/constants/api.dart';
// import 'package:booking_v1/core/errors/exception.dart';
// import 'package:booking_v1/featuers/main/data/models/wallet_model.dart';
// import 'package:booking_v1/featuers/main/domain/entities/wallet.dart';
// import 'package:http/http.dart' as http;

// import '../../../../dtos/entities/app_offer.dart';
// import '../../domain/entities/category.dart';
// import '../../domain/entities/city.dart';
// import '../../domain/entities/directorate.dart';
// import '../../domain/entities/package.dart';
// import '../../domain/entities/social_account.dart';

// abstract class MainsRemoteDataSource {
//   Future<List<Category>> getCategories();
//   Future<List<Category>> getCategoriesByPackage(int packageId);
//   Future<List<Package>> getPackages();

//   ///
//   Future<List<City>> getCities();

//   ///
//   Future<List<Directorate>> getDirectorates(int cityId);

//   ///
//   Future<List<Wallet>> getWallets();
//   Future<List<SocialAccount>> getSocialAccounts();

//   ///
//   Future<List<AppOffer>> getAppOffers();
// }

// const String walletUrl = "Wallets/";

// class MainsRemoteDataSourceImpl implements MainsRemoteDataSource {
//   final http.Client client;

//   MainsRemoteDataSourceImpl({required this.client});

//   @override
//   Future<List<Wallet>> getAllWallets() async {
//     final response = await client.get(Uri.parse(baseUrl + walletUrl));
//     if (response.statusCode == 200) {
//       List jsonResponse = json.decode(response.body);
//       return jsonResponse.map((get) => WalletModel.fromJson(get)).toList();
//     } else {
//       throw ServerException();
//     }
//   }
// }
