import 'dart:convert';

import 'package:dartz/dartz.dart';
import 'package:http/http.dart' as http;

import '../../../../core/constants/api.dart';
import '../../../../core/errors/exception.dart';
import '../models/complaint_and_suggestion_model.dart';

abstract class ComplaintAndSuggestionRemoteDataSource {
  Future<Unit> addComplaintAndSuggestion(
      ComplaintAndSuggestionModel complaintAndSuggestionModel);
}

const String complaintAndSuggestionUrl = "ComplaintsAndSuggestions/";

class ComplaintAndSuggestionRemoteDataSourceImpl
    implements ComplaintAndSuggestionRemoteDataSource {
  final http.Client client;

  ComplaintAndSuggestionRemoteDataSourceImpl({required this.client});

  @override
  Future<Unit> addComplaintAndSuggestion(
      ComplaintAndSuggestionModel complaintAndSuggestionModel) async {
    final data = jsonEncode(complaintAndSuggestionModel.toJson());
    final response = await client.post(
        Uri.parse(baseUrl + complaintAndSuggestionUrl),
        headers: {"Content-Type": "application/json"},
        body: data);
    if (response.statusCode == 201 || response.statusCode == 200) {
      return Future.value(unit);
    } else {
      throw ServerException();
    }
  }
}
