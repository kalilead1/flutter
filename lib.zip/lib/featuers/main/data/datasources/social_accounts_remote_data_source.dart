import 'dart:convert';

import 'package:booking_v1/core/constants/api.dart';
import 'package:booking_v1/core/errors/exception.dart';
import 'package:booking_v1/featuers/main/data/models/social_account_model.dart';
import 'package:booking_v1/featuers/main/domain/entities/social_account.dart';
import 'package:http/http.dart' as http;

abstract class SocialAccountsRemoteDataSource {
  Future<List<SocialAccount>> getAllSocialAccounts();
}

const String socialAccountUrl = "SocialAccounts/";

class SocialAccountsRemoteDataSourceImpl
    implements SocialAccountsRemoteDataSource {
  final http.Client client;

  SocialAccountsRemoteDataSourceImpl({required this.client});

  @override
  Future<List<SocialAccount>> getAllSocialAccounts() async {
    final response = await client.get(Uri.parse(baseUrl + socialAccountUrl));
    if (response.statusCode == 200) {
      List jsonResponse = json.decode(response.body);
      return jsonResponse
          .map((get) => SocialAccountModel.fromJson(get))
          .toList();
    } else {
      throw ServerException();
    }
  }
}
