import 'dart:convert';

import 'package:booking_v1/core/constants/api.dart';
import 'package:booking_v1/core/errors/exception.dart';
import 'package:http/http.dart' as http;

import '../../domain/entities/city.dart';
import '../models/city_model.dart';

abstract class CitiesRemoteDataSource {
  Future<List<City>> getAllCities();
}

const String cityUrl = "Cities";

class CitiesRemoteDataSourceImpl implements CitiesRemoteDataSource {
  final http.Client client;

  CitiesRemoteDataSourceImpl({required this.client});

  @override
  Future<List<City>> getAllCities() async {
    final response = await client.get(Uri.parse(baseUrl + cityUrl));
    if (response.statusCode == 200) {
      List jsonResponse = json.decode(response.body);
      return jsonResponse.map((get) => CityModel.fromJson(get)).toList();
    } else {
      throw ServerException();
    }
  }
}
