import 'package:booking_v1/featuers/main/domain/enums/app_theme_mode.dart';
import 'package:shared_preferences/shared_preferences.dart';

class ThemeLocalDataSource {
  static const String _key = 'app_theme_mode';

  Future<void> saveTheme(AppThemeMode mode) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt(_key, mode.index);
  }

  Future<AppThemeMode> loadTheme() async {
    final prefs = await SharedPreferences.getInstance();
    final index = prefs.getInt(_key);
    if (index == null) return AppThemeMode.system;
    return AppThemeMode.values[index];
  }
}
