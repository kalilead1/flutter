import 'package:booking_v1/featuers/main/domain/entities/category.dart';
import 'package:equatable/equatable.dart';

abstract class CategoriesState extends Equatable {
  const CategoriesState();
  @override
  List<Object?> get props => [];
}

class CategoriesInitialState extends CategoriesState {}

class LoadingCategoriesState extends CategoriesState {}

class LoadedCategoriesState extends CategoriesState {
  final List<Category> categories;

  const LoadedCategoriesState({required this.categories});

  @override
  List<Object?> get props => [categories];
}

class ErrorCategoriesState extends CategoriesState {
  final String message;

  const ErrorCategoriesState({required this.message});

  @override
  List<Object?> get props => [message];
}
