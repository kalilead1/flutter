import 'package:dartz/dartz.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../../../../core/errors/failures.dart';
import '../../../../../core/helpers/failure_to_message.dart';
import '../../../data/repositories/categories_repository_impl.dart';
import '../../../domain/entities/category.dart';
import '../../../domain/usecases/categories_usecase.dart';
import 'categories_event.dart';
import 'categories_state.dart';

class CategoriesBloc extends Bloc<CategoriesEvent, CategoriesState> {
  final GetAllCategoriesUsecase? getAllCategoriesUsecase;

  CategoriesBloc({
    this.getAllCategoriesUsecase,
  }) : super(CategoriesInitialState()) {
    on<GetAllCategoriesEvent>((event, emit) async {
      emit(LoadingCategoriesState());

      final failureOrCategories = await getAllCategoriesUsecase!();
      emit(_mapFailureOrGetAllCategories(failureOrCategories));
    });
    on<RefreshAllCategoriesEvent>((event, emit) async {
      emit(LoadingCategoriesState());

      cacheCategoriesList = [];
      final failureOrCategories = await getAllCategoriesUsecase!();
      emit(_mapFailureOrGetAllCategories(failureOrCategories));
    });
  }

  CategoriesState _mapFailureOrGetAllCategories(
      Either<Failure, List<Category>> either) {
    return either.fold(
      (failure) => ErrorCategoriesState(message: failureToMessage(failure)),
      (categories) => LoadedCategoriesState(categories: categories),
    );
  }
}
