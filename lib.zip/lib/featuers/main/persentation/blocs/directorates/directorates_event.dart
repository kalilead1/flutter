import 'package:equatable/equatable.dart';

abstract class DirectoratesEvent extends Equatable {
  const DirectoratesEvent();
  @override
  List<Object?> get props => [];
}

class GetAllDirectoratesEvent extends DirectoratesEvent {
  final int? cityId;

  const GetAllDirectoratesEvent({this.cityId});
  @override
  List<Object?> get props => [cityId];
}

class RefreshAllDirectoratesEvent extends DirectoratesEvent {
  final int? cityId;

  const RefreshAllDirectoratesEvent({this.cityId});
  @override
  List<Object?> get props => [cityId];
}
