import 'package:dartz/dartz.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../../../../core/errors/failures.dart';
import '../../../../../core/helpers/failure_to_message.dart';
import '../../../data/repositories/directorates_repository_impl.dart';
import '../../../domain/entities/directorate.dart';
import '../../../domain/usecases/directorates_usecase.dart';
import 'directorates_event.dart';
import 'directorates_state.dart';

class DirectoratesBloc extends Bloc<DirectoratesEvent, DirectoratesState> {
  final GetAllDirectoratesUsecase? getAllDirectoratesUsecase;

  DirectoratesBloc({
    this.getAllDirectoratesUsecase,
  }) : super(DirectoratesInitialState()) {
    on<GetAllDirectoratesEvent>((event, emit) async {
      emit(LoadingDirectoratesState());

      final failureOrDirectorates =
          await getAllDirectoratesUsecase!(event.cityId);
      emit(_mapFailureOrGetAllDirectorates(failureOrDirectorates));
    });
    on<RefreshAllDirectoratesEvent>((event, emit) async {
      emit(LoadingDirectoratesState());

      cacheDirectoratesList = [];
      final failureOrDirectorates =
          await getAllDirectoratesUsecase!(event.cityId);
      emit(_mapFailureOrGetAllDirectorates(failureOrDirectorates));
    });
  }

  DirectoratesState _mapFailureOrGetAllDirectorates(
      Either<Failure, List<Directorate>> either) {
    return either.fold(
      (failure) => ErrorDirectoratesState(message: failureToMessage(failure)),
      (directorates) => LoadedDirectoratesState(directorates: directorates),
    );
  }
}
