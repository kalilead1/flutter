import 'package:equatable/equatable.dart';

import '../../../domain/entities/directorate.dart';

abstract class DirectoratesState extends Equatable {
  const DirectoratesState();
  @override
  List<Object?> get props => [];
}

class DirectoratesInitialState extends DirectoratesState {}

class LoadingDirectoratesState extends DirectoratesState {}

class LoadedDirectoratesState extends DirectoratesState {
  final List<Directorate> directorates;

  const LoadedDirectoratesState({required this.directorates});

  @override
  List<Object?> get props => [directorates];
}

class ErrorDirectoratesState extends DirectoratesState {
  final String message;

  const ErrorDirectoratesState({required this.message});

  @override
  List<Object?> get props => [message];
}
