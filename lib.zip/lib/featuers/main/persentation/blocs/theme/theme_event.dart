// import 'package:equatable/equatable.dart';

// abstract class ThemeEvent extends Equatable {
//   @override
//   List<Object?> get props => [];
// }

// class ToggleThemeEvent extends ThemeEvent {}

// class SetThemeEvent extends ThemeEvent {
//   final bool isDark;

//   SetThemeEvent(this.isDark);

//   @override
//   List<Object?> get props => [isDark];
// }

import 'package:booking_v1/featuers/main/domain/enums/app_theme_mode.dart';
import 'package:equatable/equatable.dart';

abstract class ThemeEvent extends Equatable {
  const ThemeEvent();

  @override
  List<Object?> get props => [];
}

class LoadThemeEvent extends ThemeEvent {}

class ChangeThemeEvent extends ThemeEvent {
  final AppThemeMode mode;

  const ChangeThemeEvent(this.mode);

  @override
  List<Object?> get props => [mode];
}
