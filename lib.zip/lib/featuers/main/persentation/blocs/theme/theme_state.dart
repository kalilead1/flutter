// import 'package:equatable/equatable.dart';

// class ThemeState extends Equatable {
//   final bool isDark;

//   const ThemeState({required this.isDark});

//   ThemeState copyWith({bool? isDark}) =>
//       ThemeState(isDark: isDark ?? this.isDark);

//   @override
//   List<Object?> get props => [isDark];
// }

import 'package:booking_v1/featuers/main/domain/enums/app_theme_mode.dart';
import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';

class ThemeState extends Equatable {
  final ThemeMode themeMode;
  final AppThemeMode savedMode;

  const ThemeState(
    this.themeMode,
    this.savedMode,
  );

  @override
  List<Object?> get props => [themeMode, savedMode];
}
