// import 'package:flutter_bloc/flutter_bloc.dart';
// import 'theme_event.dart';
// import 'theme_state.dart';

// class ThemeBloc extends Bloc<ThemeEvent, ThemeState> {
//   ThemeBloc() : super(const ThemeState(isDark: false)) {
//     on<ToggleThemeEvent>(_onToggleTheme);
//     on<SetThemeEvent>(_onSetTheme);
//   }

//   void _onToggleTheme(ToggleThemeEvent event, Emitter<ThemeState> emit) {
//     emit(state.copyWith(isDark: !state.isDark));
//   }

//   void _onSetTheme(SetThemeEvent event, Emitter<ThemeState> emit) {
//     emit(state.copyWith(isDark: event.isDark));
//   }
// }

import 'package:booking_v1/featuers/main/domain/enums/app_theme_mode.dart';
import 'package:booking_v1/featuers/main/domain/repositories/theme_repository.dart';
import 'package:booking_v1/featuers/main/persentation/blocs/theme/theme_event.dart';
import 'package:booking_v1/featuers/main/persentation/blocs/theme/theme_state.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

class ThemeBloc extends Bloc<ThemeEvent, ThemeState> {
  final ThemeRepository repo;

  ThemeBloc(this.repo)
      : super(const ThemeState(
          ThemeMode.system,
          AppThemeMode.system,
        )) {
    on<LoadThemeEvent>((event, emit) async {
      final mode = await repo.loadTheme();
      emit(ThemeState(_convert(mode), mode));
    });

    on<ChangeThemeEvent>((event, emit) async {
      await repo.saveTheme(event.mode);
      emit(ThemeState(_convert(event.mode), event.mode));
    });
  }

  ThemeMode _convert(AppThemeMode mode) {
    switch (mode) {
      case AppThemeMode.light:
        return ThemeMode.light;
      case AppThemeMode.dark:
        return ThemeMode.dark;
      default:
        return ThemeMode.system;
    }
  }
}
