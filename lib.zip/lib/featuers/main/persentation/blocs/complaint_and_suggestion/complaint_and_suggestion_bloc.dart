import 'package:flutter_bloc/flutter_bloc.dart';

import '../../../../../core/helpers/failure_to_message.dart';
import '../../../../../core/routing/navigation_service.dart';
import '../../../domain/usecases/complaint_and_suggestion_usecase.dart';
import 'complaint_and_suggestion_event.dart';
import 'complaint_and_suggestion_state.dart';

class ComplaintAndSuggestionBloc
    extends Bloc<ComplaintAndSuggestionEvent, ComplaintAndSuggestionState> {
  final AddComplaintAndSuggestionUsecase? addUsecase;

  ComplaintAndSuggestionBloc({this.addUsecase}) : super(InitialState()) {
    on<AddComplaintAndSuggestionEvent>((event, emit) async {
      emit(LoadingState());

      final failureOrSuccess = await addUsecase!(event.complaintAndSuggestion);
      failureOrSuccess.fold(
        (failure) => emit(ErrorAddedState(message: failureToMessage(failure))),
        (unit) {
          emit(SuccessfullyAddedState());
          // NavigationService.pop();
        },
      );
    });

    on<CancelAddedEvent>((event, emit) async {
      NavigationService.pop();
    });
  }
}
