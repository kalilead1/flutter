import 'package:equatable/equatable.dart';

abstract class ComplaintAndSuggestionState extends Equatable {
  const ComplaintAndSuggestionState();
  @override
  List<Object?> get props => [];
}

class InitialState extends ComplaintAndSuggestionState {}

class LoadingState extends ComplaintAndSuggestionState {}

class SuccessfullyAddedState extends ComplaintAndSuggestionState {}

class ErrorAddedState extends ComplaintAndSuggestionState {
  final String message;

  const ErrorAddedState({required this.message});

  @override
  List<Object?> get props => [message];
}
