import 'package:equatable/equatable.dart';

import '../../../domain/entities/complaint_and_suggestion.dart';

abstract class ComplaintAndSuggestionEvent extends Equatable {
  const ComplaintAndSuggestionEvent();
  @override
  List<Object?> get props => [];
}

class CancelAddedEvent extends ComplaintAndSuggestionEvent {}

class AddComplaintAndSuggestionEvent extends ComplaintAndSuggestionEvent {
  final ComplaintAndSuggestion complaintAndSuggestion;

  const AddComplaintAndSuggestionEvent({required this.complaintAndSuggestion});

  @override
  List<Object?> get props => [complaintAndSuggestion];
}
