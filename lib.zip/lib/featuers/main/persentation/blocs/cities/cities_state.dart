import 'package:booking_v1/featuers/main/domain/entities/city.dart';
import 'package:equatable/equatable.dart';

abstract class CitiesState extends Equatable {
  const CitiesState();
  @override
  List<Object?> get props => [];
}

class InitialState extends CitiesState {}

class LoadingState extends CitiesState {}

class LoadedCitiesState extends CitiesState {
  final List<City> city;

  const LoadedCitiesState({required this.city});

  @override
  List<Object?> get props => [city];
}

class ErrorState extends CitiesState {
  final String message;

  const ErrorState({required this.message});

  @override
  List<Object?> get props => [message];
}
