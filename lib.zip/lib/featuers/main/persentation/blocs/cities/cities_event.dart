import 'package:equatable/equatable.dart';

abstract class CitiesEvent extends Equatable {
  const CitiesEvent();
  @override
  List<Object?> get props => [];
}

class GetAllCitiesEvent extends CitiesEvent {}

class RefreshAllCitiesEvent extends CitiesEvent {}
