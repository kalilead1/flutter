import 'package:dartz/dartz.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../../../../core/errors/failures.dart';
import '../../../../../core/helpers/failure_to_message.dart';
import '../../../data/repositories/cities_repository_impl.dart';
import '../../../domain/entities/city.dart';
import '../../../domain/usecases/cities_usecase.dart';
import 'cities_event.dart';
import 'cities_state.dart';

class CitiesBloc extends Bloc<CitiesEvent, CitiesState> {
  final GetAllCitiesUsecase? getAllCitiesUsecase;

  CitiesBloc({
    this.getAllCitiesUsecase,
  }) : super(InitialState()) {
    on<GetAllCitiesEvent>((event, emit) async {
      emit(LoadingState());

      final failureOrCities = await getAllCitiesUsecase!();
      emit(_mapFailureOrGetAllCities(failureOrCities));
    });
    on<RefreshAllCitiesEvent>((event, emit) async {
      emit(LoadingState());

      cacheCitiesList = [];
      final failureOrCities = await getAllCitiesUsecase!();
      emit(_mapFailureOrGetAllCities(failureOrCities));
    });
  }

  CitiesState _mapFailureOrGetAllCities(Either<Failure, List<City>> either) {
    return either.fold(
      (failure) => ErrorState(message: failureToMessage(failure)),
      (cities) => LoadedCitiesState(city: cities),
    );
  }
}
