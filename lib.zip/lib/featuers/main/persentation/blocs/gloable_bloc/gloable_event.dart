import 'package:equatable/equatable.dart';

abstract class GloableEvent extends Equatable {
  const GloableEvent();
  @override
  List<Object?> get props => [];
}

class RefreshServiceEvent extends GloableEvent {}
