import 'package:flutter_bloc/flutter_bloc.dart';

import 'gloable_event.dart';
import 'gloable_state.dart';

class GloableBloc extends Bloc<GloableEvent, GloableState> {
  GloableBloc() : super(GloableState(counter: 0)) {
    on<GloableEvent>((event, emit) async {
      if (event is RefreshServiceEvent) {
        emit(GloableState(counter: state.counter + 1));
      }
    });
  }
}

final gloableBloc = GloableBloc();
