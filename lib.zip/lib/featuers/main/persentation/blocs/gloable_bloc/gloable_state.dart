import 'package:equatable/equatable.dart';

class GloableState extends Equatable {
  final int counter;
  const GloableState({required this.counter});
  @override
  List<Object?> get props => [counter];
}
