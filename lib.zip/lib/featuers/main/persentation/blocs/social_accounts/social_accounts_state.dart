import 'package:equatable/equatable.dart';

import '../../../domain/entities/social_account.dart';

abstract class SocialAccountsState extends Equatable {
  const SocialAccountsState();
  @override
  List<Object?> get props => [];
}

class InitialState extends SocialAccountsState {}

class LoadingState extends SocialAccountsState {}

class LoadedSocialAccountsState extends SocialAccountsState {
  final List<SocialAccount> socialAccounts;

  const LoadedSocialAccountsState({required this.socialAccounts});

  @override
  List<Object?> get props => [socialAccounts];
}

class ErrorState extends SocialAccountsState {
  final String message;

  const ErrorState({required this.message});

  @override
  List<Object?> get props => [message];
}
