import 'package:equatable/equatable.dart';

abstract class SocialAccountsEvent extends Equatable {
  const SocialAccountsEvent();
  @override
  List<Object?> get props => [];
}

class GetAllSocialAccountsEvent extends SocialAccountsEvent {}

class RefreshAllSocialAccountsEvent extends SocialAccountsEvent {}
