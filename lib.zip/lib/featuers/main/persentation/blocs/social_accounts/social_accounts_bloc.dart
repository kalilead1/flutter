import 'package:booking_v1/core/errors/failures.dart';
import 'package:booking_v1/core/helpers/failure_to_message.dart';
import 'package:dartz/dartz.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../../data/repositories/wallets_repository_impl.dart';
import '../../../domain/entities/social_account.dart';
import '../../../domain/usecases/social_accounts_usecase.dart';
import 'social_accounts_event.dart';
import 'social_accounts_state.dart';

class SocialAccountsBloc
    extends Bloc<SocialAccountsEvent, SocialAccountsState> {
  final GetAllSocialAccountsUsecase? getAllSocialAccountsUsecase;

  SocialAccountsBloc({
    this.getAllSocialAccountsUsecase,
  }) : super(InitialState()) {
    on<GetAllSocialAccountsEvent>((event, emit) async {
      emit(LoadingState());

      final failureOrSocialAccounts = await getAllSocialAccountsUsecase!();
      emit(_mapFailureOrGetAllSocialAccounts(failureOrSocialAccounts));
    });
    on<RefreshAllSocialAccountsEvent>((event, emit) async {
      cacheWalletsList = [];
      emit(LoadingState());

      final failureOrSocialAccounts = await getAllSocialAccountsUsecase!();
      emit(_mapFailureOrGetAllSocialAccounts(failureOrSocialAccounts));
    });
  }

  SocialAccountsState _mapFailureOrGetAllSocialAccounts(
      Either<Failure, List<SocialAccount>> either) {
    return either.fold(
      (failure) => ErrorState(message: failureToMessage(failure)),
      (socialAccounts) =>
          LoadedSocialAccountsState(socialAccounts: socialAccounts),
    );
  }
}
