import 'package:equatable/equatable.dart';

abstract class PermissionEvent extends Equatable {
  const PermissionEvent();
  @override
  List<Object?> get props => [];
}

class RequestPermissions extends PermissionEvent {}
