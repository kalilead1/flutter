// lib/features/permission/presentation/bloc/permission_bloc.dart
import 'package:equatable/equatable.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../../../../core/errors/failures.dart';
import '../../../domain/usecases/app_permissions_usecase.dart';

// Events
abstract class PermissionEvent extends Equatable {
  const PermissionEvent();
  @override
  List<Object?> get props => [];
}

class RequestPermissionsEvent extends PermissionEvent {}

/////////////////////////////////////////////////////////////
// States
abstract class PermissionState extends Equatable {
  const PermissionState();
  @override
  List<Object?> get props => [];
}

class PermissionInitial extends PermissionState {}

class PermissionGranted extends PermissionState {}

class PermissionDenied extends PermissionState {}

class PermissionError extends PermissionState {
  final String message;
  const PermissionError(this.message);

  @override
  List<Object?> get props => [message];
}

// Bloc
class PermissionBloc extends Bloc<PermissionEvent, PermissionState> {
  final RequestPermissionsUseCase? useCase;

  PermissionBloc({this.useCase}) : super(PermissionInitial()) {
    on<RequestPermissionsEvent>((event, emit) async {
      final result = await useCase!();
      result.fold(
        (failure) {
          if (failure is PermissionDeniedFailure) {
            emit(PermissionDenied());
          } else {
            emit(PermissionError(failure.toString()));
          }
        },
        (granted) => emit(granted ? PermissionGranted() : PermissionDenied()),
      );
    });
  }
}
