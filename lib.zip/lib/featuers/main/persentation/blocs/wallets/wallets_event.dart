import 'package:equatable/equatable.dart';

abstract class WalletsEvent extends Equatable {
  const WalletsEvent();
  @override
  List<Object?> get props => [];
}

class GetAllWalletsEvent extends WalletsEvent {}

class RefreshAllWalletsEvent extends WalletsEvent {}
