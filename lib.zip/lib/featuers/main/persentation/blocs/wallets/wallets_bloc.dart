import 'package:booking_v1/core/errors/failures.dart';
import 'package:booking_v1/core/helpers/failure_to_message.dart';
import 'package:booking_v1/featuers/main/domain/entities/wallet.dart';
import 'package:booking_v1/featuers/main/domain/usecases/wallets_usecase.dart';
import 'package:booking_v1/featuers/main/persentation/blocs/wallets/wallets_event.dart';
import 'package:booking_v1/featuers/main/persentation/blocs/wallets/wallets_state.dart';
import 'package:dartz/dartz.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../../data/repositories/wallets_repository_impl.dart';

class WalletsBloc extends Bloc<WalletsEvent, WalletsState> {
  final GetAllWalletsUsecase? getAllWalletUsecase;

  WalletsBloc({
    this.getAllWalletUsecase,
  }) : super(WalletsInitialState()) {
    on<GetAllWalletsEvent>((event, emit) async {
      emit(LoadingWalletsState());

      final failureOrWallets = await getAllWalletUsecase!();
      emit(_mapFailureOrGetAllWallets(failureOrWallets));
    });
    on<RefreshAllWalletsEvent>((event, emit) async {
      cacheWalletsList = [];

      emit(LoadingWalletsState());

      final failureOrWallets = await getAllWalletUsecase!();
      emit(_mapFailureOrGetAllWallets(failureOrWallets));
    });
  }

  WalletsState _mapFailureOrGetAllWallets(
      Either<Failure, List<Wallet>> either) {
    return either.fold(
      (failure) => ErrorWalletsState(message: failureToMessage(failure)),
      (wallets) => LoadedWalletsState(wallets: wallets),
    );
  }
}
