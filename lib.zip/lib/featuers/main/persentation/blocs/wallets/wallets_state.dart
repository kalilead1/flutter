import 'package:booking_v1/featuers/main/domain/entities/wallet.dart';
import 'package:equatable/equatable.dart';

abstract class WalletsState extends Equatable {
  const WalletsState();
  @override
  List<Object?> get props => [];
}

class WalletsInitialState extends WalletsState {}

class LoadingWalletsState extends WalletsState {}

class LoadedWalletsState extends WalletsState {
  final List<Wallet> wallets;

  const LoadedWalletsState({required this.wallets});

  @override
  List<Object?> get props => [wallets];
}

class ErrorWalletsState extends WalletsState {
  final String message;

  const ErrorWalletsState({required this.message});

  @override
  List<Object?> get props => [message];
}
