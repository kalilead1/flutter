// import 'package:flutter/src/widgets/framework.dart';
import 'package:booking_v1/core/constants/strings.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';

class ViewAppOffers extends StatelessWidget {
  final bool _isCarouselVisible = true;
  const ViewAppOffers({super.key});
  @override
  Widget build(BuildContext context) {
    return AnimatedContainer(
      duration: const Duration(milliseconds: 300),
      height: _isCarouselVisible ? 160.0 : 0.0,
      child: _isCarouselVisible
          ? CarouselSlider(
              options: CarouselOptions(
                // padEnds: false,
                height: 160.0,
                autoPlay: true,
                enlargeCenterPage: true,
                enlargeStrategy: CenterPageEnlargeStrategy.scale,
                // scrollDirection: Axis.vertical,
                viewportFraction: 0.8,
                aspectRatio: 2.0,
                initialPage: 0,
              ),
              items: [
                'assets/images/image1.jpg',
                'assets/images/image2.jpg',
                'assets/images/image3.jpg',
              ].map((i) {
                return Builder(
                  builder: (BuildContext context) {
                    return Container(
                      width: MediaQuery.of(context).size.width,
                      margin: const EdgeInsets.symmetric(horizontal: 0.0),
                      decoration: BoxDecoration(
                        borderRadius:
                            BorderRadius.circular(defaultBorderRadious),
                        // color: Color(0xFF3D6C91),
                        border: Border.all(
                          color:
                              // Theme.of(context).colorScheme.onPrimaryContainer,
                              Theme.of(context).colorScheme.primary,
                        ),
                        image: DecorationImage(
                          image: AssetImage(i),
                          fit: BoxFit.cover,
                        ),
                      ),
                    );
                  },
                );
              }).toList(),
            )
          : const SizedBox.shrink(),
    );
  }
}

class ViewAppOffersTest extends StatelessWidget {
  final bool _isCarouselVisible = true;
  const ViewAppOffersTest({super.key});
  @override
  Widget build(BuildContext context) {
    return AnimatedContainer(
      duration: const Duration(milliseconds: 300),
      height: _isCarouselVisible ? 160.0 : 0.0,
      child: _isCarouselVisible
          ? CarouselSlider(
              options: CarouselOptions(
                height: 160.0,
                autoPlay: true,
                enlargeCenterPage: true,
                viewportFraction: 0.8,
                aspectRatio: 2.0,
                initialPage: 0,
              ),
              items: [
                'assets/images/image1.jpg',
                'assets/images/image2.jpg',
                'assets/images/image3.jpg',
              ].map((i) {
                return Builder(
                  builder: (BuildContext context) {
                    return Container(
                      width: MediaQuery.of(context).size.width,
                      margin: const EdgeInsets.symmetric(horizontal: 0.0),
                      decoration: BoxDecoration(
                        borderRadius:
                            BorderRadius.circular(defaultBorderRadious),
                        // color: Color(0xFF3D6C91),
                        border: Border.all(
                          color:
                              // Theme.of(context).colorScheme.onPrimaryContainer,
                              Theme.of(context).colorScheme.primary,
                        ),
                        image: DecorationImage(
                          image: AssetImage(i),
                          fit: BoxFit.cover,
                        ),
                      ),
                    );
                  },
                );
              }).toList(),
            )
          : const SizedBox.shrink(),
    );
  }
}
