import 'package:booking_v1/core/routing/router_extensions.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../domain/enums/app_theme_mode.dart';
import '../blocs/theme/theme_bloc.dart';
import '../blocs/theme/theme_event.dart';
import '../blocs/theme/theme_state.dart';

void showThemeSheet(BuildContext context) {
  showModalBottomSheet(
    context: context,
    builder: (_) {
      return BlocBuilder<ThemeBloc, ThemeState>(
        builder: (context, state) {
          return SizedBox(
            height: 185,
            child: Padding(
              padding: EdgeInsets.symmetric(vertical: 40, horizontal: 25),
              child: Row(
                spacing: 10,
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  Expanded(
                    child: ThemeOptionButton(
                      label: 'النظام',
                      value: AppThemeMode.system,
                      groupValue: state.savedMode,
                      onChanged: () {
                        context
                            .read<ThemeBloc>()
                            .add(ChangeThemeEvent(AppThemeMode.system));
                      },
                    ),
                  ),
                  Expanded(
                    child: ThemeOptionButton(
                      label: 'فاتح',
                      value: AppThemeMode.light,
                      groupValue: state.savedMode,
                      onChanged: () {
                        context
                            .read<ThemeBloc>()
                            .add(ChangeThemeEvent(AppThemeMode.light));
                      },
                    ),
                  ),
                  Expanded(
                    child: ThemeOptionButton(
                      label: 'داكن',
                      value: AppThemeMode.dark,
                      groupValue: state.savedMode,
                      onChanged: () {
                        context
                            .read<ThemeBloc>()
                            .add(ChangeThemeEvent(AppThemeMode.dark));
                      },
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      );
    },
  );
}

class ThemeOptionButton extends StatelessWidget {
  final String label;
  final AppThemeMode value;
  final AppThemeMode groupValue;
  final Function() onChanged;

  const ThemeOptionButton({
    Key? key,
    required this.label,
    required this.value,
    required this.groupValue,
    required this.onChanged,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final isSelected = value == groupValue;

    return GestureDetector(
      onTap: () {
        context.back();
        onChanged();
      },
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 6),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: isSelected
              ? Theme.of(context).colorScheme.primary.withOpacity(0.15)
              : Colors.transparent,
          border: Border.all(
            color: isSelected
                ? Theme.of(context).colorScheme.primary
                : Colors.grey.shade400,
          ),
          borderRadius: BorderRadius.circular(12),
        ),
        child: Column(
          children: [
            Expanded(
              child: Text(
                label,
                style: TextStyle(
                  fontSize: 18,
                  color: Theme.of(context).textTheme.bodyLarge?.color,
                ),
              ),
            ),
            Icon(
              isSelected ? Icons.check_circle : Icons.radio_button_unchecked,
              color: isSelected
                  ? Theme.of(context).colorScheme.primary
                  : Colors.grey,
            ),
          ],
        ),
      ),
    );
  }
}
