import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:go_router/go_router.dart';

import '../../../../../../core/widgets/custom_bottom_sheet_widget.dart';
import '../../../../../../core/constants/strings.dart';
import '../../../../../../core/widgets/container_widgets.dart';
import '../../../../../core/errors/view_error_message_widget.dart';
import '../../../../../core/widgets/ciracle_loading_widget.dart';
import '../../../../../dependency_injection/initial.dart';
import '../../blocs/cities/cities_bloc.dart';
import '../../blocs/cities/cities_event.dart';
import '../../blocs/cities/cities_state.dart';

class SelectionCityWidget extends StatefulWidget {
  // final TextEditingController cityIdController;
  // // final int? initCityId;
  final ValueChanged onSelected;

  const SelectionCityWidget({
    super.key,
    // required this.cityIdController,
    required this.onSelected,
    // this.initCityId,
  });

  @override
  State<SelectionCityWidget> createState() => _SelectionCityWidgetState();
}

class _SelectionCityWidgetState extends State<SelectionCityWidget> {
  final TextEditingController textController = TextEditingController();

  late final CitiesBloc _citiesBloc;

  @override
  void initState() {
    super.initState();
    _citiesBloc = getIt<CitiesBloc>();

    // final int? cityId = int.tryParse(widget.cityIdController.text);
    // if (cityId != null) {
    //   _citiesBloc.add(GetCityByIdEvent(cityId: cityId));
    // }
  }

  Future<int?> _showCitiesModalBottomSheet() async {
    return await showModalBottomSheet<int>(
      context: context,
      builder: (context) => BlocProvider(
        create: (context) => getIt<CitiesBloc>()..add(GetAllCitiesEvent()),
        child: CustomBottomSheetWidget(
          appTitle: "اختار المدينة",
          onPressedReplay: () {
            _citiesBloc.add(RefreshAllCitiesEvent());
          },
          body: BlocBuilder<CitiesBloc, CitiesState>(
            builder: (context, state) {
              if (state is LoadingState) {
                return CiracleLoadingWidget();
              } else if (state is ErrorState) {
                return ViewErrorMessageWidget(errorMessage: state.message);
              } else if (state is LoadedCitiesState) {
                return ListView.separated(
                  itemBuilder: (context, index) {
                    final city = state.city[index];
                    return GestureDetector(
                      onTap: () {
                        setState(() {
                          textController.text = city.name!;
                        });
                        context.pop(city.id);
                      },
                      child: SecondaryContainer(
                        child: Text(
                          "${index + 1}.  ${city.name}",
                          style: Theme.of(context).textTheme.titleMedium,
                        ),
                      ),
                    );
                  },
                  separatorBuilder: (context, index) =>
                      SizedBox(height: defaultSpacing),
                  itemCount: state.city.length,
                );
              } else {
                return CiracleLoadingWidget();
              }
            },
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return TextFormField(
      style: TextStyle(letterSpacing: 0),
      decoration: InputDecoration(
        label: Text('المدينة'),
        suffixIcon: Icon(Icons.keyboard_arrow_down_outlined),
      ),
      controller: textController,
      validator: (value) {
        return value!.isEmpty ? "$textFieldIsEmptyMessage المدينة" : null;
      },
      readOnly: true,
      onTap: () async {
        final result = await _showCitiesModalBottomSheet();
        if (result != null) {
          widget.onSelected(result);
        }
      },
    );
  }
}

// class SelectionCityWidget extends StatelessWidget {
//   // final String label;
//   final TextEditingController cityIdController;
//   // final void Function(String?)? onChanged;
//   final ValueChanged? onSelected;

//   const SelectionCityWidget({
//     super.key,
//     // required this.label,
//     required this.cityIdController,
//     this.onSelected,
//   });

//   // final List<city> list = cityDataList;
//   // int cityId = 0;

//   @override
//   Widget build(BuildContext context) {
//     TextEditingController textController = TextEditingController(text: "jhjh");
//     return TextFormField(
//       style: TextStyle(letterSpacing: 0),
//       decoration: InputDecoration(
//         label: Text("الفئة"),
//         suffixIcon: Icon(Icons.keyboard_arrow_down_outlined),
//       ),
//       controller: textController,
//       validator: (value) {
//         return value!.isEmpty ? "$textFieldIsEmptyMessage الفئة" : null;
//       },
//       readOnly: true,
//       onTap: () async {
//         final result = showModalBottomSheet<String>(
//           context: context,
//           builder: (context) {
//             return citysListWidget();
//           },
//         );
//         if (result != null) {
//           onSelected!(await result);
//         }
//       },
//     );
//   }
// }

// class citysListWidget extends StatelessWidget {
//   const citysListWidget({super.key});

//   @override
//   Widget build(BuildContext context) {
//     return BlocProvider(
//       create: (context) => getIt<citysBloc>()..add(GetAllcitysEvent()),
//       child: CustomBottomSheetWidget(
//         appTitle: "اختار الفئة",
//         body: BlocBuilder<citysBloc, citysState>(
//           builder: (context, state) {
//             if (state is LoadingcitysState) {
//               return CiracleLoadingWidget();
//             } else if (state is ErrorcitysState) {
//               return ViewErrorMessageWidget(errorMessage: state.message);
//             } else if (state is LoadedcitysState) {
//               return ListView.separated(
//                 itemBuilder: (context, index) {
//                   final city = state.citys[index];
//                   return GestureDetector(
//                     onTap: () {
//                       Navigator.pop(context, city.id.toString());
//                     },
//                     child: SecondaryContainer(
//                       child: Text(
//                         "${index + 1}.  ${city.name}",
//                         style: Theme.of(context).textTheme.titleMedium,
//                       ),
//                     ),
//                   );
//                 },
//                 separatorBuilder: (context, index) =>
//                     SizedBox(height: defaultSpacing),
//                 itemCount: state.citys.length,
//               );
//             } else {
//               return CiracleLoadingWidget();
//             }
//           },
//         ),
//       ),
//     );
//   }
// }
