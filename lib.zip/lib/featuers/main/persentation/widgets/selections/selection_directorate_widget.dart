import 'package:booking_v1/core/errors/view_error_message_widget.dart';
import 'package:booking_v1/core/widgets/ciracle_loading_widget.dart';
import 'package:booking_v1/dependency_injection/initial.dart';
import 'package:booking_v1/featuers/main/persentation/blocs/directorates/directorates_event.dart';
import 'package:booking_v1/featuers/main/persentation/blocs/directorates/directorates_state.dart';

import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:go_router/go_router.dart';

import '../../../../../../core/widgets/custom_bottom_sheet_widget.dart';
import '../../../../../../core/constants/strings.dart';
import '../../../../../../core/widgets/container_widgets.dart';
import '../../blocs/directorates/directorates_bloc.dart';

class SelectionDirectorateWidget extends StatefulWidget {
  final int? cityId;
  final ValueChanged onSelected;

  const SelectionDirectorateWidget({
    super.key,
    this.cityId,
    required this.onSelected,
  });

  @override
  State<SelectionDirectorateWidget> createState() =>
      _SelectionDirectorateWidgetState();
}

class _SelectionDirectorateWidgetState
    extends State<SelectionDirectorateWidget> {
  final TextEditingController textController = TextEditingController();

  final TextEditingController initial = TextEditingController();
  late final DirectoratesBloc _directoratesBloc;
  // bool isEnable = false;

  @override
  void initState() {
    super.initState();

    _directoratesBloc = getIt<DirectoratesBloc>();
    if (widget.cityId == null) {
      textController.clear;
    }
    // if (widget.cityId != null) {
    //   isEnable = true;
    // }
  }

  Future<int?> _showDirectoratesModalBottomSheet() async {
    return await showModalBottomSheet<int>(
      context: context,
      builder: (context) => BlocProvider(
        create: (context) => getIt<DirectoratesBloc>()
          ..add(GetAllDirectoratesEvent(cityId: widget.cityId)),
        child: CustomBottomSheetWidget(
          appTitle: "اختار المديرية",
          onPressedReplay: () {
            _directoratesBloc.add(RefreshAllDirectoratesEvent());
          },
          body: BlocBuilder<DirectoratesBloc, DirectoratesState>(
            builder: (context, state) {
              if (state is LoadingDirectoratesState) {
                return CiracleLoadingWidget();
              } else if (state is ErrorDirectoratesState) {
                return ViewErrorMessageWidget(errorMessage: state.message);
              } else if (state is LoadedDirectoratesState) {
                return ListView.separated(
                  itemBuilder: (context, index) {
                    final directorate = state.directorates[index];
                    return GestureDetector(
                      onTap: () {
                        setState(() {
                          textController.text = directorate.name!;
                        });
                        context.pop(directorate.id);
                      },
                      child: SecondaryContainer(
                        child: Text(
                          "${index + 1}.  ${directorate.name}",
                          style: Theme.of(context).textTheme.titleMedium,
                        ),
                      ),
                    );
                  },
                  separatorBuilder: (context, index) =>
                      SizedBox(height: defaultSpacing),
                  itemCount: state.directorates.length,
                );
              } else {
                return CiracleLoadingWidget();
              }
            },
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    // final init =

    return TextFormField(
      enabled: widget.cityId == null ? false : true,
      // enabled: isEnable,
      style: TextStyle(letterSpacing: 0),
      decoration: InputDecoration(
        label: Text('المديرية'),
        suffixIcon: Icon(Icons.keyboard_arrow_down_outlined),
      ),
      controller: textController,
      validator: (value) {
        return value!.isEmpty || widget.cityId == null
            ? "$textFieldIsEmptyMessage المديرية"
            : null;
      },
      readOnly: true,
      onTap: () async {
        final result = await _showDirectoratesModalBottomSheet();
        if (result != null) {
          widget.onSelected(result);
        }
      },
    );
  }
}

// class SelectionDirectorateWidget extends StatelessWidget {
//   // final String label;
//   final TextEditingController directorateIdController;
//   // final void Function(String?)? onChanged;
//   final ValueChanged? onSelected;

//   const SelectionDirectorateWidget({
//     super.key,
//     // required this.label,
//     required this.directorateIdController,
//     this.onSelected,
//   });

//   // final List<directorate> list = directorateDataList;
//   // int directorateId = 0;

//   @override
//   Widget build(BuildContext context) {
//     TextEditingController textController = TextEditingController(text: "jhjh");
//     return TextFormField(
//       style: TextStyle(letterSpacing: 0),
//       decoration: InputDecoration(
//         label: Text("الفئة"),
//         suffixIcon: Icon(Icons.keyboard_arrow_down_outlined),
//       ),
//       controller: textController,
//       validator: (value) {
//         return value!.isEmpty ? "$textFieldIsEmptyMessage الفئة" : null;
//       },
//       readOnly: true,
//       onTap: () async {
//         final result = showModalBottomSheet<String>(
//           context: context,
//           builder: (context) {
//             return DirectoratesListWidget();
//           },
//         );
//         if (result != null) {
//           onSelected!(await result);
//         }
//       },
//     );
//   }
// }

// class DirectoratesListWidget extends StatelessWidget {
//   const DirectoratesListWidget({super.key});

//   @override
//   Widget build(BuildContext context) {
//     return BlocProvider(
//       create: (context) => getIt<DirectoratesBloc>()..add(GetAllDirectoratesEvent()),
//       child: CustomBottomSheetWidget(
//         appTitle: "اختار الفئة",
//         body: BlocBuilder<DirectoratesBloc, DirectoratesState>(
//           builder: (context, state) {
//             if (state is LoadingDirectoratesState) {
//               return CiracleLoadingWidget();
//             } else if (state is ErrorDirectoratesState) {
//               return ViewErrorMessageWidget(errorMessage: state.message);
//             } else if (state is LoadedDirectoratesState) {
//               return ListView.separated(
//                 itemBuilder: (context, index) {
//                   final directorate = state.Directorates[index];
//                   return GestureDetector(
//                     onTap: () {
//                       Navigator.pop(context, directorate.id.toString());
//                     },
//                     child: SecondaryContainer(
//                       child: Text(
//                         "${index + 1}.  ${directorate.name}",
//                         style: Theme.of(context).textTheme.titleMedium,
//                       ),
//                     ),
//                   );
//                 },
//                 separatorBuilder: (context, index) =>
//                     SizedBox(height: defaultSpacing),
//                 itemCount: state.Directorates.length,
//               );
//             } else {
//               return CiracleLoadingWidget();
//             }
//           },
//         ),
//       ),
//     );
//   }
// }
