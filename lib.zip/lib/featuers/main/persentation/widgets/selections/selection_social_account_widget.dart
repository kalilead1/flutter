import 'package:booking_v1/core/errors/view_error_message_widget.dart';
import 'package:booking_v1/core/widgets/ciracle_loading_widget.dart';
import 'package:booking_v1/dependency_injection/initial.dart';
import 'package:booking_v1/featuers/main/domain/entities/social_account.dart';

import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:go_router/go_router.dart';

import '../../../../../../core/widgets/custom_bottom_sheet_widget.dart';
import '../../../../../../core/constants/strings.dart';
import '../../../../../../core/widgets/container_widgets.dart';
import '../../blocs/social_accounts/social_accounts_bloc.dart';
import '../../blocs/social_accounts/social_accounts_event.dart';
import '../../blocs/social_accounts/social_accounts_state.dart';

class SelectionSocialAccountWidget extends StatefulWidget {
  final List<int> excludedSocialIds;
  final ValueChanged onSelected;

  const SelectionSocialAccountWidget({
    super.key,
    required this.excludedSocialIds,
    required this.onSelected,
  });

  @override
  State<SelectionSocialAccountWidget> createState() =>
      _SelectionSocialAccountWidgetState();
}

class _SelectionSocialAccountWidgetState
    extends State<SelectionSocialAccountWidget> {
  final TextEditingController textController = TextEditingController();

  late final SocialAccountsBloc _socialAccountsBloc;

  @override
  void initState() {
    super.initState();

    _socialAccountsBloc = getIt<SocialAccountsBloc>();
  }

  Future<SocialAccount?> _showModalBottomSheet() async {
    return await showModalBottomSheet<SocialAccount?>(
      context: context,
      builder: (context) => BlocProvider(
        create: (context) =>
            getIt<SocialAccountsBloc>()..add(GetAllSocialAccountsEvent()),
        child: CustomBottomSheetWidget(
          appTitle: "اختار حساب التواصل الاجتماعي",
          onPressedReplay: () {
            _socialAccountsBloc.add(RefreshAllSocialAccountsEvent());
          },
          body: BlocBuilder<SocialAccountsBloc, SocialAccountsState>(
            builder: (context, state) {
              if (state is LoadingState) {
                return CiracleLoadingWidget();
              } else if (state is ErrorState) {
                return ViewErrorMessageWidget(errorMessage: state.message);
              } else if (state is LoadedSocialAccountsState) {
                final socialAccounts = state.socialAccounts
                    .where((w) => !widget.excludedSocialIds.contains(w.id))
                    .toList();
                return ListView.separated(
                  itemBuilder: (context, index) {
                    final socialAccount = socialAccounts[index];
                    return GestureDetector(
                      onTap: () {
                        setState(() {
                          textController.text = socialAccount.name!;
                        });
                        context.pop(socialAccount);
                      },
                      child: SecondaryContainer(
                        child: Text(
                          "${index + 1}.  ${socialAccount.name}",
                          style: Theme.of(context).textTheme.titleMedium,
                        ),
                      ),
                    );
                  },
                  separatorBuilder: (context, index) =>
                      SizedBox(height: defaultSpacing),
                  itemCount: socialAccounts.length,
                );
              } else {
                return CiracleLoadingWidget();
              }
            },
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return TextFormField(
      style: TextStyle(letterSpacing: 0),
      decoration: InputDecoration(
        label: Text('حسابات التواصل'),
        suffixIcon: Icon(Icons.keyboard_arrow_down_outlined),
      ),
      controller: textController,
      validator: (value) {
        return value!.isEmpty
            ? "$textFieldIsEmptyMessage حسابات التواصل"
            : null;
      },
      readOnly: true,
      onTap: () async {
        final result = await _showModalBottomSheet();
        if (result != null) {
          widget.onSelected(result);
        }
      },
    );
  }
}
