import 'package:booking_v1/core/errors/view_error_message_widget.dart';
import 'package:booking_v1/core/widgets/ciracle_loading_widget.dart';
import 'package:booking_v1/dependency_injection/initial.dart';
import 'package:booking_v1/featuers/main/persentation/blocs/categories/categories_event.dart';
import 'package:booking_v1/featuers/main/persentation/blocs/categories/categories_state.dart';

import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:go_router/go_router.dart';

import '../../../../../../core/widgets/custom_bottom_sheet_widget.dart';
import '../../../../../../core/constants/strings.dart';
import '../../../../../../core/widgets/container_widgets.dart';
import '../../blocs/categories/categories_bloc.dart';

class SelectionCategoriesWidget extends StatefulWidget {
  final ValueChanged onSelected;

  const SelectionCategoriesWidget({
    super.key,
    required this.onSelected,
  });

  @override
  State<SelectionCategoriesWidget> createState() =>
      _SelectionCategoriesWidgetState();
}

class _SelectionCategoriesWidgetState extends State<SelectionCategoriesWidget> {
  final TextEditingController textController = TextEditingController();
  late final CategoriesBloc _categoriesBloc;

  @override
  void initState() {
    super.initState();
    _categoriesBloc = getIt<CategoriesBloc>();
  }

  Future<int?> _showCategoryModalBottomSheet() async {
    return await showModalBottomSheet<int>(
      context: context,
      builder: (context) => BlocProvider(
        create: (context) =>
            getIt<CategoriesBloc>()..add(GetAllCategoriesEvent()),
        child: CustomBottomSheetWidget(
          appTitle: "اختار الفئة",
          onPressedReplay: () {
            _categoriesBloc.add(RefreshAllCategoriesEvent());
          },
          body: BlocBuilder<CategoriesBloc, CategoriesState>(
            builder: (context, state) {
              if (state is LoadingCategoriesState) {
                return CiracleLoadingWidget();
              } else if (state is ErrorCategoriesState) {
                return ViewErrorMessageWidget(errorMessage: state.message);
              } else if (state is LoadedCategoriesState) {
                // if (widget.initCategoryId != null) {
                return ListView.separated(
                  itemBuilder: (context, index) {
                    final category = state.categories[index];
                    return GestureDetector(
                      onTap: () {
                        setState(() {
                          textController.text = category.name!;
                        });
                        context.pop(category.id);
                      },
                      child: SecondaryContainer(
                        child: Text(
                          "${index + 1}.  ${category.name}",
                          style: Theme.of(context).textTheme.titleMedium,
                        ),
                      ),
                    );
                  },
                  separatorBuilder: (context, index) =>
                      SizedBox(height: defaultSpacing),
                  itemCount: state.categories.length,
                );
              } else {
                return CiracleLoadingWidget();
              }
            },
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return TextFormField(
      style: TextStyle(letterSpacing: 0),
      decoration: InputDecoration(
        label: Text('الفئة'),
        suffixIcon: Icon(Icons.keyboard_arrow_down_outlined),
      ),
      controller: textController,
      validator: (value) {
        return value!.isEmpty ? "$textFieldIsEmptyMessage الفئة" : null;
      },
      readOnly: true,
      onTap: () async {
        final result = await _showCategoryModalBottomSheet();
        if (result != null) {
          widget.onSelected(result);
        }
      },
    );
  }
}

// import 'package:booking_v1/core/errors/view_error_message_widget.dart';
// import 'package:booking_v1/core/widgets/ciracle_loading_widget.dart';
// import 'package:booking_v1/dependency_injection/initial.dart';
// import 'package:booking_v1/featuers/main/persentation/bloc/categories/categories_event.dart';
// import 'package:booking_v1/featuers/main/persentation/bloc/categories/categories_state.dart';

// import 'package:flutter/material.dart';
// import 'package:flutter_bloc/flutter_bloc.dart';

// import '../../../../../../core/widgets/custom_bottom_sheet_widget.dart';
// import '../../../../../../core/constants/strings.dart';
// import '../../../../../../core/widgets/container_widgets.dart';
// import '../../bloc/categories/categories_bloc.dart';

// class SelectionCategoriesWidget extends StatefulWidget {
//   final TextEditingController categoryIdController;
//   // final int? initCategoryId;
//   final ValueChanged onSelected;

//   const SelectionCategoriesWidget({
//     super.key,
//     required this.categoryIdController,
//     required this.onSelected,
//     // this.initCategoryId,
//   });

//   @override
//   State<SelectionCategoriesWidget> createState() =>
//       _SelectionCategoriesWidgetState();
// }

// class _SelectionCategoriesWidgetState extends State<SelectionCategoriesWidget> {
//   final TextEditingController textController = TextEditingController();
//   late final CategoriesBloc _categoriesBloc;

//   @override
//   void initState() {
//     super.initState();
//     _categoriesBloc = getIt<CategoriesBloc>();

//     // final int? categoryId = int.tryParse(widget.categoryIdController.text);
//     // if (categoryId != null) {
//     //   _categoriesBloc.add(GetCategoryByIdEvent(categoryId: categoryId));
//     // }
//   }

//   Future<String?> _showCategoryModalBottomSheet() async {
//     return await showModalBottomSheet<String>(
//       context: context,
//       builder: (context) => BlocProvider(
//         create: (context) =>
//             getIt<CategoriesBloc>()..add(GetAllCategoriesEvent()),
//         child: CustomBottomSheetWidget(
//           appTitle: "اختار الفئة",
//           body: BlocBuilder<CategoriesBloc, CategoriesState>(
//             builder: (context, state) {
//               if (state is LoadingCategoriesState) {
//                 return CiracleLoadingWidget();
//               } else if (state is ErrorCategoriesState) {
//                 return ViewErrorMessageWidget(errorMessage: state.message);
//               } else if (state is LoadedCategoriesState) {
//                 // if (widget.initCategoryId != null) {
//                 return ListView.separated(
//                   itemBuilder: (context, index) {
//                     final category = state.categories[index];
//                     return GestureDetector(
//                       onTap: () {
//                         setState(() {
//                           textController.text = category.name!;
//                         });
//                         Navigator.pop(context, category.id.toString());
//                       },
//                       child: SecondaryContainer(
//                         child: Text(
//                           "${index + 1}.  ${category.name}",
//                           style: Theme.of(context).textTheme.titleMedium,
//                         ),
//                       ),
//                     );
//                   },
//                   separatorBuilder: (context, index) =>
//                       SizedBox(height: defaultSpacing),
//                   itemCount: state.categories.length,
//                 );
//                 // } else {
//                 //   final initCategory = state.category.firstWhere(
//                 //     (e) => e.id == widget.initCategoryId,
//                 //   );
//                 //   textController.text = initCategory.name!;
//                 // }
//               } else {
//                 return CiracleLoadingWidget();
//               }
//             },
//           ),
//         ),
//       ),
//     );
//   }

//   @override
//   Widget build(BuildContext context) {
//     return BlocListener<CategoriesBloc, CategoriesState>(
//       bloc: _categoriesBloc,
//       listener: (context, state) {
//         if (state is LoadedCategoryByIdState) {
//           textController.text = state.category.name!;
//           widget.categoryIdController.text = state.category.id.toString();
//         }
//       },
//       child: TextFormField(
//         style: TextStyle(letterSpacing: 0),
//         decoration: InputDecoration(
//           label: Text('الفئة'),
//           suffixIcon: Icon(Icons.keyboard_arrow_down_outlined),
//         ),
//         controller: textController,
//         validator: (value) {
//           return value!.isEmpty ? "$textFieldIsEmptyMessage الفئة" : null;
//         },
//         readOnly: true,
//         onTap: () async {
//           final result = await _showCategoryModalBottomSheet();
//           if (result != null) {
//             widget.onSelected(result);
//           }
//         },
//       ),
//     );
//   }
// }

// // class SelectionCategoriesWidget extends StatelessWidget {
// //   // final String label;
// //   final TextEditingController categoryIdController;
// //   // final void Function(String?)? onChanged;
// //   final ValueChanged? onSelected;

// //   const SelectionCategoriesWidget({
// //     super.key,
// //     // required this.label,
// //     required this.categoryIdController,
// //     this.onSelected,
// //   });

// //   // final List<Category> list = categoryDataList;
// //   // int categoryId = 0;

// //   @override
// //   Widget build(BuildContext context) {
// //     TextEditingController textController = TextEditingController(text: "jhjh");
// //     return TextFormField(
// //       style: TextStyle(letterSpacing: 0),
// //       decoration: InputDecoration(
// //         label: Text("الفئة"),
// //         suffixIcon: Icon(Icons.keyboard_arrow_down_outlined),
// //       ),
// //       controller: textController,
// //       validator: (value) {
// //         return value!.isEmpty ? "$textFieldIsEmptyMessage الفئة" : null;
// //       },
// //       readOnly: true,
// //       onTap: () async {
// //         final result = showModalBottomSheet<String>(
// //           context: context,
// //           builder: (context) {
// //             return CategoryListWidget();
// //           },
// //         );
// //         if (result != null) {
// //           onSelected!(await result);
// //         }
// //       },
// //     );
// //   }
// // }

// // class CategoryListWidget extends StatelessWidget {
// //   const CategoryListWidget({super.key});

// //   @override
// //   Widget build(BuildContext context) {
// //     return BlocProvider(
// //       create: (context) => getIt<CategoryBloc>()..add(GetAllCategoryEvent()),
// //       child: CustomBottomSheetWidget(
// //         appTitle: "اختار الفئة",
// //         body: BlocBuilder<CategoryBloc, CategoryState>(
// //           builder: (context, state) {
// //             if (state is LoadingCategoryState) {
// //               return CiracleLoadingWidget();
// //             } else if (state is ErrorCategoryState) {
// //               return ViewErrorMessageWidget(errorMessage: state.message);
// //             } else if (state is LoadedCategoryState) {
// //               return ListView.separated(
// //                 itemBuilder: (context, index) {
// //                   final category = state.Category[index];
// //                   return GestureDetector(
// //                     onTap: () {
// //                       Navigator.pop(context, category.id.toString());
// //                     },
// //                     child: SecondaryContainer(
// //                       child: Text(
// //                         "${index + 1}.  ${category.name}",
// //                         style: Theme.of(context).textTheme.titleMedium,
// //                       ),
// //                     ),
// //                   );
// //                 },
// //                 separatorBuilder: (context, index) =>
// //                     SizedBox(height: defaultSpacing),
// //                 itemCount: state.Category.length,
// //               );
// //             } else {
// //               return CiracleLoadingWidget();
// //             }
// //           },
// //         ),
// //       ),
// //     );
// //   }
// // }
