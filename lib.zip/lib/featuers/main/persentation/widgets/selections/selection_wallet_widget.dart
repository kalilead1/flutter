// import 'package:booking_v1/core/errors/view_error_message_widget.dart';
// import 'package:booking_v1/core/widgets/ciracle_loading_widget.dart';
// import 'package:booking_v1/dependency_injection/initial.dart';
// import 'package:booking_v1/featuers/main/persentation/bloc/wallets/wallets_event.dart';
// import 'package:booking_v1/featuers/main/persentation/bloc/wallets/wallets_state.dart';

// import 'package:flutter/material.dart';
// import 'package:flutter_bloc/flutter_bloc.dart';

// import '../../../../../../core/widgets/custom_bottom_sheet_widget.dart';
// import '../../../../../../core/constants/strings.dart';
// import '../../../../../../core/widgets/container_widgets.dart';
// import '../../bloc/wallets/wallets_bloc.dart';

// class SelectionWalletWidget extends StatefulWidget {
//   final TextEditingController walletIdController;
//   final ValueChanged onSelected;

//   const SelectionWalletWidget({
//     super.key,
//     required this.walletIdController,
//     required this.onSelected,
//   });

//   @override
//   State<SelectionWalletWidget> createState() => _SelectionWalletWidgetState();
// }

// class _SelectionWalletWidgetState extends State<SelectionWalletWidget> {
//   final TextEditingController textController = TextEditingController();

//   late final WalletsBloc _walletsBloc;

//   @override
//   void initState() {
//     super.initState();

//     _walletsBloc = getIt<WalletsBloc>();

//     final int? walletId = int.tryParse(widget.walletIdController.text);
//     if (walletId != null) {
//       _walletsBloc.add(GetWalletByIdEvent(walletId: walletId));
//     }
//   }

//   Future<String?> _showWalletsModalBottomSheet() async {
//     return await showModalBottomSheet<String>(
//       context: context,
//       builder: (context) => BlocProvider(
//         create: (context) => getIt<WalletsBloc>()..add(GetAllWalletsEvent()),
//         child: CustomBottomSheetWidget(
//           appTitle: "اختار محفظة",
//           body: BlocBuilder<WalletsBloc, WalletsState>(
//             builder: (context, state) {
//               if (state is LoadingWalletsState) {
//                 return CiracleLoadingWidget();
//               } else if (state is ErrorWalletsState) {
//                 return ViewErrorMessageWidget(errorMessage: state.message);
//               } else if (state is LoadedWalletsState) {
//                 return ListView.separated(
//                   itemBuilder: (context, index) {
//                     final wallet = state.wallets[index];
//                     return GestureDetector(
//                       onTap: () {
//                         setState(() {
//                           textController.text = wallet.name!;
//                         });
//                         Navigator.pop(context, wallet.id.toString());
//                       },
//                       child: SecondaryContainer(
//                         child: Text(
//                           "${index + 1}.  ${wallet.name}",
//                           style: Theme.of(context).textTheme.titleMedium,
//                         ),
//                       ),
//                     );
//                   },
//                   separatorBuilder: (context, index) =>
//                       SizedBox(height: defaultSpacing),
//                   itemCount: state.wallets.length,
//                 );
//               } else {
//                 return CiracleLoadingWidget();
//               }
//             },
//           ),
//         ),
//       ),
//     );
//   }

//   @override
//   Widget build(BuildContext context) {
//     return BlocListener<WalletsBloc, WalletsState>(
//       bloc: _walletsBloc,
//       listener: (context, state) {
//         if (state is LoadedWalletByIdState) {
//           textController.text = state.wallet.name!;
//           widget.walletIdController.text = state.wallet.id.toString();
//         }
//       },
//       child: TextFormField(
//         style: TextStyle(letterSpacing: 0),
//         decoration: InputDecoration(
//           label: Text('المحفظة'),
//           suffixIcon: Icon(Icons.keyboard_arrow_down_outlined),
//         ),
//         controller: textController,
//         validator: (value) {
//           return value!.isEmpty ? "$textFieldIsEmptyMessage المحفظة" : null;
//         },
//         readOnly: true,
//         onTap: () async {
//           final result = await _showWalletsModalBottomSheet();
//           if (result != null) {
//             widget.onSelected(result);
//           }
//         },
//       ),
//     );
//   }
// }
