import 'package:booking_v1/core/errors/view_error_message_widget.dart';
import 'package:booking_v1/core/widgets/ciracle_loading_widget.dart';
import 'package:booking_v1/dependency_injection/initial.dart';
import 'package:booking_v1/featuers/main/persentation/blocs/wallets/wallets_event.dart';
import 'package:booking_v1/featuers/main/persentation/blocs/wallets/wallets_state.dart';

import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:go_router/go_router.dart';

import '../../../../../../core/widgets/custom_bottom_sheet_widget.dart';
import '../../../../../../core/constants/strings.dart';
import '../../../../../../core/widgets/container_widgets.dart';
import '../../../domain/entities/wallet.dart';
import '../../blocs/wallets/wallets_bloc.dart';

class SelectionWalletWidgetTest extends StatefulWidget {
  final List<int> excludedWalletIds;
  final ValueChanged onSelected;

  const SelectionWalletWidgetTest({
    super.key,
    required this.onSelected,
    required this.excludedWalletIds,
  });

  @override
  State<SelectionWalletWidgetTest> createState() =>
      _SelectionWalletWidgetTestState();
}

class _SelectionWalletWidgetTestState extends State<SelectionWalletWidgetTest> {
  final TextEditingController textController = TextEditingController();

  late final WalletsBloc _walletsBloc;

  @override
  void initState() {
    super.initState();

    _walletsBloc = getIt<WalletsBloc>();
  }

  Future<Wallet?> _showWalletsModalBottomSheet() async {
    return await showModalBottomSheet<Wallet>(
      context: context,
      builder: (context) => BlocProvider(
        create: (context) => getIt<WalletsBloc>()..add(GetAllWalletsEvent()),
        child: CustomBottomSheetWidget(
          appTitle: "اختار محفظة",
          onPressedReplay: () {
            _walletsBloc.add(RefreshAllWalletsEvent());
          },
          body: BlocBuilder<WalletsBloc, WalletsState>(
            // bloc: _walletsBloc,
            builder: (context, state) {
              if (state is LoadingWalletsState) {
                return CiracleLoadingWidget();
              } else if (state is ErrorWalletsState) {
                return ViewErrorMessageWidget(errorMessage: state.message);
              } else if (state is LoadedWalletsState) {
                final wallets = state.wallets
                    .where((w) => !widget.excludedWalletIds.contains(w.id))
                    .toList();
                return ListView.separated(
                  itemBuilder: (context, index) {
                    final wallet = wallets[index];
                    return GestureDetector(
                      onTap: () {
                        setState(() {
                          textController.text = wallet.name!;
                        });
                        context.pop(wallet);
                      },
                      child: SecondaryContainer(
                        child: Text(
                          "${index + 1}.  ${wallet.name}",
                          style: Theme.of(context).textTheme.titleMedium,
                        ),
                      ),
                    );
                  },
                  separatorBuilder: (context, index) =>
                      SizedBox(height: defaultSpacing),
                  itemCount: wallets.length,
                );
              } else {
                return CiracleLoadingWidget();
              }
            },
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return TextFormField(
      style: TextStyle(letterSpacing: 0),
      decoration: InputDecoration(
        label: Text('المحفظة'),
        suffixIcon: Icon(Icons.keyboard_arrow_down_outlined),
      ),
      controller: textController,
      validator: (value) {
        return value!.isEmpty ? "$textFieldIsEmptyMessage المحفظة" : null;
      },
      readOnly: true,
      onTap: () async {
        final result = await _showWalletsModalBottomSheet();
        if (result != null) {
          widget.onSelected(result);
        }
      },
    );
  }
}
