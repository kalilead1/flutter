// import 'package:flutter/material.dart';
// import 'package:flutter_bloc/flutter_bloc.dart';

// import '../../../../../core/constants/strings.dart';
// import '../../../../../dependency_injection/initial.dart';
// import '../../bloc/categories/categories_bloc.dart';
// import '../../bloc/categories/categories_event.dart';
// import '../../bloc/categories/categories_state.dart';

// // class ViewCategorySmallWidget1 extends StatelessWidget {
// //   final int categoryId;
// //   const ViewCategorySmallWidget1({super.key, required this.categoryId});

// //   @override
// //   Widget build(BuildContext context) {
// //     return Container(
// //       padding: EdgeInsets.symmetric(horizontal: 8),
// //       decoration: BoxDecoration(
// //         color: Theme.of(context).colorScheme.primary,
// //         borderRadius: BorderRadius.circular(defaultBorderRadious),
// //       ),
// //       child: Text(
// //         textAlign: TextAlign.center,
// //         "$categoryId",
// //         // style: Theme.of(context).textTheme.titleSmall,
// //         style: TextStyle(
// //           fontSize: 11,
// //           color: Colors.white,
// //         ),
// //       ),
// //     );
// //   }
// // }

// // class ViewCategorySmallWidget2 extends StatelessWidget {
// //   final int categoryId;
// //   const ViewCategorySmallWidget2({super.key, required this.categoryId});

// //   @override
// //   Widget build(BuildContext context) {
// //     return Text(
// //       textAlign: TextAlign.center,
// //       "$categoryId",
// //       style: Theme.of(context).textTheme.displaySmall,
// //     );
// //   }
// // }

// // class ViewCategorySmallWidget extends StatelessWidget {
// //   final int categoryId;
// //   final TextStyle? textStyle;
// //   const ViewCategorySmallWidget(
// //       {super.key, required this.categoryId, this.textStyle});

// //   @override
// //   Widget build(BuildContext context) {
// //     return Text(
// //       textAlign: TextAlign.center,
// //       "$categoryId",
// //       style: textStyle ?? Theme.of(context).textTheme.displaySmall,
// //     );
// //   }
// // }

// class ViewCategoryPrimaryWidget extends StatelessWidget {
//   final int categoryId;
//   const ViewCategoryPrimaryWidget({super.key, required this.categoryId});

//   @override
//   Widget build(BuildContext context) {
//     return BlocProvider(
//       create: (context) => getIt<CategoriesBloc>()
//         ..add(GetCategoryByIdEvent(categoryId: categoryId)),
//       child: Container(
//         padding: EdgeInsets.symmetric(horizontal: 8),
//         decoration: BoxDecoration(
//           color: Theme.of(context).colorScheme.primary,
//           borderRadius: BorderRadius.circular(defaultBorderRadious),
//         ),
//         child: BlocBuilder<CategoriesBloc, CategoriesState>(
//           builder: (context, state) {
//             if (state is LoadedCategoryByIdState) {
//               return Text(
//                 textAlign: TextAlign.center,
//                 "${state.category.name}",
//                 // style: Theme.of(context).textTheme.titleSmall,
//                 style: TextStyle(
//                   fontSize: 11,
//                   color: Colors.white,
//                 ),
//               );
//             } else {
//               return Text(
//                 textAlign: TextAlign.center,
//                 "الفئة",
//                 // style: Theme.of(context).textTheme.titleSmall,
//                 style: TextStyle(
//                   fontSize: 11,
//                   color: Colors.white,
//                 ),
//               );
//             }
//           },
//         ),
//       ),
//     );
//   }
// }

// class ViewCategorySecondaryWidget extends StatelessWidget {
//   final int categoryId;
//   final TextStyle? textStyle;
//   const ViewCategorySecondaryWidget({
//     super.key,
//     required this.categoryId,
//     this.textStyle,
//   });

//   @override
//   Widget build(BuildContext context) {
//     return BlocProvider(
//       create: (context) => getIt<CategoriesBloc>()
//         ..add(GetCategoryByIdEvent(categoryId: categoryId)),
//       child: BlocBuilder<CategoriesBloc, CategoriesState>(
//         builder: (context, state) {
//           if (state is LoadedCategoryByIdState) {
//             return Text(
//               "${state.category.name}",
//               style: textStyle ?? Theme.of(context).textTheme.displaySmall,
//             );
//           } else {
//             return Text(
//               "الفئة",
//               // style: Theme.of(context).textTheme.titleSmall,
//               style: TextStyle(
//                 fontSize: 11,
//                 color: Colors.white,
//               ),
//             );
//           }
//         },
//       ),
//     );
//   }
// }

// class ViewCategoryWathBackgroundWidget extends StatelessWidget {
//   final int categoryId;
//   const ViewCategoryWathBackgroundWidget({super.key, required this.categoryId});

//   @override
//   Widget build(BuildContext context) {
//     return BlocProvider(
//       create: (context) => getIt<CategoriesBloc>()
//         ..add(GetCategoryByIdEvent(categoryId: categoryId)),
//       child: Container(
//         padding: EdgeInsets.symmetric(horizontal: 8),
//         decoration: BoxDecoration(
//           color: Theme.of(context).colorScheme.primary,
//           borderRadius: BorderRadius.circular(defaultBorderRadious),
//         ),
//         child: BlocBuilder<CategoriesBloc, CategoriesState>(
//           builder: (context, state) {
//             if (state is LoadedCategoryByIdState) {
//               return Text(
//                 textAlign: TextAlign.center,
//                 "${state.category.name}",
//                 // style: Theme.of(context).textTheme.titleSmall,
//                 style: TextStyle(
//                   fontSize: 11,
//                   color: Colors.white,
//                 ),
//               );
//             } else {
//               return Text(
//                 textAlign: TextAlign.center,
//                 "الفئة",
//                 // style: Theme.of(context).textTheme.titleSmall,
//                 style: TextStyle(
//                   fontSize: 11,
//                   color: Colors.white,
//                 ),
//               );
//             }
//           },
//         ),
//       ),
//     );
//   }
// }
