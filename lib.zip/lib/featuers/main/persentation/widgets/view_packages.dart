import 'package:booking_v1/core/constants/strings.dart';
import 'package:booking_v1/core/widgets/container_widgets.dart';
import 'package:flutter/material.dart';

import '../../../../tests/test_get_all_stores.dart';

class ViewPackages extends StatelessWidget {
  const ViewPackages({super.key});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: defaultPadding),
      child: Column(
        spacing: defaultSpacing / 3,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          GestureDetector(
            onTap: () {
              Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => TestGetAllStores(),
                  ));
            },
            child: SizedBox(
              height: 80,
              child: TertiaryContainer(child: SizedBox()),
            ),
          ),
        ],
      ),
    );
  }
}
