import 'package:flutter/material.dart';

class FavoritesPage extends StatefulWidget {
  const FavoritesPage({super.key});

  @override
  State<FavoritesPage> createState() => _FavoritesPageState();
}

class _FavoritesPageState extends State<FavoritesPage> {
  @override
  Widget build(BuildContext context) {
    return SizedBox();
    // return DefaultTabController(
    //   length: 7,
    //   child: Directionality(
    //     textDirection: TextDirection.rtl,
    //     child: Scaffold(
    //       appBar: AppBar(
    //         toolbarHeight: 24,
    //         bottom: PreferredSize(
    //           preferredSize: Size.fromHeight(5),
    //           child: TabBarServices(),
    //         ),
    //       ),
    //       body: TabBarViewServices(),
    //     ),
    //   ),
    // );
  }
}
