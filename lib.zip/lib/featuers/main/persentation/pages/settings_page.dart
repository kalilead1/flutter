import 'package:booking_v1/core/routing/app_routes.dart';
import 'package:booking_v1/core/routing/router_extensions.dart';
import 'package:flutter/material.dart';
import 'package:booking_v1/core/constants/colors.dart';
import 'package:booking_v1/core/constants/strings.dart';
import 'package:booking_v1/core/widgets/container_widgets.dart';
import 'package:flutter_svg/svg.dart';

import '../../../../core/widgets/icon_svg_widget.dart';
import '../widgets/theme_bottom_sheet.dart';

class SettingsPage extends StatelessWidget {
  const SettingsPage({super.key});
  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        body: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.all(defaultPadding),
            child: Column(
              spacing: 12,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Container(
                  padding: EdgeInsets.symmetric(vertical: 14),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(defaultBorderRadious),
                    color: Theme.of(context).colorScheme.primaryContainer,
                    border: Border.all(
                      color: Theme.of(context).colorScheme.onPrimaryContainer,
                    ),
                  ),
                  child: ListTile(
                    leading: CircleAvatar(
                      radius: 25,
                      backgroundColor: Theme.of(context).colorScheme.tertiary,
                      child: IconSvg(
                        iconName: "User Icon",
                        color: Theme.of(context).colorScheme.secondary,
                      ),
                    ),
                    title: Text(
                      "اسم المستخدم",
                      style: Theme.of(context).textTheme.titleLarge,
                    ),
                    subtitle: Text("777 777 777",
                        style: Theme.of(context).textTheme.labelLarge),
                    trailing: Wrap(
                      crossAxisAlignment: WrapCrossAlignment.end,
                      runSpacing: 5,
                      children: [
                        IconButton(
                          onPressed: () {},
                          icon: Icon(Icons.edit),
                        ),
                        IconButton(
                          onPressed: () {},
                          icon: IconSvg(
                            iconName: "Log out",
                            color: errorColor,
                          ),
                        ),
                      ],
                    ),
                    onTap: () {
                      context.pushTo(profileUserRoute, extra: 1);
                    },
                  ),
                ),
                _myStore(context: context),
                SecondaryContainer(
                  paddingHorizontal: 0,
                  paddingVertical: 0,
                  child: Column(
                    children: [
                      _listTile(
                        context: context,
                        icon: Icons.location_city,
                        title: "المدينة",
                        onTap: () {},
                      ),
                      _listTile(
                        context: context,
                        icon: Theme.of(context).brightness.name == "dark"
                            ? Icons.dark_mode_rounded
                            : Icons.light_mode_rounded,
                        title: Theme.of(context).brightness.name == "dark"
                            ? "الوضع الليلي"
                            : "الوضع الفاتح",
                        onTap: () {
                          showThemeSheet(context);
                        },
                      ),
                      _listTile(
                        context: context,
                        icon: Icons.help,
                        title: "مساعدة",
                        onTap: () {},
                      ),
                    ],
                  ),
                ),
                SecondaryContainer(
                  paddingHorizontal: 0,
                  paddingVertical: 0,
                  child: Column(
                    children: [
                      _listTile(
                        context: context,
                        icon: Icons.message,
                        title: "شكوى او مقترح",
                        onTap: () {
                          context.pushTo(complaintAndSuggestionRoute);
                        },
                      ),
                      _listTile(
                        context: context,
                        icon: Icons.privacy_tip,
                        title: "سياسة الخصوصية",
                        onTap: () {},
                      ),
                      _listTile(
                        context: context,
                        icon: Icons.star_purple500_outlined,
                        title: "تقييم التطبيق",
                        onTap: () {},
                      ),
                      _listTile(
                        context: context,
                        icon: Icons.share,
                        title: "مشاركة التطبيق",
                        onTap: () {},
                      ),
                      _listTile(
                        context: context,
                        icon: Icons.support_agent,
                        title: "الدعم الفني",
                        onTap: () {},
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  ListTile _listTile(
      {required BuildContext context,
      required IconData icon,
      required String title,
      required Function() onTap}) {
    return ListTile(
      leading: Icon(
        icon,
        color: Theme.of(context).colorScheme.primary,
      ),
      title: Text(
        title,
        style: Theme.of(context).textTheme.titleMedium,
      ),
      trailing: Icon(Icons.chevron_right),
      onTap: onTap,
      splashColor: Theme.of(context).colorScheme.primary.withOpacity(0.20),
      dense: true,
    );
  }

  Container _myStore({required BuildContext context}) {
    return Container(
      decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(defaultBorderRadious),
          color: Theme.of(context).colorScheme.primary.withOpacity(0.80),
          border: Border.all(color: Theme.of(context).colorScheme.primary)),
      child: ListTile(
        leading: SvgPicture.asset(
          "assets/icons/Shop Icon.svg",
          colorFilter: ColorFilter.mode(
            Colors.white,
            BlendMode.srcIn,
          ),
          height: 22,
        ),
        title: Text(
          "المتجر الخاص بي",
          style: TextStyle(fontSize: 16, color: Colors.white),
        ),
        trailing: Icon(Icons.chevron_right, color: Colors.white),
        onTap: () {
          context.pushTo(storeOwnerRoute, extra: 4);
          // showModalBottomSheet(
          //   scrollControlDisabledMaxHeightRatio: 0.3,
          //   context: context,
          //   builder: (context) {
          //     return Padding(
          //       padding: const EdgeInsets.all(defaultPadding),
          //       child: Column(
          //         spacing: defaultSpacing,
          //         mainAxisAlignment: MainAxisAlignment.spaceBetween,
          //         children: [
          //           SizedBox(
          //             height: 40,
          //             child: Center(
          //               child: Text(
          //                 "الدخول الى المتجر",
          //                 style: Theme.of(context).textTheme.displayLarge,
          //               ),
          //             ),
          //           ),
          //           Column(
          //             spacing: defaultSpacing,
          //             children: [
          //               OutlinedButton(
          //                   onPressed: () {
          //                     // Navigator.pop(context);
          //                     // Navigator.push(
          //                     //     context,
          //                     //     MaterialPageRoute(
          //                     //         builder: (context) => StoresOwnerPage(
          //                     //               ownerId: 1,
          //                     //             )));
          //                     context.back();
          //                     context.pushTo(storeOwnerRoute, extra: 1);
          //                   },
          //                   child: Text("كمالك")),
          //               OutlinedButton(onPressed: () {}, child: Text("كمشغل")),
          //               SizedBox(),
          //             ],
          //           ),
          //         ],
          //       ),
          //     );
          //   },
          // );
        },
      ),
    );
  }
}
