import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:booking_v1/core/constants/colors.dart';
import 'package:booking_v1/core/constants/strings.dart';

import '../../../../core/widgets/botton_widghts.dart';

class ErrorScreenPage extends StatelessWidget {
  const ErrorScreenPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          title: Text("صفحة الاخطاء"),
        ),
        body: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.all(defaultPadding),
            child: Column(
              spacing: defaultSpacing,
              // crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                // ViewService(),

                Container(
                  height: 150,
                  padding: EdgeInsets.all(defaultPadding),
                  decoration: BoxDecoration(
                    color: errorColor,
                    borderRadius: BorderRadius.circular(defaultBorderRadious),
                  ),
                  child: Text("لا يوجد صفحة"),
                ),
                Container(
                  constraints: BoxConstraints(
                    minWidth: MediaQuery.of(context).size.width,
                  ),
                  height: 200,
                  // padding: EdgeInsets.all(defaultPadding / 2),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(defaultBorderRadious),
                    gradient: LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.center,
                      colors: [
                        Colors.blueAccent,
                        Colors.transparent,
                      ],
                    ),
                  ),
                  // child: HeadService(
                  //     storeName: "storeName",
                  //     storeLocation: "storeLocation",
                  //     storeLogo: "storeLogo",
                  //     serviceRating: 3.5),
                  child: Container(
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topCenter,
                        end: Alignment.center,
                        colors: [
                          Colors.blueAccent,
                          const Color.fromARGB(188, 131, 21, 21),
                        ],
                      ),
                    ),
                    child: ListTile(
                      leading: CircleAvatar(
                        backgroundColor: Theme.of(context).colorScheme.tertiary,
                        radius: 20,
                      ),
                      title: Text(
                        "store Name",
                        style: Theme.of(context).textTheme.titleSmall,
                      ),
                      subtitle: Text(
                        "Location",
                        style: Theme.of(context).textTheme.bodySmall,
                      ),
                      trailing: Wrap(
                        alignment: WrapAlignment.center,
                        crossAxisAlignment: WrapCrossAlignment.center,
                        children: [
                          IconButton(
                            onPressed: () {},
                            icon: Icon(Icons.favorite_border),
                          ),
                          Container(
                            padding: EdgeInsets.symmetric(horizontal: 5),
                            decoration: BoxDecoration(
                              borderRadius:
                                  BorderRadius.circular(defaultBorderRadious),
                              color: Theme.of(context)
                                  .colorScheme
                                  .primary
                                  .withOpacity(0.20),
                              border: Border.all(
                                  color: Theme.of(context).colorScheme.primary),
                            ),
                            child: Wrap(
                              alignment: WrapAlignment.center,
                              crossAxisAlignment: WrapCrossAlignment.center,
                              children: [
                                Text(
                                  "3.5",
                                  style: Theme.of(context).textTheme.titleSmall,
                                ),
                                Icon(
                                  Icons.star,
                                  size: 20,
                                  color: warningColor,
                                ),
                              ],
                            ),
                            // ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
        bottomNavigationBar: Padding(
          padding: EdgeInsets.only(
            bottom: defaultPadding,
            left: defaultPadding,
            right: defaultPadding,
            top: defaultPadding / 2,
          ),
          child: PrimaryElevatedButton(
            onPressed: () {},
            text: "TertiaryElevatedButton",
          ),
        ),

        // bottomNavigationBar: ClipRRect(
        //   child: BackdropFilter(
        //     filter: ImageFilter.blur(sigmaX: 50, sigmaY: 100),
        //     child: BottomAppBar(
        //       color: Colors.transparent,
        //       elevation: 0,
        //       child: Padding(
        //         padding: EdgeInsets.only(bottom: 0),
        //         child: PrimaryElevatedButton(
        //           onPressed: () {},
        //           text: "TertiaryElevatedButton",
        //         ),
        //       ),
        //     ),
        //   ),
        // ),

        // floatingActionButton: Row(
        //   spacing: defaultSpacing,
        //   children: [
        //     Expanded(
        //       child: PrimaryElevatedButton(
        //         onPressed: () {},
        //         text: "احجز الان",
        //       ),
        //     ),
        //     Expanded(
        //       child: SecondaryElevatedButton(
        //         onPressed: () {},
        //         text: "المبلغ",
        //       ),
        //     ),
        //   ],
        // ),
        // floatingActionButtonLocation: FloatingActionButtonLocation.centerFloat,
      ),
    );
  }
}

// import 'package:flutter/material.dart';

class CardInfo extends StatelessWidget {
  const CardInfo({
    super.key,
    required this.last4Digits,
    required this.name,
    required this.expiryDate,
    this.isSelected = false,
    this.press,
    this.bgColor = darkPrimaryColor,
  });

  final String last4Digits, name, expiryDate;
  final bool isSelected;
  final VoidCallback? press;
  final Color bgColor;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: press,
      child: Column(
        children: [
          AspectRatio(
            aspectRatio: 2,
            child: Container(
              decoration: BoxDecoration(
                color: bgColor,
                borderRadius: const BorderRadius.all(
                  Radius.circular(defaultBorderRadious * 2),
                ),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Expanded(
                    child: Padding(
                      padding: const EdgeInsets.symmetric(
                          horizontal: defaultPadding),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Spacer(),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text("4444"),
                              if (isSelected)
                                CircleAvatar(
                                  radius: 12,
                                  backgroundColor: Colors.white,
                                  child: Padding(
                                      padding: const EdgeInsets.all(
                                          defaultPadding / 4),
                                      child: Text("333333")),
                                )
                            ],
                          ),
                          const Spacer(),
                          Text(
                            "**** **** **** $last4Digits",
                            style: const TextStyle(
                                color: Colors.white,
                                fontSize: 18,
                                fontWeight: FontWeight.w500),
                          ),
                          const SizedBox(height: defaultPadding),
                        ],
                      ),
                    ),
                  ),
                  SizedBox(
                    height: 80,
                    width: double.infinity,
                    child: Stack(
                      children: [
                        Text("222"),
                        Padding(
                          padding: const EdgeInsets.all(defaultPadding),
                          child: DefaultTextStyle(
                            style: const TextStyle(
                              fontWeight: FontWeight.w500,
                              color: Colors.white70,
                            ),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(name),
                                const SizedBox(height: defaultPadding / 4),
                                Text(expiryDate)
                              ],
                            ),
                          ),
                        )
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
          if (isSelected) const SizedBox(height: defaultPadding),
          if (isSelected)
            Form(
              child: TextFormField(
                validator: (value) {
                  return null;
                },
                onSaved: (cvv) {},
                keyboardType: TextInputType.number,
                maxLength: 4,
                inputFormatters: [
                  FilteringTextInputFormatter.digitsOnly,
                ],
                decoration: InputDecoration(
                  hintText: "CVV",
                  counterText: "",
                  prefixIcon: Padding(
                    padding: const EdgeInsets.symmetric(
                        vertical: defaultPadding * 0.75),
                    child: Text("data"),
                  ),
                ),
              ),
            ),
          if (isSelected) const SizedBox(height: defaultPadding / 2),
        ],
      ),
    );
  }
}
