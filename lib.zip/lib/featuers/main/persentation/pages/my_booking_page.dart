import 'package:booking_v1/featuers/bookings/persentation/pages/view_user_bookings_page.dart';
import 'package:flutter/material.dart';

class MyBookingPage extends StatefulWidget {
  const MyBookingPage({super.key});

  @override
  State<MyBookingPage> createState() => _MyBookingPageState();
}

class _MyBookingPageState extends State<MyBookingPage> {
  @override
  Widget build(BuildContext context) {
    return ViewUserBookingsPage();
  }
}
