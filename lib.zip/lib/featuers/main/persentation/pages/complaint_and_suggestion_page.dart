import 'package:booking_v1/core/constants/strings.dart';
import 'package:booking_v1/core/widgets/bottom_items.dart';
import 'package:booking_v1/core/widgets/botton_widghts.dart';
import 'package:booking_v1/core/widgets/input_widgets.dart';
import 'package:booking_v1/core/widgets/snack_bar_widgets.dart';
import 'package:booking_v1/featuers/main/persentation/blocs/complaint_and_suggestion/complaint_and_suggestion_event.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../domain/entities/complaint_and_suggestion.dart';
import '../../domain/enums/complaint_and_suggestion_enum.dart';
import '../blocs/complaint_and_suggestion/complaint_and_suggestion_bloc.dart';
import '../blocs/complaint_and_suggestion/complaint_and_suggestion_state.dart';

class ComplaintAndSuggestionPage extends StatefulWidget {
  const ComplaintAndSuggestionPage({super.key});

  @override
  State<ComplaintAndSuggestionPage> createState() =>
      _ComplaintAndSuggestionPageState();
}

class _ComplaintAndSuggestionPageState
    extends State<ComplaintAndSuggestionPage> {
  // استخدام Enum لتحديد النوع النشط
  ComplaintAndSuggestionEnum selectedType =
      ComplaintAndSuggestionEnum.suggestion;

  final TextEditingController _messageController = TextEditingController();

  // دالة للتعامل مع تغيير النوع
  void _onTypeSelected(ComplaintAndSuggestionEnum type) {
    setState(() {
      selectedType = type;
    });
  }

  // دالة للإرسال
  void _submitMessage() {
    String message = _messageController.text.trim();

    if (message.isEmpty) {
      showSnackBarError(context: context, error: 'الرجاء كتابة الرسالة');
    } else {
      final data = ComplaintAndSuggestion(
          id: 0, message: _messageController.text, typeMessage: selectedType);
      context
          .read<ComplaintAndSuggestionBloc>()
          .add(AddComplaintAndSuggestionEvent(complaintAndSuggestion: data));
      _messageController.clear();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          title: Text('الشكاوى والبلاغات'),
        ),
        body: BlocConsumer<ComplaintAndSuggestionBloc,
            ComplaintAndSuggestionState>(
          listener: (context, state) {
            if (state is SuccessfullyAddedState) {
              return showSnackBarSuccess(
                  context: context,
                  success: 'تم إرسال ${selectedType.arabicName} بنجاح');
            } else if (state is ErrorAddedState) {
              return showSnackBarError(context: context, error: state.message);
            }
          },
          builder: (context, state) {
            if (state is LoadingState) {
              return Center(child: CircularProgressIndicator());
            }
            return Padding(
              padding: const EdgeInsets.all(defaultPadding),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const SizedBox(height: 20),

                  // Switch buttons باستخدام Enum
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 60),
                    child: Container(
                      decoration: BoxDecoration(
                        color: Theme.of(context).colorScheme.primaryContainer,
                        borderRadius: BorderRadius.circular(30),
                      ),
                      padding: const EdgeInsets.all(4),
                      child: Row(
                        children: [
                          // زر بلاغ (Report)
                          Expanded(
                            child: _buildSwitchButton(
                              context: context,
                              type: ComplaintAndSuggestionEnum.suggestion,
                              label: 'مقترح',
                            ),
                          ),

                          // زر شكوى (Complaint)
                          Expanded(
                            child: _buildSwitchButton(
                              context: context,
                              type: ComplaintAndSuggestionEnum.complaint,
                              label: 'شكوى',
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 30),

                  // حقل الرسالة
                  CustomInputFieldWidget(
                    label: 'رسالة ال${selectedType.arabicName}',
                    textController: _messageController,
                    maxLength: 150,
                    minLines: 1,
                    maxLines: 4,
                    textInputType: TextInputType.name,
                  ),
                ],
              ),
            );
          },
        ),
        bottomNavigationBar: TwoBottomItems(
            child1: PrimaryElevatedButton(
          onPressed: _submitMessage,
          text: "ارسال ال${selectedType.arabicName}",
        )),
      ),
    );
  }
// class _ComplaintAndSuggestionPageState
//     extends State<ComplaintAndSuggestionPage> {
//   // استخدام Enum لتحديد النوع النشط
//   ComplaintAndSuggestionEnum selectedType =
//       ComplaintAndSuggestionEnum.suggestion;

//   final TextEditingController _messageController = TextEditingController();

//   // دالة للتعامل مع تغيير النوع
//   void _onTypeSelected(ComplaintAndSuggestionEnum type) {
//     setState(() {
//       selectedType = type;
//     });
//   }

//   // دالة للإرسال
//   void _submitMessage() {
//     String message = _messageController.text.trim();

//     if (message.isEmpty) {
//       ScaffoldMessenger.of(context).showSnackBar(
//         const SnackBar(
//           content: Text('الرجاء كتابة الرسالة'),
//           backgroundColor: Colors.red,
//         ),
//       );
//       return;
//     }

//     // هنا يمكنك التعامل مع النوع والرسالة
//     String typeName = selectedType.arabicName;

//     ScaffoldMessenger.of(context).showSnackBar(
//       SnackBar(
//         content: Text('تم إرسال $typeName بنجاح'),
//         backgroundColor: const Color(0xFF764ba2),
//       ),
//     );

//     _messageController.clear();
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       body: Container(
//         decoration: const BoxDecoration(
//           gradient: LinearGradient(
//             begin: Alignment.topLeft,
//             end: Alignment.bottomRight,
//             colors: [Color(0xFF667eea), Color(0xFF764ba2)],
//           ),
//         ),
//         child: Center(
//           child: Directionality(
//             textDirection: TextDirection.rtl,
//             child: Padding(
//               padding: const EdgeInsets.all(16.0),
//               child: Card(
//                 elevation: 20,
//                 shape: RoundedRectangleBorder(
//                   borderRadius: BorderRadius.circular(20),
//                 ),
//                 child: Padding(
//                   padding: const EdgeInsets.all(24.0),
//                   child: Column(
//                     mainAxisSize: MainAxisSize.min,
//                     children: [
//                       // العنوان
//                       Text(
//                         'الشكاوى والبلاغات',
//                         style: TextStyle(
//                           fontSize: 24,
//                           fontWeight: FontWeight.bold,
//                           color: Colors.grey[800],
//                         ),
//                       ),
//                       const SizedBox(height: 8),
//                       Container(
//                         width: 60,
//                         height: 4,
//                         decoration: BoxDecoration(
//                           color: const Color(0xFF764ba2),
//                           borderRadius: BorderRadius.circular(2),
//                         ),
//                       ),
//                       const SizedBox(height: 30),

//                       // Switch buttons باستخدام Enum
//                       Container(
//                         decoration: BoxDecoration(
//                           color: Colors.grey[200],
//                           borderRadius: BorderRadius.circular(30),
//                         ),
//                         padding: const EdgeInsets.all(4),
//                         child: Row(
//                           children: [
//                             // زر شكوى (Complaint)
//                             Expanded(
//                               child: _buildSwitchButton(
//                                 context: context,
//                                 type: ComplaintAndSuggestionEnum.complaint,
//                                 label: 'شكوى',
//                               ),
//                             ),

//                             // زر بلاغ (Report)
//                             Expanded(
//                               child: _buildSwitchButton(
//                                 context: context,
//                                 type: ComplaintAndSuggestionEnum.suggestion,
//                                 label: 'بلاغ',
//                               ),
//                             ),
//                           ],
//                         ),
//                       ),

//                       const SizedBox(height: 30),

//                       // عرض النوع المحدد (اختياري - للمعاينة)
//                       Container(
//                         padding: const EdgeInsets.symmetric(
//                           horizontal: 12,
//                           vertical: 8,
//                         ),
//                         decoration: BoxDecoration(
//                           color: const Color(0xFF764ba2).withOpacity(0.1),
//                           borderRadius: BorderRadius.circular(10),
//                         ),
//                         child: Text(
//                           'النوع المحدد: ${selectedType.arabicName}',
//                           style: const TextStyle(
//                             fontWeight: FontWeight.w500,
//                           ),
//                         ),
//                       ),

//                       const SizedBox(height: 20),

//                       // حقل الرسالة
//                       TextField(
//                         controller: _messageController,
//                         textAlign: TextAlign.right,
//                         maxLines: 5,
//                         decoration: InputDecoration(
//                           hintText: 'الرسالة',
//                           hintStyle: TextStyle(color: Colors.grey[400]),
//                           border: OutlineInputBorder(
//                             borderRadius: BorderRadius.circular(15),
//                             borderSide: BorderSide.none,
//                           ),
//                           filled: true,
//                           fillColor: Colors.grey[100],
//                           contentPadding: const EdgeInsets.all(16),
//                         ),
//                       ),

//                       const SizedBox(height: 30),

//                       // زر الإرسال
//                       SizedBox(
//                         width: double.infinity,
//                         height: 50,
//                         child: ElevatedButton(
//                           onPressed: _submitMessage,
//                           style: ElevatedButton.styleFrom(
//                             backgroundColor: const Color(0xFF764ba2),
//                             foregroundColor: Colors.white,
//                             shape: RoundedRectangleBorder(
//                               borderRadius: BorderRadius.circular(30),
//                             ),
//                           ),
//                           child: const Text(
//                             'ارسال',
//                             style: TextStyle(
//                               fontSize: 18,
//                               fontWeight: FontWeight.bold,
//                             ),
//                           ),
//                         ),
//                       ),
//                     ],
//                   ),
//                 ),
//               ),
//             ),
//           ),
//         ),
//       ),
//     );
//   }

// // تعريف Enum للأزرار
// enum ReportType {
//   complaint, // شكوى
//   report,     // بلاغ
// }

// extension ReportTypeExtension on ReportType {
//   String get arabicName {
//     switch (this) {
//       case ReportType.complaint:
//         return 'شكوى';
//       case ReportType.report:
//         return 'بلاغ';
//     }
//   }
// }

  // دالة مساعدة لبناء أزرار السويتش
  Widget _buildSwitchButton({
    required BuildContext context,
    required ComplaintAndSuggestionEnum type,
    required String label,
  }) {
    bool isSelected = selectedType == type;

    return GestureDetector(
      onTap: () => _onTypeSelected(type),
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 12),
        decoration: BoxDecoration(
          color: isSelected
              ? Theme.of(context).colorScheme.primary
              : Colors.transparent,
          borderRadius: BorderRadius.circular(30),
        ),
        child: Text(
          label,
          textAlign: TextAlign.center,
          style: TextStyle(
            color: isSelected ? Colors.white : Colors.grey[600],
            fontWeight: FontWeight.bold,
            fontSize: 16,
          ),
        ),
      ),
    );
  }

  @override
  void dispose() {
    _messageController.dispose();
    super.dispose();
  }
}
