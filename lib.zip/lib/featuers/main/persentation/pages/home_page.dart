import 'package:booking_v1/core/constants/colors.dart';
import 'package:booking_v1/dependency_injection/initial.dart';
import 'package:booking_v1/featuers/services/persentation/bloc/services/services_bloc.dart';
import 'package:booking_v1/featuers/services/persentation/bloc/services/services_event.dart';
import 'package:booking_v1/featuers/main/persentation/widgets/view_app_offers.dart';
import 'package:booking_v1/featuers/main/persentation/widgets/view_packages.dart';
import 'package:booking_v1/featuers/services/persentation/widgets/view_list_services_widget.dart';
import 'package:booking_v1/featuers/stores/persentation/widgets/view_popular_stores.dart';
import 'package:flutter/material.dart';
import 'package:booking_v1/core/constants/strings.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  @override
  Widget build(BuildContext context) {
    return MultiBlocProvider(
      providers: [
        BlocProvider<ServicesBloc>(
            create: (_) => getIt<ServicesBloc>()..add(GetAllServicesEvent())),
      ],
      child: Directionality(
        textDirection: TextDirection.rtl,
        child: DefaultTabController(
          length: 7,
          child: Scaffold(
            body: NestedScrollView(
              headerSliverBuilder: (context, innerBoxIsScrolled) => [
                SliverAppBar(
                  // pinned: true,
                  expandedHeight: 455,
                  flexibleSpace: FlexibleSpaceBar(
                    collapseMode: CollapseMode.pin,
                    background: Padding(
                      padding: const EdgeInsets.only(bottom: 0),
                      child: Column(
                        // spacing: defaultSpacing,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          ViewAppOffers(),
                          SizedBox(height: defaultSpacing),
                          ViewPackages(),
                          SizedBox(height: defaultSpacing),
                          ViewPopularStores(),
                          // Placeholder(fallbackHeight: 60),
                          Padding(
                            padding: const EdgeInsets.symmetric(
                                horizontal: defaultPadding),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text(
                                  "الخدمات",
                                  style: Theme.of(context).textTheme.titleLarge,
                                ),
                                InkWell(
                                  onTap: () {},
                                  child: _popupMenuButtonWidget(),
                                ),
                              ],
                            ),
                          ),
                          // PrimaryTitle(
                          //   title: "الخدمات",
                          //   onTap: () {
                          //     return SizedBox();
                          //   },
                          // ),
                        ],
                      ),
                    ),
                  ),
                  // bottom: PreferredSize(
                  //   preferredSize: Size.fromHeight(5),
                  //   child: TabBarServices(),
                  // ),
                ),
                // SliverToBoxAdapter(),
                SliverAppBar(
                  toolbarHeight: 24,
                  pinned: true,
                  bottom: PreferredSize(
                    preferredSize: Size.fromHeight(5),
                    child: TabBar(
                      padding: EdgeInsets.only(bottom: defaultPadding / 4),
                      isScrollable: true,
                      tabs: [
                        Text("الكل"),
                        Text("صالات"),
                        Text("كوش"),
                        Text("صوتيات"),
                        Text("فندق"),
                        Text("خيم"),
                        Text("المزيد"),
                      ],
                    ),
                  ),
                ),
              ],
              body: TabBarView(children: [
                ViewListServicesWidget(),
                ViewListServicesWidget(categoryId: 12),
                ViewListServicesWidget(categoryId: 13),
                ViewListServicesWidget(categoryId: 14),
                ViewListServicesWidget(categoryId: 15),
                ViewListServicesWidget(categoryId: 16),
                Center(child: SizedBox()),
              ]),
            ),
          ),
        ),
      ),
    );
  }

  Widget _popupMenuButtonWidget() {
    return PopupMenuButton(
      icon: Icon(Icons.filter_list, size: 20),

      // لون الخلفية
      color: Theme.of(context).colorScheme.primaryContainer,

      // مكان ظهور القائمة (تحت الزر)
      offset: Offset(10, 40), // يظهر تحت الزر بمسافة 40 بكسل

      // شكل القائمة
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(10),
      ),

      // ارتفاع كل عنصر
      elevation: 4,

      // عناصر القائمة
      itemBuilder: (BuildContext context) => [
        PopupMenuItem(
          onTap: () {},
          child: Directionality(
            textDirection: TextDirection.rtl,
            child: Row(
              children: [
                Icon(Icons.star_rate_rounded, size: 20, color: warningColor),
                SizedBox(width: 12),
                Text('الاكثر تقييم'),
              ],
            ),
          ),
        ),
        PopupMenuItem(
          onTap: () {},
          child: Directionality(
            textDirection: TextDirection.rtl,
            child: Row(
              children: [
                Icon(Icons.location_on, size: 20),
                SizedBox(width: 12),
                Text('الاقرب لي'),
              ],
            ),
          ),
        ),
      ],
    );
  }
}
