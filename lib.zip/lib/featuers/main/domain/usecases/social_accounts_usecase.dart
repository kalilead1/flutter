import 'package:dartz/dartz.dart';

import '../../../../core/errors/failures.dart';
import '../entities/social_account.dart';
import '../repositories/social_accounts_repository.dart';

class GetAllSocialAccountsUsecase {
  final SocialAccountsRepository repository;

  GetAllSocialAccountsUsecase(this.repository);

  Future<Either<Failure, List<SocialAccount>>> call() async {
    return await repository.getAllSocialAccounts();
  }
}
