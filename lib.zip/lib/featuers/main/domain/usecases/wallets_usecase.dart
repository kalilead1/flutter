import 'package:dartz/dartz.dart';

import '../../../../core/errors/failures.dart';
import '../entities/wallet.dart';
import '../repositories/wallets_repository.dart';

class GetAllWalletsUsecase {
  final WalletsRepository repository;

  GetAllWalletsUsecase(this.repository);

  Future<Either<Failure, List<Wallet>>> call() async {
    return await repository.getAllWallets();
  }
}
