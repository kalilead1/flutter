import 'package:dartz/dartz.dart';

import '../../../../../core/errors/failures.dart';
import '../entities/complaint_and_suggestion.dart';
import '../repositories/complaint_and_suggestion_repository.dart';

class AddComplaintAndSuggestionUsecase {
  final ComplaintAndSuggestionRepository repository;

  AddComplaintAndSuggestionUsecase(this.repository);

  Future<Either<Failure, Unit>> call(
      ComplaintAndSuggestion complaintAndSuggestion) async {
    return await repository.addComplaintAndSuggestion(complaintAndSuggestion);
  }
}
