import 'package:dartz/dartz.dart';

import '../../../../core/errors/failures.dart';
import '../entities/category.dart';
import '../repositories/categories_repository.dart';

class GetAllCategoriesUsecase {
  final CategoriesRepository repository;

  GetAllCategoriesUsecase(this.repository);

  Future<Either<Failure, List<Category>>> call() async {
    return await repository.getAllCategories();
  }
}
