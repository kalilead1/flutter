import 'package:dartz/dartz.dart';

import '../../../../core/errors/failures.dart';
import '../entities/city.dart';
import '../repositories/cities_repository.dart';

class GetAllCitiesUsecase {
  final CitiesRepository repository;

  GetAllCitiesUsecase(this.repository);

  Future<Either<Failure, List<City>>> call() async {
    return await repository.getAllCities();
  }
}
