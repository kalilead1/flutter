import 'package:dartz/dartz.dart';

import '../../../../core/errors/failures.dart';
import '../repositories/app_permission_repository.dart';

class RequestPermissionsUseCase {
  final AppPermissionRepository repository;

  RequestPermissionsUseCase(this.repository);

  Future<Either<Failure, bool>> call() async {
    return await repository.requestCameraAndStoragePermissions();
  }
}
