import 'package:dartz/dartz.dart';

import '../../../../core/errors/failures.dart';
import '../entities/directorate.dart';
import '../repositories/directorates_repository.dart';

class GetAllDirectoratesUsecase {
  final DirectoratesRepository repository;

  GetAllDirectoratesUsecase(this.repository);

  Future<Either<Failure, List<Directorate>>> call(int? cityId) async {
    return await repository.getAllDirectorates(cityId);
  }
}
