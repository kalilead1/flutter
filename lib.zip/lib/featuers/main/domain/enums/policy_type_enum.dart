enum PolicyTypeEnum {
  bookingPolicy, // سياسة الحجز
  cancellationPolicy, // سياسة الالغاء
  modificationPolicy, // سياسة التعديل
  storePolicy, // سياسة المتجر
}

extension PolicyTypeEnumExtension on PolicyTypeEnum {
  String get arabicName {
    switch (this) {
      case PolicyTypeEnum.bookingPolicy:
        return 'سياسة الحجز';
      case PolicyTypeEnum.cancellationPolicy:
        return 'سياسة الالغاء';
      case PolicyTypeEnum.modificationPolicy:
        return 'سياسة التعديل';
      case PolicyTypeEnum.storePolicy:
        return 'سياسة المتجر';
    }
  }

  int get value {
    switch (this) {
      case PolicyTypeEnum.bookingPolicy:
        return 1;
      case PolicyTypeEnum.cancellationPolicy:
        return 2;
      case PolicyTypeEnum.modificationPolicy:
        return 3;
      case PolicyTypeEnum.storePolicy:
        return 4;
    }
  }

  static PolicyTypeEnum fromValue(int value) {
    switch (value) {
      case 1:
        return PolicyTypeEnum.bookingPolicy;
      case 2:
        return PolicyTypeEnum.cancellationPolicy;
      case 3:
        return PolicyTypeEnum.modificationPolicy;
      case 4:
        return PolicyTypeEnum.storePolicy;
      default:
        throw Exception('لا يوجد');
    }
  }
}
