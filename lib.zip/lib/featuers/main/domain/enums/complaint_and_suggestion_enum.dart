enum ComplaintAndSuggestionEnum {
  complaint, // شكوى
  suggestion, // مقترح
}

extension ComplaintAndSuggestionEnumExtension on ComplaintAndSuggestionEnum {
  String get arabicName {
    switch (this) {
      case ComplaintAndSuggestionEnum.complaint:
        return 'شكوى';
      case ComplaintAndSuggestionEnum.suggestion:
        return 'مقترح';
    }
  }

  int get value {
    switch (this) {
      case ComplaintAndSuggestionEnum.complaint:
        return 1;
      case ComplaintAndSuggestionEnum.suggestion:
        return 2;
    }
  }

  static ComplaintAndSuggestionEnum fromValue(int value) {
    switch (value) {
      case 1:
        return ComplaintAndSuggestionEnum.complaint;
      case 2:
        return ComplaintAndSuggestionEnum.suggestion;
      default:
        throw Exception('لا يوجد');
    }
  }
}
