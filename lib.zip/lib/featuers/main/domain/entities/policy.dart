import 'package:booking_v1/featuers/main/domain/enums/policy_type_enum.dart';
import 'package:equatable/equatable.dart';

class Policy extends Equatable {
  final int? id;
  final PolicyTypeEnum? policyTypeEnum;
  final String? description;

  const Policy({
    this.id,
    this.policyTypeEnum,
    this.description,
  });

  @override
  List<Object?> get props => [id, policyTypeEnum, description];
}
