import 'package:equatable/equatable.dart';

import '../enums/complaint_and_suggestion_enum.dart';

class ComplaintAndSuggestion extends Equatable {
  final int? id;
  final String? message;
  final ComplaintAndSuggestionEnum? typeMessage;

  const ComplaintAndSuggestion({
    this.id,
    this.message,
    this.typeMessage,
  });

  @override
  List<Object?> get props => [
        id,
        message,
        typeMessage,
      ];
}
