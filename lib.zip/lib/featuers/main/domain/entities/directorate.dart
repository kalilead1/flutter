import 'package:equatable/equatable.dart';

import 'city.dart';

class Directorate extends Equatable {
  final int? id;
  final String? name;
  final int? cityId;
  final City? city;

  const Directorate({
    this.id,
    this.name,
    this.cityId,
    this.city,
  });

  @override
  List<Object?> get props => [id, name, cityId, city];
}
