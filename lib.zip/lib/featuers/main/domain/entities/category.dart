import 'package:equatable/equatable.dart';

class Category extends Equatable {
  final int? id;
  final String? name;
  final String? logo;

  const Category({
    this.id,
    this.name,
    this.logo,
  });

  @override
  List<Object?> get props => [id, name, logo];
}
