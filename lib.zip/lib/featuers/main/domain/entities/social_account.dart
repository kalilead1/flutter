import 'package:equatable/equatable.dart';

class SocialAccount extends Equatable {
  final int? id;
  final String? name;

  const SocialAccount({
    this.id,
    this.name,
  });

  @override
  List<Object?> get props => [id, name];
}
