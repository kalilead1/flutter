import 'package:equatable/equatable.dart';

class PackageCategory extends Equatable {
  final int? id;
  final int? categoryId;
  final int? packageId;

  const PackageCategory({
    this.id,
    this.categoryId,
    this.packageId,
  });

  @override
  List<Object?> get props => [id, categoryId, packageId];
}
