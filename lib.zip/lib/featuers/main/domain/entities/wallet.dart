import 'package:equatable/equatable.dart';

class Wallet extends Equatable {
  final int? id;
  final String? name;
  final String? logo;

  const Wallet({
    this.id,
    this.name,
    this.logo,
  });

  @override
  List<Object?> get props => [id, name, logo];
}
