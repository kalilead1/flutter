import 'package:dartz/dartz.dart';

import '../../../../core/errors/failures.dart';
import '../../../main/domain/entities/complaint_and_suggestion.dart';

abstract class ComplaintAndSuggestionRepository {
  Future<Either<Failure, Unit>> addComplaintAndSuggestion(
      ComplaintAndSuggestion complaintAndSuggestion);
}
