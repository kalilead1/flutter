import 'package:booking_v1/featuers/main/domain/entities/wallet.dart';
import 'package:dartz/dartz.dart';

import '../../../../core/errors/failures.dart';

abstract class WalletsRepository {
  Future<Either<Failure, List<Wallet>>> getAllWallets();
}
