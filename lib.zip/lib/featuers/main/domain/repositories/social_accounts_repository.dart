import 'package:dartz/dartz.dart';

import '../../../../core/errors/failures.dart';
import '../entities/social_account.dart';

abstract class SocialAccountsRepository {
  Future<Either<Failure, List<SocialAccount>>> getAllSocialAccounts();
}
