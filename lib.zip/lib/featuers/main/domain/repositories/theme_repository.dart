import 'package:booking_v1/featuers/main/domain/enums/app_theme_mode.dart';

abstract class ThemeRepository {
  Future<void> saveTheme(AppThemeMode mode);
  Future<AppThemeMode> loadTheme();
}
