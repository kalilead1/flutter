import 'package:dartz/dartz.dart';

import '../../../../core/errors/failures.dart';

abstract class AppPermissionRepository {
  Future<Either<Failure, bool>> requestCameraAndStoragePermissions();
}
