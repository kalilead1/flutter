import 'package:booking_v1/featuers/main/domain/entities/category.dart';
import 'package:dartz/dartz.dart';

import '../../../../core/errors/failures.dart';

abstract class CategoriesRepository {
  Future<Either<Failure, List<Category>>> getAllCategories();
}
