import 'package:dartz/dartz.dart';

import '../../../../core/errors/failures.dart';
import '../entities/directorate.dart';

abstract class DirectoratesRepository {
  Future<Either<Failure, List<Directorate>>> getAllDirectorates(int? cityId);
}
