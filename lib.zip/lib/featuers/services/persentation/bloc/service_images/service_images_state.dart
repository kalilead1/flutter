import 'package:booking_v1/featuers/services/domain/entities/service_image.dart';
import 'package:equatable/equatable.dart';

abstract class ServiceImagesState extends Equatable {
  const ServiceImagesState();
  @override
  List<Object?> get props => [];
}

class ServiceImagesInitialState extends ServiceImagesState {}

class LoadingServiceImagesState extends ServiceImagesState {}

class LoadedServiceImagesState extends ServiceImagesState {
  final List<ServiceImage> serviceImages;

  const LoadedServiceImagesState({required this.serviceImages});

  @override
  List<Object?> get props => [serviceImages];
}

class LoadedServiceImageByIdState extends ServiceImagesState {
  final ServiceImage serviceImage;

  const LoadedServiceImageByIdState({required this.serviceImage});

  @override
  List<Object?> get props => [serviceImage];
}

class SuccessfulyServiceImagesState extends ServiceImagesState {
  final String message;

  const SuccessfulyServiceImagesState({required this.message});

  @override
  List<Object?> get props => [message];
}

class ErrorServiceImagesState extends ServiceImagesState {
  final String message;

  const ErrorServiceImagesState({required this.message});

  @override
  List<Object?> get props => [message];
}
