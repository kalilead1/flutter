import 'package:booking_v1/core/errors/failures.dart';
import 'package:booking_v1/core/helpers/failure_to_message.dart';
import 'package:booking_v1/featuers/services/domain/entities/service_image.dart';
import 'package:booking_v1/featuers/services/domain/usecases/service_images_usecase.dart';
import 'package:booking_v1/featuers/services/persentation/bloc/service_images/service_images_event.dart';
import 'package:booking_v1/featuers/services/persentation/bloc/service_images/service_images_state.dart';
import 'package:dartz/dartz.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../../../../core/app_events_bus/app_event.dart';
import '../../../../../core/app_events_bus/app_event_bus.dart';
import '../../../../../core/app_events_bus/auto_refresh_bloc.dart';

class ServiceImagesBloc extends Bloc<ServiceImagesEvent, ServiceImagesState>
    with AutoRefreshBloc<ServiceImagesEvent, ServiceImagesState> {
  final GetAllServiceImagesByServiceIdUsecase? getAllServiceImagesUsecase;
  final GetServiceImageByIdUsecase? getServiceImageByIdUsecase;
  final AddServiceImageUsecase? addServiceImageUsecase;
  final DeleteServiceImageUsecase? deleteServiceImageUsecase;

  ServiceImagesBloc({
    this.getAllServiceImagesUsecase,
    this.getServiceImageByIdUsecase,
    this.addServiceImageUsecase,
    this.deleteServiceImageUsecase,
  }) : super(ServiceImagesInitialState()) {
    setupAutoRefresh<ServiceChangedEvent>();

    on<GetAllServiceImagesEvent>((event, emit) async {
      emit(LoadingServiceImagesState());

      final failureOrServiceImages =
          await getAllServiceImagesUsecase!(event.serviceId);
      emit(_mapFailureOrGetAllServiceImages(failureOrServiceImages));
    });
    on<RefreshAllServiceImagesEvent>((event, emit) async {
      emit(LoadingServiceImagesState());

      final failureOrServiceImages =
          await getAllServiceImagesUsecase!(event.serviceId);
      emit(_mapFailureOrGetAllServiceImages(failureOrServiceImages));
    });
    on<GetServiceImageByIdEvent>((event, emit) async {
      emit(LoadingServiceImagesState());

      final failureOrGetServiceImageById =
          await getServiceImageByIdUsecase!(event.serviceImageId);
      emit(_mapFailureOGetServiceImageById(failureOrGetServiceImageById));
    });
    on<RefreshGetServiceImageByIdEvent>((event, emit) async {
      emit(LoadingServiceImagesState());

      final failureOrGetServiceImageById =
          await getServiceImageByIdUsecase!(event.serviceImageId);
      emit(_mapFailureOGetServiceImageById(failureOrGetServiceImageById));
    });
    on<AddServiceImagesEvent>((event, emit) async {
      emit(LoadingServiceImagesState());

      if (event.serviceImage.isNotEmpty) {
        Either<Failure, Unit>? failureOrAddImage;
        for (var image in event.serviceImage) {
          failureOrAddImage = await addServiceImageUsecase!(
              ServiceImage(image: image.path, serviceId: event.serviceId),
              event.serviceId);
        }
        failureOrAddImage!.fold(
          (failure) =>
              emit(ErrorServiceImagesState(message: failureToMessage(failure))),
          (unit) {
            emit(
                SuccessfulyServiceImagesState(message: "تمت اضافة صورة بنجاح"));
            AppEventBus.instance.fire(ServiceChangedEvent());
          },
        );
      }
    });
    on<DeleteServiceImageEvent>((event, emit) async {
      emit(LoadingServiceImagesState());

      final failureOrDeleteImage =
          await deleteServiceImageUsecase!(event.imageId, event.serviceId);
      failureOrDeleteImage.fold(
        (failure) =>
            emit(ErrorServiceImagesState(message: failureToMessage(failure))),
        (unit) {
          emit(SuccessfulyServiceImagesState(message: "تم حذف الصورة بنجاح"));
          AppEventBus.instance.fire(ServiceChangedEvent());
        },
      );
    });
  }

  ServiceImagesState _mapFailureOrGetAllServiceImages(
      Either<Failure, List<ServiceImage>> either) {
    return either.fold(
      (failure) => ErrorServiceImagesState(message: failureToMessage(failure)),
      (serviceImages) => LoadedServiceImagesState(serviceImages: serviceImages),
    );
  }

  ServiceImagesState _mapFailureOGetServiceImageById(
      Either<Failure, ServiceImage> either) {
    return either.fold(
      (failure) => ErrorServiceImagesState(message: failureToMessage(failure)),
      (serviceImage) => LoadedServiceImageByIdState(serviceImage: serviceImage),
    );
  }
}
