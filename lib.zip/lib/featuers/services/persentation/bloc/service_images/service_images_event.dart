import 'dart:io';

import 'package:booking_v1/featuers/services/domain/entities/service_image.dart';
import 'package:equatable/equatable.dart';

abstract class ServiceImagesEvent extends Equatable {
  const ServiceImagesEvent();
  @override
  List<Object?> get props => [];
}

class GetAllServiceImagesEvent extends ServiceImagesEvent {
  final int serviceId;
  const GetAllServiceImagesEvent({required this.serviceId});

  @override
  List<Object?> get props => [serviceId];
}

class GetServiceImageByIdEvent extends ServiceImagesEvent {
  final int serviceImageId;
  const GetServiceImageByIdEvent({required this.serviceImageId});

  @override
  List<Object?> get props => [serviceImageId];
}

class RefreshAllServiceImagesEvent extends ServiceImagesEvent {
  final int serviceId;
  const RefreshAllServiceImagesEvent({required this.serviceId});

  @override
  List<Object?> get props => [serviceId];
}

class RefreshGetServiceImageByIdEvent extends ServiceImagesEvent {
  final int serviceImageId;
  const RefreshGetServiceImageByIdEvent({required this.serviceImageId});

  @override
  List<Object?> get props => [serviceImageId];
}

// class AddServiceImagesEvent extends ServiceImagesEvent {
//   final List<ServiceImage> serviceImages;
//   const AddServiceImagesEvent({required this.serviceImages});

//   @override
//   List<Object?> get props => [serviceImages];
// }

class AddServiceImagesEvent extends ServiceImagesEvent {
  final List<File> serviceImage;
  final int serviceId;

  const AddServiceImagesEvent(
      {required this.serviceImage, required this.serviceId});

  @override
  List<Object?> get props => [serviceImage, serviceId];
}

class UpdateServiceImageEvent extends ServiceImagesEvent {
  final ServiceImage serviceImage;
  const UpdateServiceImageEvent({required this.serviceImage});

  @override
  List<Object?> get props => [serviceImage];
}

class DeleteServiceImageEvent extends ServiceImagesEvent {
  final int imageId;
  final int serviceId;

  const DeleteServiceImageEvent(
      {required this.imageId, required this.serviceId});

  @override
  List<Object?> get props => [imageId, serviceId];
}
