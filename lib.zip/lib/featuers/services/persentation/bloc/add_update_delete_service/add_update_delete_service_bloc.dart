import 'dart:io';

import 'package:booking_v1/core/app_events_bus/app_event.dart';
import 'package:booking_v1/core/app_events_bus/app_event_bus.dart';
import 'package:booking_v1/featuers/services/domain/entities/service.dart';
import 'package:booking_v1/featuers/services/domain/entities/service_image.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../../../../core/helpers/failure_to_message.dart';
import '../../../../../core/routing/app_routes.dart';
import '../../../../../core/routing/navigation_service.dart';
import '../../../domain/usecases/service_images_usecase.dart';
import '../../../domain/usecases/services_usecase.dart';
import '../../pages/args/add_pages_args.dart';
import 'add_update_delete_service_event.dart';
import 'add_update_delete_service_state.dart';

class AddUpdateDeleteServiceBloc
    extends Bloc<AddUpdateDeleteServiceEvent, AddUpdateDeleteServiceState> {
  final AddServiceUsecase addServiceUsecase;
  final AddServiceImageUsecase addServiceImageUsecase;
  final UpdateServiceBaiscInfoUsecase updateServiceBaiscInfo;
  final UpdateServiceGloableInfoUsecase updateServiceGloableInfo;

  // Service? service;
  String? name;
  double? price;
  String? duration;
  int? storeId;
  int? userId;
  int? peopleCount;
  String? description;
  String? includedServices;
  List<File> _serviceImages = [];

  AddUpdateDeleteServiceBloc({
    required this.addServiceUsecase,
    required this.addServiceImageUsecase,
    required this.updateServiceBaiscInfo,
    required this.updateServiceGloableInfo,
  }) : super(AddUpdateDeleteServiceInitialState()) {
    on<AddNewServiceEvent>((event, emit) async {
      emit(LoadingAddUpdateDeleteServiceState());
      storeId = event.storeId;

      emit(
        EditingAddServiceState(
          name: name,
          price: price,
          duration: duration,
          storeId: storeId,
          userId: userId,
          peopleCount: peopleCount,
          description: description,
          includedServices: includedServices,
          serviceImages: _serviceImages,
        ),
      );
      NavigationService.push(addUpdateServiceBaiscRoute,
          extra: AddUpdateServiceArgs());
    });
    on<AddServiceBasicInfoEvent>((event, emit) async {
      emit(LoadingAddUpdateDeleteServiceState());

      name = event.service.name;
      price = event.service.price;
      duration = event.service.duration;
      //storeId = event.storeId;
      userId = event.service.userId;
      peopleCount = event.service.peopleCount;

      emit(
        EditingAddServiceState(
          name: name,
          price: price,
          duration: duration,
          storeId: storeId,
          userId: userId,
          peopleCount: peopleCount,
          description: description,
          includedServices: includedServices,
          serviceImages: _serviceImages,
        ),
      );
      NavigationService.push(addUpdateServiceGloableRoute,
          extra: AddUpdateServiceArgs());
    });
    on<AddServiceGloableEvent>((event, emit) async {
      emit(LoadingAddUpdateDeleteServiceState());

      description = event.service.description;
      includedServices = event.service.includedServices;

      emit(
        EditingAddServiceState(
          name: name,
          price: price,
          duration: duration,
          storeId: storeId,
          userId: userId,
          peopleCount: peopleCount,
          description: description,
          includedServices: includedServices,
          serviceImages: _serviceImages,
        ),
      );
      NavigationService.push(addServiceImageRoute,
          extra: AddUpdateServiceImagesArgs());
    });
    on<AddServiceImageEvent>((event, emit) async {
      emit(LoadingAddUpdateDeleteServiceState());
      _serviceImages = event.serviceImage;

      emit(
        EditingAddServiceState(
          name: name,
          price: price,
          duration: duration,
          storeId: storeId,
          userId: userId,
          peopleCount: peopleCount,
          description: description,
          includedServices: includedServices,
          serviceImages: _serviceImages,
        ),
      );
      NavigationService.push(confirmAddServiceRoute);
    });
    on<SubmitAddServiceEvent>((event, emit) async {
      emit(LoadingAddUpdateDeleteServiceState());

      final service = Service(
        name: name,
        price: price,
        duration: duration,
        storeId: storeId,
        userId: userId,
        peopleCount: peopleCount,
        description: description,
        includedServices: includedServices,
      );
      final failureOrAddStore = await addServiceUsecase(service);
      failureOrAddStore.fold(
        (failure) => emit(
          ErrorAddServiceState(message: failureToMessage(failure)),
        ),
        (serviceId) {
          if (_serviceImages.isNotEmpty) {
            for (var serviceImage in _serviceImages) {
              addServiceImageUsecase(
                  ServiceImage(
                    image: serviceImage.path,
                    serviceId: serviceId,
                  ),
                  serviceId);
            }
          }
          AppEventBus.instance.fire(ServiceChangedEvent());
          NavigationService.popUntil(serviceOwnerRoute);
          emit(SuccessfullyAddServiceState());

          // getIt<ServicesBloc>()
          //     .add(GetServiceByStoreIdEvent(storeId: storeId!));
          // NavigationService.push(serviceOwnerRoute, extra: storeId);
        },
      );
    });
    ////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////
    on<UpdateServiceEvent>((event, emit) async {
      emit(LoadingAddUpdateDeleteServiceState());
      emit(EditingAddServiceState());
    });
    on<UpdateServiceBasicInfoEvent>((event, emit) async {
      emit(LoadingAddUpdateDeleteServiceState());

      final failureOrUpdate =
          await updateServiceBaiscInfo(event.service.id!, event.service);
      failureOrUpdate.fold(
        (failure) =>
            emit(ErrorUpdateServiceState(message: failureToMessage(failure))),
        (unit) {
          AppEventBus.instance.fire(ServiceChangedEvent());
          emit(SuccessfullyUpdateServiceState());
          NavigationService.pop();
        },
      );
    });
    on<UpdateServiceGloableEvent>((event, emit) async {
      emit(LoadingAddUpdateDeleteServiceState());

      final failureOrUpdate =
          await updateServiceGloableInfo(event.service.id!, event.service);
      failureOrUpdate.fold(
        (failure) =>
            emit(ErrorUpdateServiceState(message: failureToMessage(failure))),
        (unit) {
          AppEventBus.instance.fire(ServiceChangedEvent());
          emit(SuccessfullyUpdateServiceState());
          NavigationService.pop();
        },
      );
    });
    //on<UpdateServiceImageEvent>((event, emit) async {});
    ////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////
    on<CancelAddServiceEvent>((event, emit) async {
      NavigationService.popUntil(serviceOwnerRoute);
    });
  }
}
//////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////
// import 'dart:io';

// import 'package:booking_v1/dependency_injection/initial.dart';
// import 'package:booking_v1/featuers/services/domain/entities/service.dart';
// import 'package:booking_v1/featuers/services/domain/entities/service_image.dart';
// import 'package:booking_v1/featuers/services/persentation/bloc/services/services_bloc.dart';
// import 'package:booking_v1/featuers/services/persentation/bloc/services/services_event.dart';
// import 'package:flutter_bloc/flutter_bloc.dart';

// import '../../../../../core/helpers/failure_to_message.dart';
// import '../../../../../core/routing/app_routes.dart';
// import '../../../../../core/routing/navigation_service.dart';
// import '../../../domain/usecases/service_images_usecase.dart';
// import '../../../domain/usecases/services_usecase.dart';
// import '../../pages/args/add_pages_args.dart';
// import 'add_update_delete_service_event.dart';
// import 'add_update_delete_service_state.dart';

// class AddUpdateDeleteServiceBloc
//     extends Bloc<AddUpdateDeleteServiceEvent, AddUpdateDeleteServiceState> {
//   final AddServiceUsecase addServiceUsecase;
//   final AddServiceImageUsecase addServiceImageUsecase;

//   late Service service;
//   String? name;
//   double? price;
//   String? duration;
//   int? storeId;
//   int? userId;
//   int? peopleCount;
//   String? description;
//   String? includedServices;
//   List<File> _serviceImages = [];

//   AddUpdateDeleteServiceBloc({
//     required this.addServiceUsecase,
//     required this.addServiceImageUsecase,
//   }) : super(AddUpdateDeleteServiceInitialState()) {
//     on<AddUpdateDeleteServiceEvent>((event, emit) async {
//       if (event is AddNewServiceEvent) {
//         emit(LoadingAddUpdateDeleteServiceState());
//         storeId = event.storeId;

//         emit(
//           EditingAddServiceState(
//             name: name,
//             price: price,
//             duration: duration,
//             storeId: storeId,
//             userId: userId,
//             peopleCount: peopleCount,
//             description: description,
//             includedServices: includedServices,
//             serviceImages: _serviceImages,
//           ),
//         );
//         NavigationService.push(addUpdateServiceBaiscRoute,
//             extra: AddUpdateServiceArgs());
//       }
//       ///////////////
//       else if (event is AddServiceBasicInfoEvent) {
//         emit(LoadingAddUpdateDeleteServiceState());

//         name = event.name;
//         price = event.price;
//         duration = event.duration;
//         storeId = event.storeId;
//         userId = event.userId;
//         peopleCount = event.peopleCount;

//         emit(
//           EditingAddServiceState(
//             name: name,
//             price: price,
//             duration: duration,
//             storeId: storeId,
//             userId: userId,
//             peopleCount: peopleCount,
//             description: description,
//             includedServices: includedServices,
//             serviceImages: _serviceImages,
//           ),
//         );
//         NavigationService.push(addUpdateServiceGloableRoute,
//             extra: AddUpdateServiceArgs());
//       }
//       /////////
//       else if (event is AddServiceGeneralEvent) {
//         emit(LoadingAddUpdateDeleteServiceState());

//         description = event.description;
//         includedServices = event.includedServices;

//         emit(
//           EditingAddServiceState(
//             name: name,
//             price: price,
//             duration: duration,
//             storeId: storeId,
//             userId: userId,
//             peopleCount: peopleCount,
//             description: description,
//             includedServices: includedServices,
//             serviceImages: _serviceImages,
//           ),
//         );
//         NavigationService.push(addUpdateServiceImageRoute,
//             extra: AddUpdateServiceImagesArgs());
//       }
//       /////////
//       else if (event is AddServiceImageEvent) {
//         emit(LoadingAddUpdateDeleteServiceState());

//         _serviceImages = event.serviceImage;

//         emit(
//           EditingAddServiceState(
//             name: name,
//             price: price,
//             duration: duration,
//             storeId: storeId,
//             userId: userId,
//             peopleCount: peopleCount,
//             description: description,
//             includedServices: includedServices,
//             serviceImages: _serviceImages,
//           ),
//         );
//         NavigationService.push(confirmAddServiceRoute);
//       }
//       /////////
//       else if (event is SubmitAddServiceEvent) {
//         emit(LoadingAddUpdateDeleteServiceState());

//         final service = Service(
//           name: name,
//           price: price,
//           duration: duration,
//           storeId: storeId,
//           userId: userId,
//           peopleCount: peopleCount,
//           description: description,
//           includedServices: includedServices,
//         );
//         final failureOrAddStore = await addServiceUsecase(service);
//         failureOrAddStore.fold(
//           (failure) => emit(
//             ErrorAddUpdateDeleteServiceState(
//                 message: failureToMessage(failure)),
//           ),
//           (serviceId) {
//             if (_serviceImages.isNotEmpty) {
//               for (var serviceImage in _serviceImages) {
//                 addServiceImageUsecase(ServiceImage(
//                   image: serviceImage.path,
//                   serviceId: serviceId,
//                 ));
//               }
//             }
//             // NavigationService.popUntil(serviceOwnerRoute);
//             emit(SuccessfullyAddUpdateDeleteServiceState(serviceId: serviceId));
//             // getIt<ServicesBloc>()
//             //     .add(GetServiceByStoreIdEvent(storeId: storeId!));
//             // NavigationService.push(serviceOwnerRoute, extra: storeId);
//           },
//         );
//       }
//       /////////
//       else if (event is CancelAddServiceEvent) {
//         NavigationService.popUntil(serviceOwnerRoute);
//       }
//     });
//   }

//   // AddStoreState _mapFailureOrAddedStore(Either<Failure, int> either) {
//   //   return either.fold(
//   //     (failure) => ErrorAddStoreState(message: failureToMessage(failure)),
//   //     (storeId) => SuccessfullyAddStoreState(storeId: storeId),
//   //   );
//   // }
// }
