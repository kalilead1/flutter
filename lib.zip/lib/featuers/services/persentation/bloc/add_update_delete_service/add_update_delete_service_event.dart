import 'dart:io';

import 'package:equatable/equatable.dart';

import '../../../domain/entities/service.dart';

abstract class AddUpdateDeleteServiceEvent extends Equatable {
  const AddUpdateDeleteServiceEvent();
  @override
  List<Object?> get props => [];
}

////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////
class AddNewServiceEvent extends AddUpdateDeleteServiceEvent {
  final int storeId;
  const AddNewServiceEvent({required this.storeId});

  @override
  List<Object?> get props => [storeId];
}

class UpdateServiceEvent extends AddUpdateDeleteServiceEvent {}

////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////
class AddServiceBasicInfoEvent extends AddUpdateDeleteServiceEvent {
  final Service service;

  const AddServiceBasicInfoEvent({
    required this.service,
  });

  @override
  List<Object?> get props => [service];
}

class UpdateServiceBasicInfoEvent extends AddUpdateDeleteServiceEvent {
  final Service service;
  const UpdateServiceBasicInfoEvent({required this.service});

  @override
  List<Object?> get props => [service];
}

////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////
class AddServiceGloableEvent extends AddUpdateDeleteServiceEvent {
  final Service service;

  const AddServiceGloableEvent({required this.service});

  @override
  List<Object?> get props => [service];
}

class UpdateServiceGloableEvent extends AddUpdateDeleteServiceEvent {
  final Service service;
  const UpdateServiceGloableEvent({required this.service});

  @override
  List<Object?> get props => [service];
}

////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////
class AddServiceImageEvent extends AddUpdateDeleteServiceEvent {
  final List<File> serviceImage;

  const AddServiceImageEvent({required this.serviceImage});

  @override
  List<Object?> get props => [serviceImage];
}

class UpdateServiceImageEvent extends AddUpdateDeleteServiceEvent {}

////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////
class SubmitAddServiceEvent extends AddUpdateDeleteServiceEvent {}

class CancelAddServiceEvent extends AddUpdateDeleteServiceEvent {}
