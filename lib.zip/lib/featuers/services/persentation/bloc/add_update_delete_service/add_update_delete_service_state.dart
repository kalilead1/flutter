import 'dart:io';

import 'package:equatable/equatable.dart';

abstract class AddUpdateDeleteServiceState extends Equatable {
  const AddUpdateDeleteServiceState();
  @override
  List<Object?> get props => [];
}

class AddUpdateDeleteServiceInitialState extends AddUpdateDeleteServiceState {}

class LoadingAddUpdateDeleteServiceState extends AddUpdateDeleteServiceState {}

class EditingAddServiceState extends AddUpdateDeleteServiceState {
  final String? name;
  final double? price;
  final String? duration;
  final int? storeId;
  final int? userId;
  final int? peopleCount;
  final String? description;
  final String? includedServices;

  final List<File> serviceImages;

  const EditingAddServiceState({
    this.name,
    this.price,
    this.duration,
    this.storeId,
    this.userId,
    this.peopleCount,
    this.description,
    this.includedServices,
    this.serviceImages = const [],
  });

  @override
  List<Object?> get props => [
        name,
        price,
        duration,
        storeId,
        userId,
        peopleCount,
        description,
        includedServices,
        serviceImages
      ];
}

class SuccessfullyAddServiceState extends AddUpdateDeleteServiceState {}

class ErrorAddServiceState extends AddUpdateDeleteServiceState {
  final String message;

  const ErrorAddServiceState({required this.message});

  @override
  List<Object?> get props => [message];
}

class SuccessfullyUpdateServiceState extends AddUpdateDeleteServiceState {}

class ErrorUpdateServiceState extends AddUpdateDeleteServiceState {
  final String message;

  const ErrorUpdateServiceState({required this.message});

  @override
  List<Object?> get props => [message];
}
