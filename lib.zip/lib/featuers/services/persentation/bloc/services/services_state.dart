import 'package:booking_v1/featuers/services/domain/entities/service.dart';
import 'package:equatable/equatable.dart';

abstract class ServicesState extends Equatable {
  const ServicesState();
  @override
  List<Object?> get props => [];
}

class ServicesInitialState extends ServicesState {}

class LoadingServicesState extends ServicesState {}

class LoadedServicesState extends ServicesState {
  final List<Service> services;

  const LoadedServicesState({required this.services});

  @override
  List<Object?> get props => [services];
}
// class LoadedServicesState extends ServicesState {
//   final Map<int, List<Service>> services;
//   final Map<int, int> currentPage;
//   final Map<int, bool> hasMore;

//   const LoadedServicesState({
//     required this.currentPage,
//     required this.hasMore,
//     required this.services,
//   });

//   LoadedServicesState copyWhit({
//     Map<int, List<Service>>? services,
//     Map<int, int>? currentPage,
//     Map<int, bool>? hasMore,
//   }) {
//     return LoadedServicesState(
//       currentPage: currentPage ?? this.currentPage,
//       hasMore: hasMore ?? this.hasMore,
//       services: services ?? this.services,
//     );
//   }

//   @override
//   List<Object?> get props => [services, currentPage, hasMore];
// }

class LoadedServiceByIdState extends ServicesState {
  final Service service;

  const LoadedServiceByIdState({required this.service});

  @override
  List<Object?> get props => [service];
}

class ErrorServicesState extends ServicesState {
  final String message;

  const ErrorServicesState({required this.message});

  @override
  List<Object?> get props => [message];
}
