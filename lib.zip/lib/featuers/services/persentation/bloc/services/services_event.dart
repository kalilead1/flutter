import 'package:equatable/equatable.dart';

abstract class ServicesEvent extends Equatable {
  const ServicesEvent();
  @override
  List<Object?> get props => [];
}

class GetAllServicesEvent extends ServicesEvent {
  final int? categoryId;
  final int page;
  final int limit;
  const GetAllServicesEvent({this.categoryId, this.page = 1, this.limit = 10});

  @override
  List<Object?> get props => [categoryId, page, limit];
}

class GetServiceByIdEvent extends ServicesEvent {
  final int serviceId;
  const GetServiceByIdEvent({required this.serviceId});

  @override
  List<Object?> get props => [serviceId];
}

class GetServiceByStoreIdEvent extends ServicesEvent {
  final int storeId;
  const GetServiceByStoreIdEvent({required this.storeId});

  @override
  List<Object?> get props => [storeId];
}

class RefreshGetServiceByStoreIdEvent extends ServicesEvent {
  final int storeId;
  const RefreshGetServiceByStoreIdEvent({required this.storeId});

  @override
  List<Object?> get props => [storeId];
}

class RefreshAllServicesEvent extends ServicesEvent {
  final int categoryId;
  const RefreshAllServicesEvent({required this.categoryId});

  @override
  List<Object?> get props => [categoryId];
}

class RefreshGetServiceByIdEvent extends ServicesEvent {
  final int serviceId;
  const RefreshGetServiceByIdEvent({required this.serviceId});

  @override
  List<Object?> get props => [serviceId];
}
