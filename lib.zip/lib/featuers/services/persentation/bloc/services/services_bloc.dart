import 'package:booking_v1/core/app_events_bus/app_event.dart';
import 'package:booking_v1/core/app_events_bus/auto_refresh_bloc.dart';
import 'package:booking_v1/core/errors/failures.dart';
import 'package:booking_v1/core/helpers/failure_to_message.dart';
import 'package:booking_v1/featuers/services/domain/entities/service.dart';
import 'package:booking_v1/featuers/services/domain/usecases/services_usecase.dart';
import 'package:booking_v1/featuers/services/persentation/bloc/services/services_event.dart';
import 'package:booking_v1/featuers/services/persentation/bloc/services/services_state.dart';
import 'package:dartz/dartz.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../../../main/persentation/blocs/gloable_bloc/gloable_bloc.dart';

class ServicesBloc extends Bloc<ServicesEvent, ServicesState>
    with AutoRefreshBloc<ServicesEvent, ServicesState> {
  final GetAllServicesUsecase? getAllServicesUsecase;
  final GetServiceByIdUsecase? getServiceByIdUsecase;
  final GetServiceByStoreIdUsecase? getServiceByStoreIdUsecase;

  ServicesBloc({
    this.getAllServicesUsecase,
    this.getServiceByIdUsecase,
    this.getServiceByStoreIdUsecase,
  }) : super(ServicesInitialState()) {
    setupAutoRefresh<ServiceChangedEvent>();
    on<GetAllServicesEvent>((event, emit) async {
      emit(LoadingServicesState());

      final failureOrServices = await getAllServicesUsecase!(event.categoryId);
      emit(_mapFailureOrGetAllServices(failureOrServices));
    });
    on<RefreshAllServicesEvent>((event, emit) async {
      emit(LoadingServicesState());

      final failureOrServices = await getAllServicesUsecase!(event.categoryId);
      emit(_mapFailureOrGetAllServices(failureOrServices));
    });
    on<GetServiceByStoreIdEvent>((event, emit) async {
      emit(LoadingServicesState());

      final failureOrServices =
          await getServiceByStoreIdUsecase!(event.storeId);
      emit(_mapFailureOrGetAllServices(failureOrServices));
    });
    on<RefreshGetServiceByStoreIdEvent>((event, emit) async {
      emit(LoadingServicesState());
      gloableBloc.stream.listen((_) {
        add(RefreshGetServiceByStoreIdEvent(storeId: event.storeId));
      });
      final failureOrServices =
          await getServiceByStoreIdUsecase!(event.storeId);
      emit(_mapFailureOrGetAllServices(failureOrServices));
    });
    on<GetServiceByIdEvent>((event, emit) async {
      emit(LoadingServicesState());

      final failureOrGetServiceById =
          await getServiceByIdUsecase!(event.serviceId);
      emit(_mapFailureOGetServiceById(failureOrGetServiceById));
    });
    on<RefreshGetServiceByIdEvent>((event, emit) async {
      emit(LoadingServicesState());

      final failureOrGetServiceById =
          await getServiceByIdUsecase!(event.serviceId);
      emit(_mapFailureOGetServiceById(failureOrGetServiceById));
    });
  }

  ServicesState _mapFailureOrGetAllServices(
      Either<Failure, List<Service>> either) {
    return either.fold(
      (failure) => ErrorServicesState(message: failureToMessage(failure)),
      (services) => LoadedServicesState(services: services),
    );
  }

  ServicesState _mapFailureOGetServiceById(Either<Failure, Service> either) {
    return either.fold(
      (failure) => ErrorServicesState(message: failureToMessage(failure)),
      (service) => LoadedServiceByIdState(service: service),
    );
  }
}
// import 'package:booking_v1/core/errors/failures.dart';
// import 'package:booking_v1/core/helpers/failure_to_message.dart';
// import 'package:booking_v1/featuers/services/domain/entities/service.dart';
// import 'package:booking_v1/featuers/services/domain/usecases/services_usecase.dart';
// import 'package:booking_v1/featuers/services/persentation/bloc/services/services_event.dart';
// import 'package:booking_v1/featuers/services/persentation/bloc/services/services_state.dart';
// import 'package:dartz/dartz.dart';
// import 'package:flutter_bloc/flutter_bloc.dart';

// import '../../../../main/persentation/bloc/gloable_bloc/gloable_bloc.dart';

// class ServicesBloc extends Bloc<ServicesEvent, ServicesState> {
//   final GetAllServicesUsecase? getAllServicesUsecase;
//   final GetServiceByIdUsecase? getServiceByIdUsecase;
//   final GetServiceByStoreIdUsecase? getServiceByStoreIdUsecase;

//   ServicesBloc({
//     this.getAllServicesUsecase,
//     this.getServiceByIdUsecase,
//     this.getServiceByStoreIdUsecase,
//   }) : super(ServicesInitialState()) {
//     on<ServicesEvent>((event, emit) async {
//       if (event is GetAllServicesEvent) {
//         emit(LoadingServicesState());

//         final failureOrServices =
//             await getAllServicesUsecase!(event.categoryId);
//         emit(_mapFailureOrGetAllServices(failureOrServices));
//       } else if (event is RefreshAllServicesEvent) {
//         emit(LoadingServicesState());

//         final failureOrServices =
//             await getAllServicesUsecase!(event.categoryId);
//         emit(_mapFailureOrGetAllServices(failureOrServices));
//       } else if (event is GetServiceByStoreIdEvent) {
//         emit(LoadingServicesState());

//         final failureOrServices =
//             await getServiceByStoreIdUsecase!(event.storeId);
//         emit(_mapFailureOrGetAllServices(failureOrServices));
//       } else if (event is RefreshGetServiceByStoreIdEvent) {
//         emit(LoadingServicesState());
//         gloableBloc.stream.listen((_) {
//           add(RefreshGetServiceByStoreIdEvent(storeId: event.storeId));
//         });
//         final failureOrServices =
//             await getServiceByStoreIdUsecase!(event.storeId);
//         emit(_mapFailureOrGetAllServices(failureOrServices));
//       } else if (event is GetServiceByIdEvent) {
//         emit(LoadingServicesState());

//         final failureOrGetServiceById =
//             await getServiceByIdUsecase!(event.serviceId);
//         emit(_mapFailureOGetServiceById(failureOrGetServiceById));
//       } else if (event is RefreshGetServiceByIdEvent) {
//         emit(LoadingServicesState());

//         final failureOrGetServiceById =
//             await getServiceByIdUsecase!(event.serviceId);
//         emit(_mapFailureOGetServiceById(failureOrGetServiceById));
//       }
//     });
//   }

//   ServicesState _mapFailureOrGetAllServices(
//       Either<Failure, List<Service>> either) {
//     return either.fold(
//       (failure) => ErrorServicesState(message: failureToMessage(failure)),
//       (services) => LoadedServicesState(services: services),
//     );
//   }

//   ServicesState _mapFailureOGetServiceById(Either<Failure, Service> either) {
//     return either.fold(
//       (failure) => ErrorServicesState(message: failureToMessage(failure)),
//       (service) => LoadedServiceByIdState(service: service),
//     );
//   }
// }
