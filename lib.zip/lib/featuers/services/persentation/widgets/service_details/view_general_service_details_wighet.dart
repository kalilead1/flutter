import 'package:booking_v1/core/constants/strings.dart';
import 'package:booking_v1/core/routing/router_extensions.dart';
import 'package:booking_v1/core/widgets/container_widgets.dart';
import 'package:flutter/material.dart';

import '../../../../../core/constants/api.dart';
import '../../../../../core/routing/app_routes.dart';
import '../../../../../core/widgets/text_widgets.dart';
import '../../../../../core/widgets/urls_widget.dart';
import '../../../../../core/widgets/view_image_ciracle_widget.dart';
import '../../../../stores/domain/entities/store.dart';
import '../../../domain/entities/service.dart';

class ViewGeneralServiceDetailsWighet extends StatelessWidget {
  final Service service;
  final Store store;
  const ViewGeneralServiceDetailsWighet({
    super.key,
    required this.service,
    required this.store,
  });

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Padding(
        padding: EdgeInsets.all(defaultPadding),
        child: Column(
          spacing: defaultSpacing,
          children: [
            SecondaryContainer(
              child: Column(
                spacing: defaultSpacing / 2,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    "الوصف",
                    style: Theme.of(context).textTheme.titleMedium,
                  ),
                  ExpandableText(text: service.description.toString()),
                ],
              ),
            ),
            SecondaryContainer(
              child: Column(
                spacing: defaultSpacing / 2,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    "الخدمات المشمولة",
                    style: Theme.of(context).textTheme.titleMedium,
                  ),
                  ExpandableText(text: service.includedServices.toString()),
                ],
              ),
            ),
            SecondaryContainer(
              paddingHorizontal: 0,
              paddingVertical: 0,
              child: ListTile(
                contentPadding: EdgeInsets.only(right: defaultPadding),
                onTap: () {
                  context.pushTo(storeDetailsRoute, extra: store.id);
                },
                leading: ViewImageCiracleWidget(
                  imageURL: store.logo != null
                      ? baseUrlStoreImagesFolder + store.logo!
                      : baseUrlStoreImagesFolder,
                  size: 45,
                ),
                title: Text(
                  store.name.toString(),
                  style: Theme.of(context).textTheme.titleMedium,
                ),
                subtitle: Text(
                  "${store.directorate!.city!.name}  ${store.directorate!.name}",
                  style: Theme.of(context).textTheme.bodyMedium,
                ),
                trailing: Wrap(
                  children: [
                    IconButton(
                      onPressed: () {
                        Urls.urlMessage(store.phone!);
                      },
                      icon: Icon(Icons.message_rounded),
                    ),
                    IconButton(
                      onPressed: () {
                        Urls.urlPhone(store.phone!);
                      },
                      icon: Icon(Icons.phone),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
