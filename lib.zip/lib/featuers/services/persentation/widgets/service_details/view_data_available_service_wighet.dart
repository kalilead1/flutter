import 'package:booking_v1/core/constants/strings.dart';
import 'package:booking_v1/core/widgets/container_widgets.dart';
import 'package:booking_v1/featuers/bookings/persentation/bloc/bookings_query/bookings_query_state.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../../../../core/widgets/calendar_widget.dart';
import '../../../../../dependency_injection/initial.dart';
import '../../../../bookings/persentation/bloc/bookings_query/bookings_query_bloc.dart';
import '../../../../bookings/persentation/bloc/bookings_query/bookings_query_event.dart';

// class ViewDataAvailableServiceWighet extends StatefulWidget {
//   final int serviceId;
//   const ViewDataAvailableServiceWighet({super.key, required this.serviceId});

//   @override
//   State<ViewDataAvailableServiceWighet> createState() =>
//       _ViewDataAvailableServiceWighetState();
// }

// class _ViewDataAvailableServiceWighetState
//     extends State<ViewDataAvailableServiceWighet> {
//   final List<DateTime> bookedDates = [
//     DateTime(2026, 1, 17),
//     DateTime(2026, 1, 12),
//     DateTime(2026, 2, 17),
//     DateTime(2026, 1, 20),
//     DateTime(2026, 1, 22),
//   ];
//   @override
//   Widget build(BuildContext context) {
//     return Directionality(
//       textDirection: TextDirection.rtl,
//       child: Padding(
//         padding: const EdgeInsets.all(defaultPadding),
//         child: SecondaryContainer(
//           paddingHorizontal: 0,
//           paddingVertical: 0,
//           child: BookingCalendar(
//             bookedDates: bookedDates,
//             selectable: true,
//           ),
//           // child: CalendarDatePicker(
//           //   initialDate: DateTime.now(),
//           //   firstDate: DateTime(2000),
//           //   lastDate: DateTime(2030),
//           //   onDateChanged: (value) {},
//           // ),
//         ),
//       ),
//     );
//   }
// }
class ViewDataAvailableServiceWighet extends StatelessWidget {
  final int serviceId;
  const ViewDataAvailableServiceWighet({super.key, required this.serviceId});

  // final List<DateTime> bookedDates = [
  //   DateTime(2026, 1, 17),
  //   DateTime(2026, 1, 12),
  //   DateTime(2026, 2, 17),
  //   DateTime(2026, 1, 20),
  //   DateTime(2026, 1, 22),
  // ];
  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (context) => getIt<BookingsQueryBloc>()
        ..addAndRemember(
            GetBookingsDatesByServiceIdEvent(serviceId: serviceId)),
      child: Directionality(
        textDirection: TextDirection.rtl,
        child: Padding(
          padding: const EdgeInsets.all(defaultPadding),
          child: BlocBuilder<BookingsQueryBloc, BookingsQueryState>(
              builder: (context, state) {
            if (state is LoadingState) {
              return Center(child: CircularProgressIndicator());
            } else if (state is LoadedBookingsDatesByServiceIdState) {
              return SecondaryContainer(
                paddingHorizontal: 0,
                paddingVertical: 0,
                child: BookingCalendar(
                  bookedDates: state.bookingsDates,
                  selectable: true,
                ),
              );
            } else {
              return SecondaryContainer(
                  child: Center(child: Text("خطاء غير متوقع")));
            }
          }),
        ),
      ),
    );
  }
}
