import 'package:booking_v1/core/constants/strings.dart';
import 'package:booking_v1/core/widgets/container_widgets.dart';
import 'package:flutter/material.dart';

class ViewRatingsServiceWighet extends StatefulWidget {
  final int serviceId;
  const ViewRatingsServiceWighet({super.key, required this.serviceId});

  @override
  State<ViewRatingsServiceWighet> createState() =>
      _ViewRatingsServiceWighetState();
}

class _ViewRatingsServiceWighetState extends State<ViewRatingsServiceWighet> {
  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Column(
        spacing: defaultSpacing,
        children: [
          SecondaryContainer(
              child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              Column(
                spacing: defaultSpacing / 4,
                children: [
                  Text(
                    "4.5",
                    style: Theme.of(context).textTheme.titleLarge,
                  ),
                  Text("data"),
                  // SizedBox.expand(),
                  Wrap(
                    // spacing: defaultSpacing / 6,
                    children: [
                      Icon(
                        Icons.star_rate_rounded,
                        color: Colors.amberAccent,
                        size: 18,
                      ),
                      Icon(
                        Icons.star_rate_rounded,
                        color: Colors.amberAccent,
                        size: 18,
                      ),
                      Icon(
                        Icons.star_rate_rounded,
                        color: Colors.amberAccent,
                        size: 18,
                      ),
                      Icon(
                        Icons.star_rate_rounded,
                        color: Colors.amberAccent,
                        size: 18,
                      ),
                      Icon(
                        Icons.star_half_rounded,
                        color: Colors.amberAccent,
                        size: 18,
                      ),
                    ],
                  )
                ],
              ),
              Column(
                spacing: defaultSpacing / 4,
                children: [],
              ),
            ],
          )),
        ],
      ),
    );
  }
}
