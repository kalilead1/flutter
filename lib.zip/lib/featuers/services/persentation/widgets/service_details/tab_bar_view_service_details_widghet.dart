import 'package:booking_v1/core/constants/strings.dart';
import 'package:booking_v1/featuers/services/persentation/widgets/service_details/view_data_available_service_wighet.dart';
import 'package:booking_v1/featuers/services/persentation/widgets/service_details/view_general_service_details_wighet.dart';
import 'package:booking_v1/featuers/services/persentation/widgets/service_details/view_ratings_service_wighet.dart';
import 'package:flutter/material.dart';

import '../../../../stores/domain/entities/store.dart';
import '../../../domain/entities/service.dart';

class TabBarViewServiceDetailsWidghet extends StatefulWidget {
  final Store store;
  final Service service;
  const TabBarViewServiceDetailsWidghet({
    super.key,
    required this.store,
    required this.service,
  });

  @override
  State<TabBarViewServiceDetailsWidghet> createState() =>
      _TabBarViewServiceDetailsWidghetState();
}

class _TabBarViewServiceDetailsWidghetState
    extends State<TabBarViewServiceDetailsWidghet> {
  @override
  Widget build(BuildContext context) {
    return TabBarView(
      children: [
        SingleChildScrollView(
            child: ViewGeneralServiceDetailsWighet(
          service: widget.service,
          store: widget.store,
        )),
        // Center(child: Text("صالات افراح", style: TextStyle(fontSize: 16))),
        SingleChildScrollView(
          child: ViewDataAvailableServiceWighet(serviceId: widget.service.id!),
        ),
        CustomScrollView(
          slivers: [
            SliverList(
              delegate: SliverChildBuilderDelegate(
                semanticIndexOffset: 10,
                childCount: 10,
                (context, index) {
                  return Container(
                    margin: EdgeInsets.symmetric(
                      horizontal: defaultPadding,
                      vertical: defaultPadding / 2,
                    ),
                    child:
                        ViewRatingsServiceWighet(serviceId: widget.service.id!),
                  );
                },
              ),
            ),
          ],
        ),
      ],
    );
  }
}
