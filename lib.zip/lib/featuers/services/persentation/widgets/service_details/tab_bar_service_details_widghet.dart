import 'package:booking_v1/core/constants/strings.dart';
import 'package:flutter/material.dart';

// class TabBarServiceDetailsWidghet extends StatelessWidget {
//   const TabBarServiceDetailsWidghet({super.key});

//   @override
//   Widget build(BuildContext context) {
//     return TabBar(
//       padding: EdgeInsets.only(bottom: defaultPadding / 4),
//       isScrollable: true,
//       tabs: [
//         Text("التفاصيل"),
//         Text("التاريخ المتاح"),
//         Text("التقييمات"),
//       ],
//     );
//   }
// }

class TabBarServiceDetailsWidghet extends StatelessWidget {
  const TabBarServiceDetailsWidghet({super.key});

  @override
  Widget build(BuildContext context) {
    return TabBar(
      indicatorPadding: EdgeInsets.zero,
      indicator: BoxDecoration(
        color: Color(0xFF4F8EC3),
        borderRadius: BorderRadius.circular(defaultBorderRadious * 2),
      ),
      labelPadding: EdgeInsets.symmetric(horizontal: 30, vertical: 5),
      indicatorSize: TabBarIndicatorSize.tab,
      isScrollable: true,
      labelColor: Colors.white,
      tabAlignment: TabAlignment.center,
      splashBorderRadius: BorderRadius.circular(defaultBorderRadious),
      tabs: [
        Text("التفاصيل"),
        Text("التاريخ المتاح"),
        Text("التقييمات"),
      ],
    );
  }
}
