import 'package:flutter/material.dart';

import '../../../../core/constants/strings.dart';

// class ViewPrimaryServiceDetailsWighet extends StatefulWidget {
//   const ViewPrimaryServiceDetailsWighet({
//     super.key,
//     this.serviceName = "اسم الخدمة",
//     this.servicePrice = 00.0,
//     this.serviceStat = "مغلق",
//     this.servicePeriod = "من 0 صباح الى 0 الليل",
//     this.serviceNumberOfPeople = 00,
//   });

//   final String serviceName;
//   final double servicePrice;
//   final String serviceStat;
//   final String servicePeriod;
//   final double serviceNumberOfPeople;

//   @override
//   State<ViewPrimaryServiceDetailsWighet> createState() =>
//       _ViewPrimaryServiceDetailsWighetState();
// }

// class _ViewPrimaryServiceDetailsWighetState
//     extends State<ViewPrimaryServiceDetailsWighet> {
//   @override
//   Widget build(BuildContext context) {
//     return Directionality(
//       textDirection: TextDirection.rtl,
//       child: Padding(
//         padding: const EdgeInsets.all(defaultPadding),
//         child: PrimaryContainer(
//             child: Column(
//           spacing: defaultSpacing / 2,
//           children: [
//             Row(
//               mainAxisAlignment: MainAxisAlignment.spaceBetween,
//               children: [
//                 Text(widget.serviceName,
//                     style: Theme.of(context).textTheme.titleLarge),
//                 Text("${widget.servicePrice.toString()}  ر.ي",
//                     style: Theme.of(context).textTheme.displayLarge),
//               ],
//             ),
//             Divider(),
//             Row(
//               mainAxisAlignment: MainAxisAlignment.spaceAround,
//               children: [
//                 Column(
//                   crossAxisAlignment: CrossAxisAlignment.center,
//                   children: [
//                     Text(
//                       widget.serviceStat,
//                       style: Theme.of(context).textTheme.bodyLarge,
//                     ),
//                     Text(
//                       "الحالة",
//                       style: Theme.of(context).textTheme.labelSmall,
//                     ),
//                   ],
//                 ),
//                 Column(
//                   crossAxisAlignment: CrossAxisAlignment.center,
//                   children: [
//                     Text(
//                       widget.servicePeriod,
//                       style: Theme.of(context).textTheme.bodyLarge,
//                     ),
//                     Text(
//                       "المدة",
//                       style: Theme.of(context).textTheme.labelSmall,
//                     ),
//                   ],
//                 ),
//                 Column(
//                   crossAxisAlignment: CrossAxisAlignment.center,
//                   children: [
//                     Text(
//                       "${widget.serviceNumberOfPeople.toString()} شخص",
//                       style: Theme.of(context).textTheme.bodyLarge,
//                     ),
//                     Text(
//                       "السعة",
//                       style: Theme.of(context).textTheme.labelSmall,
//                     ),
//                   ],
//                 ),
//               ],
//             ),
//           ],
//         )),
//       ),
//     );
//   }
// }

class ViewPrimaryServiceDetailsWighet extends StatelessWidget {
  const ViewPrimaryServiceDetailsWighet({
    super.key,
    this.serviceName = "اسم الخدمة",
    this.servicePrice = 00.0,
    this.serviceStat = "مغلق",
    this.servicePeriod = "من 0 صباح الى 0 الليل",
    this.serviceNumberOfPeople = 00,
  });

  final String serviceName;
  final double servicePrice;
  final String serviceStat;
  final String servicePeriod;
  final int serviceNumberOfPeople;

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Column(
        spacing: defaultSpacing / 2,
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 8),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(serviceName,
                    style: Theme.of(context).textTheme.titleLarge),
                Text("${servicePrice.toString()}  ر.ي",
                    style: Theme.of(context).textTheme.displayLarge),
              ],
            ),
          ),
          Divider(),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Text(
                    serviceStat,
                    style: Theme.of(context).textTheme.bodyLarge,
                  ),
                  Text(
                    "الحالة",
                    style: Theme.of(context).textTheme.labelSmall,
                  ),
                ],
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Text(
                    servicePeriod,
                    style: Theme.of(context).textTheme.bodyLarge,
                  ),
                  Text(
                    "المدة",
                    style: Theme.of(context).textTheme.labelSmall,
                  ),
                ],
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Text(
                    "${serviceNumberOfPeople.toString()} شخص",
                    style: Theme.of(context).textTheme.bodyLarge,
                  ),
                  Text(
                    "السعة",
                    style: Theme.of(context).textTheme.labelSmall,
                  ),
                ],
              ),
            ],
          ),
        ],
      ),
    );
  }
}
