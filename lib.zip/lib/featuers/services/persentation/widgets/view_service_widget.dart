import 'package:booking_v1/core/routing/app_routes.dart';
import 'package:booking_v1/core/routing/router_extensions.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';

import '../../../../core/constants/colors.dart';
import '../../../../core/constants/strings.dart';
import '../../../../core/widgets/container_widgets.dart';
import '../../../stores/persentation/widgets/view_store_small.dart';
import '../../domain/entities/service.dart';
import 'view_primary_service_details_wighet.dart';
import 'view_image_service_widget.dart';

class ViewServiceHorizontalForOwner extends StatelessWidget {
  final Service service;
  const ViewServiceHorizontalForOwner({super.key, required this.service});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.all(defaultPadding / 2),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(defaultBorderRadious),
        color: Theme.of(context).colorScheme.secondary,
        border: Border.all(
          color: Theme.of(context).colorScheme.onPrimaryContainer,
        ),
      ),
      child: Expanded(
        child: Column(
          spacing: defaultSpacing,
          children: [
            ViewSingleImageServiceWidget(serviceId: service.id!),
            ViewPrimaryServiceDetailsWighet(
              serviceName: service.name!,
              servicePrice: service.price!,
              servicePeriod: service.duration!,
              serviceNumberOfPeople: service.peopleCount!,
            ),
          ],
        ),
      ),
    );
  }
}

class ViewServiceVertical extends StatelessWidget {
  final Service service;

  const ViewServiceVertical({
    super.key,
    required this.service,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        context.pushTo(serviceDetailsRoute, extra: service.id);
      },
      child: PrimaryContainer(
        paddingHorizontal: 0,
        paddingVertical: 0,
        child: Padding(
          padding: const EdgeInsets.all(2),
          child: Column(
            children: [
              Expanded(
                child: Stack(
                  children: [
                    ViewSingleImageService2Widget(serviceId: service.id!),
                    Padding(
                      padding: const EdgeInsets.all(defaultPadding / 2 - 2),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            height: 37,
                            decoration: BoxDecoration(
                              color: Theme.of(context)
                                  .colorScheme
                                  .secondary
                                  .withOpacity(0.3),
                              shape: BoxShape.circle,
                            ),
                            child: IconButton(
                              onPressed: () {},
                              icon: Icon(Icons.favorite_border_rounded),
                            ),
                          ),
                          Container(
                            padding: EdgeInsets.symmetric(horizontal: 8),
                            decoration: BoxDecoration(
                              color: Theme.of(context).colorScheme.primary,
                              borderRadius:
                                  BorderRadius.circular(defaultBorderRadious),
                            ),
                            child: Text(
                              textAlign: TextAlign.center,
                              "${service.store!.category!.name}",
                              // style: Theme.of(context).textTheme.titleSmall,
                              style: TextStyle(
                                fontSize: 11,
                                color: Colors.white,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(6),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  // crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Column(
                      // mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          service.name.toString(),
                          style: Theme.of(context).textTheme.titleMedium,
                        ),
                        Row(
                          children: [
                            Icon(
                              Icons.star_rate_rounded,
                              size: 12,
                              color: warningColor,
                            ),
                            Icon(
                              Icons.star_rate_rounded,
                              size: 12,
                              color: warningColor,
                            ),
                            Icon(
                              Icons.star_rate_rounded,
                              size: 12,
                              color: warningColor,
                            ),
                            Icon(
                              Icons.star_rate_rounded,
                              size: 12,
                              color: warningColor,
                            ),
                            Icon(
                              Icons.star_rate_rounded,
                              size: 12,
                              color: warningColor,
                            ),
                          ],
                        )
                      ],
                    ),
                    Expanded(
                      child: Text(
                        "ر.ي ${service.price}",
                        style: Theme.of(context).textTheme.displayMedium,
                        textAlign: TextAlign.left,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                  ],
                ),
              ),
              SizedBox(height: 5),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 6),
                child: ViewStoreSmallWidget(
                  storeId: service.store!.id!,
                  storeName: service.store!.name!,
                  storeLogo: service.store!.logo!,
                  storeCity: service.store!.directorate!.city!.name!,
                  storeDirectorateName: service.store!.directorate!.name!,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
// class ViewServiceVertical extends StatelessWidget {
//   final int? serviceId;
//   final String? serviceImage;
//   final String? serviceName;
//   final double? servicePrice;
//   final int? storeId;
//   final int? categoryId;
//   // final String? storeImage;
//   // final String? storeName;
//   // final String? storeCategory;
//   // final String? storeLocation;
//   const ViewServiceVertical({
//     super.key,
//     this.serviceId,
//     this.serviceImage,
//     this.serviceName,
//     this.servicePrice,
//     this.storeId,
//     this.categoryId,
//     // this.storeImage,
//     // this.storeName,
//     // this.storeCategory,
//     // this.storeLocation,
//   });

//   @override
//   Widget build(BuildContext context) {
//     // int categoryId = 13;
//     return MultiBlocProvider(
//       providers: [
//         BlocProvider(
//           create: (context) =>
//               getIt<StoresBloc>()..add(GetStoreByIdEvent(storeId: storeId!)),
//         )
//       ],
//       child: GestureDetector(
//         onTap: () {
//           // Navigator.pushNamed(context, serviceDetailsScreenRoute);
//           context.pushTo(serviceDetailsRoute, extra: serviceId);
//         },
//         child: PrimaryContainer(
//           paddingHorizontal: 0,
//           paddingVertical: 0,
//           child: BlocBuilder<StoresBloc, StoresState>(
//             builder: (context, state) {
//               if (state is LoadedStoreByIdState) {
//                 return Padding(
//                   padding: const EdgeInsets.all(2),
//                   child: Column(
//                     children: [
//                       Expanded(
//                         child: Stack(
//                           children: [
//                             ViewSingleImageService2Widget(
//                                 serviceId: serviceId!),
//                             Padding(
//                               padding:
//                                   const EdgeInsets.all(defaultPadding / 2 - 2),
//                               child: Row(
//                                 mainAxisAlignment:
//                                     MainAxisAlignment.spaceBetween,
//                                 crossAxisAlignment: CrossAxisAlignment.start,
//                                 children: [
//                                   Container(
//                                     height: 37,
//                                     decoration: BoxDecoration(
//                                       color: Theme.of(context)
//                                           .colorScheme
//                                           .secondary
//                                           .withOpacity(0.3),
//                                       shape: BoxShape.circle,
//                                     ),
//                                     child: IconButton(
//                                       onPressed: () {},
//                                       icon: Icon(Icons.favorite_border_rounded),
//                                     ),
//                                   ),
//                                   ViewCategoryWathBackgroundWidget(
//                                       categoryId: state.store.categoryId!),
//                                 ],
//                               ),
//                             ),
//                           ],
//                         ),
//                       ),
//                       Padding(
//                         padding: const EdgeInsets.all(6),
//                         child: Row(
//                           mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                           // crossAxisAlignment: CrossAxisAlignment.end,
//                           children: [
//                             Column(
//                               // mainAxisAlignment: MainAxisAlignment.start,
//                               crossAxisAlignment: CrossAxisAlignment.start,
//                               children: [
//                                 Text(
//                                   "$serviceName",
//                                   style:
//                                       Theme.of(context).textTheme.titleMedium,
//                                 ),
//                                 Row(
//                                   children: [
//                                     Icon(
//                                       Icons.star_rate_rounded,
//                                       size: 12,
//                                       color: warningColor,
//                                     ),
//                                     Icon(
//                                       Icons.star_rate_rounded,
//                                       size: 12,
//                                       color: warningColor,
//                                     ),
//                                     Icon(
//                                       Icons.star_rate_rounded,
//                                       size: 12,
//                                       color: warningColor,
//                                     ),
//                                     Icon(
//                                       Icons.star_rate_rounded,
//                                       size: 12,
//                                       color: warningColor,
//                                     ),
//                                     Icon(
//                                       Icons.star_rate_rounded,
//                                       size: 12,
//                                       color: warningColor,
//                                     ),
//                                   ],
//                                 )
//                               ],
//                             ),
//                             SizedBox(
//                               width: 60,
//                               child: Text(
//                                 "ر.ي $servicePrice",
//                                 style:
//                                     Theme.of(context).textTheme.displayMedium,
//                                 maxLines: 1,
//                                 overflow: TextOverflow.ellipsis,
//                               ),
//                             ),
//                           ],
//                         ),
//                       ),
//                       SizedBox(height: 5),
//                       Padding(
//                         padding: const EdgeInsets.symmetric(horizontal: 6),
//                         child: Row(
//                           spacing: defaultSpacing / 3,
//                           mainAxisAlignment: MainAxisAlignment.start,
//                           children: [
//                             ViewImageCiracleWidget(
//                               imageURL: state.store.logo != null
//                                   ? baseUrlStoreaImagesFolder +
//                                       state.store.logo!
//                                   : baseUrlStoreaImagesFolder,
//                               size: 25,
//                             ),
//                             Text(
//                               "${state.store.name}",
//                               style: Theme.of(context).textTheme.bodySmall,
//                             ),
//                             CircleAvatar(
//                               radius: 2,
//                               backgroundColor: Theme.of(context)
//                                   .colorScheme
//                                   .tertiary
//                                   .withOpacity(0.7),
//                             ),
//                             Text(
//                               "${state.store.directorateId}",
//                               style: Theme.of(context).textTheme.bodySmall,
//                             ),
//                           ],
//                         ),
//                       ),
//                     ],
//                   ),
//                 );
//               } else {
//                 return SizedBox();
//               }
//             },
//           ),
//         ),
//       ),
//     );
//   }
// }

class ViewServiceHorizontal extends StatelessWidget {
  const ViewServiceHorizontal({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.all(defaultPadding / 2),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(defaultBorderRadious),
        color: Theme.of(context).colorScheme.secondary,
        border: Border.all(
          color: Theme.of(context).colorScheme.onPrimaryContainer,
        ),
      ),
      child: Expanded(
        child: Column(
          children: [
            // HeadService3(),
            Stack(
              children: [
                Container(
                  height: 160,
                  decoration: BoxDecoration(
                    color: Theme.of(context)
                        .colorScheme
                        .secondary
                        .withOpacity(0.10),
                    borderRadius: BorderRadius.circular(defaultBorderRadious),
                    border: Border.all(
                      color: Theme.of(context).colorScheme.onPrimaryContainer,
                    ),
                    image: DecorationImage(
                      image: AssetImage("assets/images/image2.jpg"),
                      fit: BoxFit.cover,
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(defaultPadding / 2),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        height: 35,
                        decoration: BoxDecoration(
                          color: Theme.of(context).colorScheme.tertiary,
                          shape: BoxShape.circle,
                        ),
                        child: IconButton(
                          constraints: BoxConstraints(maxHeight: 5),
                          style: ButtonStyle(),
                          iconSize: 26,
                          splashRadius: 10,
                          onPressed: () {},
                          icon: Icon(Icons.favorite_border_rounded),
                        ),
                      ),
                      Container(
                        padding: EdgeInsets.symmetric(horizontal: 6),
                        decoration: BoxDecoration(
                          color: Theme.of(context)
                              .colorScheme
                              .secondary
                              .withOpacity(0.4),
                          borderRadius:
                              BorderRadius.circular(defaultBorderRadious),
                        ),
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.end,
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              "4.3",
                              style: Theme.of(context).textTheme.titleSmall,
                            ),
                            Icon(
                              Icons.star_rate_rounded,
                              size: 20,
                              color: Colors.amberAccent,
                            )
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),

            Container(
              constraints: BoxConstraints(
                minWidth: MediaQuery.of(context).size.width,
              ),
              color: Theme.of(context).colorScheme.secondary,
              child: Padding(
                padding: const EdgeInsets.only(
                  top: 8,
                  right: 8,
                  left: 12,
                  bottom: 2,
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      "اسم الخدمة",
                      style: Theme.of(context).textTheme.titleLarge,
                    ),
                    Text(
                      "00.0 ر.ي",
                      style: Theme.of(context).textTheme.displayLarge,
                    ),
                  ],
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 6),
              child: Row(
                spacing: defaultSpacing / 2,
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Container(
                    decoration: BoxDecoration(
                      color: Theme.of(context).colorScheme.secondary,
                      border: Border.all(
                        color: Theme.of(context).colorScheme.primary,
                        width: 1,
                      ),
                      shape: BoxShape.circle,
                    ),
                    child: CircleAvatar(
                      radius: 10,
                      child: Center(
                        child: SvgPicture.asset(
                          "assets/logos/logo4.svg",
                          colorFilter: ColorFilter.mode(
                            Theme.of(context)
                                .colorScheme
                                .tertiary
                                .withOpacity(0.40),
                            BlendMode.srcIn,
                          ),
                          height: 10,
                        ),
                      ),
                    ),
                  ),
                  Text(
                    "اسم المتجر",
                    style: Theme.of(context).textTheme.bodySmall,
                  ),
                  CircleAvatar(
                    radius: 2,
                    backgroundColor:
                        Theme.of(context).colorScheme.tertiary.withOpacity(0.7),
                  ),
                  Text(
                    "الفئة",
                    style: Theme.of(context).textTheme.bodySmall,
                  ),
                  CircleAvatar(
                    radius: 2,
                    backgroundColor:
                        Theme.of(context).colorScheme.tertiary.withOpacity(0.7),
                  ),
                  Text(
                    "الموقع",
                    style: Theme.of(context).textTheme.bodySmall,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
