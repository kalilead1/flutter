import 'package:flutter/material.dart';

import '../../../../../core/constants/strings.dart';
import '../../../../../core/widgets/input_widgets.dart';

class ServiceGloableInfoForm extends StatelessWidget {
  final GlobalKey<FormState> formKey;
  final TextEditingController serviceDescription;
  final TextEditingController serviceIncludedServices;

  const ServiceGloableInfoForm({
    super.key,
    required this.formKey,
    required this.serviceDescription,
    required this.serviceIncludedServices,
  });

  @override
  Widget build(BuildContext context) {
    return Form(
      key: formKey,
      child: Column(
        spacing: defaultSpacing,
        children: [
          CustomInputFieldWidget(
            label: "وصف الخدمة",
            textController: serviceDescription,
            maxLength: 150,
            maxLines: 3,
            minLines: 1,
          ),
          CustomInputFieldWidget(
            label: "الخدمات المشمولة",
            textController: serviceIncludedServices,
            maxLength: 200,
            minLines: 1,
          ),
        ],
      ),
    );
  }
}
