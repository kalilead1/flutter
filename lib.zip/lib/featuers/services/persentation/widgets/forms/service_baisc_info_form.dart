import 'package:flutter/material.dart';

import '../../../../../core/constants/strings.dart';
import '../../../../../core/widgets/input_widgets.dart';
import '../../../domain/enums/duration_services_enum.dart';

class ServiceBaiscInfoForm extends StatelessWidget {
  final GlobalKey<FormState> formKey;
  final TextEditingController serviceName;
  final TextEditingController servicePrice;
  final TextEditingController serviceDuration;
  final TextEditingController servicePeopleCount;

  const ServiceBaiscInfoForm({
    super.key,
    required this.formKey,
    required this.serviceName,
    required this.servicePrice,
    required this.serviceDuration,
    required this.servicePeopleCount,
  });

  @override
  Widget build(BuildContext context) {
    return Form(
      key: formKey,
      child: Column(
        spacing: defaultSpacing,
        children: [
          CustomInputFieldWidget(
            label: "اسم الخدمة",
            textController: serviceName,
          ),
          CustomInputFieldWidget(
            label: "سعر الخدمة",
            textController: servicePrice,
            textInputType: TextInputType.numberWithOptions(decimal: true),
            suffix: Text("ر.ي"),
          ),
          CustomInputSeletctedWidget(
            list: durationServicesList,
            label: "مده الخدمة",
            textController: serviceDuration,
          ),
          CustomInputFieldWidget(
            label: "سعة الاشخاص",
            textController: servicePeopleCount,
            textInputType: TextInputType.numberWithOptions(decimal: true),
          ),
        ],
      ),
    );
  }
}
