import 'dart:io';

import 'package:booking_v1/core/constants/strings.dart';
import 'package:booking_v1/core/widgets/botton_widghts.dart';
import 'package:booking_v1/core/widgets/image_picker/widgets/image_uploader_widget.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

class AddImagesForm extends StatefulWidget {
  final Function(List<File>)? onSaved;
  final int maxImages;
  const AddImagesForm(
      {super.key, required this.onSaved, required this.maxImages});

  @override
  State<AddImagesForm> createState() => _AddImagesFormState();
}

class _AddImagesFormState extends State<AddImagesForm> {
  List<File> _images = [];

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        spacing: defaultSpacing,
        children: [
          ImageUploaderWidghet(
            maxImages: widget.maxImages,
            onChanged: (value) {
              setState(() {
                _images = value;
              });
            },
          ),
          SizedBox(height: defaultSpacing),
          PrimaryElevatedButton(
              onPressed: () {
                widget.onSaved != null ? widget.onSaved!(_images) : null;
                context.pop();
              },
              text: "اضافة")
        ],
      ),
    );
  }
}
// class AddImagesForm extends StatefulWidget {
//   final Function(List<File>)? onSaved;
//   final int maxImages;
//   const AddImagesForm(
//       {super.key, required this.onSaved, required this.maxImages});

//   @override
//   State<AddImagesForm> createState() => _AddImagesFormState();
// }

// class _AddImagesFormState extends State<AddImagesForm> {
//   List<File> _images = [];

//   void showDialogForm() {
//     showDialog(
//       context: context,
//       builder: (context) {
//         return Dialog(
//           child: Padding(
//             padding: const EdgeInsets.all(defaultPadding),
//             child: Column(
//               mainAxisSize: MainAxisSize.min,
//               spacing: defaultSpacing,
//               children: [
//                 Text("اضافة صور ${widget.maxImages}"),
//                 ImageUploaderWidghet(
//                   maxImages: widget.maxImages,
//                   onChanged: (value) {
//                     setState(() {
//                       _images = value;
//                     });
//                   },
//                 ),
//                 SizedBox(height: defaultSpacing),
//                 PrimaryElevatedButton(
//                     onPressed: () {
//                       widget.onSaved != null ? widget.onSaved!(_images) : null;
//                       context.pop();
//                     },
//                     text: "اضافة")
//               ],
//             ),
//           ),
//         );
//       },
//     );
//   }

//   @override
//   Widget build(BuildContext context) {
//     return SecondaryElevatedButton(
//       onPressed: () {
//         showDialogForm();
//       },
//       text: "اضافة صور",
//     );
//   }
// }

void addServiceImagesDialog({
  required BuildContext context,
  Function(List<File>)? onSaved,
  required int maxImages,
}) {
  showDialog(
    context: context,
    builder: (context) {
      return Padding(
        padding: const EdgeInsets.symmetric(horizontal: 1),
        child: Dialog(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(defaultBorderRadious),
          ),
          backgroundColor: Theme.of(context).scaffoldBackgroundColor,
          insetPadding: EdgeInsets.all(defaultPadding),
          child: Padding(
            padding: EdgeInsets.all(defaultPadding),
            child: Column(
              spacing: defaultSpacing * 2,
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  "اضافة صور",
                  style: Theme.of(context).textTheme.titleLarge,
                ),
                AddImagesForm(
                  onSaved: onSaved,
                  maxImages: maxImages,
                ),
              ],
            ),
          ),
        ),
      );
    },
  );
}
