import 'package:booking_v1/core/widgets/container_widgets.dart';
import 'package:booking_v1/dependency_injection/initial.dart';
import 'package:booking_v1/featuers/services/persentation/bloc/service_images/service_images_bloc.dart';
import 'package:booking_v1/featuers/services/persentation/bloc/service_images/service_images_event.dart';
import 'package:booking_v1/featuers/services/persentation/bloc/service_images/service_images_state.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_svg/svg.dart';
import 'package:go_router/go_router.dart';

import '../../../../core/constants/api.dart';
import '../../../../core/constants/strings.dart';
import '../../../../core/widgets/botton_widghts.dart';
import '../../../../core/widgets/dialog_widgets.dart';

class ViewSingleImageServiceWidget extends StatelessWidget {
  final int serviceId;
  const ViewSingleImageServiceWidget({super.key, required this.serviceId});

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (context) => getIt<ServiceImagesBloc>()
        ..addAndRemember(GetAllServiceImagesEvent(serviceId: serviceId)),
      child: BlocBuilder<ServiceImagesBloc, ServiceImagesState>(
        builder: (context, state) {
          if (state is LoadedServiceImagesState) {
            return Container(
              height: 160,
              decoration: BoxDecoration(
                color:
                    Theme.of(context).colorScheme.secondary.withOpacity(0.10),
                borderRadius: BorderRadius.circular(defaultBorderRadious),
                border: Border.all(
                  color: Theme.of(context).colorScheme.onPrimaryContainer,
                ),
                image: DecorationImage(
                  // image: AssetImage("assets/images/image2.jpg"),
                  image: NetworkImage(baseUrlServiceImagesFolder +
                      state.serviceImages.first.image!),
                  fit: BoxFit.cover,
                ),
              ),
            );
            // } else if (state is ErrorServiceImagesState) {
            //   return Container(
            //     height: 160,
            //     decoration: BoxDecoration(
            //       color:
            //           Theme.of(context).colorScheme.secondary.withOpacity(0.10),
            //       borderRadius: BorderRadius.circular(defaultBorderRadious),
            //       border: Border.all(
            //         color: Theme.of(context).colorScheme.onPrimaryContainer,
            //       ),
            //     ),
            //     child: Center(child: Text(state.message)),
            //   );
          } else {
            return SizedBox(
              height: 160,
              child: Center(
                child: SvgPicture.asset(
                  "assets/logos/logo4.svg",
                  colorFilter: ColorFilter.mode(
                    Theme.of(context)
                        .colorScheme
                        .tertiary
                        .withValues(alpha: 0.7),
                    BlendMode.srcIn,
                  ),
                  height: 50,
                ),
              ),
            );
          }
        },
      ),
    );
  }
}

class ViewSingleImageServiceSquireWidget extends StatelessWidget {
  final int serviceId;
  const ViewSingleImageServiceSquireWidget(
      {super.key, required this.serviceId});

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (context) => getIt<ServiceImagesBloc>()
        ..addAndRemember(GetAllServiceImagesEvent(serviceId: serviceId)),
      child: BlocBuilder<ServiceImagesBloc, ServiceImagesState>(
        builder: (context, state) {
          if (state is LoadedServiceImagesState) {
            return Container(
              height: 80,
              width: 90,
              decoration: BoxDecoration(
                color:
                    Theme.of(context).colorScheme.secondary.withOpacity(0.10),
                borderRadius: BorderRadius.circular(defaultBorderRadious),
                border: Border.all(
                  color: Theme.of(context).colorScheme.onPrimaryContainer,
                ),
                image: DecorationImage(
                  // image: AssetImage("assets/images/image2.jpg"),
                  image: NetworkImage(baseUrlServiceImagesFolder +
                      state.serviceImages.first.image!),
                  fit: BoxFit.cover,
                ),
              ),
            );
          } else if (state is ErrorServiceImagesState) {
            return Container(
              height: 70,
              width: 90,
              decoration: BoxDecoration(
                color:
                    Theme.of(context).colorScheme.secondary.withOpacity(0.10),
                borderRadius: BorderRadius.circular(defaultBorderRadious),
                border: Border.all(
                  color: Theme.of(context).colorScheme.onPrimaryContainer,
                ),
              ),
              child: SizedBox(
                height: 70,
                width: 90,
                child: Center(
                  child: SvgPicture.asset(
                    "assets/logos/logo4.svg",
                    colorFilter: ColorFilter.mode(
                      Theme.of(context)
                          .colorScheme
                          .tertiary
                          .withValues(alpha: 0.7),
                      BlendMode.srcIn,
                    ),
                    height: 25,
                  ),
                ),
              ),
              // child: Center(child: Text(state.message)),
            );
          } else {
            return SizedBox(
              height: 70,
              width: 90,
              child: Center(
                child: SvgPicture.asset(
                  "assets/logos/logo4.svg",
                  colorFilter: ColorFilter.mode(
                    Theme.of(context)
                        .colorScheme
                        .tertiary
                        .withValues(alpha: 0.7),
                    BlendMode.srcIn,
                  ),
                  height: 30,
                ),
              ),
            );
          }
        },
      ),
    );
  }
}

class ViewSingleImageService2Widget extends StatelessWidget {
  final int serviceId;
  const ViewSingleImageService2Widget({super.key, required this.serviceId});

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (context) => getIt<ServiceImagesBloc>()
        ..addAndRemember(GetAllServiceImagesEvent(serviceId: serviceId)),
      child: BlocBuilder<ServiceImagesBloc, ServiceImagesState>(
        builder: (context, state) {
          if (state is LoadedServiceImagesState) {
            return Container(
              // height: 160,
              decoration: BoxDecoration(
                color: Theme.of(context)
                    .colorScheme
                    .tertiary
                    .withValues(alpha: 0.2),
                borderRadius: BorderRadius.vertical(top: Radius.circular(10)),
                border: Border.all(
                  color: Theme.of(context).colorScheme.onPrimaryContainer,
                ),
                image: DecorationImage(
                  // image: AssetImage("assets/images/image2.jpg"),
                  image: NetworkImage(baseUrlServiceImagesFolder +
                      state.serviceImages.first.image!),
                  fit: BoxFit.cover,
                ),
              ),
            );
            // } else if (state is ErrorServiceImagesState) {
            //   return Container(
            //     height: 160,
            //     decoration: BoxDecoration(
            //       color:
            //           Theme.of(context).colorScheme.secondary.withOpacity(0.10),
            //       borderRadius: BorderRadius.circular(defaultBorderRadious),
            //       border: Border.all(
            //         color: Theme.of(context).colorScheme.onPrimaryContainer,
            //       ),
            //     ),
            //     child: Center(child: Text(state.message)),
            //   );
          } else {
            return SizedBox(
              height: 160,
              child: Center(
                child: SvgPicture.asset(
                  "assets/logos/logo4.svg",
                  colorFilter: ColorFilter.mode(
                    Theme.of(context)
                        .colorScheme
                        .tertiary
                        .withValues(alpha: 0.7),
                    BlendMode.srcIn,
                  ),
                  height: 50,
                ),
              ),
            );
          }
        },
      ),
    );
  }
}

class ViewMultiImagesServiceWidget extends StatelessWidget {
  final int serviceId;
  final bool _isCarouselVisible = true;
  const ViewMultiImagesServiceWidget({super.key, required this.serviceId});
  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (context) => getIt<ServiceImagesBloc>()
        ..addAndRemember(GetAllServiceImagesEvent(serviceId: serviceId)),
      child: BlocBuilder<ServiceImagesBloc, ServiceImagesState>(
        builder: (context, state) {
          if (state is LoadedServiceImagesState) {
            return AnimatedContainer(
              duration: const Duration(milliseconds: 300),
              height: _isCarouselVisible ? 160.0 : 0.0,
              child: _isCarouselVisible
                  ? CarouselSlider(
                      options: CarouselOptions(
                        // padEnds: false,
                        height: 160.0,
                        autoPlay: true,
                        enlargeCenterPage: true,
                        enlargeStrategy: CenterPageEnlargeStrategy.scale,
                        viewportFraction: 0.8,
                        aspectRatio: 2.0,
                        initialPage: 0,
                      ),
                      items: state.serviceImages.map((i) {
                        return Builder(
                          builder: (BuildContext context) {
                            return Container(
                              width: MediaQuery.of(context).size.width,
                              margin:
                                  const EdgeInsets.symmetric(horizontal: 0.0),
                              decoration: BoxDecoration(
                                borderRadius:
                                    BorderRadius.circular(defaultBorderRadious),
                                // color: Color(0xFF3D6C91),
                                border: Border.all(
                                  color:
                                      // Theme.of(context).colorScheme.onPrimaryContainer,
                                      Theme.of(context).colorScheme.tertiary,
                                ),
                                image: DecorationImage(
                                  image: NetworkImage(
                                      baseUrlServiceImagesFolder + i.image!),
                                  fit: BoxFit.cover,
                                ),
                              ),
                            );
                          },
                        );
                      }).toList(),
                    )
                  : const SizedBox.shrink(),
            );
          } else {
            return Padding(
              padding: const EdgeInsets.only(
                top: defaultPadding,
                right: defaultPadding,
                left: defaultPadding,
              ),
              child: PrimaryContainer(
                child: SizedBox(
                  height: 140,
                  child: Center(
                    child: SvgPicture.asset(
                      "assets/logos/logo4.svg",
                      colorFilter: ColorFilter.mode(
                        Theme.of(context)
                            .colorScheme
                            .tertiary
                            .withValues(alpha: 0.7),
                        BlendMode.srcIn,
                      ),
                      height: 50,
                    ),
                  ),
                ),
              ),
            );
          }
        },
      ),
    );
  }
}

class ViewSingleImageServiceForDeleteWidget extends StatelessWidget {
  final int serviceId;
  const ViewSingleImageServiceForDeleteWidget(
      {super.key, required this.serviceId});

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (context) => getIt<ServiceImagesBloc>()
        ..addAndRemember(GetAllServiceImagesEvent(serviceId: serviceId)),
      child: BlocBuilder<ServiceImagesBloc, ServiceImagesState>(
        builder: (context, state) {
          if (state is LoadedServiceImagesState) {
            return ListView.separated(
              itemCount: state.serviceImages.length,
              separatorBuilder: (context, index) {
                return SizedBox(height: defaultSpacing);
              },
              itemBuilder: (context, index) {
                final image = state.serviceImages[index];
                return Stack(
                  children: [
                    Container(
                      height: 160,
                      width: MediaQuery.of(context).size.width,
                      decoration: BoxDecoration(
                        color: Theme.of(context)
                            .colorScheme
                            .secondary
                            .withOpacity(0.10),
                        borderRadius:
                            BorderRadius.circular(defaultBorderRadious),
                        border: Border.all(
                          color:
                              Theme.of(context).colorScheme.onPrimaryContainer,
                        ),
                        image: DecorationImage(
                          image: NetworkImage(
                              baseUrlServiceImagesFolder + image.image!),
                          fit: BoxFit.cover,
                        ),
                      ),
                    ),
                    Positioned(
                      right: 10,
                      top: 10,
                      child: InkWell(
                        onTap: () {
                          AppDialog.showCustomDialog(
                            context: context,
                            title: "حذف صورة",
                            content: "هل انت متاكد من حذف الصورة؟",
                            childAction: CancelElevatedButton(
                                onPressed: () {
                                  if (state.serviceImages.length <= 2) {
                                    AppDialog.showErrorMessageDialog(
                                      context: context,
                                      title: "فشل حذف الصورة",
                                      content: "لا يمكنك حذف الصورة",
                                    );
                                  }
                                  context.pop();
                                },
                                text: "نعم"),
                          );
                        },
                        child: Container(
                          decoration: BoxDecoration(
                              color: Colors.redAccent.withValues(alpha: 0.8),
                              shape: BoxShape.circle),
                          child: Padding(
                            padding: const EdgeInsets.all(4),
                            child: const Icon(
                              Icons.delete,
                              color: Colors.white,
                            ),
                          ),
                        ),
                      ),
                      // child: CircleAvatar(
                      //   backgroundColor:
                      //       Theme.of(context).colorScheme.secondary,
                      //   foregroundColor: errorColor,
                      //   // Theme.of(context).colorScheme.primary,
                      //   child: IconButton(
                      //     onPressed: () {},
                      //     icon: Icon(Icons.delete),
                      //   ),
                      // ),
                    ),
                  ],
                );
              },
            );
          } else if (state is ErrorServiceImagesState) {
            return Center(child: Text(state.message));
          } else if (state is LoadingServiceImagesState) {
            return Center(child: CircularProgressIndicator());
          } else {
            return SizedBox(
              height: 70,
              width: 90,
              child: Center(
                child: SvgPicture.asset(
                  "assets/logos/logo4.svg",
                  colorFilter: ColorFilter.mode(
                    Theme.of(context)
                        .colorScheme
                        .tertiary
                        .withValues(alpha: 0.7),
                    BlendMode.srcIn,
                  ),
                  height: 30,
                ),
              ),
            );
          }
        },
      ),
    );
  }
}
