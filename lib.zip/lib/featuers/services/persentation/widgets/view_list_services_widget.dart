import 'package:booking_v1/dependency_injection/initial.dart';
import 'package:booking_v1/featuers/services/persentation/bloc/services/services_bloc.dart';
import 'package:booking_v1/featuers/services/persentation/bloc/services/services_event.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../../../core/constants/strings.dart';
import '../../../../core/widgets/ciracle_loading_widget.dart';
import '../../../../core/widgets/container_widgets.dart';
import '../bloc/services/services_state.dart';
import 'view_service_widget.dart';

class ViewListServicesWidget extends StatelessWidget {
  final int categoryId;
  const ViewListServicesWidget({super.key, this.categoryId = 0});

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (context) => getIt<ServicesBloc>()
        ..add(GetAllServicesEvent(categoryId: categoryId)),
      child: BlocBuilder<ServicesBloc, ServicesState>(
        builder: (context, state) {
          if (state is LoadingServicesState) {
            return CiracleLoadingWidget();
          } else if (state is LoadedServicesState) {
            return CustomScrollView(
              slivers: [
                SliverPadding(
                  padding: const EdgeInsets.all(defaultPadding - 3),
                  sliver: SliverGrid(
                    gridDelegate:
                        const SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 2,
                      mainAxisSpacing: defaultPadding,
                      crossAxisSpacing: defaultPadding,
                      childAspectRatio: 0.7,
                    ),
                    delegate: SliverChildBuilderDelegate(
                      childCount: state.services
                          .length, // يمكن تغييره حسب البيانات القادمة من API
                      (context, index) {
                        final service = state.services[index];
                        return ViewServiceVertical(service: service);
                      },
                    ),
                  ),
                ),
              ],
            );
          } else if (state is ErrorServicesState) {
            return SecondaryContainer(
                child: Center(
              child: Text(state.message),
            ));
          } else {
            return CiracleLoadingWidget();
          }
        },
      ),
    );
  }
}
