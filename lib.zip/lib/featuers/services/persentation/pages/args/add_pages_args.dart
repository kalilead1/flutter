import '../../../domain/entities/service.dart';

// class AddUpdateServiceBaiscArgs {
//   final Service? service;
//   final bool isUpdateService;

//   AddUpdateServiceBaiscArgs({this.service, this.isUpdateService = false});
// }

class AddUpdateServiceArgs {
  final Service? service;
  final bool isUpdateService;

  AddUpdateServiceArgs({this.service, this.isUpdateService = false});
}

class AddUpdateServiceImagesArgs {
  final int? serviceId;
  final bool isUpdateService;

  AddUpdateServiceImagesArgs({this.serviceId, this.isUpdateService = false});
}
