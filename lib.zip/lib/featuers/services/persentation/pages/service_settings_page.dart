import 'package:booking_v1/core/constants/colors.dart';
import 'package:booking_v1/core/routing/app_routes.dart';
import 'package:booking_v1/core/routing/router_extensions.dart';
import 'package:booking_v1/core/widgets/ciracle_loading_widget.dart';
import 'package:booking_v1/core/widgets/container_widgets.dart';
import 'package:booking_v1/featuers/services/persentation/pages/args/add_pages_args.dart';
import 'package:booking_v1/tests/loading_test.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../../../core/constants/strings.dart';
import '../../../../dependency_injection/initial.dart';
import '../bloc/services/services_bloc.dart';
import '../bloc/services/services_event.dart';
import '../bloc/services/services_state.dart';
import '../widgets/view_primary_service_details_wighet.dart';
import '../widgets/view_image_service_widget.dart';

class ServiceSettingsPage extends StatelessWidget {
  final int serviceId;
  const ServiceSettingsPage({required this.serviceId, super.key});

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (context) => getIt<ServicesBloc>()
        ..addAndRemember(GetServiceByIdEvent(serviceId: serviceId)),
      child: Directionality(
        textDirection: TextDirection.rtl,
        child: Scaffold(
          appBar: AppBar(
            title: Text("تفاصيل خدمة"),
          ),
          body: BlocBuilder<ServicesBloc, ServicesState>(
            builder: (context, state) {
              if (state is LoadingServicesState) {
                return CiracleLoadingWidget();
              } else if (state is ErrorServicesState) {
                return Center(child: Text(state.message));
              } else if (state is LoadedServiceByIdState) {
                final service = state.service;
                return CustomRefresh(
                  onRefresh: () async {
                    BlocProvider.of<ServicesBloc>(context)
                        .add(RefreshGetServiceByIdEvent(serviceId: serviceId));
                  },
                  child: ListView(
                    // spacing: defaultSpacing,
                    children: [
                      ViewMultiImagesServiceWidget(serviceId: serviceId),
                      SizedBox(height: defaultSpacing),
                      Padding(
                        padding: const EdgeInsets.symmetric(
                            horizontal: defaultPadding),
                        child: PrimaryContainer(
                          paddingHorizontal: 5,
                          paddingVertical: 12,
                          child: ViewPrimaryServiceDetailsWighet(
                            serviceName: service.name!,
                            servicePrice: service.price!,
                            servicePeriod: service.duration!,
                            serviceNumberOfPeople: service.peopleCount!,
                          ),
                        ),
                      ),
                      SizedBox(height: defaultSpacing),
                      Padding(
                        padding: const EdgeInsets.symmetric(
                            horizontal: defaultPadding),
                        child: SecondaryContainer(
                          paddingHorizontal: 0,
                          paddingVertical: 5,
                          child: Column(
                            children: [
                              _listTile(
                                context: context,
                                icon: Icons.data_saver_off,
                                title: "حجوزات الخدمة",
                                onTap: () {
                                  context.pushTo(viewServiceBookingsRoute,
                                      extra: service.id);
                                  // context.pushTo(addUpdateServiceBaiscRoute,
                                  //     extra: AddUpdateServiceArgs(
                                  //       service: service,
                                  //       isUpdateService: true,
                                  //     ));
                                },
                              ),
                              _listTile(
                                context: context,
                                icon: Icons.data_saver_off,
                                title: "معلومات الخدمة الاساسية",
                                onTap: () {
                                  // context
                                  //     .read<AddUpdateDeleteServiceBloc>()
                                  //     .add(UpdateServiceEvent());
                                  context.pushTo(addUpdateServiceBaiscRoute,
                                      extra: AddUpdateServiceArgs(
                                        service: service,
                                        isUpdateService: true,
                                      ));
                                },
                              ),
                              _listTile(
                                context: context,
                                icon: Icons.data_saver_off,
                                title: "معلومات الخدمة العامة",
                                onTap: () {
                                  // context
                                  //     .read<AddUpdateDeleteServiceBloc>()
                                  //     .add(UpdateServiceEvent());
                                  context.pushTo(addUpdateServiceGloableRoute,
                                      extra: AddUpdateServiceArgs(
                                        isUpdateService: true,
                                        service: service,
                                      ));
                                },
                              ),
                              _listTile(
                                context: context,
                                icon: Icons.photo_library_outlined,
                                title: "صور الخدمة",
                                onTap: () {
                                  context.pushTo(updateServiceImageRoute,
                                      extra: serviceId);
                                },
                              ),
                            ],
                          ),
                        ),
                      ),
                      SizedBox(height: defaultSpacing),
                      Padding(
                        padding: const EdgeInsets.symmetric(
                            horizontal: defaultPadding),
                        child: Container(
                          decoration: BoxDecoration(
                            color: errorColor.withValues(alpha: 0.9),
                            border: Border.all(
                                color: errorColor.withValues(alpha: 0.9)),
                            borderRadius:
                                BorderRadius.circular(defaultBorderRadious),
                          ),
                          child: ListTile(
                            iconColor: Colors.white,
                            textColor: Colors.white,
                            leading: Icon(
                              Icons.delete_rounded,
                            ),
                            title: const Text(
                              "حذف الخدمة",
                              style: TextStyle(fontSize: 16),
                              // style: Theme.of(context).textTheme.titleMedium,
                            ),
                            trailing: const Icon(Icons.chevron_right),
                            onTap: () {},
                            splashColor: errorColor.withValues(alpha: 0.2),
                            dense: true,
                          ),
                        ),
                      ),
                    ],
                  ),
                );
              } else {
                return SizedBox();
              }
            },
          ),
        ),
      ),
    );
  }

  ListTile _listTile(
      {required BuildContext context,
      required IconData icon,
      required String title,
      required Function() onTap}) {
    return ListTile(
      leading: Icon(
        icon,
        color: Theme.of(context).colorScheme.primary,
      ),
      title: Text(
        title,
        style: Theme.of(context).textTheme.titleMedium,
      ),
      trailing: Icon(Icons.chevron_right),
      onTap: onTap,
      splashColor: Theme.of(context).colorScheme.primary.withOpacity(0.20),
      dense: true,
    );
  }
}
