import 'package:booking_v1/core/constants/strings.dart';
import 'package:booking_v1/core/routing/router_extensions.dart';
import 'package:booking_v1/core/widgets/bottom_items.dart';
import 'package:booking_v1/core/widgets/botton_widghts.dart';
import 'package:booking_v1/dependency_injection/initial.dart';
import 'package:booking_v1/featuers/services/persentation/bloc/services/services_bloc.dart';
import 'package:booking_v1/featuers/services/persentation/bloc/services/services_event.dart';
import 'package:booking_v1/featuers/services/persentation/bloc/services/services_state.dart';
import 'package:booking_v1/tests/loading_test.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../../../core/routing/app_routes.dart';
import '../../../../core/widgets/ciracle_loading_widget.dart';
import '../bloc/add_update_delete_service/add_update_delete_service_bloc.dart';
import '../bloc/add_update_delete_service/add_update_delete_service_event.dart';
import '../widgets/view_service_widget.dart';

class ServicesOwnerPage extends StatelessWidget {
  final int storeId;
  const ServicesOwnerPage({required this.storeId, super.key});

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (context) => getIt<ServicesBloc>()
        ..addAndRemember(GetServiceByStoreIdEvent(storeId: storeId)),
      child: Directionality(
        textDirection: TextDirection.rtl,
        child: Scaffold(
          appBar: AppBar(
            title: Text("الخدمات"),
          ),
          body: BlocBuilder<ServicesBloc, ServicesState>(
            builder: (context, state) {
              if (state is LoadingServicesState) {
                return CiracleLoadingWidget();
              } else if (state is ErrorServicesState) {
                return Center(
                  child: Text(state.message),
                );
              } else if (state is LoadedServicesState) {
                return CustomRefresh(
                  onRefresh: () async {
                    BlocProvider.of<ServicesBloc>(context)
                        .add(RefreshGetServiceByStoreIdEvent(storeId: storeId));
                  },
                  child: Padding(
                    padding: EdgeInsets.all(defaultPadding),
                    child: ListView.separated(
                      itemBuilder: (context, index) {
                        final service = state.services[index];
                        return GestureDetector(
                          onTap: () {
                            context.pushTo(serviceSettingRoute,
                                extra: service.id);
                          },
                          child:
                              ViewServiceHorizontalForOwner(service: service),
                        );
                      },
                      separatorBuilder: (context, index) {
                        return SizedBox(height: defaultSpacing);
                      },
                      itemCount: state.services.length,
                    ),
                  ),
                );
              } else {
                return CiracleLoadingWidget();
              }
            },
          ),
          bottomNavigationBar: TwoBottomItems(
            child1: PrimaryElevatedButton(
                onPressed: () {
                  // context.pushTo(addUpdateServiceBaiscRoute,
                  //     extra: AddUpdateServiceBaiscArgs(storeId: storeId));
                  BlocProvider.of<AddUpdateDeleteServiceBloc>(context)
                      .add(AddNewServiceEvent(storeId: storeId));
                },
                text: "اضافة خدمة"),
          ),
        ),
      ),
    );
  }
}
