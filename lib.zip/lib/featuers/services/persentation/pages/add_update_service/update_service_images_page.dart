import 'package:booking_v1/core/constants/rules.dart';
import 'package:booking_v1/core/routing/router_extensions.dart';
import 'package:booking_v1/core/widgets/snack_bar_widgets.dart';
import 'package:booking_v1/dependency_injection/initial.dart';
import 'package:booking_v1/featuers/services/persentation/bloc/service_images/service_images_event.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:go_router/go_router.dart';

import '../../../../../core/constants/api.dart';
import '../../../../../core/constants/strings.dart';
import '../../../../../core/widgets/bottom_items.dart';
import '../../../../../core/widgets/botton_widghts.dart';
import '../../../../../core/widgets/dialog_widgets.dart';
import '../../../../../core/widgets/custom_steps_add_widget.dart';
import '../../bloc/service_images/service_images_bloc.dart';
import '../../bloc/service_images/service_images_state.dart';
import '../../widgets/forms/add_images_form.dart';

class UpdateServiceImagesPage extends StatefulWidget {
  final int serviceId;
  const UpdateServiceImagesPage({
    super.key,
    required this.serviceId,
  });

  @override
  State<UpdateServiceImagesPage> createState() =>
      _UpdateServiceImagesPageState();
}

class _UpdateServiceImagesPageState extends State<UpdateServiceImagesPage> {
  late final ServiceImagesBloc _imagesBloc;
  int countImages = 0;
  @override
  void initState() {
    _imagesBloc = getIt<ServiceImagesBloc>();
    _imagesBloc
        .addAndRemember(GetAllServiceImagesEvent(serviceId: widget.serviceId));
    super.initState();
  }

  void validateFormThenAddOrUpdateService() {
    // if (_serviceImages.isNotEmpty) {
    //   context
    //       .read<AddUpdateDeleteServiceBloc>()
    //       .add(AddServiceImageEvent(serviceImage: _serviceImages));
    // }
  }
  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          title: Text("تعديل خدمة"),
        ),
        body: Padding(
          padding: const EdgeInsets.all(defaultPadding),
          child: Column(
            spacing: defaultSpacing,
            children: [
              Text(
                "صور الخدمة $countImages",
                style: Theme.of(context).textTheme.displayLarge,
              ),
              Row(
                spacing: 6,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  CustomContainerStepsAddWidget(),
                ],
              ),
              SizedBox(height: 10),
              SecondaryElevatedButton(
                onPressed: () {
                  addServiceImagesDialog(
                    context: context,
                    maxImages: maxImagesForService - countImages,
                    onSaved: (p0) {
                      setState(() {
                        _imagesBloc.add(AddServiceImagesEvent(
                            serviceImage: p0, serviceId: widget.serviceId));
                      });
                    },
                  );
                },
                text: "اضافة صور",
              ),
              BlocConsumer<ServiceImagesBloc, ServiceImagesState>(
                bloc: _imagesBloc,
                listener: (context, state) {
                  if (state is SuccessfulyServiceImagesState) {
                    return showSnackBarSuccess(
                        context: context, success: state.message);
                  } else if (state is ErrorServiceImagesState) {
                    if (state.message == deletedOperationFailureMessage) {
                      return showSnackBarError(
                          context: context,
                          error:
                              "${state.message}، يجب ان تحتوي خدمتك على اكثر $minImagesForService صور");
                    }
                  }
                },
                builder: (context, state) {
                  if (state is LoadingServiceImagesState) {
                    return Expanded(
                        child: Center(child: CircularProgressIndicator()));
                  } else if (state is ErrorServiceImagesState) {
                    if (state.message == emptyCacheFailureMessage) {
                      return Expanded(
                          child: Center(child: Text("لا يوجد صور لخدمتك")));
                    }
                    return Expanded(child: Center(child: Text(state.message)));
                  } else if (state is LoadedServiceImagesState) {
                    countImages = state.serviceImages.length;

                    return Expanded(
                      child: ListView.separated(
                        itemCount: state.serviceImages.length,
                        separatorBuilder: (context, index) {
                          return SizedBox(height: defaultSpacing);
                        },
                        itemBuilder: (context, index) {
                          final image = state.serviceImages[index];
                          return Stack(
                            children: [
                              Container(
                                height: 160,
                                width: MediaQuery.of(context).size.width,
                                decoration: BoxDecoration(
                                  color: Theme.of(context)
                                      .colorScheme
                                      .secondary
                                      .withOpacity(0.10),
                                  borderRadius: BorderRadius.circular(
                                      defaultBorderRadious),
                                  border: Border.all(
                                    color: Theme.of(context)
                                        .colorScheme
                                        .onPrimaryContainer,
                                  ),
                                  image: DecorationImage(
                                    image: NetworkImage(
                                        baseUrlServiceImagesFolder +
                                            image.image!),
                                    fit: BoxFit.cover,
                                  ),
                                ),
                              ),
                              // Text(countImages.toString())
                              Positioned(
                                right: 10,
                                top: 10,
                                child: InkWell(
                                  onTap: () {
                                    AppDialog.showCustomDialog(
                                      context: context,
                                      title: "حذف صورة",
                                      content: "هل انت متاكد من حذف الصورة؟",
                                      childAction: CancelElevatedButton(
                                          onPressed: () {
                                            _imagesBloc.add(
                                              DeleteServiceImageEvent(
                                                  imageId: image.id!,
                                                  serviceId: widget.serviceId),
                                            );
                                            // if (state.serviceImages.length <=
                                            //     2) {
                                            //   AppDialog.showErrorMessageDialog(
                                            //     context: context,
                                            //     title: "فشل حذف الصورة",
                                            //     content: "لا يمكنك حذف الصورة",

                                            //   );
                                            // }
                                            context.pop();
                                          },
                                          text: "نعم"),
                                    );
                                  },
                                  child: Container(
                                    decoration: BoxDecoration(
                                        color: Colors.redAccent
                                            .withValues(alpha: 0.8),
                                        shape: BoxShape.circle),
                                    child: Padding(
                                      padding: const EdgeInsets.all(4),
                                      child: const Icon(
                                        Icons.delete,
                                        color: Colors.white,
                                      ),
                                    ),
                                  ),
                                ),
                                // child: CircleAvatar(
                                //   backgroundColor:
                                //       Theme.of(context).colorScheme.secondary,
                                //   foregroundColor: errorColor,
                                //   // Theme.of(context).colorScheme.primary,
                                //   child: IconButton(
                                //     onPressed: () {},
                                //     icon: Icon(Icons.delete),
                                //   ),
                                // ),
                              ),
                            ],
                          );
                        },
                      ),
                    );
                  } else {
                    return Expanded(
                        child: Center(child: Text(unknownFailureMessage)));
                  }
                },
              ),
            ],
          ),
        ),
        bottomNavigationBar: TwoBottomItems(
          child1: SecondaryElevatedButton(
            onPressed: () {
              context.back();
            },
            text: "الغاء",
          ),
        ),
      ),
    );
  }
}
