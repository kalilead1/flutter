import 'package:booking_v1/core/routing/router_extensions.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../../../../core/constants/strings.dart';
import '../../../../../core/widgets/bottom_items.dart';
import '../../../../../core/widgets/botton_widghts.dart';
import '../../../../../core/widgets/ciracle_loading_widget.dart';
import '../../../../../core/widgets/snack_bar_widgets.dart';
import '../../../domain/entities/service.dart';
import '../../../../../core/widgets/custom_steps_add_widget.dart';
import '../../bloc/add_update_delete_service/add_update_delete_service_bloc.dart';
import '../../bloc/add_update_delete_service/add_update_delete_service_event.dart';
import '../../bloc/add_update_delete_service/add_update_delete_service_state.dart';
import '../../widgets/forms/service_gloable_info_form.dart';

class AddUpdateServiceGloableInfoPage extends StatefulWidget {
  final Service? service;
  final bool isUpdateService;
  const AddUpdateServiceGloableInfoPage(
      {super.key, this.service, required this.isUpdateService});

  @override
  State<AddUpdateServiceGloableInfoPage> createState() =>
      _AddUpdateServiceGloableInfoPageState();
}

class _AddUpdateServiceGloableInfoPageState
    extends State<AddUpdateServiceGloableInfoPage> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController _serviceDescriptionController =
      TextEditingController();
  final TextEditingController _serviceIncludedServicesController =
      TextEditingController();

  @override
  void initState() {
    if (widget.isUpdateService) {
      _serviceDescriptionController.text = widget.service!.description!;
      _serviceIncludedServicesController.text =
          widget.service!.includedServices!;
    } else {}
    super.initState();
  }

  void validateFormThenAddOrUpdateService() {
    final isValidateForm = _formKey.currentState!.validate();
    if (isValidateForm) {
      final service = Service(
        id: widget.isUpdateService ? widget.service!.id : 0,
        description: _serviceDescriptionController.text,
        includedServices: _serviceIncludedServicesController.text,
      );

      if (widget.isUpdateService) {
        context
            .read<AddUpdateDeleteServiceBloc>()
            .add(UpdateServiceGloableEvent(service: service));
      } else {
        // BlocProvider and use update service event
        context
            .read<AddUpdateDeleteServiceBloc>()
            .add(AddServiceGloableEvent(service: service));
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          title: Text(widget.isUpdateService ? "تعديل خدمة" : "اضافة خدمة"),
        ),
        body: BlocConsumer<AddUpdateDeleteServiceBloc,
            AddUpdateDeleteServiceState>(listener: (context, state) {
          if (state is SuccessfullyUpdateServiceState) {
            return showSnackBarSuccess(
                context: context, success: "تم التعديل بنجاح");
          } else if (state is ErrorUpdateServiceState) {
            return showSnackBarError(context: context, error: state.message);
          }
        }, builder: (context, state) {
          if (state is LoadingAddUpdateDeleteServiceState) {
            return CiracleLoadingWidget();
          }
          return SingleChildScrollView(
            child: Padding(
              padding: EdgeInsets.all(defaultPadding),
              child: Column(
                spacing: defaultSpacing,
                children: [
                  Text(
                    "معلومات الخدمة العامة",
                    style: Theme.of(context).textTheme.displayLarge,
                  ),
                  Row(
                    spacing: 6,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      widget.isUpdateService
                          ? SizedBox()
                          : CustomCircleStepsAddWidget(),
                      CustomContainerStepsAddWidget(),
                      widget.isUpdateService
                          ? SizedBox()
                          : CustomCircleStepsAddWidget(),
                      widget.isUpdateService
                          ? SizedBox()
                          : CustomCircleStepsAddWidget(),
                    ],
                  ),
                  SizedBox(height: 20),
                  ServiceGloableInfoForm(
                    formKey: _formKey,
                    serviceDescription: _serviceDescriptionController,
                    serviceIncludedServices: _serviceIncludedServicesController,
                  ),
                ],
              ),
            ),
          );
        }),
        bottomNavigationBar: TwoBottomItems(
          child1: PrimaryElevatedButton(
            onPressed: () {
              // showModalBottomSheet(context: context, builder: )
              validateFormThenAddOrUpdateService();
            },
            text: widget.isUpdateService ? "حفظ التعديل" : "حفظ",
          ),
          child2: SecondaryElevatedButton(
            onPressed: () {
              if (widget.isUpdateService) {
                context.back();
              } else {
                BlocProvider.of<AddUpdateDeleteServiceBloc>(context)
                    .add(CancelAddServiceEvent());
              }
            },
            text: "الغاء",
          ),
        ),
      ),
    );
  }
}
