import 'dart:io';

import 'package:booking_v1/core/routing/router_extensions.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../../../../core/constants/strings.dart';
import '../../../../../core/widgets/bottom_items.dart';
import '../../../../../core/widgets/botton_widghts.dart';
import '../../../../../core/widgets/custom_bottom_sheet_widget.dart';
import '../../../../../core/widgets/image_picker/widgets/image_uploader_widget.dart';
import '../../../../../core/widgets/custom_steps_add_widget.dart';
import '../../bloc/add_update_delete_service/add_update_delete_service_bloc.dart';
import '../../bloc/add_update_delete_service/add_update_delete_service_event.dart';
import '../../widgets/view_image_service_widget.dart';

class AddServiceImagesPage extends StatefulWidget {
  final int? serviceId;
  final bool isUpdateService;
  const AddServiceImagesPage({
    super.key,
    this.serviceId,
    required this.isUpdateService,
  });

  @override
  State<AddServiceImagesPage> createState() => _AddServiceImagesPageState();
}

class _AddServiceImagesPageState extends State<AddServiceImagesPage> {
  List<File> _serviceImages = [];

  @override
  void initState() {
    if (widget.isUpdateService) {
    } else {}
    super.initState();
  }

  void validateFormThenAddOrUpdateService() {
    if (widget.isUpdateService) {
    } else {
      if (_serviceImages.isNotEmpty) {
        context
            .read<AddUpdateDeleteServiceBloc>()
            .add(AddServiceImageEvent(serviceImage: _serviceImages));
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          title: Text(widget.isUpdateService ? "تعديل خدمة" : "اضافة خدمة"),
          actions: [
            widget.isUpdateService
                ? IconButton(
                    onPressed: () {
                      showModalBottomSheet(
                        constraints: BoxConstraints(
                          maxHeight: MediaQuery.of(context).size.height,
                        ),
                        context: context,
                        builder: (context) => CustomBottomSheetWidget(
                          appTitle: "اضافة صور جديدة للخدمة",
                          body: SizedBox(),
                        ),
                      );
                    },
                    icon: Icon(Icons.add_photo_alternate_outlined),
                  )
                : SizedBox()
          ],
        ),
        body: Padding(
          padding: const EdgeInsets.all(defaultPadding),
          child: Column(
            spacing: defaultSpacing,
            children: [
              Text(
                "صور الخدمة",
                style: Theme.of(context).textTheme.displayLarge,
              ),
              Row(
                spacing: 6,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  widget.isUpdateService
                      ? SizedBox()
                      : CustomCircleStepsAddWidget(),
                  widget.isUpdateService
                      ? SizedBox()
                      : CustomCircleStepsAddWidget(),
                  CustomContainerStepsAddWidget(),
                  widget.isUpdateService
                      ? SizedBox()
                      : CustomCircleStepsAddWidget(),
                ],
              ),
              SizedBox(height: 10),
              widget.isUpdateService
                  ? Expanded(
                      child: ViewSingleImageServiceForDeleteWidget(
                          serviceId: widget.serviceId!),
                    )
                  : ImageUploaderWidghet(
                      maxImages: 6,
                      onChanged: (value) {
                        setState(() {
                          _serviceImages = value;
                        });
                      },
                    ),
            ],
          ),
        ),
        bottomNavigationBar: TwoBottomItems(
          child1: PrimaryElevatedButton(
            onPressed: () {
              // showModalBottomSheet(context: context, builder: )
              validateFormThenAddOrUpdateService();
            },
            text: widget.isUpdateService ? "حفظ التعديل" : "اضافة",
          ),
          child2: SecondaryElevatedButton(
            onPressed: () {
              if (widget.isUpdateService) {
                context.back();
              } else {
                BlocProvider.of<AddUpdateDeleteServiceBloc>(context)
                    .add(CancelAddServiceEvent());
              }
            },
            text: "الغاء",
          ),
        ),
      ),
    );
  }
}
