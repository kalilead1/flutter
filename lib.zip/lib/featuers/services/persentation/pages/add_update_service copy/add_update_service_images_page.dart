import 'dart:io';

import 'package:booking_v1/core/routing/router_extensions.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../../../../core/constants/strings.dart';
import '../../../../../core/widgets/bottom_items.dart';
import '../../../../../core/widgets/botton_widghts.dart';
import '../../../../../core/widgets/dialog_widgets.dart';
import '../../../../../core/widgets/image_picker/widgets/image_uploader_widget.dart';
import '../../../domain/entities/service_image.dart';
import '../../../../../core/widgets/custom_steps_add_widget.dart';
import '../../bloc/add_update_delete_service/add_update_delete_service_bloc.dart';
import '../../bloc/add_update_delete_service/add_update_delete_service_event.dart';

class AddUpdateServiceImagesPage extends StatefulWidget {
  final List<ServiceImage>? serviceImages;
  final bool isUpdateService;
  const AddUpdateServiceImagesPage({
    super.key,
    required this.isUpdateService,
    this.serviceImages,
  });

  @override
  State<AddUpdateServiceImagesPage> createState() =>
      _AddUpdateServiceImagesPageState();
}

class _AddUpdateServiceImagesPageState
    extends State<AddUpdateServiceImagesPage> {
  List<File> _serviceImages = [];

  @override
  void initState() {
    if (widget.isUpdateService) {
    } else {}
    super.initState();
  }

  void validateFormThenAddOrUpdateService() {
    if (widget.isUpdateService) {
    } else {
      if (_serviceImages.isNotEmpty) {
        context
            .read<AddUpdateDeleteServiceBloc>()
            .add(AddServiceImageEvent(serviceImage: _serviceImages));
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          title: Text(widget.isUpdateService ? "تعديل خدمة" : "اضافة خدمة"),
        ),
        body: Padding(
          padding: const EdgeInsets.all(defaultPadding),
          child: Column(
            spacing: defaultSpacing,
            children: [
              Text(
                "صور الخدمة",
                style: Theme.of(context).textTheme.displayLarge,
              ),
              Row(
                spacing: 6,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  widget.isUpdateService
                      ? SizedBox()
                      : CustomCircleStepsAddWidget(),
                  widget.isUpdateService
                      ? SizedBox()
                      : CustomCircleStepsAddWidget(),
                  CustomContainerStepsAddWidget(),
                  widget.isUpdateService
                      ? SizedBox()
                      : CustomCircleStepsAddWidget(),
                ],
              ),
              SizedBox(height: 10),
              widget.isUpdateService
                  ? Expanded(
                      child: ListView.separated(
                        itemCount: 2,
                        itemBuilder: (context, index) {
                          return Stack(
                            children: [
                              // ViewSingleImageServiceWidget(),
                              Positioned(
                                right: 10,
                                top: 10,
                                child: InkWell(
                                  onTap: () {
                                    AppDialog.showCustomDialog(
                                        context: context,
                                        title: "حذف صورة",
                                        content: "هل انت متاكد من حذف الصورة؟",
                                        childAction: CancelElevatedButton(
                                            onPressed: () {}, text: "نعم"));
                                  },
                                  child: Container(
                                    decoration: BoxDecoration(
                                        color: Colors.redAccent
                                            .withValues(alpha: 0.8),
                                        shape: BoxShape.circle),
                                    child: Padding(
                                      padding: const EdgeInsets.all(4),
                                      child: const Icon(
                                        Icons.delete,
                                        color: Colors.white,
                                      ),
                                    ),
                                  ),
                                ),
                                // child: CircleAvatar(
                                //   backgroundColor:
                                //       Theme.of(context).colorScheme.secondary,
                                //   foregroundColor: errorColor,
                                //   // Theme.of(context).colorScheme.primary,
                                //   child: IconButton(
                                //     onPressed: () {},
                                //     icon: Icon(Icons.delete),
                                //   ),
                                // ),
                              ),
                            ],
                          );
                        },
                        separatorBuilder: (context, index) => SizedBox(
                          height: defaultSpacing,
                        ),
                      ),
                    )
                  : ImageUploaderWidghet(
                      maxImages: 6,
                      onChanged: (value) {
                        setState(() {
                          _serviceImages = value;
                        });
                      },
                    ),
            ],
          ),
        ),
        bottomNavigationBar: TwoBottomItems(
          child1: PrimaryElevatedButton(
            onPressed: () {
              // showModalBottomSheet(context: context, builder: )
              validateFormThenAddOrUpdateService();
            },
            text: widget.isUpdateService ? "حفظ التعديل" : "اضافة",
          ),
          child2: SecondaryElevatedButton(
            onPressed: () {
              if (widget.isUpdateService) {
                context.back();
              } else {
                BlocProvider.of<AddUpdateDeleteServiceBloc>(context)
                    .add(CancelAddServiceEvent());
              }
            },
            text: "الغاء",
          ),
        ),
      ),
    );
  }
}
