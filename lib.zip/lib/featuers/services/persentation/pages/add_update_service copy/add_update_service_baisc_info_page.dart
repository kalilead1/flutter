// import 'package:booking_v1/core/routing/router_extensions.dart';
// import 'package:flutter/material.dart';
// import 'package:flutter_bloc/flutter_bloc.dart';

// import '../../../../../core/constants/strings.dart';
// import '../../../../../core/widgets/bottom_items.dart';
// import '../../../../../core/widgets/botton_widghts.dart';
// import '../../../../../core/widgets/custom_steps_add_widget.dart';
// import '../../../domain/entities/service.dart';
// import '../../../../../core/widgets/input_widgets.dart';
// import '../../../domain/enums/duration_services_enum.dart';
// import '../../bloc/add_update_delete_service/add_update_delete_service_bloc.dart';
// import '../../bloc/add_update_delete_service/add_update_delete_service_event.dart';

// class AddUpdateServiceBaiscInfoPage extends StatefulWidget {
//   final int storeId;
//   final Service? service;
//   final bool isUpdateService;
//   const AddUpdateServiceBaiscInfoPage({
//     super.key,
//     required this.storeId,
//     required this.isUpdateService,
//     this.service,
//   });

//   @override
//   State<AddUpdateServiceBaiscInfoPage> createState() =>
//       _AddUpdateServiceBaiscInfoPageState();
// }

// class _AddUpdateServiceBaiscInfoPageState
//     extends State<AddUpdateServiceBaiscInfoPage> {
//   final _formKey = GlobalKey<FormState>();
//   final TextEditingController _serviceNameController = TextEditingController();
//   final TextEditingController _servicePriceController = TextEditingController();
//   final TextEditingController _serviceDurationController =
//       TextEditingController();
//   final TextEditingController _servicePeopleCountController =
//       TextEditingController();

//   @override
//   void initState() {
//     if (widget.isUpdateService) {
//       _serviceNameController.text = widget.service!.name!;
//       _servicePriceController.text = widget.service!.price!.toString();
//       _serviceDurationController.text = widget.service!.duration!;
//       _servicePeopleCountController.text =
//           widget.service!.peopleCount!.toString();
//     }
//     // else {
//     //   _serviceNameController.text = widget.service!.name!;
//     //   _servicePriceController.text = widget.service!.price!.toString();
//     //   _serviceDurationController.text = widget.service!.duration!;
//     //   _servicePeopleCountController.text =
//     //       widget.service!.peopleCount!.toString();
//     // }
//     super.initState();
//   }

//   void validateFormThenAddOrUpdateService() {
//     final isValidateForm = _formKey.currentState!.validate();
//     if (isValidateForm) {
//       final service = Service(
//         id: widget.isUpdateService ? widget.service!.id : 0,
//         name: _serviceNameController.text,
//         price: double.tryParse(_servicePriceController.text),
//         duration: _serviceDurationController.text,
//         peopleCount: int.tryParse(_servicePeopleCountController.text),
//       );

//       if (widget.isUpdateService) {
//         // BlocProvider and use update service event
//         showModalBottomSheet(
//           context: context,
//           builder: (context) => Padding(
//             padding: EdgeInsets.all(defaultPadding),
//             child: ListView(
//               children: [
//                 Text(service.id.toString()),
//                 Text(service.name!),
//                 Text(service.price.toString()),
//                 Text(service.duration!),
//                 Text(service.peopleCount.toString()),
//               ],
//             ),
//           ),
//         );
//       } else {
//         // BlocProvider and use update service event
//         context.read<AddUpdateDeleteServiceBloc>().add(AddServiceBasicInfoEvent(
//               name: service.name!,
//               price: service.price!,
//               peopleCount: service.peopleCount!,
//               duration: service.duration!,
//               storeId: widget.storeId,
//               userId: 1,
//             ));
//       }
//     }
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Directionality(
//       textDirection: TextDirection.rtl,
//       child: Scaffold(
//         appBar: AppBar(
//           title: Text(widget.isUpdateService ? "تعديل خدمة" : "اضافة خدمة"),
//         ),
//         body: SingleChildScrollView(
//           child: Padding(
//             padding: EdgeInsets.all(defaultPadding),
//             child: Form(
//               key: _formKey,
//               child: Column(
//                 spacing: defaultSpacing,
//                 children: [
//                   Text(
//                     "معلومات الخدمة الاساسية",
//                     style: Theme.of(context).textTheme.displayLarge,
//                   ),
//                   Row(
//                     spacing: 6,
//                     mainAxisAlignment: MainAxisAlignment.center,
//                     children: [
//                       CustomContainerStepsAddWidget(),
//                       widget.isUpdateService
//                           ? SizedBox()
//                           : CustomCircleStepsAddWidget(),
//                       widget.isUpdateService
//                           ? SizedBox()
//                           : CustomCircleStepsAddWidget(),
//                       widget.isUpdateService
//                           ? SizedBox()
//                           : CustomCircleStepsAddWidget(),
//                     ],
//                   ),
//                   SizedBox(height: 20),
//                   CustomInputFieldWidget(
//                     label: "اسم الخدمة",
//                     textController: _serviceNameController,
//                   ),
//                   CustomInputFieldWidget(
//                     label: "سعر الخدمة",
//                     textController: _servicePriceController,
//                     textInputType:
//                         TextInputType.numberWithOptions(decimal: true),
//                     suffix: Text("ر.ي"),
//                   ),
//                   CustomInputSeletctedWidget(
//                     list: durationServicesList,
//                     label: "مده الخدمة",
//                     textController: _serviceDurationController,
//                   ),
//                   CustomInputFieldWidget(
//                     label: "سعة الاشخاص",
//                     textController: _servicePeopleCountController,
//                     textInputType:
//                         TextInputType.numberWithOptions(decimal: true),
//                   ),
//                 ],
//               ),
//             ),
//           ),
//         ),
//         bottomNavigationBar: TwoBottomItems(
//           child1: PrimaryElevatedButton(
//             onPressed: () {
//               validateFormThenAddOrUpdateService();
//             },
//             text: widget.isUpdateService ? "حفظ التعديل" : "التالي",
//           ),
//           child2: SecondaryElevatedButton(
//             onPressed: () {
//               if (widget.isUpdateService) {
//                 context.back();
//               } else {
//                 BlocProvider.of<AddUpdateDeleteServiceBloc>(context)
//                     .add(CancelAddServiceEvent());
//               }
//             },
//             text: "الغاء",
//           ),
//         ),
//       ),
//     );
//   }
// }
