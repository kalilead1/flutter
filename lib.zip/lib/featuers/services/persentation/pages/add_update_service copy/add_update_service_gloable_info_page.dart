// import 'package:booking_v1/core/routing/router_extensions.dart';
// import 'package:flutter/material.dart';
// import 'package:flutter_bloc/flutter_bloc.dart';

// import '../../../../../core/constants/strings.dart';
// import '../../../../../core/widgets/bottom_items.dart';
// import '../../../../../core/widgets/botton_widghts.dart';
// import '../../../domain/entities/service.dart';
// import '../../../../../core/widgets/input_widgets.dart';
// import '../../../../../core/widgets/custom_steps_add_widget.dart';
// import '../../bloc/add_update_delete_service/add_update_delete_service_bloc.dart';
// import '../../bloc/add_update_delete_service/add_update_delete_service_event.dart';

// class AddUpdateServiceGloableInfoPage extends StatefulWidget {
//   final Service? service;
//   final bool isUpdateService;
//   const AddUpdateServiceGloableInfoPage(
//       {super.key, this.service, required this.isUpdateService});

//   @override
//   State<AddUpdateServiceGloableInfoPage> createState() =>
//       _AddUpdateServiceGloableInfoPageState();
// }

// class _AddUpdateServiceGloableInfoPageState
//     extends State<AddUpdateServiceGloableInfoPage> {
//   final _formKey = GlobalKey<FormState>();
//   final TextEditingController _serviceDescriptionController =
//       TextEditingController();
//   final TextEditingController _serviceIncludedServicesController =
//       TextEditingController();

//   @override
//   void initState() {
//     if (widget.isUpdateService) {
//       _serviceDescriptionController.text = widget.service!.description!;
//       _serviceIncludedServicesController.text =
//           widget.service!.includedServices!;
//     } else {}
//     super.initState();
//   }

//   void validateFormThenAddOrUpdateService() {
//     final isValidateForm = _formKey.currentState!.validate();
//     if (isValidateForm) {
//       final service = Service(
//         id: widget.isUpdateService ? widget.service!.id : 0,
//         description: _serviceDescriptionController.text,
//         includedServices: _serviceIncludedServicesController.text,
//       );

//       if (widget.isUpdateService) {
//         // BlocProvider and use update service event
//         showModalBottomSheet(
//           context: context,
//           builder: (context) => Padding(
//             padding: EdgeInsets.all(defaultPadding),
//             child: ListView(
//               children: [
//                 Text(service.id.toString()),
//                 Text(service.name!),
//                 Text(service.price.toString()),
//                 Text(service.duration!),
//                 Text(service.peopleCount.toString()),
//               ],
//             ),
//           ),
//         );
//       } else {
//         // BlocProvider and use update service event
//         context.read<AddUpdateDeleteServiceBloc>().add(AddServiceGloableEvent(
//               description: service.description!,
//               includedServices: service.includedServices!,
//             ));
//       }
//     }
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Directionality(
//       textDirection: TextDirection.rtl,
//       child: Scaffold(
//         appBar: AppBar(
//           title: Text(widget.isUpdateService ? "تعديل خدمة" : "اضافة خدمة"),
//         ),
//         body: SingleChildScrollView(
//           child: Padding(
//             padding: EdgeInsets.all(defaultPadding),
//             child: Form(
//               key: _formKey,
//               child: Column(
//                 spacing: defaultSpacing,
//                 children: [
//                   Text(
//                     "معلومات الخدمة العامة",
//                     style: Theme.of(context).textTheme.displayLarge,
//                   ),
//                   Row(
//                     spacing: 6,
//                     mainAxisAlignment: MainAxisAlignment.center,
//                     children: [
//                       widget.isUpdateService
//                           ? SizedBox()
//                           : CustomCircleStepsAddWidget(),
//                       CustomContainerStepsAddWidget(),
//                       widget.isUpdateService
//                           ? SizedBox()
//                           : CustomCircleStepsAddWidget(),
//                       widget.isUpdateService
//                           ? SizedBox()
//                           : CustomCircleStepsAddWidget(),
//                     ],
//                   ),
//                   SizedBox(height: 20),
//                   CustomInputFieldWidget(
//                     label: "وصف الخدمة",
//                     textController: _serviceDescriptionController,
//                     maxLength: 150,
//                     maxLines: 3,
//                     minLines: 1,
//                   ),
//                   CustomInputFieldWidget(
//                     label: "الخدمات المشمولة",
//                     textController: _serviceIncludedServicesController,
//                     maxLength: 200,
//                     minLines: 1,
//                   ),
//                 ],
//               ),
//             ),
//           ),
//         ),
//         bottomNavigationBar: TwoBottomItems(
//           child1: PrimaryElevatedButton(
//             onPressed: () {
//               // showModalBottomSheet(context: context, builder: )
//               validateFormThenAddOrUpdateService();
//             },
//             text: widget.isUpdateService ? "حفظ التعديل" : "حفظ",
//           ),
//           child2: SecondaryElevatedButton(
//             onPressed: () {
//               if (widget.isUpdateService) {
//                 context.back();
//               } else {
//                 BlocProvider.of<AddUpdateDeleteServiceBloc>(context)
//                     .add(CancelAddServiceEvent());
//               }
//             },
//             text: "الغاء",
//           ),
//         ),
//       ),
//     );
//   }
// }
