import 'package:booking_v1/featuers/services/persentation/bloc/add_update_delete_service/add_update_delete_service_bloc.dart';
import 'package:booking_v1/featuers/services/persentation/bloc/add_update_delete_service/add_update_delete_service_event.dart';
import 'package:booking_v1/featuers/services/persentation/bloc/add_update_delete_service/add_update_delete_service_state.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../../../../core/constants/strings.dart';
import '../../../../../core/widgets/bottom_items.dart';
import '../../../../../core/widgets/botton_widghts.dart';
import '../../../../../core/widgets/ciracle_loading_widget.dart';
import '../../../../../core/widgets/custom_steps_add_widget.dart';
import '../../../../../core/widgets/snack_bar_widgets.dart';

class ConfirmAddServicePage extends StatelessWidget {
  const ConfirmAddServicePage({super.key});

  @override
  Widget build(BuildContext context) {
    String? serviceName;
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: Text("اضافة خدمة")),
        body: Padding(
          padding: EdgeInsets.all(defaultPadding),
          child: BlocConsumer<AddUpdateDeleteServiceBloc,
              AddUpdateDeleteServiceState>(
            listener: (context, state) {
              if (state is SuccessfullyAddServiceState) {
                return showSnackBarSuccess(
                    context: context,
                    success: "تم اضافة خدمة باسم $serviceName بنجاح");
              } else if (state is ErrorAddServiceState) {
                return showSnackBarError(
                    context: context, error: state.message);
              }
            },
            builder: (context, state) {
              if (state is LoadingAddUpdateDeleteServiceState) {
                return CiracleLoadingWidget();
              } else if (state is EditingAddServiceState) {
                serviceName = state.name;
                return Column(
                  spacing: defaultSpacing,
                  children: [
                    Text(
                      "تاكيد انشاء خدمة",
                      style: Theme.of(context).textTheme.displayLarge,
                    ),
                    Row(
                      spacing: 6,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        CustomCircleStepsAddWidget(),
                        CustomCircleStepsAddWidget(),
                        CustomCircleStepsAddWidget(),
                        CustomContainerStepsAddWidget(),
                      ],
                    ),
                    SizedBox(height: 50),
                    Text(
                      "هل تريد انشاء خدمة باسم؟",
                      style: Theme.of(context).textTheme.bodyLarge,
                    ),
                    Text(
                      state.name ?? "non",
                      style: Theme.of(context).textTheme.titleLarge,
                    ),
                  ],
                );
              } else {
                return Center(
                  child: Text("nooon"),
                );
              }
            },
          ),
        ),
        bottomNavigationBar: TwoBottomItems(
          child1: PrimaryElevatedButton(
            onPressed: () {
              // context.read<AddStoreBloc>().add(SubmitStoreEvent());
              BlocProvider.of<AddUpdateDeleteServiceBloc>(context)
                  .add(SubmitAddServiceEvent());
              // Navigator.pushNamed(context, entryPointScreenRoute);
            },
            text: "انشاء",
          ),
          child2: SecondaryElevatedButton(
            onPressed: () {
              BlocProvider.of<AddUpdateDeleteServiceBloc>(context)
                  .add(CancelAddServiceEvent());
            },
            text: "الغاء",
          ),
        ),
      ),
    );
  }
}
