import 'package:booking_v1/core/constants/strings.dart';
import 'package:flutter/material.dart';

class AddSericePage extends StatelessWidget {
  const AddSericePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(),
      body: Padding(
        padding: const EdgeInsets.all(defaultPadding),
        child: Stepper(
          currentStep: 0,
          steps: [
            Step(title: Text("data1"), content: _widget()),
            Step(title: Text("data2"), content: _widget()),
            Step(title: Text("data3"), content: _widget()),
          ],
        ),
      ),
    );
  }

  Widget _widget() {
    return Column(
      children: [
        Container(
          height: 100,
          width: 300,
          color: Colors.red,
        ),
        Container(
          height: 100,
          width: 300,
          color: Colors.amber,
        ),
        Container(
          height: 100,
          width: 300,
          color: Colors.blueGrey,
        ),
      ],
    );
  }
}
