import 'package:booking_v1/core/constants/strings.dart';
import 'package:booking_v1/core/widgets/bottom_items.dart';
import 'package:booking_v1/core/widgets/botton_widghts.dart';
import 'package:booking_v1/core/widgets/container_widgets.dart';
import 'package:booking_v1/core/widgets/share_link_widget.dart';
import 'package:booking_v1/dependency_injection/initial.dart';
import 'package:booking_v1/featuers/bookings/persentation/bloc/bookings_command/bookings_command_event.dart';
import 'package:booking_v1/featuers/services/persentation/bloc/services/services_bloc.dart';
import 'package:booking_v1/featuers/services/persentation/bloc/services/services_event.dart';
import 'package:booking_v1/featuers/services/persentation/bloc/services/services_state.dart';
import 'package:booking_v1/featuers/services/persentation/widgets/service_details/tab_bar_service_details_widghet.dart';
import 'package:booking_v1/featuers/services/persentation/widgets/service_details/tab_bar_view_service_details_widghet.dart';
import 'package:booking_v1/featuers/services/persentation/widgets/view_primary_service_details_wighet.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../../../core/widgets/ciracle_loading_widget.dart';
import '../../../../tests/loading_test.dart';
import '../../../bookings/persentation/bloc/bookings_command/bookings_command_bloc.dart';
import '../../domain/entities/service.dart';
import '../widgets/view_image_service_widget.dart';

class ViewServiceDetailPage extends StatefulWidget {
  final int serviceId;
  const ViewServiceDetailPage({super.key, required this.serviceId});

  @override
  State<ViewServiceDetailPage> createState() => _ViewServiceDetailPageState();
}

class _ViewServiceDetailPageState extends State<ViewServiceDetailPage> {
  late double expandedHeight = 390;
  late double collapsedHeight = kToolbarHeight;
  Service? service;
  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: DefaultTabController(
        length: 3,
        child: Scaffold(
          body: BlocProvider(
            create: (context) => getIt<ServicesBloc>()
              ..addAndRemember(
                  GetServiceByIdEvent(serviceId: widget.serviceId)),
            child: BlocBuilder<ServicesBloc, ServicesState>(
              builder: (context, state) {
                if (state is LoadingServicesState) {
                  return CiracleLoadingWidget();
                } else if (state is LoadedServiceByIdState) {
                  service = state.service;
                  return CustomRefresh(
                    onRefresh: () async {
                      BlocProvider.of<ServicesBloc>(context).add(
                          RefreshGetServiceByIdEvent(
                              serviceId: widget.serviceId));
                    },
                    child: NestedScrollView(
                      headerSliverBuilder: (context, innerBoxIsScrolled) => [
                        SliverAppBar(
                          pinned: true,
                          // floating: true,
                          // snap: true,
                          // surfaceTintColor: Colors.blue,
                          expandedHeight: expandedHeight,
                          actions: [
                            IconButton(
                              onPressed: () {
                                ShareLink.shareService(service!.id!);
                              },
                              icon: Icon(Icons.share),
                            ),
                          ],
                          flexibleSpace: LayoutBuilder(
                            builder: (context, constraints) {
                              double currentHeight = constraints.biggest.height;

                              bool isCollapsed = currentHeight <= 100;
                              return FlexibleSpaceBar(
                                title: isCollapsed
                                    ? Text(
                                        service!.name.toString(),
                                        style: Theme.of(context)
                                            .textTheme
                                            .titleLarge,
                                      )
                                    : null,
                                collapseMode: CollapseMode.parallax,
                                background: Column(
                                  spacing: defaultSpacing,
                                  mainAxisAlignment: MainAxisAlignment.end,
                                  children: [
                                    ViewMultiImagesServiceWidget(
                                      serviceId: widget.serviceId,
                                    ),
                                    Padding(
                                      padding:
                                          const EdgeInsets.all(defaultPadding),
                                      child: PrimaryContainer(
                                        paddingHorizontal: 5,
                                        paddingVertical: 12,
                                        child: ViewPrimaryServiceDetailsWighet(
                                          serviceName: service!.name.toString(),
                                          servicePrice: service!.price!,
                                          serviceNumberOfPeople:
                                              service!.peopleCount!,
                                          servicePeriod:
                                              service!.duration.toString(),
                                        ),
                                      ),
                                    )
                                  ],
                                ),
                              );
                            },
                          ),
                        ),
                        SliverAppBar(
                          toolbarHeight: 10,
                          pinned: true,
                          flexibleSpace: Padding(
                            padding: const EdgeInsets.only(top: 8),
                            child: TabBarServiceDetailsWidghet(),
                          ),
                        ),
                      ],
                      body: TabBarViewServiceDetailsWidghet(
                        service: service!,
                        store: service!.store!,
                      ),
                    ),
                  );
                } else if (state is ErrorServicesState) {
                  return Center(child: Text(state.message));
                } else {
                  return SizedBox();
                }
              },
            ),
          ),
          bottomNavigationBar: SingleBottomItem(
            child: Row(
              spacing: defaultSpacing,
              children: [
                Expanded(
                  child: PrimaryElevatedButton(
                      onPressed: () {
                        context
                            .read<BookingsCommandBloc>()
                            .add(AddBookingOnlineEvent(service: service!));
                      },
                      text: "احجز الان"),
                ),
                TertiaryContainer(
                  paddingVertical: 0,
                  // paddingHorizontal: 0,
                  minWidth: 100,
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        "00,0 ر.ي",
                        style: TextStyle(
                            color: Theme.of(context).scaffoldBackgroundColor,
                            fontSize: 16,
                            fontWeight: FontWeight.bold),
                      ),
                      Text(
                        "العربون",
                        style: TextStyle(
                            color: Theme.of(context)
                                .scaffoldBackgroundColor
                                .withOpacity(0.7)),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
