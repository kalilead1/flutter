enum DurationServicesEnum {
  fullDay,
  halfDay,
}

const List<String> durationServicesList = [
  "يوم كامل",
  "الفترة الصباحية",
  "الفترة المسائية",
  "من 8 ص الى 2 م",
  "من 8 ص الى 8 م",
  "من 1 م الى 1 ص",
];
