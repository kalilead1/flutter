import 'package:booking_v1/featuers/services/domain/entities/service_image.dart';
import 'package:booking_v1/featuers/services/domain/repositories/service_images_repository.dart';
import 'package:dartz/dartz.dart';

import '../../../../../core/errors/failures.dart';

class GetAllServiceImagesByServiceIdUsecase {
  final ServiceImagesRepository repository;

  GetAllServiceImagesByServiceIdUsecase(this.repository);

  Future<Either<Failure, List<ServiceImage>>> call(int serviceId) async {
    return await repository.getAllServiceImagesByServiceId(serviceId);
  }
}

class GetServiceImageByIdUsecase {
  final ServiceImagesRepository repository;

  GetServiceImageByIdUsecase(this.repository);

  Future<Either<Failure, ServiceImage>> call(int id) async {
    return await repository.getServiceImageById(id);
  }
}

class AddServiceImageUsecase {
  final ServiceImagesRepository repository;

  AddServiceImageUsecase(this.repository);

  Future<Either<Failure, Unit>> call(
      ServiceImage serviceImage, int serviceId) async {
    return await repository.addServiceImage(serviceImage, serviceId);
  }
}

class DeleteServiceImageUsecase {
  final ServiceImagesRepository repository;

  DeleteServiceImageUsecase(this.repository);

  Future<Either<Failure, Unit>> call(int imageId, int serviceId) async {
    return await repository.deleteServiceImage(imageId, serviceId);
  }
}
