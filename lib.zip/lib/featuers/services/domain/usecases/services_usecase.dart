import 'package:dartz/dartz.dart';

import '../../../../../core/errors/failures.dart';
import '../entities/service.dart';
import '../repositories/services_repository.dart';

class GetAllServicesUsecase {
  final ServicesRepository repository;

  GetAllServicesUsecase(this.repository);

  Future<Either<Failure, List<Service>>> call(int? categoryId) async {
    return await repository.getAllServices(categoryId);
  }
}

class GetServiceByStoreIdUsecase {
  final ServicesRepository repository;

  const GetServiceByStoreIdUsecase(this.repository);

  Future<Either<Failure, List<Service>>> call(int storeId) async {
    return await repository.getServiceByStoreId(storeId);
  }
}

class GetServiceByIdUsecase {
  final ServicesRepository repository;

  GetServiceByIdUsecase(this.repository);

  Future<Either<Failure, Service>> call(int id) async {
    return await repository.getServiceById(id);
  }
}

class AddServiceUsecase {
  final ServicesRepository repository;

  AddServiceUsecase(this.repository);

  Future<Either<Failure, int>> call(Service service) async {
    return await repository.addService(service);
  }
}

class UpdateServiceBaiscInfoUsecase {
  final ServicesRepository repository;

  UpdateServiceBaiscInfoUsecase(this.repository);

  Future<Either<Failure, Unit>> call(int id, Service service) async {
    return await repository.updateServiceBaiscInfo(id, service);
  }
}

class UpdateServiceGloableInfoUsecase {
  final ServicesRepository repository;

  UpdateServiceGloableInfoUsecase(this.repository);

  Future<Either<Failure, Unit>> call(int id, Service service) async {
    return await repository.updateServiceGloableInfo(id, service);
  }
}
