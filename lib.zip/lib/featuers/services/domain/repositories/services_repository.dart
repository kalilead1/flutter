import 'package:booking_v1/featuers/services/domain/entities/service.dart';
import 'package:dartz/dartz.dart';

import '../../../../core/errors/failures.dart';

abstract class ServicesRepository {
  Future<Either<Failure, List<Service>>> getAllServices(int? categoryId);
  Future<Either<Failure, List<Service>>> getServiceByStoreId(int storeId);
  Future<Either<Failure, Service>> getServiceById(int id);
  Future<Either<Failure, int>> addService(Service service);
  Future<Either<Failure, Unit>> updateServiceBaiscInfo(int id, Service service);
  Future<Either<Failure, Unit>> updateServiceGloableInfo(
      int id, Service service);
  // Future<Either<Failure, Unit>> deleteService(int id);
}
