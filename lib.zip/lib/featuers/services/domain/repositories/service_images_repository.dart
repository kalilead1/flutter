import 'package:booking_v1/featuers/services/domain/entities/service_image.dart';
import 'package:dartz/dartz.dart';

import '../../../../core/errors/failures.dart';

abstract class ServiceImagesRepository {
  Future<Either<Failure, List<ServiceImage>>> getAllServiceImagesByServiceId(
      int serviceId);
  Future<Either<Failure, ServiceImage>> getServiceImageById(int id);
  Future<Either<Failure, Unit>> addServiceImage(
      ServiceImage serviceImage, int serviceId);
  Future<Either<Failure, Unit>> deleteServiceImage(int imageId, int serviceId);
  // Future<Either<Failure, Unit>> updateService(int id, Service service);
}
