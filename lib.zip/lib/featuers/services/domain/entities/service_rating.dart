import 'package:equatable/equatable.dart';

import '../../../auth/domain/entities/user.dart';
import 'service.dart';

class ServiceRating extends Equatable {
  final int? id;
  final int? serviceId;
  final Service? service;
  final int? userId;
  final User? user;
  final int? ratingValue;
  final String? comment;

  const ServiceRating({
    this.id,
    this.serviceId,
    this.service,
    this.userId,
    this.user,
    this.ratingValue,
    this.comment,
  });

  @override
  List<Object?> get props =>
      [id, serviceId, service, userId, user, ratingValue, comment];
}
