import 'package:equatable/equatable.dart';

import 'service.dart';

class ServiceImage extends Equatable {
  final int? id;
  final int? serviceId;
  final Service? service;
  final String? image;

  const ServiceImage({
    this.id,
    this.serviceId,
    this.service,
    this.image,
  });

  @override
  List<Object?> get props => [id, serviceId, service, image];
}
