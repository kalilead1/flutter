import 'package:equatable/equatable.dart';

import '../../../stores/domain/entities/store.dart';

class Service extends Equatable {
  final int? id;
  final String? name;
  final double? price;
  final String? duration;
  final int? peopleCount;
  final int? storeId;
  final Store? store;
  final String? description;
  final String? includedServices;
  final int? userId;

  const Service({
    this.id,
    this.name,
    this.price,
    this.duration,
    this.peopleCount,
    this.storeId,
    this.store,
    this.description,
    this.includedServices,
    this.userId,
  });

  @override
  List<Object?> get props => [
        id,
        name,
        price,
        duration,
        peopleCount,
        storeId,
        store,
        description,
        includedServices,
        userId,
      ];
}
