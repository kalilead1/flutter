import 'package:booking_v1/core/constants/rules.dart';
import 'package:booking_v1/core/errors/exception.dart';
import 'package:booking_v1/core/errors/failures.dart';
import 'package:booking_v1/core/network/network_info.dart';
import 'package:booking_v1/featuers/services/data/datasources/service_images_remote_data_source.dart';
import 'package:booking_v1/featuers/services/data/models/service_image_model.dart';
import 'package:booking_v1/featuers/services/domain/entities/service_image.dart';
import 'package:booking_v1/featuers/services/domain/repositories/service_images_repository.dart';
import 'package:dartz/dartz.dart';

class ServiceImagesRepositoryImpl implements ServiceImagesRepository {
  final ServiceImagesRemoteDataSource serviceImagesRemoteDataSource;
  final NetworkInfo networkInfo;

  ServiceImagesRepositoryImpl({
    required this.serviceImagesRemoteDataSource,
    required this.networkInfo,
  });

  @override
  Future<Either<Failure, List<ServiceImage>>> getAllServiceImagesByServiceId(
      int serviceId) async {
    try {
      final remoteServiceImage = await serviceImagesRemoteDataSource
          .getAllServiceImagesByServiceId(serviceId);
      if (remoteServiceImage.isEmpty) {
        return Left(EmptyCacheFailure());
      } else {
        return Right(remoteServiceImage);
      }
    } on ServerException {
      return Left(ServerFailure());
    }

    // if (await networkInfo.isConnected) {
    //   try {
    //     final remoteServiceImage =
    //         await serviceImagesRemoteDataSource.getAllServiceImages();
    //     if (remoteServiceImage.isEmpty) {
    //       return Left(EmptyCacheFailure());
    //     } else {
    //       return Right(remoteServiceImage);
    //     }
    //   } on ServerException {
    //     return Left(ServerFailure());
    //   }
    // } else {
    //   return Left(OfflineFailure());
    // }
  }

  @override
  Future<Either<Failure, ServiceImage>> getServiceImageById(int id) async {
    try {
      final remoteServiceImage =
          await serviceImagesRemoteDataSource.getServiceImageById(id);
      if (remoteServiceImage.props.isEmpty) {
        return Left(EmptyCacheFailure());
      } else {
        return Right(remoteServiceImage);
      }
    } on ServerException {
      return Left(ServerFailure());
    }

    // if (await networkInfo.isConnected) {
    //   try {
    //     final remoteServiceImage =
    //         await serviceImagesRemoteDataSource.getServiceImageById(id);
    //     if (remoteServiceImage.props.isEmpty) {
    //       return Left(EmptyCacheFailure());
    //     } else {
    //       return Right(remoteServiceImage);
    //     }
    //   } on ServerException {
    //     return Left(ServerFailure());
    //   }
    // } else {
    //   return Left(OfflineFailure());
    // }
  }

  @override
  Future<Either<Failure, Unit>> addServiceImage(
      ServiceImage serviceImage, int serviceId) async {
    final allImages = await serviceImagesRemoteDataSource
        .getAllServiceImagesByServiceId(serviceId);

    if (allImages.length <= maxImagesForService) {
      try {
        final data = ServiceImageModel(
          id: 0,
          serviceId: serviceImage.serviceId,
          image: serviceImage.image,
        );
        final remoteServiceImage =
            await serviceImagesRemoteDataSource.addServiceImage(data);
        return Right(remoteServiceImage);
      } on ServerException {
        return Left(ServerFailure());
      }
    } else {
      return Left(AddedOperationFailure());
    }
  }

  @override
  Future<Either<Failure, Unit>> deleteServiceImage(
      int imageId, int serviceId) async {
    // التحقق من وجود صور للمتجر
    // لا يمكن حذف الصورة اذا كانت اقل من 1
    final allImages = await serviceImagesRemoteDataSource
        .getAllServiceImagesByServiceId(serviceId);

    if (allImages.length >= minImagesForService) {
      try {
        final remoteStoreDocument =
            await serviceImagesRemoteDataSource.deleteServiceImage(imageId);
        return Right(remoteStoreDocument);
      } on ServerException {
        return Left(ServerFailure());
      }
    } else {
      return Left(DeletedOperationFailure());
    }
  }
}
