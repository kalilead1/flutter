import 'package:booking_v1/core/errors/exception.dart';
import 'package:booking_v1/core/errors/failures.dart';
import 'package:booking_v1/core/network/network_info.dart';
import 'package:booking_v1/featuers/services/data/datasources/services_remote_data_source.dart';
import 'package:booking_v1/featuers/services/data/models/service_model.dart';
import 'package:booking_v1/featuers/services/domain/entities/service.dart';
import 'package:booking_v1/featuers/services/domain/repositories/services_repository.dart';
import 'package:dartz/dartz.dart';

class ServicesRepositoryImpl implements ServicesRepository {
  final ServicesRemoteDataSource servicesRemoteDataSource;
  final NetworkInfo networkInfo;

  ServicesRepositoryImpl({
    required this.servicesRemoteDataSource,
    required this.networkInfo,
  });

  @override
  Future<Either<Failure, List<Service>>> getAllServices(int? categoryId) async {
    // if (await networkInfo.isConnected) {
    try {
      final remoteService =
          await servicesRemoteDataSource.getAllServices(categoryId);
      // return Right(remoteWallet);
      if (remoteService.isEmpty) {
        return Left(EmptyCacheFailure());
      } else {
        return Right(remoteService);
      }
    } on ServerException {
      return Left(ServerFailure());
    }
    // } else {
    //   return Left(OfflineFailure());
    // }
  }

  @override
  Future<Either<Failure, Service>> getServiceById(int id) async {
    // if (await networkInfo.isConnected) {
    try {
      final remoteService = await servicesRemoteDataSource.getServiceById(id);
      if (remoteService.props.isEmpty) {
        return Left(EmptyCacheFailure());
      } else {
        return Right(remoteService);
      }
    } on ServerException {
      return Left(ServerFailure());
    }
    // } else {
    //   return Left(OfflineFailure());
    // }
  }

  @override
  Future<Either<Failure, List<Service>>> getServiceByStoreId(
      int storeId) async {
    // if (await networkInfo.isConnected) {
    try {
      final remoteService =
          await servicesRemoteDataSource.getServiceByStoreId(storeId);
      if (remoteService.isEmpty) {
        return Left(EmptyCacheFailure());
      } else {
        return Right(remoteService);
      }
    } on ServerException {
      return Left(ServerFailure());
    }
    // } else {
    //   return Left(OfflineFailure());
    // }
  }

  @override
  Future<Either<Failure, int>> addService(Service service) async {
    try {
      final data = ServiceModel(
        id: 0,
        name: service.name,
        price: service.price,
        duration: service.duration,
        peopleCount: service.peopleCount,
        storeId: service.storeId,
        description: service.description,
        includedServices: service.includedServices,
        userId: service.userId,
      );
      final remoteStore = await servicesRemoteDataSource.addService(data);
      return Right(remoteStore);
    } on ServerException {
      return Left(ServerFailure());
    }
  }

  @override
  Future<Either<Failure, Unit>> updateServiceBaiscInfo(
      int id, Service service) async {
    try {
      final data = ServiceModel(
        id: id,
        name: service.name,
        price: service.price,
        duration: service.duration,
        peopleCount: service.peopleCount,
      );
      final remoteStore =
          await servicesRemoteDataSource.updateService(id, data);
      return Right(remoteStore);
    } on ServerException {
      return Left(ServerFailure());
    }
  }

  @override
  Future<Either<Failure, Unit>> updateServiceGloableInfo(
      int id, Service service) async {
    try {
      final data = ServiceModel(
        id: id,
        description: service.description,
        includedServices: service.includedServices,
      );
      final remoteStore =
          await servicesRemoteDataSource.updateService(id, data);
      return Right(remoteStore);
    } on ServerException {
      return Left(ServerFailure());
    }
  }
}
