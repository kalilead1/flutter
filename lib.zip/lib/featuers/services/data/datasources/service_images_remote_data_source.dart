import 'dart:convert';

import 'package:booking_v1/core/constants/api.dart';
import 'package:booking_v1/core/errors/exception.dart';
import 'package:booking_v1/featuers/services/data/models/service_image_model.dart';
import 'package:booking_v1/featuers/services/domain/entities/service_image.dart';
import 'package:dartz/dartz.dart';
import 'package:http/http.dart' as http;

abstract class ServiceImagesRemoteDataSource {
  Future<List<ServiceImage>> getAllServiceImagesByServiceId(int serviceId);
  Future<ServiceImage> getServiceImageById(int id);
  Future<Unit> addServiceImage(ServiceImageModel serviceImageModel);
  Future<Unit> deleteServiceImage(int id);
  // Future<Unit> updateService(int id, Service service);
}

const String serviceImageUrl = "ServiceImages/";

class ServiceImagesRemoteDataSourceImpl
    implements ServiceImagesRemoteDataSource {
  final http.Client client;

  ServiceImagesRemoteDataSourceImpl({required this.client});

  @override
  Future<List<ServiceImage>> getAllServiceImagesByServiceId(
      int serviceId) async {
    final String url = "GetServiceImageByServiceId/";
    final response = await client.get(
      Uri.parse(baseUrl + serviceImageUrl + url + serviceId.toString()),
    );
    if (response.statusCode == 200) {
      List jsonResponse = json.decode(response.body);
      return jsonResponse
          .map((get) => ServiceImageModel.fromJson(get))
          .toList();
    } else {
      throw ServerException();
    }
  }

  @override
  Future<ServiceImage> getServiceImageById(int id) async {
    final response =
        await client.get(Uri.parse(baseUrl + serviceImageUrl + id.toString()));
    if (response.statusCode == 200) {
      return ServiceImageModel.fromJson(json.decode(response.body));
    } else {
      throw ServerException();
    }
  }

  @override
  Future<Unit> addServiceImage(ServiceImageModel serviceImageModel) async {
    var request =
        http.MultipartRequest('POST', Uri.parse(baseUrl + serviceImageUrl));
    request.fields['serviceId'] = serviceImageModel.serviceId.toString();

    if (serviceImageModel.image != null) {
      request.files.add(
          await http.MultipartFile.fromPath("image", serviceImageModel.image!));
    }

    final response = await request.send();
    if (response.statusCode == 200 || response.statusCode == 201) {
      return Future.value(unit);
    } else {
      throw ServerException();
    }
  }

  @override
  Future<Unit> deleteServiceImage(int id) async {
    final imageId = "$id/";
    final response = await client.delete(
        Uri.parse(baseUrl + serviceImageUrl + imageId),
        headers: {"Content-Type": "application/json"});
    if (response.statusCode == 201 || response.statusCode == 204) {
      return Future.value(unit);
    } else {
      throw ServerException();
    }
  }
}
