import 'dart:convert';

import 'package:dartz/dartz.dart';
import 'package:http/http.dart' as http;

import '../../../../core/constants/api.dart';
import '../../../../core/errors/exception.dart';
import '../../domain/entities/service.dart';
import '../models/service_model.dart';

abstract class ServicesRemoteDataSource {
  Future<List<Service>> getAllServices(int? categoryId);
  Future<List<Service>> getServiceByStoreId(int storeId);
  Future<Service> getServiceById(int id);
  Future<int> addService(ServiceModel serviceModel);
  Future<Unit> updateService(int id, ServiceModel serviceModel);
  // Future<Unit> updateServiceBaiscInfo(int id, ServiceModel serviceModel);
  // Future<Unit> updateServiceGloableInfo(int id, ServiceModel serviceModel);
  // Future<Unit> deleteService(int id);
}

const String serviceUrl = "Services/";

class ServicesRemoteDataSourceImpl implements ServicesRemoteDataSource {
  final http.Client client;

  ServicesRemoteDataSourceImpl({required this.client});

  @override
  Future<List<Service>> getAllServices(int? categoryId) async {
    final String url = "ByCategoryId/${categoryId ?? 0}";
    final response = await client.get(Uri.parse(baseUrl + serviceUrl + url));
    if (response.statusCode == 200) {
      List jsonResponse = json.decode(response.body);
      return jsonResponse.map((get) => ServiceModel.fromJson(get)).toList();
    } else {
      throw ServerException();
    }
  }

  @override
  Future<List<Service>> getServiceByStoreId(int storeId) async {
    final String url = "GetServiceByStoreId/";
    final response = await client.get(
      Uri.parse(baseUrl + serviceUrl + url + storeId.toString()),
    );
    if (response.statusCode == 200) {
      List jsonResponse = json.decode(response.body);
      return jsonResponse.map((get) => ServiceModel.fromJson(get)).toList();
    } else {
      throw ServerException();
    }
  }

  @override
  Future<Service> getServiceById(int id) async {
    final response =
        await client.get(Uri.parse(baseUrl + serviceUrl + id.toString()));
    if (response.statusCode == 200) {
      return ServiceModel.fromJson(json.decode(response.body));
    } else {
      throw ServerException();
    }
  }

  @override
  Future<int> addService(ServiceModel serviceModel) async {
    final data = jsonEncode(serviceModel.toJson());
    final response = await client.post(Uri.parse(baseUrl + serviceUrl),
        headers: {"Content-Type": "application/json"}, body: data);
    if (response.statusCode == 201 || response.statusCode == 200) {
      final responseBody = response.body;
      final data = json.decode(responseBody);
      return data['id'];
    } else {
      throw ServerException();
    }
  }

  @override
  Future<Unit> updateService(int id, ServiceModel serviceModel) async {
    final String url = id.toString();
    final data = jsonEncode(serviceModel.toJson());
    final response = await client.patch(Uri.parse(baseUrl + serviceUrl + url),
        headers: {"Content-Type": "application/json"}, body: data);
    if (response.statusCode == 204 || response.statusCode == 200) {
      return Future.value(unit);
    } else {
      throw ServerException();
    }
  }

  // @override
  // Future<Unit> deleteService(int id) async {
  //   final String url = id.toString();
  //   final response = await client.delete(Uri.parse(baseUrl + serviceUrl + url),
  //       headers: {"Content-Type": "application/json"});
  //   if (response.statusCode == 201 || response.statusCode == 200) {
  //     return Future.value(unit);
  //   } else {
  //     throw ServerException();
  //   }
  // }
}
