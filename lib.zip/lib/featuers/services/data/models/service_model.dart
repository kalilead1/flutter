import 'package:booking_v1/featuers/services/domain/entities/service.dart';

import '../../../stores/data/models/store_model.dart';

class ServiceModel extends Service {
  const ServiceModel({
    super.id,
    super.name,
    super.price,
    super.duration,
    super.peopleCount,
    super.storeId,
    super.store,
    super.description,
    super.includedServices,
    super.userId,
  });

  factory ServiceModel.fromJson(Map<String, dynamic> json) {
    return ServiceModel(
      id: json['id'],
      name: json['name'],
      price: json['price'],
      duration: json['duration'],
      peopleCount: json['peopleCount'],
      storeId: json['storeId'],
      store: json['store'] != null ? StoreModel.fromJson(json['store']) : null,
      description: json['description'],
      includedServices: json['includedServices'],
      userId: json['userId'],
    );
  }
  Map<String, dynamic> toJson() => {
        "id": id,
        'name': name,
        'price': price,
        'duration': duration,
        'peopleCount': peopleCount,
        'storeId': storeId,
        'description': description,
        'includedServices': includedServices,
        'userId': userId,
      };
}
