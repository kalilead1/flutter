import 'package:booking_v1/featuers/services/domain/entities/service_image.dart';

import 'service_model.dart';

class ServiceImageModel extends ServiceImage {
  const ServiceImageModel({
    super.id,
    super.serviceId,
    super.service,
    super.image,
  });

  factory ServiceImageModel.fromJson(Map<String, dynamic> json) {
    return ServiceImageModel(
      id: json['id'],
      serviceId: json['serviceId'],
      service: json['service'] != null
          ? ServiceModel.fromJson(json['service'])
          : null,
      image: json['image'],
    );
  }
}
