import 'package:booking_v1/featuers/services/domain/entities/service_rating.dart';

import 'service_model.dart';

class ServiceRatingModel extends ServiceRating {
  const ServiceRatingModel({
    super.id,
    super.serviceId,
    super.service,
    super.userId,
    super.user,
    super.ratingValue,
    super.comment,
  });

  factory ServiceRatingModel.fromJson(Map<String, dynamic> json) {
    return ServiceRatingModel(
      id: json['id'],
      serviceId: json['serviceId'],
      service: json['service'] != null
          ? ServiceModel.fromJson(json['service'])
          : null,
      userId: json['userId'],
      // user: json['user']!= null
      //     ? UserModel.fromJson(json['user'])
      //     : null,
      ratingValue: json['ratingValue'],
      comment: json['comment'],
    );
  }
}
