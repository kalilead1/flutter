import 'package:booking_v1/featuers/bookings/domain/enums/bookings_statues_enum.dart';
import 'package:flutter/material.dart';

import 'view_list_bookings_widget.dart';

class TabBarViewBookingsStatuesWighets extends StatelessWidget {
  final int? userId;
  final int? storeId;
  final int? serviceId;
  const TabBarViewBookingsStatuesWighets({
    super.key,
    this.userId,
    this.storeId,
    this.serviceId,
  });

  @override
  Widget build(BuildContext context) {
    return TabBarView(
      children: [
        if (userId != null) ...[
          ViewListUserBookingsWidget(userId: userId!),
          ViewListUserBookingsWidget(
              userId: userId!,
              bookingsState: BookingsStatuesEnum.pendingPayment),
          ViewListUserBookingsWidget(
              userId: userId!, bookingsState: BookingsStatuesEnum.perliminary),
          ViewListUserBookingsWidget(
              userId: userId!, bookingsState: BookingsStatuesEnum.confirmed),
          ViewListUserBookingsWidget(
              userId: userId!, bookingsState: BookingsStatuesEnum.cancelled),
          ViewListUserBookingsWidget(
              userId: userId!, bookingsState: BookingsStatuesEnum.rejected),
          ViewListUserBookingsWidget(
              userId: userId!, bookingsState: BookingsStatuesEnum.completed),
        ] else if (storeId != null) ...[
          ViewListStoreBookingsWidget(storeId: storeId!),
          ViewListStoreBookingsWidget(
              storeId: storeId!,
              bookingsState: BookingsStatuesEnum.pendingPayment),
          ViewListStoreBookingsWidget(
              storeId: storeId!,
              bookingsState: BookingsStatuesEnum.perliminary),
          ViewListStoreBookingsWidget(
              storeId: storeId!, bookingsState: BookingsStatuesEnum.confirmed),
          ViewListStoreBookingsWidget(
              storeId: storeId!, bookingsState: BookingsStatuesEnum.cancelled),
          ViewListStoreBookingsWidget(
              storeId: storeId!, bookingsState: BookingsStatuesEnum.rejected),
          ViewListStoreBookingsWidget(
              storeId: storeId!, bookingsState: BookingsStatuesEnum.completed),
        ] else if (serviceId != null) ...[
          ViewListServiceBookingsWidget(serviceId: serviceId!),
          ViewListServiceBookingsWidget(
              serviceId: serviceId!,
              bookingsState: BookingsStatuesEnum.pendingPayment),
          ViewListServiceBookingsWidget(
              serviceId: serviceId!,
              bookingsState: BookingsStatuesEnum.perliminary),
          ViewListServiceBookingsWidget(
              serviceId: serviceId!,
              bookingsState: BookingsStatuesEnum.confirmed),
          ViewListServiceBookingsWidget(
              serviceId: serviceId!,
              bookingsState: BookingsStatuesEnum.cancelled),
          ViewListServiceBookingsWidget(
              serviceId: serviceId!,
              bookingsState: BookingsStatuesEnum.rejected),
          ViewListServiceBookingsWidget(
              serviceId: serviceId!,
              bookingsState: BookingsStatuesEnum.completed),
        ]

        // Center(child: Text("التحقق من الدفع", style: TextStyle(fontSize: 16))),
        // Center(child: Text("حجز مبدئي", style: TextStyle(fontSize: 16))),
        // Center(child: Text("حجز نهائي", style: TextStyle(fontSize: 16))),
        // Center(child: Text("حجز ملغي", style: TextStyle(fontSize: 16))),
        // Center(child: Text("حجز مرفوض", style: TextStyle(fontSize: 16))),
        // Center(child: Text("حجز منتهي", style: TextStyle(fontSize: 16))),
      ],
    );
  }
}
