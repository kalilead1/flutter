import 'package:booking_v1/core/constants/strings.dart';
import 'package:booking_v1/featuers/bookings/domain/enums/bookings_statues_enum.dart';
import 'package:flutter/material.dart';

class ViewSmallBookingStateWidget extends StatelessWidget {
  final BookingsStatuesEnum bookingsState;
  const ViewSmallBookingStateWidget({required this.bookingsState, super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding:
          EdgeInsets.symmetric(horizontal: defaultPadding / 3, vertical: 3),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(defaultBorderRadious),
        color: getBookingStateBackgroundColor(bookingsState, context),
        /////////////////////////////////////////////////////////////////////
        border: Border.all(
            color: getBookingStateBorderColor(bookingsState, context)),
      ),
      child: Text(
        bookingsState.arabicName,
        style: Theme.of(context).textTheme.bodySmall,
        // style: TextStyle(fontSize: 10, color: Colors.white),
      ),
    );
  }
}

class ViewLargeBookingStateWidget extends StatelessWidget {
  final BookingsStatuesEnum bookingsState;
  const ViewLargeBookingStateWidget({required this.bookingsState, super.key});

  @override
  Widget build(BuildContext context) {
    return Column(
      spacing: 8,
      children: [
        Container(
          constraints:
              BoxConstraints(minWidth: MediaQuery.of(context).size.width),
          padding: EdgeInsets.all(15),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(defaultBorderRadious - 2),
            color: getBookingStateBackgroundColor(bookingsState, context),
            /////////////////////////////////////////////////////////////////////
            border: Border.all(
                color: getBookingStateBorderColor(bookingsState, context)),
          ),
          child: Text(
            "الحالة:  ${bookingsState.arabicName}",
            style: Theme.of(context).textTheme.titleMedium,
            textAlign: TextAlign.center,
            // style: TextStyle(fontSize: 10, color: Colors.white),
          ),
        ),
        Center(child: Text(bookingsState.description))
      ],
    );
  }
}
