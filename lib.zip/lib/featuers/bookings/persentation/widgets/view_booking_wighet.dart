import 'package:booking_v1/core/constants/strings.dart';
import 'package:booking_v1/core/routing/app_routes.dart';
import 'package:booking_v1/core/routing/router_extensions.dart';
import 'package:booking_v1/core/widgets/container_widgets.dart';
import 'package:booking_v1/featuers/bookings/persentation/widgets/view_booking_state_widghet.dart';
import 'package:flutter/material.dart';

import '../../../services/persentation/widgets/view_image_service_widget.dart';
import '../../../stores/persentation/widgets/view_store_small.dart';
import '../../domain/entities/booking.dart';
import '../pages/args/view_booking_details_args.dart';

class ViewUserBookingWighet extends StatelessWidget {
  final Booking booking;
  const ViewUserBookingWighet({required this.booking, super.key});

  @override
  Widget build(BuildContext context) {
    // return SecondaryContainer(
    //   paddingHorizontal: 0,
    //   paddingVertical: 0,
    //   child: Expanded(
    //     child: ListTile(
    //       isThreeLine: true,
    //       leading: Expanded(
    //           child: ViewSingleImageServiceSquireWidget(
    //               serviceId: booking.service!.id!)),
    //       title: Text(
    //         booking.service!.store!.category!.name.toString(),
    //         style: Theme.of(context).textTheme.displaySmall,
    //       ),
    //       subtitle: Column(
    //         spacing: 3,
    //         crossAxisAlignment: CrossAxisAlignment.start,
    //         children: [
    //           Text(
    //             booking.service!.name.toString(),
    //             style: Theme.of(context).textTheme.titleMedium,
    //           ),
    //           Text("${booking.service!.price} ر.ي",
    //               style: Theme.of(context).textTheme.titleSmall),
    //           // SizedBox(height: 50),
    //           ViewStoreSmallWidget(
    //             storeId: booking.service!.store!.id!,
    //             storeName: booking.service!.store!.name!,
    //             storeLogo: booking.service!.store!.logo!,
    //             storeCity: booking.service!.store!.directorate!.city!.name!,
    //           ),
    //         ],
    //       ),
    //       trailing: Column(
    //         mainAxisAlignment: MainAxisAlignment.spaceBetween,
    //         crossAxisAlignment: CrossAxisAlignment.end,
    //         children: [
    //           ViewBookingStateWidghet(
    //             bookingsState: booking.bookingStateEnum!,
    //           ),
    //           // ,
    //           // Expanded(child: SizedBox(height: 10)),
    //           Text(
    //               "${booking.bookingDate!.day} - ${booking.bookingDate!.month} - ${booking.bookingDate!.year}",
    //               style: Theme.of(context).textTheme.bodySmall),
    //         ],
    //       ),
    //     ),
    //   ),
    // );
    return SecondaryContainer(
      child: GestureDetector(
        onTap: () {
          context.pushTo(
            viewBookingDetailsRoute,
            extra:
                ViewBookingDetailsArgs(bookingId: booking.id!, forStore: false),
          );
        },
        child: SizedBox(
          height: 70,
          child: Row(
            spacing: defaultSpacing,
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                spacing: defaultSpacing,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  ViewSingleImageServiceSquireWidget(
                      serviceId: booking.service!.id!),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(booking.service!.store!.category!.name!,
                          style: Theme.of(context).textTheme.displaySmall),
                      Text(booking.service!.name!,
                          style: Theme.of(context).textTheme.titleMedium),
                      // Placeholder(),
                      // SizedBox(),
                      // Text("${booking.service!.price} ر.ي",
                      //     style: Theme.of(context).textTheme.titleSmall),
                      ViewStoreSmallWidget(
                        storeId: booking.service!.store!.id!,
                        storeName: booking.service!.store!.name!,
                        storeLogo: booking.service!.store!.logo!,
                        // storeCity:
                        //     booking.service!.store!.directorate!.city!.name!,
                      ),
                    ],
                  ),
                ],
              ),
              Column(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.end,
                mainAxisSize: MainAxisSize.max,
                children: [
                  ViewSmallBookingStateWidget(
                    bookingsState: booking.bookingStateEnum!,
                  ),
                  Text(
                      "${booking.bookingDate!.day} - ${booking.bookingDate!.month} - ${booking.bookingDate!.year}",
                      style: Theme.of(context).textTheme.bodySmall),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class ViewStoreBookingWighet extends StatelessWidget {
  final Booking booking;
  const ViewStoreBookingWighet({required this.booking, super.key});

  @override
  Widget build(BuildContext context) {
    return SecondaryContainer(
      paddingHorizontal: 0,
      paddingVertical: 10,
      child: ListTile(
        onTap: () {
          context.pushTo(
            viewBookingDetailsRoute,
            extra: ViewBookingDetailsArgs(bookingId: booking.id!),
          );
        },
        dense: true,
        leading: CircleAvatar(
          radius: 26,
          child: Center(child: Icon(Icons.person)),
        ),
        title: Text(booking.user!.name.toString(),
            style: Theme.of(context).textTheme.titleMedium),
        subtitle: Text(booking.service!.name!,
            style: Theme.of(context).textTheme.displaySmall),
        trailing: ViewSmallBookingStateWidget(
          bookingsState: booking.bookingStateEnum!,
        ),
      ),
    );
  }
}

// class ViewBookingWighet extends StatelessWidget {
//   const ViewBookingWighet({super.key});

//   @override
//   Widget build(BuildContext context) {
//     return SecondaryContainer(
//       paddingSpace: 0,
//       child: ListTile(
//         horizontalTitleGap: 10,
//         // enabled: false,
//         contentPadding: EdgeInsets.symmetric(horizontal: 15, vertical: 10),
//         leading: Container(
//           height: 180,
//           width: 80,
//           decoration: BoxDecoration(
//             borderRadius: BorderRadius.circular(defaultBorderRadious),
//             border: Border.all(
//                 color: Theme.of(context).colorScheme.onPrimaryContainer),
//             color: Theme.of(context).colorScheme.secondary,
//           ),
//           child: Center(
//             child: SvgPicture.asset(
//               "assets/logos/logo4.svg",
//               colorFilter: ColorFilter.mode(
//                 Theme.of(context).colorScheme.tertiary.withOpacity(0.20),
//                 BlendMode.srcIn,
//               ),
//               height: 80,
//             ),
//           ),
//         ),
//         title: Column(
//           crossAxisAlignment: CrossAxisAlignment.start,
//           children: [
//             Text("الفئة", style: Theme.of(context).textTheme.displaySmall),
//             Text("اسم الخدمة", style: Theme.of(context).textTheme.titleMedium),
//             // Placeholder(),
//             // Text("data", style: Theme.of(context).textTheme.displaySmall),
//           ],
//         ),
//         subtitle: ViewStoreSmall(),
//         trailing: Column(
//           mainAxisAlignment: MainAxisAlignment.spaceBetween,
//           crossAxisAlignment: CrossAxisAlignment.end,
//           children: [
//             ViewBookingStateWidghet(stateNum: 1),
//             Text("0000-00-00", style: Theme.of(context).textTheme.bodySmall),
//           ],
//         ),
//       ),
//     );
//   }
// }
