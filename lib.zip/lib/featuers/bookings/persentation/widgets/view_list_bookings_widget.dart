import 'package:booking_v1/dependency_injection/initial.dart';
import 'package:booking_v1/featuers/bookings/domain/enums/bookings_statues_enum.dart';
import 'package:booking_v1/tests/loading_test.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../../../core/constants/strings.dart';
import '../../../../core/widgets/ciracle_loading_widget.dart';
import '../../domain/entities/booking.dart';
import '../bloc/bookings_query/bookings_query_bloc.dart';
import '../bloc/bookings_query/bookings_query_event.dart';
import '../bloc/bookings_query/bookings_query_state.dart';
import 'view_booking_wighet.dart';

class ViewListUserBookingsWidget extends StatelessWidget {
  final int userId;
  final BookingsStatuesEnum? bookingsState;
  const ViewListUserBookingsWidget({
    super.key,
    required this.userId,
    this.bookingsState,
  });

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (context) => getIt<BookingsQueryBloc>()
        ..addAndRemember(
          GetBookingsByUserIdEvent(userId: userId, bookingState: bookingsState),
        ),
      child: BlocBuilder<BookingsQueryBloc, BookingsQueryState>(
        builder: (context, state) {
          if (state is LoadingState) {
            return CiracleLoadingWidget();
          } else if (state is LoadedState) {
            return CustomRefresh(
              onRefresh: () async {
                BlocProvider.of<BookingsQueryBloc>(context).add(
                    RefreshGetBookingsByUserIdEvent(
                        userId: userId, bookingState: bookingsState));
              },
              child: CustomScrollView(
                slivers: [
                  SliverList(
                    delegate: SliverChildBuilderDelegate(
                      // semanticIndexOffset: 10,
                      childCount: state.bookings.length,
                      (context, index) {
                        final booking = state.bookings[index];
                        return Container(
                          margin: EdgeInsets.symmetric(
                            horizontal: defaultPadding,
                            vertical: defaultPadding / 2,
                          ),
                          child: ViewUserBookingWighet(booking: booking),
                        );
                      },
                    ),
                  ),
                ],
              ),
            );
          } else if (state is ErrorState) {
            return Center(child: Text(state.message));
          } else {
            return CiracleLoadingWidget();
          }
        },
      ),
    );
  }
}

class ViewListBookingsWidget extends StatelessWidget {
  final List<Booking> bookings;
  final BookingsStatuesEnum? bookingsStatue;
  const ViewListBookingsWidget({
    super.key,
    required this.bookings,
    this.bookingsStatue,
  });

  @override
  Widget build(BuildContext context) {
    final filtterBookings = bookingsStatue != null
        ? bookings
            .where((element) => element.bookingStateEnum == bookingsStatue)
            .toList()
        : bookings;

    return ListView.builder(
      itemCount: filtterBookings.length,
      itemBuilder: (context, index) {
        final booking = filtterBookings[index];
        return Container(
          margin: EdgeInsets.symmetric(
            horizontal: defaultPadding,
            vertical: defaultPadding / 2,
          ),
          child: ViewUserBookingWighet(booking: booking),
        );
      },
    );
  }
}

////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////
class ViewListStoreBookingsWidget extends StatelessWidget {
  final int storeId;
  final BookingsStatuesEnum? bookingsState;
  const ViewListStoreBookingsWidget({
    super.key,
    required this.storeId,
    this.bookingsState,
  });

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (context) => getIt<BookingsQueryBloc>()
        ..addAndRemember(
          GetBookingsByStoreIdEvent(
              storeId: storeId, bookingState: bookingsState),
        ),
      child: BlocBuilder<BookingsQueryBloc, BookingsQueryState>(
        builder: (context, state) {
          if (state is LoadingState) {
            return CiracleLoadingWidget();
          } else if (state is LoadedState) {
            return CustomRefresh(
              onRefresh: () async {
                BlocProvider.of<BookingsQueryBloc>(context).add(
                    RefreshGetBookingsByStoreIdEvent(
                        storeId: storeId, bookingState: bookingsState));
              },
              child: CustomScrollView(
                slivers: [
                  SliverList(
                    delegate: SliverChildBuilderDelegate(
                      // semanticIndexOffset: 10,
                      childCount: state.bookings.length,
                      (context, index) {
                        final booking = state.bookings[index];
                        return Container(
                          margin: EdgeInsets.symmetric(
                            horizontal: defaultPadding,
                            vertical: defaultPadding / 2,
                          ),
                          child: ViewStoreBookingWighet(booking: booking),
                        );
                      },
                    ),
                  ),
                ],
              ),
            );
          } else if (state is ErrorState) {
            if (state.message == emptyCacheFailureMessage) {
              return Center(child: Text("لايوجد اي حجوزات لمتجرك"));
            }
            return Center(child: Text(state.message));
          } else {
            return CiracleLoadingWidget();
          }
        },
      ),
    );
  }
}

class ViewListServiceBookingsWidget extends StatelessWidget {
  final int serviceId;
  final BookingsStatuesEnum? bookingsState;
  const ViewListServiceBookingsWidget({
    super.key,
    required this.serviceId,
    this.bookingsState,
  });

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (context) => getIt<BookingsQueryBloc>()
        ..addAndRemember(
          GetBookingsByServiceIdEvent(
              serviceId: serviceId, bookingState: bookingsState),
        ),
      child: BlocBuilder<BookingsQueryBloc, BookingsQueryState>(
        builder: (context, state) {
          if (state is LoadingState) {
            return CiracleLoadingWidget();
          } else if (state is LoadedState) {
            return CustomRefresh(
              onRefresh: () async {
                BlocProvider.of<BookingsQueryBloc>(context).add(
                    RefreshGetBookingsByServiceIdEvent(
                        serviceId: serviceId, bookingState: bookingsState));
              },
              child: CustomScrollView(
                slivers: [
                  SliverList(
                    delegate: SliverChildBuilderDelegate(
                      // semanticIndexOffset: 10,
                      childCount: state.bookings.length,
                      (context, index) {
                        final booking = state.bookings[index];
                        return Container(
                          margin: EdgeInsets.symmetric(
                            horizontal: defaultPadding,
                            vertical: defaultPadding / 2,
                          ),
                          child: ViewStoreBookingWighet(booking: booking),
                        );
                      },
                    ),
                  ),
                ],
              ),
            );
          } else if (state is ErrorState) {
            if (state.message == emptyCacheFailureMessage) {
              return Center(child: Text("لايوجد اي حجوزات"));
            }
            return Center(child: Text(state.message));
          } else {
            return CiracleLoadingWidget();
          }
        },
      ),
    );
  }
}
