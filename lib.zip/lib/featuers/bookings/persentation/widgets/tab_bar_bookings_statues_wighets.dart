import 'package:booking_v1/core/constants/strings.dart';
import 'package:flutter/material.dart';

class TabBarBookingsStatuesWighets extends StatelessWidget {
  const TabBarBookingsStatuesWighets({super.key});

  @override
  Widget build(BuildContext context) {
    return TabBar(
      padding: EdgeInsets.only(bottom: defaultPadding / 4),
      isScrollable: true,
      tabs: [
        Text("الكل"),
        Text("التحقق من الدفع"),
        Text("حجز مبدئي"),
        Text("حجز نهائي"),
        Text("حجز ملغي"),
        Text("حجز مرفوض"),
        Text("حجز منتهي"),
      ],
    );
  }
}
