import 'package:booking_v1/core/helpers/failure_to_message.dart';
import 'package:booking_v1/featuers/bookings/domain/entities/booking.dart';
import 'package:booking_v1/featuers/bookings/domain/enums/booking_method_enum.dart';
import 'package:booking_v1/featuers/bookings/domain/enums/bookings_statues_enum.dart';
import 'package:booking_v1/featuers/payments/domain/enums/payment_method_enum.dart';
import 'package:booking_v1/featuers/payments/domain/enums/payment_transaction_type_enum.dart';
import 'package:booking_v1/featuers/services/domain/entities/service.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../../../../core/app_events_bus/app_event.dart';
import '../../../../../core/app_events_bus/app_event_bus.dart';
import '../../../../../core/routing/app_routes.dart';
import '../../../../../core/routing/navigation_service.dart';
import '../../../../payments/domain/entities/payment.dart';
import '../../../../payments/domain/usecases/payments_usecase.dart';
import '../../../../stores/domain/entities/store_wallet.dart';
import '../../../../stores/domain/usecases/store_wallet_usecase.dart';
import '../../../domain/usecases/bookings_usecase.dart';
import 'bookings_command_event.dart';
import 'bookings_command_state.dart';

class BookingsCommandBloc
    extends Bloc<BookingsCommandEvent, BookingsCommandState> {
  final GetBookingsDatesByServiceIdUsecase? getBookingDateByServiceIdUsecase;
  final GetStoreWalletsUsecase? getStoreWalletsUsecase;
  final AddBookingUsecase? addBookingUsecase;
  final AddPaymentUsecase? addPaymentUsecase;

  Service? service;
  DateTime? selectedDate;
  List<DateTime>? bookingDates;
  String? note;
  bool? approvalOfPolitics;
  List<StoreWallet>? storeWallets;
  int? walletId;
  int? transcationNumber;
  String? transcationImage;
  PaymentMethodEnum? paymentMethodEnum;

  BookingsCommandBloc({
    this.getBookingDateByServiceIdUsecase,
    this.getStoreWalletsUsecase,
    this.addBookingUsecase,
    this.addPaymentUsecase,
  }) : super(InitialState()) {
    on<AddBookingOnlineEvent>((event, emit) async {
      emit(LoadingState());
      service = null;
      bookingDates = null;
      selectedDate = null;
      note = null;
      approvalOfPolitics = null;
      storeWallets = null;
      walletId = null;
      transcationNumber = null;
      transcationImage = null;
      paymentMethodEnum = null;

      service = event.service;
      NavigationService.push(addDetailsBookingRoute);

      final failureOrSuccess =
          await getBookingDateByServiceIdUsecase!(service!.id!);
      failureOrSuccess.fold(
        (failure) => ErrorState(message: failureToMessage(failure)),
        (dates) => bookingDates = dates,
      );
      final failureOrSuccess2 =
          await getStoreWalletsUsecase!(service!.storeId!);
      failureOrSuccess2.fold(
        (failure) => ErrorState(message: failureToMessage(failure)),
        (wallets) => storeWallets = wallets,
      );

      emit(_commandState());
    });
    on<AddNoteAndDateOnlineEvent>((event, emit) async {
      emit(LoadingState());

      selectedDate = event.selectedDate;
      note = event.note;

      emit(_commandState());
      NavigationService.push(checkAddBookingRoute);
    });
    on<ApprovalOfPolicyBookingOnlineEvent>((event, emit) async {
      emit(LoadingState());

      approvalOfPolitics = event.approvalOfPolitics;

      emit(_commandState());

      NavigationService.push(paymentBookingOnlineRoute);
    });
    on<SubmitAddBookingOnlineEvent>((event, emit) async {
      emit(LoadingState());

      walletId = event.walletId;
      transcationImage = event.transcationImage;
      transcationNumber = event.transcationNumber;
      paymentMethodEnum = event.paymentMethodEnum;

      emit(_commandState());
      final booking = Booking(
        acceptedAllPolicies: approvalOfPolitics,
        bookingDate: selectedDate,
        userId: 4,
        bookingMethodEnem: BookingMethodEnum.onlineBooking,
        bookingStateEnum: BookingsStatuesEnum.pendingPayment,
        note: note,
        serviceId: service!.id,
      );
      final failureOrSuccess = await addBookingUsecase!(booking);
      failureOrSuccess.fold(
        (failure) => ErrorState(message: failureToMessage(failure)),
        (bookingId) {
          final amount = service!.price! * 0.30;
          final payment = Payment(
            bookingId: bookingId,
            walletId: walletId,
            transactionNumber: transcationNumber,
            transactionImage: transcationImage,
            amount: amount,
            paymentMethodEnum: paymentMethodEnum,
            paymentTransactionTypeEnum:
                PaymentTransactionTypeEnum.depositPayment,
          );
          addPaymentUsecase!(payment);
          emit(SuccessfullyState());
          NavigationService.replace(entryPointRoute, extra: 3);
          // AppEventBus.instance.fire(BookingChangedEvent());
          AppEventBus.instance.fire(PaymentChangedEvent());
        },
      );
    });
    on<CancelAddBookingOnlineEvent>((event, emit) async {
      NavigationService.popUntil(serviceDetailsRoute);
    });
  }

  BookingsCommandState _commandState() {
    return EditingAddBookingOnlineState(
      service: service,
      bookingDates: bookingDates,
      selectedDate: selectedDate,
      note: note,
      approvalOfPolitics: approvalOfPolitics,
      storeWallets: storeWallets,
      walletId: walletId,
      transcationNumber: transcationNumber,
      transcationImage: transcationImage,
      paymentMethodEnum: paymentMethodEnum,
    );
  }
}
