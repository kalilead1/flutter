import 'package:equatable/equatable.dart';

import '../../../../payments/domain/enums/payment_method_enum.dart';
import '../../../../services/domain/entities/service.dart';

abstract class BookingsCommandEvent extends Equatable {
  const BookingsCommandEvent();
  @override
  List<Object?> get props => [];
}

class AddBookingOnlineEvent extends BookingsCommandEvent {
  final Service service;
  const AddBookingOnlineEvent({required this.service});

  @override
  List<Object?> get props => [service];
}

class AddNoteAndDateOnlineEvent extends BookingsCommandEvent {
  final DateTime selectedDate;
  final String note;

  const AddNoteAndDateOnlineEvent(
      {required this.selectedDate, required this.note});

  @override
  List<Object?> get props => [selectedDate, note];
}

class ApprovalOfPolicyBookingOnlineEvent extends BookingsCommandEvent {
  final bool approvalOfPolitics;

  const ApprovalOfPolicyBookingOnlineEvent({
    required this.approvalOfPolitics,
  });

  @override
  List<Object?> get props => [approvalOfPolitics];
}

class SubmitAddBookingOnlineEvent extends BookingsCommandEvent {
  final int? walletId;
  final int transcationNumber;
  final String transcationImage;
  final PaymentMethodEnum paymentMethodEnum;

  const SubmitAddBookingOnlineEvent({
    this.walletId,
    required this.transcationNumber,
    required this.transcationImage,
    required this.paymentMethodEnum,
  });

  @override
  List<Object?> get props =>
      [walletId, transcationNumber, transcationImage, paymentMethodEnum];
}

class CancelAddBookingOnlineEvent extends BookingsCommandEvent {}
