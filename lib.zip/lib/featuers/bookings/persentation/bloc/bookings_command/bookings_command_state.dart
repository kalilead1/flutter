import 'package:equatable/equatable.dart';

import '../../../../payments/domain/enums/payment_method_enum.dart';
import '../../../../services/domain/entities/service.dart';
import '../../../../stores/domain/entities/store_wallet.dart';

abstract class BookingsCommandState extends Equatable {
  const BookingsCommandState();
  @override
  List<Object?> get props => [];
}

class InitialState extends BookingsCommandState {}

class LoadingState extends BookingsCommandState {}

class SuccessfullyState extends BookingsCommandState {}

class ErrorState extends BookingsCommandState {
  final String message;

  const ErrorState({required this.message});

  @override
  List<Object?> get props => [message];
}

class EditingAddBookingOnlineState extends BookingsCommandState {
  final Service? service;
  final DateTime? selectedDate;
  final List<DateTime>? bookingDates;
  final String? note;
  final bool? approvalOfPolitics;
  final List<StoreWallet>? storeWallets;
  final int? walletId;
  final int? transcationNumber;
  final String? transcationImage;
  final PaymentMethodEnum? paymentMethodEnum;

  const EditingAddBookingOnlineState({
    this.service,
    this.selectedDate,
    this.bookingDates,
    this.note,
    this.approvalOfPolitics,
    this.storeWallets,
    this.walletId,
    this.transcationNumber,
    this.transcationImage,
    this.paymentMethodEnum,
  });

  @override
  List<Object?> get props => [
        service,
        selectedDate,
        bookingDates,
        note,
        approvalOfPolitics,
        storeWallets,
        walletId,
        transcationNumber,
        transcationImage,
        paymentMethodEnum
      ];
}
