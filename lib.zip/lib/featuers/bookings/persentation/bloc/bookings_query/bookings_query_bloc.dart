import 'package:booking_v1/core/errors/failures.dart';
import 'package:booking_v1/core/helpers/failure_to_message.dart';
import 'package:booking_v1/featuers/bookings/domain/enums/bookings_statues_enum.dart';
import 'package:dartz/dartz.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../../../../core/app_events_bus/app_event.dart';
import '../../../../../core/app_events_bus/auto_refresh_bloc.dart';
import '../../../domain/entities/booking.dart';
import '../../../domain/usecases/bookings_usecase.dart';
import 'bookings_query_event.dart';
import 'bookings_query_state.dart';

class BookingsQueryBloc extends Bloc<BookingsQueryEvent, BookingsQueryState>
    with AutoRefreshBloc<BookingsQueryEvent, BookingsQueryState> {
  final GetBookingsByUserIdUsecase? getBookingsByUserIdUsecase;
  final GetBookingsByStoreIdUsecase? getBookingsByStoreIdUsecase;
  final GetBookingsByServiceIdUsecase? getBookingsByServiceIdUsecase;
  final GetBookingByIdUsecase? getBookingByIdUsecase;
  final GetBookingsDatesByServiceIdUsecase? getBookingsDatesByServiceIdUsecase;

  BookingsQueryBloc({
    this.getBookingsByUserIdUsecase,
    this.getBookingsByStoreIdUsecase,
    this.getBookingsByServiceIdUsecase,
    this.getBookingByIdUsecase,
    this.getBookingsDatesByServiceIdUsecase,
  }) : super(InitialState()) {
    setupAutoRefresh<BookingChangedEvent>();

    on<GetBookingsByUserIdEvent>((event, emit) async {
      emit(LoadingState());

      final failureOrBookings =
          await getBookingsByUserIdUsecase!(event.userId, event.bookingState);
      emit(_mapFailureOrGetAllBookings(failureOrBookings));
    });
    on<GetBookingsByStoreIdEvent>((event, emit) async {
      emit(LoadingState());

      final failureOrBookings =
          await getBookingsByStoreIdUsecase!(event.storeId, event.bookingState);
      emit(_mapFailureOrGetBookings(failureOrBookings));
    });
    on<GetBookingsByServiceIdEvent>((event, emit) async {
      emit(LoadingState());

      final failureOrBookings = await getBookingsByServiceIdUsecase!(
          event.serviceId, event.bookingState);
      emit(_mapFailureOrGetBookings(failureOrBookings));
    });
    on<GetBookingByIdEvent>((event, emit) async {
      emit(LoadingState());

      final failureOrBooking = await getBookingByIdUsecase!(event.id);
      emit(_mapFailureOrGetBookingById(failureOrBooking));
    });
    on<GetBookingsDatesByServiceIdEvent>((event, emit) async {
      emit(LoadingState());

      final failureOrBooking =
          await getBookingsDatesByServiceIdUsecase!(event.serviceId);
      failureOrBooking.fold(
        (failure) => emit(ErrorState(message: failureToMessage(failure))),
        (bookingsDates) => emit(
            LoadedBookingsDatesByServiceIdState(bookingsDates: bookingsDates)),
      );
    });
    /////////////////////////////////////////////////////////////////////////
    /////////////////////////////// Refresh /////////////////////////////////
    /////////////////////////////////////////////////////////////////////////
    on<RefreshGetBookingsByUserIdEvent>((event, emit) async {
      emit(LoadingState());

      final failureOrBookings =
          await getBookingsByUserIdUsecase!(event.userId, event.bookingState);
      emit(_mapFailureOrGetAllBookings(failureOrBookings));
    });
    on<RefreshGetBookingsByStoreIdEvent>((event, emit) async {
      emit(LoadingState());

      final failureOrBookings =
          await getBookingsByStoreIdUsecase!(event.storeId, event.bookingState);
      emit(_mapFailureOrGetBookings(failureOrBookings));
    });
    on<RefreshGetBookingsByServiceIdEvent>((event, emit) async {
      emit(LoadingState());

      final failureOrBookings = await getBookingsByServiceIdUsecase!(
          event.serviceId, event.bookingState);
      emit(_mapFailureOrGetBookings(failureOrBookings));
    });
    on<RefreshGetBookingByIdEvent>((event, emit) async {
      emit(LoadingState());

      final failureOrBooking = await getBookingByIdUsecase!(event.id);
      emit(_mapFailureOrGetBookingById(failureOrBooking));
    });
  }

  BookingsQueryState _mapFailureOrGetAllBookings(
      Either<Failure, List<Booking>> either) {
    return either.fold(
      (failure) => ErrorState(message: failureToMessage(failure)),
      (bookings) {
        final pendingPaymentBookings = bookings
            .where((element) =>
                element.bookingStateEnum == BookingsStatuesEnum.pendingPayment)
            .toList();
        final perliminaryBookings = bookings
            .where((element) =>
                element.bookingStateEnum == BookingsStatuesEnum.perliminary)
            .toList();
        final confirmedBookings = bookings
            .where((element) =>
                element.bookingStateEnum == BookingsStatuesEnum.confirmed)
            .toList();
        final cancelledBookings = bookings
            .where((element) =>
                element.bookingStateEnum == BookingsStatuesEnum.cancelled)
            .toList();
        final rejectedBookings = bookings
            .where((element) =>
                element.bookingStateEnum == BookingsStatuesEnum.rejected)
            .toList();
        final completedBookings = bookings
            .where((element) =>
                element.bookingStateEnum == BookingsStatuesEnum.completed)
            .toList();
        return LoadedAllBookingsState(
          allBookings: bookings,
          pendingPaymentBookings: pendingPaymentBookings,
          perliminaryBookings: perliminaryBookings,
          confirmedBookings: confirmedBookings,
          cancelledBookings: cancelledBookings,
          rejectedBookings: rejectedBookings,
          completedBookings: completedBookings,
        );
      },
    );
  }

  BookingsQueryState _mapFailureOrGetBookings(
      Either<Failure, List<Booking>> either) {
    return either.fold(
      (failure) => ErrorState(message: failureToMessage(failure)),
      (bookings) => LoadedState(bookings: bookings),
    );
  }

  BookingsQueryState _mapFailureOrGetBookingById(
      Either<Failure, Booking> either) {
    return either.fold(
      (failure) => ErrorState(message: failureToMessage(failure)),
      (booking) => LoadedByIdState(booking: booking),
    );
  }
}
