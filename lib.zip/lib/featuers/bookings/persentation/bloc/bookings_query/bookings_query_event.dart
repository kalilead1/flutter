import 'package:equatable/equatable.dart';

import '../../../domain/enums/bookings_statues_enum.dart';

abstract class BookingsQueryEvent extends Equatable {
  const BookingsQueryEvent();
  @override
  List<Object?> get props => [];
}

class GetBookingsByUserIdEvent extends BookingsQueryEvent {
  final int userId;
  final BookingsStatuesEnum? bookingState;
  const GetBookingsByUserIdEvent({required this.userId, this.bookingState});

  @override
  List<Object?> get props => [userId, bookingState];
}

class GetBookingsByStoreIdEvent extends BookingsQueryEvent {
  final int storeId;
  final BookingsStatuesEnum? bookingState;
  const GetBookingsByStoreIdEvent({required this.storeId, this.bookingState});

  @override
  List<Object?> get props => [storeId, bookingState];
}

class GetBookingsByServiceIdEvent extends BookingsQueryEvent {
  final int serviceId;
  final BookingsStatuesEnum? bookingState;
  const GetBookingsByServiceIdEvent(
      {required this.serviceId, this.bookingState});

  @override
  List<Object?> get props => [serviceId, bookingState];
}

class GetBookingsDatesByServiceIdEvent extends BookingsQueryEvent {
  final int serviceId;
  const GetBookingsDatesByServiceIdEvent({required this.serviceId});

  @override
  List<Object?> get props => [serviceId];
}

class GetBookingByIdEvent extends BookingsQueryEvent {
  final int id;
  const GetBookingByIdEvent({required this.id});

  @override
  List<Object?> get props => [id];
}

///////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////
class RefreshGetBookingByIdEvent extends BookingsQueryEvent {
  final int id;
  const RefreshGetBookingByIdEvent({required this.id});

  @override
  List<Object?> get props => [id];
}

class RefreshGetBookingsByUserIdEvent extends BookingsQueryEvent {
  final int userId;
  final BookingsStatuesEnum? bookingState;
  const RefreshGetBookingsByUserIdEvent(
      {required this.userId, this.bookingState});

  @override
  List<Object?> get props => [userId, bookingState];
}

class RefreshGetBookingsByStoreIdEvent extends BookingsQueryEvent {
  final int storeId;
  final BookingsStatuesEnum? bookingState;
  const RefreshGetBookingsByStoreIdEvent(
      {required this.storeId, this.bookingState});

  @override
  List<Object?> get props => [storeId, bookingState];
}

class RefreshGetBookingsByServiceIdEvent extends BookingsQueryEvent {
  final int serviceId;
  final BookingsStatuesEnum? bookingState;
  const RefreshGetBookingsByServiceIdEvent(
      {required this.serviceId, this.bookingState});

  @override
  List<Object?> get props => [serviceId, bookingState];
}
