import 'package:equatable/equatable.dart';

import '../../../domain/entities/booking.dart';

abstract class BookingsQueryState extends Equatable {
  const BookingsQueryState();
  @override
  List<Object?> get props => [];
}

class InitialState extends BookingsQueryState {}

class LoadingState extends BookingsQueryState {}

class LoadedAllBookingsState extends BookingsQueryState {
  final List<Booking> allBookings;
  final List<Booking> pendingPaymentBookings;
  final List<Booking> perliminaryBookings;
  final List<Booking> confirmedBookings;
  final List<Booking> cancelledBookings;
  final List<Booking> rejectedBookings;
  final List<Booking> completedBookings;

  const LoadedAllBookingsState({
    required this.allBookings,
    required this.pendingPaymentBookings,
    required this.perliminaryBookings,
    required this.confirmedBookings,
    required this.cancelledBookings,
    required this.rejectedBookings,
    required this.completedBookings,
  });

  @override
  List<Object?> get props => [
        allBookings,
        pendingPaymentBookings,
        perliminaryBookings,
        confirmedBookings,
        cancelledBookings,
        rejectedBookings,
        completedBookings,
      ];
}

class LoadedState extends BookingsQueryState {
  final List<Booking> bookings;

  const LoadedState({required this.bookings});

  @override
  List<Object?> get props => [bookings];
}

class LoadedBookingsDatesByServiceIdState extends BookingsQueryState {
  final List<DateTime> bookingsDates;

  const LoadedBookingsDatesByServiceIdState({required this.bookingsDates});

  @override
  List<Object?> get props => [bookingsDates];
}

class LoadedByIdState extends BookingsQueryState {
  final Booking booking;

  const LoadedByIdState({required this.booking});

  @override
  List<Object?> get props => [booking];
}

class ErrorState extends BookingsQueryState {
  final String message;

  const ErrorState({required this.message});

  @override
  List<Object?> get props => [message];
}

// class EditingAddBookingState extends BookingsQueryState {
//   final Service? service;
//   final DateTime? selectedDate;
//   final List<DateTime>? bookingDates;
//   final String? note;
//   final bool? approvalOfPolitics;
//   final List<StoreWallet>? storeWallets;
//   final Payment? payment;

//   const EditingAddBookingState({
//     this.service,
//     this.selectedDate,
//     this.bookingDates,
//     this.note,
//     this.approvalOfPolitics,
//     this.storeWallets,
//     this.payment,
//   });

//   @override
//   List<Object?> get props => [
//         service,
//         selectedDate,
//         bookingDates,
//         note,
//         approvalOfPolitics,
//         storeWallets,
//         payment,
//       ];
// }
