class ViewBookingDetailsArgs {
  final int bookingId;
  final bool forStore;

  const ViewBookingDetailsArgs({
    required this.bookingId,
    this.forStore = true,
  });
}
