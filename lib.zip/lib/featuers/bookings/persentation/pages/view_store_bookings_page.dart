import 'package:booking_v1/core/widgets/dialog_widgets.dart';
import 'package:booking_v1/featuers/bookings/persentation/widgets/tab_bar_bookings_statues_wighets.dart';
import 'package:booking_v1/featuers/bookings/persentation/widgets/tab_bar_view_bookings_statues_wighets.dart';
import 'package:flutter/material.dart';

class ViewStoreBookingsPage extends StatelessWidget {
  final int storeId;
  const ViewStoreBookingsPage({super.key, required this.storeId});

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 7,
      child: Directionality(
        textDirection: TextDirection.rtl,
        child: Scaffold(
          appBar: AppBar(
            actions: [
              IconButton(
                onPressed: () {
                  AppDialog.showCustomDialog(
                    context: context,
                    title: "الخدمة موقفة!",
                    content: "يجب الدخول الى خدمة واضافة حجز",
                  );
                },
                icon: Icon(Icons.add),
              )
            ],
            // toolbarHeight: 100,
            // flexibleSpace: Padding(
            //   padding: const EdgeInsets.symmetric(horizontal: defaultPadding),
            //   child: SearchForm(),
            // ),
            title: Text("حجوزات المتجر"),
            bottom: PreferredSize(
              preferredSize: Size.fromHeight(30),
              child: TabBarBookingsStatuesWighets(),
            ),
          ),
          body: Padding(
            padding: const EdgeInsets.only(top: 8.0),
            child: TabBarViewBookingsStatuesWighets(storeId: storeId),
          ),
        ),
      ),
    );
  }
}
