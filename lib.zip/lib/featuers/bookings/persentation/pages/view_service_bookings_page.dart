import 'package:booking_v1/featuers/bookings/persentation/widgets/tab_bar_bookings_statues_wighets.dart';
import 'package:booking_v1/featuers/bookings/persentation/widgets/tab_bar_view_bookings_statues_wighets.dart';
import 'package:flutter/material.dart';

class ViewServiceBookingsPage extends StatelessWidget {
  final int serviceId;
  const ViewServiceBookingsPage({super.key, required this.serviceId});

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 7,
      child: Directionality(
        textDirection: TextDirection.rtl,
        child: Scaffold(
          appBar: AppBar(
            actions: [
              IconButton(
                onPressed: () {},
                icon: Icon(Icons.add),
              )
            ],
            title: Text("حجوزات الخدمة"),
            bottom: PreferredSize(
              preferredSize: Size.fromHeight(30),
              child: TabBarBookingsStatuesWighets(),
            ),
          ),
          body: Padding(
            padding: const EdgeInsets.only(top: 8.0),
            child: TabBarViewBookingsStatuesWighets(serviceId: serviceId),
          ),
        ),
      ),
    );
  }
}
