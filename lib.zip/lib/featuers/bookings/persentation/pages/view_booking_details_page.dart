import 'package:booking_v1/core/constants/strings.dart';
import 'package:booking_v1/core/routing/app_routes.dart';
import 'package:booking_v1/core/routing/router_extensions.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../../../core/widgets/ciracle_loading_widget.dart';
import '../../../../core/widgets/container_widgets.dart';
import '../../../../dependency_injection/initial.dart';
import '../../../../tests/loading_test.dart';
import '../../../payments/persentation/widgets/view_amount_booking_widget.dart';
import '../../../services/persentation/widgets/view_image_service_widget.dart';
import '../../../stores/persentation/widgets/view_store_small.dart';
import '../bloc/bookings_query/bookings_query_bloc.dart';
import '../bloc/bookings_query/bookings_query_event.dart';
import '../bloc/bookings_query/bookings_query_state.dart';
import '../widgets/view_booking_state_widghet.dart';
import 'args/view_booking_details_args.dart';

class ViewBookingDetailsPage extends StatelessWidget {
  final ViewBookingDetailsArgs args;
  const ViewBookingDetailsPage({super.key, required this.args});

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (context) => getIt<BookingsQueryBloc>()
        ..addAndRemember(GetBookingByIdEvent(id: args.bookingId)),
      child: Directionality(
        textDirection: TextDirection.rtl,
        child: Scaffold(
          appBar: AppBar(title: Text("تقاصيل الحجز")),
          body: BlocBuilder<BookingsQueryBloc, BookingsQueryState>(
            builder: (context, state) {
              if (state is LoadingState) {
                return CiracleLoadingWidget();
              } else if (state is LoadedByIdState) {
                final booking = state.booking;
                String acceptedAllPolicies =
                    booking.acceptedAllPolicies! ? "نعم" : "لا";
                double total = booking.service!.price!;
                double deposit = total * 0.30;
                double remaining = total - deposit;
                return CustomRefresh(
                  onRefresh: () async {
                    context
                        .read<BookingsQueryBloc>()
                        .add(RefreshGetBookingByIdEvent(id: args.bookingId));
                  },
                  child: SingleChildScrollView(
                    child: Padding(
                      padding: const EdgeInsets.all(defaultPadding),
                      child: Column(
                        spacing: defaultSpacing,
                        children: [
                          PrimaryContainer(
                            paddingVertical: 10,
                            child: Row(
                              spacing: defaultSpacing,
                              children: [
                                ViewSingleImageServiceSquireWidget(
                                    serviceId: booking.serviceId!),
                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Text(
                                        booking.service!.store!.category!.name
                                            .toString(),
                                        style: Theme.of(context)
                                            .textTheme
                                            .displaySmall),
                                    SizedBox(height: 3),
                                    Text(booking.service!.name!,
                                        style: Theme.of(context)
                                            .textTheme
                                            .titleMedium),
                                    SizedBox(height: 5),
                                    ViewStoreSmallWidget(
                                      storeId: booking.service!.store!.id!,
                                      storeName: booking.service!.store!.name!,
                                      storeLogo: booking.service!.store!.logo!,
                                      storeCity: booking.service!.store!
                                          .directorate!.city!.name!,
                                      storeDirectorateName: booking
                                          .service!.store!.directorate!.name!,
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                          ViewAmountBookingWidget(
                            total: total,
                            deposit: deposit,
                            remaining: remaining,
                          ),
                          ViewLargeBookingStateWidget(
                              bookingsState: booking.bookingStateEnum!),
                          SecondaryContainer(
                            paddingHorizontal: 12,
                            paddingVertical: 8,
                            child: Column(
                              children: [
                                _listTile(
                                  context: context,
                                  info: booking.service!.peopleCount.toString(),
                                  title: "سعة الاشخاص",
                                ),
                                _listTile(
                                  context: context,
                                  info: booking.service!.duration!,
                                  title: "مدة الخدمة",
                                ),
                              ],
                            ),
                          ),
                          SecondaryContainer(
                            paddingHorizontal: 12,
                            paddingVertical: 8,
                            child: Column(
                              children: [
                                _listTile(
                                  context: context,
                                  info: booking.user!.name!,
                                  title: "اسم العميل:",
                                ),
                                _listTile(
                                  context: context,
                                  info: booking.user!.phoneNumber!,
                                  title: "رقم العميل:",
                                ),
                              ],
                            ),
                          ),
                          SecondaryContainer(
                            paddingHorizontal: 12,
                            paddingVertical: 8,
                            child: Column(
                              children: [
                                _listTile(
                                  context: context,
                                  info: booking.id.toString(),
                                  title: "رقم العملية",
                                ),
                                _listTile(
                                  context: context,
                                  info: booking.bookingDate!.toIso8601String(),
                                  title: "تاريخ موعد الحجز",
                                ),
                                _listTile(
                                  context: context,
                                  info: booking.createdAt!.toIso8601String(),
                                  title: "ناريخ الحجز",
                                ),
                                _listTile(
                                  context: context,
                                  info: acceptedAllPolicies,
                                  title: "الموافقة على السياسات:",
                                ),
                                _listTile(
                                  context: context,
                                  info: booking.note.toString(),
                                  title: "الملاحظة",
                                ),
                              ],
                            ),
                          ),
                          OutlinedButton(
                            onPressed: () {
                              context.pushTo(paymentDetailsRoute,
                                  extra: args.bookingId);
                            },
                            child: Text("عرض بيانات الدفع"),
                          )
                        ],
                      ),
                    ),
                  ),
                );
              } else if (state is ErrorState) {
                return Center(child: Text(state.message));
              } else {
                return CiracleLoadingWidget();
              }
            },
          ),
        ),
      ),
    );
  }

  Widget _listTile({
    required BuildContext context,
    required String info,
    required String title,
  }) {
    return Container(
      margin: const EdgeInsets.all(6),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            title,
            style: Theme.of(context).textTheme.labelMedium,
          ),
          Expanded(
            child: Text(
              info,
              softWrap: true,
              textAlign: TextAlign.end,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: Theme.of(context).textTheme.titleSmall,
            ),
          ),
        ],
      ),
    );
  }
}
