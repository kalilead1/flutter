import 'package:booking_v1/core/constants/strings.dart';
import 'package:booking_v1/core/widgets/container_widgets.dart';
import 'package:booking_v1/core/widgets/dialog_widgets.dart';
import 'package:booking_v1/featuers/services/persentation/widgets/view_image_service_widget.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../../../../core/widgets/bottom_items.dart';
import '../../../../../core/widgets/botton_widghts.dart';
import '../../../../../core/widgets/ciracle_loading_widget.dart';
import '../../../../../core/widgets/snack_bar_widgets.dart';
import '../../../../payments/persentation/widgets/view_amount_booking_widget.dart';
import '../../../../stores/persentation/widgets/view_store_small.dart';
import '../../bloc/bookings_command/bookings_command_bloc.dart';
import '../../bloc/bookings_command/bookings_command_event.dart';
import '../../bloc/bookings_command/bookings_command_state.dart';

class CheckAddBookingOnlinePage extends StatefulWidget {
  const CheckAddBookingOnlinePage({super.key});

  @override
  State<CheckAddBookingOnlinePage> createState() =>
      _CheckAddBookingOnlinePageState();
}

class _CheckAddBookingOnlinePageState extends State<CheckAddBookingOnlinePage> {
  DateTime day = DateTime.now();
  final String description =
      " بيانات بيانات بيانات بيانات بيانات بيانات بيانات بيانات الوصف";
  bool approvalOfPolitics = false;

  void approvalOfPolicyBookingValid() {
    if (approvalOfPolitics == false) {
      showSnackBarWarning(
          context: context, warning: "يجب الموافقة على سياسة الحجز للخدمة");
    } else {
      context
          .read<BookingsCommandBloc>()
          .add(ApprovalOfPolicyBookingOnlineEvent(
            approvalOfPolitics: approvalOfPolitics,
          ));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          title: Text("اضافة حجز"),
        ),
        body: BlocBuilder<BookingsCommandBloc, BookingsCommandState>(
          builder: (context, state) {
            if (state is LoadingState) {
              return CiracleLoadingWidget();
            } else if (state is ErrorState) {
              return Center(child: Text(state.message));
            } else if (state is EditingAddBookingOnlineState) {
              final service = state.service!;
              double? total = service.price!;
              double? deposit = total * 0.30;
              double? remaining = total - deposit;

              return SingleChildScrollView(
                child: Padding(
                  padding: EdgeInsets.all(defaultPadding),
                  child: Column(
                    spacing: defaultSpacing,
                    children: [
                      Text(
                        "تاكيد بيانات الحجز",
                        style: Theme.of(context).textTheme.bodyMedium,
                      ),

                      PrimaryContainer(
                        paddingVertical: 10,
                        child: Row(
                          spacing: defaultSpacing,
                          children: [
                            ViewSingleImageServiceSquireWidget(
                                serviceId: service.id!),
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text(service.store!.category!.name!,
                                    style: Theme.of(context)
                                        .textTheme
                                        .displaySmall),
                                SizedBox(height: 3),
                                Text(service.name!,
                                    style: Theme.of(context)
                                        .textTheme
                                        .titleMedium),
                                SizedBox(height: 5),
                                ViewStoreSmallWidget(
                                  storeId: service.store!.id!,
                                  storeName: service.store!.name!,
                                  storeLogo: service.store!.logo!,
                                  storeCity:
                                      service.store!.directorate!.city!.name!,
                                  storeDirectorateName:
                                      service.store!.directorate!.name!,
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),

                      // SecondaryContainer(
                      //   paddingHorizontal: 0,
                      //   paddingVertical: 0,
                      //   child: ListTile(
                      // leading: ViewSingleImageServiceSquireWidget(
                      //     serviceId: service.id!),
                      //     title: Text(
                      //       service.name.toString(),
                      //       style: Theme.of(context).textTheme.titleMedium,
                      //     ),
                      //     subtitle: Column(
                      //       crossAxisAlignment: CrossAxisAlignment.start,
                      //       children: [
                      //         Text(
                      //           service.store!.category!.name.toString(),
                      //           style: Theme.of(context).textTheme.displayMedium,
                      //         ),
                      // ViewStoreSmallWidget(
                      //   storeId: service.store!.id!,
                      //   storeName: service.store!.name!,
                      //   storeLogo: service.store!.logo!,
                      //   storeCity: service.store!.directorate!.city!.name!,
                      //   storeDirectorateName:
                      //       service.store!.directorate!.name!,
                      // ),
                      //       ],
                      //     ),
                      //   ),
                      // ),

                      ViewAmountBookingWidget(
                          total: total, deposit: deposit, remaining: remaining),
                      Row(
                        spacing: 5,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text("يحب دفع مبلغ"),
                          Text(
                            deposit.toString(),
                            style: Theme.of(context).textTheme.displayMedium,
                          ),
                          Text("لا تمام عملية الحجز"),
                        ],
                      ),
                      SecondaryContainer(
                        paddingHorizontal: 12,
                        paddingVertical: 8,
                        child: Column(
                          children: [
                            _listTile(
                              context: context,
                              info: service.peopleCount.toString(),
                              title: "عدد الاشخاص:",
                            ),
                            _listTile(
                              context: context,
                              info: service.duration.toString(),
                              title: "مدة الحجز:",
                            ),
                          ],
                        ),
                      ),
                      SecondaryContainer(
                        paddingHorizontal: 12,
                        paddingVertical: 8,
                        child: Column(
                          children: [
                            _listTile(
                              context: context,
                              info: "اسم العميل",
                              title: "اسم العميل:",
                            ),
                            _listTile(
                              context: context,
                              info: "رقم العميل",
                              title: "رقم العميل:",
                            ),
                          ],
                        ),
                      ),
                      SecondaryContainer(
                        paddingHorizontal: 12,
                        paddingVertical: 8,
                        child: Column(
                          children: [
                            _listTile(
                              context: context,
                              info: "${day.day} - ${day.month} - ${day.year}",
                              title: "تاريخ الحجز:",
                            ),
                            _listTile(
                              context: context,
                              info:
                                  "${state.selectedDate!.day} - ${state.selectedDate!.month} - ${state.selectedDate!.year}",
                              title: "تاريخ الطلب:",
                            ),
                            _listTile(
                              context: context,
                              info: state.note == null
                                  ? description
                                  : state.note!,
                              title: "الملاحظة:",
                            ),
                          ],
                        ),
                      ),
                      SecondaryContainer(
                        paddingHorizontal: 0,
                        paddingVertical: 0,
                        child: Directionality(
                          textDirection: TextDirection.ltr,
                          child: CheckboxListTile(
                            selectedTileColor: Theme.of(context)
                                .colorScheme
                                .primary
                                .withOpacity(0.20),
                            dense: true,
                            value: approvalOfPolitics,
                            title: Text(
                              textAlign: TextAlign.end,
                              "هل توافق على سياسة الحجز والالغاء؟",
                              style: Theme.of(context).textTheme.titleSmall,
                            ),
                            subtitle: GestureDetector(
                              onTap: () {
                                AppDialog.showCustomDialog(context: context);
                              },
                              child: Text(
                                textAlign: TextAlign.end,
                                "عرض سياسة الحجز والالغاء",
                                style: Theme.of(context).textTheme.displaySmall,
                              ),
                            ),
                            onChanged: (value) {
                              setState(() {
                                approvalOfPolitics = !approvalOfPolitics;
                              });
                            },
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              );
            } else {
              return CiracleLoadingWidget();
            }
          },
        ),
        bottomNavigationBar: TwoBottomItems(
          child1: PrimaryElevatedButton(
            onPressed: () {
              approvalOfPolicyBookingValid();
            },
            text: "دفع العربون",
          ),
          child2: SecondaryElevatedButton(
            onPressed: () {
              context
                  .read<BookingsCommandBloc>()
                  .add(CancelAddBookingOnlineEvent());
              // BlocProvider.of<BookingsCommandBloc>(context)
              //     .add(CancelAddBookingOnlineEvent());
            },
            text: "الغاء",
          ),
        ),
      ),
    );
  }

  Widget _listTile({
    required BuildContext context,
    required String info,
    required String title,
  }) {
    return Container(
      margin: const EdgeInsets.all(6),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            title,
            style: Theme.of(context).textTheme.labelMedium,
          ),
          Expanded(
            child: Text(
              info,
              softWrap: true,
              textAlign: TextAlign.end,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: Theme.of(context).textTheme.titleSmall,
            ),
          ),
        ],
      ),
    );
  }
  // ListTile _listTile({
  //   required BuildContext context,
  //   required String info,
  //   required String title,
  // }) {
  //   return ListTile(
  //     title: Text(
  //       title,
  //       style: Theme.of(context).textTheme.labelMedium,
  //     ),
  //     trailing: Text(
  //       info,
  //       style: Theme.of(context).textTheme.titleSmall,
  //     ),
  //     dense: true,
  //   );
  // }
}
