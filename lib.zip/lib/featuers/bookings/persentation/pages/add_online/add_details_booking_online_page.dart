import 'package:booking_v1/core/constants/strings.dart';
import 'package:booking_v1/core/widgets/calendar_widget.dart';
import 'package:booking_v1/core/widgets/ciracle_loading_widget.dart';
import 'package:booking_v1/core/widgets/container_widgets.dart';
import 'package:booking_v1/core/widgets/input_widgets.dart';
import 'package:booking_v1/core/widgets/snack_bar_widgets.dart';
import 'package:booking_v1/featuers/bookings/persentation/bloc/bookings_command/bookings_command_event.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../../../../core/widgets/bottom_items.dart';
import '../../../../../core/widgets/botton_widghts.dart';
import '../../bloc/bookings_command/bookings_command_bloc.dart';
import '../../bloc/bookings_command/bookings_command_state.dart';

class AddDetailsBookingOnlinePage extends StatefulWidget {
  const AddDetailsBookingOnlinePage({super.key});

  @override
  State<AddDetailsBookingOnlinePage> createState() =>
      _AddDetailsBookingOnlinePageState();
}

class _AddDetailsBookingOnlinePageState
    extends State<AddDetailsBookingOnlinePage> {
  TextEditingController descriptionController = TextEditingController();
  DateTime? selectedDate;
  final formKe = GlobalKey<FormState>();

  void addDetailsBookingValid() {
    if (selectedDate == null) {
      showSnackBarWarning(context: context, warning: "يجب تحديد تاريخ الحجز");
    } else {
      context.read<BookingsCommandBloc>().add(AddNoteAndDateOnlineEvent(
            note: descriptionController.text,
            selectedDate: selectedDate!,
          ));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          title: Text("اضافة حجز"),
        ),
        body: BlocBuilder<BookingsCommandBloc, BookingsCommandState>(
          builder: (context, state) {
            if (state is LoadingState) {
              return CiracleLoadingWidget();
            } else if (state is ErrorState) {
              return Center(child: Text(state.message));
            } else if (state is EditingAddBookingOnlineState) {
              return SingleChildScrollView(
                child: Padding(
                  padding: EdgeInsets.all(defaultPadding),
                  child: Form(
                    key: formKe,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      spacing: defaultSpacing,
                      children: [
                        Text(
                          "تحديد التاريخ",
                          style: Theme.of(context).textTheme.titleMedium,
                        ),
                        state.storeWallets != null
                            ? Text("${state.storeWallets!.length}",
                                style: Theme.of(context).textTheme.displaySmall)
                            : Text("data"),
                        Text(
                          state.service!.id.toString(),
                          style: Theme.of(context).textTheme.titleMedium,
                        ),
                        SecondaryContainer(
                          paddingHorizontal: 0,
                          paddingVertical: 0,
                          child: BookingCalendar(
                            bookedDates: state.bookingDates,
                            onDaySelected: (p0) {
                              setState(() {
                                selectedDate = p0;
                              });
                            },
                            selectable: true,
                          ),
                        ),
                        CustomInputFieldWidget(
                          label: "ملاحظة",
                          textController: descriptionController,
                          maxLength: 150,
                          maxLines: 2,
                          minLines: 1,
                          textInputType: TextInputType.text,
                        ),
                      ],
                    ),
                  ),
                ),
              );
            } else {
              return CiracleLoadingWidget();
            }
          },
        ),
        bottomNavigationBar: TwoBottomItems(
          child1: PrimaryElevatedButton(
            onPressed: () {
              addDetailsBookingValid();
            },
            text: "التالي",
          ),
          child2: SecondaryElevatedButton(
            onPressed: () {
              context
                  .read<BookingsCommandBloc>()
                  .add(CancelAddBookingOnlineEvent());
            },
            text: "الغاء",
          ),
        ),
      ),
    );
  }
}
