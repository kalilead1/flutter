// import 'package:booking_v1/core/constants/strings.dart';
// import 'package:booking_v1/core/routing/app_routes.dart';
// import 'package:booking_v1/core/routing/router_extensions.dart';
// import 'package:booking_v1/core/widgets/calendar_widget.dart';
// import 'package:booking_v1/core/widgets/container_widgets.dart';
// import 'package:booking_v1/core/widgets/input_widgets.dart';
// import 'package:flutter/material.dart';

// import '../../../../../core/widgets/bottom_items.dart';
// import '../../../../../core/widgets/botton_widghts.dart';
// import '../../../../services/domain/entities/service.dart';

// class AddDetailsBookingOnlineTestPage extends StatelessWidget {
//   final Service service;
//   const AddDetailsBookingOnlineTestPage({super.key, required this.service});

//   @override
//   Widget build(BuildContext context) {
//     List<DateTime> dates = [
//       DateTime(2026, 1, 22),
//       DateTime(2026, 1, 29),
//       DateTime(2026, 1, 10),
//     ];
//     // DateTime selectedDate;
//     TextEditingController descriptionController = TextEditingController();
//     return Directionality(
//       textDirection: TextDirection.rtl,
//       child: Scaffold(
//         appBar: AppBar(
//           title: Text("اضافة حجز"),
//         ),
//         body: SingleChildScrollView(
//           child: Padding(
//             padding: EdgeInsets.all(defaultPadding),
//             child: Column(
//               crossAxisAlignment: CrossAxisAlignment.start,
//               spacing: defaultSpacing,
//               children: [
//                 Text(
//                   "تحديد التاريخ",
//                   style: Theme.of(context).textTheme.titleMedium,
//                 ),
//                 SecondaryContainer(
//                   paddingHorizontal: 0,
//                   paddingVertical: 0,
//                   child: BookingCalendar(bookedDates: dates, selectable: true),
//                 ),
//                 CustomInputFieldWidget(
//                   label: "ملاحظة",
//                   textController: descriptionController,
//                   maxLength: 150,
//                   maxLines: 2,
//                   minLines: 1,
//                   textInputType: TextInputType.text,
//                 ),
//               ],
//             ),
//           ),
//         ),
//         bottomNavigationBar: TwoBottomItems(
//           child1: PrimaryElevatedButton(
//             onPressed: () {
//               context.pushTo(checkAddBookingRoute, extra: service);
//             },
//             text: "التالي",
//           ),
//           child2: SecondaryElevatedButton(
//             onPressed: () {
//               context.back();
//             },
//             text: "الغاء",
//           ),
//         ),
//       ),
//     );
//   }
// }
