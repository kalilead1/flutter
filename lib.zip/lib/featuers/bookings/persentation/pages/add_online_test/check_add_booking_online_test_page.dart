// import 'package:booking_v1/core/constants/strings.dart';
// import 'package:booking_v1/core/routing/app_routes.dart';
// import 'package:booking_v1/core/routing/router_extensions.dart';
// import 'package:booking_v1/core/widgets/container_widgets.dart';
// import 'package:booking_v1/core/widgets/dialog_widgets.dart';
// import 'package:booking_v1/featuers/services/persentation/widgets/view_image_service_widget.dart';
// import 'package:flutter/material.dart';

// import '../../../../../core/widgets/bottom_items.dart';
// import '../../../../../core/widgets/botton_widghts.dart';
// import '../../../../payments/persentation/pages/args/payment_booking_online_page_args.dart';
// import '../../../../payments/persentation/widgets/view_amount_booking_widget.dart';
// import '../../../../services/domain/entities/service.dart';
// import '../../../../stores/persentation/widgets/view_store_small.dart';

// class CheckAddBookingOnlineTestPage extends StatefulWidget {
//   final Service service;
//   const CheckAddBookingOnlineTestPage({super.key, required this.service});

//   @override
//   State<CheckAddBookingOnlineTestPage> createState() =>
//       _CheckAddBookingOnlineTestPageState();
// }

// class _CheckAddBookingOnlineTestPageState
//     extends State<CheckAddBookingOnlineTestPage> {
//   DateTime day = DateTime.now();
//   final String description =
//       " بيانات بيانات بيانات بيانات بيانات بيانات بيانات بيانات الوصف";
//   bool approvalOfPolitics = false;
//   @override
//   Widget build(BuildContext context) {
//     double total = widget.service.price!;
//     double deposit = total * 0.30;
//     double remaining = total - deposit;
//     return Directionality(
//       textDirection: TextDirection.rtl,
//       child: Scaffold(
//         appBar: AppBar(
//           title: Text("اضافة حجز"),
//         ),
//         body: SingleChildScrollView(
//           child: Padding(
//             padding: EdgeInsets.all(defaultPadding),
//             child: Column(
//               spacing: defaultSpacing,
//               children: [
//                 Text(
//                   "تاكيد بيانات الحجز",
//                   style: Theme.of(context).textTheme.bodyMedium,
//                 ),
//                 // ViewSingleImageServiceWidget(serviceId: service.id!),
//                 PrimaryContainer(
//                   child: Row(
//                     spacing: defaultSpacing,
//                     children: [
//                       ViewSingleImageServiceSquireWidget(
//                           serviceId: widget.service.id!),
//                       Column(
//                         crossAxisAlignment: CrossAxisAlignment.start,
//                         mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                         children: [
//                           Text(widget.service.store!.category!.name!,
//                               style: Theme.of(context).textTheme.displaySmall),
//                           SizedBox(height: 3),
//                           Text(widget.service.name!,
//                               style: Theme.of(context).textTheme.titleMedium),
//                           SizedBox(height: 5),
//                           ViewStoreSmallWidget(
//                             storeId: widget.service.store!.id!,
//                             storeName: widget.service.store!.name!,
//                             storeLogo: widget.service.store!.logo!,
//                             storeCity:
//                                 widget.service.store!.directorate!.city!.name!,
//                             storeDirectorateName:
//                                 widget.service.store!.directorate!.name!,
//                           ),
//                         ],
//                       ),
//                     ],
//                   ),
//                 ),
//                 // SecondaryContainer(
//                 //   paddingHorizontal: 0,
//                 //   paddingVertical: 0,
//                 //   child: ListTile(
//                 // leading: ViewSingleImageServiceSquireWidget(
//                 //     serviceId: service.id!),
//                 //     title: Text(
//                 //       service.name.toString(),
//                 //       style: Theme.of(context).textTheme.titleMedium,
//                 //     ),
//                 //     subtitle: Column(
//                 //       crossAxisAlignment: CrossAxisAlignment.start,
//                 //       children: [
//                 //         Text(
//                 //           service.store!.category!.name.toString(),
//                 //           style: Theme.of(context).textTheme.displayMedium,
//                 //         ),
//                 // ViewStoreSmallWidget(
//                 //   storeId: service.store!.id!,
//                 //   storeName: service.store!.name!,
//                 //   storeLogo: service.store!.logo!,
//                 //   storeCity: service.store!.directorate!.city!.name!,
//                 //   storeDirectorateName:
//                 //       service.store!.directorate!.name!,
//                 // ),
//                 //       ],
//                 //     ),
//                 //   ),
//                 // ),

//                 ViewAmountBookingWidget(
//                     total: total, deposit: deposit, remaining: remaining),
//                 Row(
//                   spacing: 5,
//                   mainAxisAlignment: MainAxisAlignment.center,
//                   children: [
//                     Text("يحب دفع مبلغ"),
//                     Text(
//                       deposit.toString(),
//                       style: Theme.of(context).textTheme.displayMedium,
//                     ),
//                     Text("لا تمام عملية الحجز"),
//                   ],
//                 ),
//                 SecondaryContainer(
//                   paddingHorizontal: 12,
//                   paddingVertical: 8,
//                   child: Column(
//                     children: [
//                       _listTile(
//                         context: context,
//                         info: widget.service.peopleCount.toString(),
//                         title: "عدد الاشخاص:",
//                       ),
//                       _listTile(
//                         context: context,
//                         info: widget.service.duration.toString(),
//                         title: "مدة الحجز:",
//                       ),
//                     ],
//                   ),
//                 ),
//                 SecondaryContainer(
//                   paddingHorizontal: 12,
//                   paddingVertical: 8,
//                   child: Column(
//                     children: [
//                       _listTile(
//                         context: context,
//                         info: "اسم العميل",
//                         title: "اسم العميل:",
//                       ),
//                       _listTile(
//                         context: context,
//                         info: "رقم العميل",
//                         title: "رقم العميل:",
//                       ),
//                     ],
//                   ),
//                 ),
//                 SecondaryContainer(
//                   paddingHorizontal: 12,
//                   paddingVertical: 8,
//                   child: Column(
//                     children: [
//                       _listTile(
//                         context: context,
//                         info: "${day.day} - ${day.month} - ${day.year}",
//                         title: "تاريخ الحجز:",
//                       ),
//                       _listTile(
//                         context: context,
//                         info: "${day.day + 3} - ${day.month} - ${day.year}",
//                         title: "تاريخ الطلب:",
//                       ),
//                       _listTile(
//                         context: context,
//                         info: description,
//                         title: "الملاحظة:",
//                       ),
//                     ],
//                   ),
//                 ),
//                 SecondaryContainer(
//                   paddingHorizontal: 0,
//                   paddingVertical: 0,
//                   child: Directionality(
//                     textDirection: TextDirection.ltr,
//                     child: CheckboxListTile(
//                       selectedTileColor: Theme.of(context)
//                           .colorScheme
//                           .primary
//                           .withOpacity(0.20),
//                       dense: true,
//                       value: approvalOfPolitics,
//                       title: Text(
//                         textAlign: TextAlign.end,
//                         "هل توافق على سياسة الحجز والالغاء؟",
//                         style: Theme.of(context).textTheme.titleSmall,
//                       ),
//                       subtitle: GestureDetector(
//                         onTap: () {
//                           AppDialog.showCustomDialog(context: context);
//                         },
//                         child: Text(
//                           textAlign: TextAlign.end,
//                           "عرض سياسة الحجز والالغاء",
//                           style: Theme.of(context).textTheme.displaySmall,
//                         ),
//                       ),
//                       onChanged: (value) {
//                         setState(() {
//                           approvalOfPolitics = !approvalOfPolitics;
//                         });
//                       },
//                     ),
//                   ),
//                 ),
//               ],
//             ),
//           ),
//         ),
//         bottomNavigationBar: TwoBottomItems(
//           child1: PrimaryElevatedButton(
//             onPressed: () {
//               // context.pushTo(checkAddBookingRoute, extra: widget.service);

//               context.pushTo(paymentBookingOnlineRoute,
//                   extra: PaymentBookingOnlinePageArgs(
//                     storeId: widget.service.storeId!,
//                     total: total,
//                     deposit: deposit,
//                     remaining: remaining,
//                   ));

//               // Navigator.push(
//               //     context,
//               //     MaterialPageRoute(
//               //         builder: (context) => GetAllWalletTestPage()));
//             },
//             text: "دفع العربون",
//           ),
//           child2: SecondaryElevatedButton(
//             onPressed: () {
//               context.back();
//             },
//             text: "الغاء",
//           ),
//         ),
//       ),
//     );
//   }

//   Widget _listTile({
//     required BuildContext context,
//     required String info,
//     required String title,
//   }) {
//     return Container(
//       margin: const EdgeInsets.all(6),
//       child: Row(
//         mainAxisAlignment: MainAxisAlignment.spaceBetween,
//         children: [
//           Text(
//             title,
//             style: Theme.of(context).textTheme.labelMedium,
//           ),
//           Expanded(
//             child: Text(
//               info,
//               softWrap: true,
//               textAlign: TextAlign.end,
//               maxLines: 1,
//               overflow: TextOverflow.ellipsis,
//               style: Theme.of(context).textTheme.titleSmall,
//             ),
//           ),
//         ],
//       ),
//     );
//   }
//   // ListTile _listTile({
//   //   required BuildContext context,
//   //   required String info,
//   //   required String title,
//   // }) {
//   //   return ListTile(
//   //     title: Text(
//   //       title,
//   //       style: Theme.of(context).textTheme.labelMedium,
//   //     ),
//   //     trailing: Text(
//   //       info,
//   //       style: Theme.of(context).textTheme.titleSmall,
//   //     ),
//   //     dense: true,
//   //   );
//   // }
// }
