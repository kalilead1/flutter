import 'package:booking_v1/core/constants/strings.dart';
import 'package:booking_v1/featuers/bookings/persentation/widgets/tab_bar_bookings_statues_wighets.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../../../dependency_injection/initial.dart';
import '../../../../tests/loading_test.dart';
import '../../../auth/persentation/widgets/view_login_widget.dart';
import '../bloc/bookings_query/bookings_query_bloc.dart';
import '../bloc/bookings_query/bookings_query_event.dart';
import '../bloc/bookings_query/bookings_query_state.dart';
import '../widgets/view_list_bookings_widget.dart';

class ViewUserBookingsPage extends StatefulWidget {
  const ViewUserBookingsPage({super.key});

  @override
  State<ViewUserBookingsPage> createState() => _ViewUserBookingsPageState();
}

class _ViewUserBookingsPageState extends State<ViewUserBookingsPage> {
  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (context) => getIt<BookingsQueryBloc>()
        ..addAndRemember(
          GetBookingsByUserIdEvent(userId: 4),
        ),
      child: BlocBuilder<BookingsQueryBloc, BookingsQueryState>(
        // listener: (context, state) {
        //   if (state is ErrorState) {
        //     if (state.message == noLoginFailureMessage) {
        //       return ViewLoginBottomSheetWidget(context: context);
        //     }
        //   }
        // },
        builder: (context, state) {
          if (state is LoadingState) {
            return Center(child: CircularProgressIndicator());
          } else if (state is ErrorState) {
            if (state.message == noLoginFailureMessage) {
              return ViewLoginWidget();
            }
            return Center(child: Text(state.message));
          } else if (state is LoadedAllBookingsState) {
            return DefaultTabController(
              length: 7,
              child: Directionality(
                textDirection: TextDirection.rtl,
                child: CustomRefresh(
                  onRefresh: () async {
                    context
                        .read<BookingsQueryBloc>()
                        .add(RefreshGetBookingsByUserIdEvent(userId: 4));
                  },
                  child: Scaffold(
                    appBar: AppBar(
                      toolbarHeight: 40,
                      // flexibleSpace: Padding(
                      //   padding: const EdgeInsets.symmetric(
                      //       horizontal: defaultPadding),
                      //   child: SearchForm(),
                      // ),
                      bottom: PreferredSize(
                        preferredSize: Size.fromHeight(0),
                        child: TabBarBookingsStatuesWighets(),
                      ),
                    ),
                    // appBar: AppBar(
                    //   toolbarHeight: 100,
                    //   flexibleSpace: Padding(
                    //     padding: const EdgeInsets.symmetric(
                    //         horizontal: defaultPadding),
                    //     child: SearchForm(),
                    //   ),
                    //   bottom: PreferredSize(
                    //     preferredSize: Size.fromHeight(0),
                    //     child: TabBarBookingsStatuesWighets(),
                    //   ),
                    // ),
                    body: TabBarView(
                      children: [
                        ViewListBookingsWidget(bookings: state.allBookings),
                        ViewListBookingsWidget(
                            bookings: state.pendingPaymentBookings),
                        ViewListBookingsWidget(
                            bookings: state.perliminaryBookings),
                        ViewListBookingsWidget(
                            bookings: state.confirmedBookings),
                        ViewListBookingsWidget(
                            bookings: state.cancelledBookings),
                        ViewListBookingsWidget(
                            bookings: state.rejectedBookings),
                        ViewListBookingsWidget(
                            bookings: state.completedBookings),
                      ],
                    ),
                  ),
                ),
              ),
            );
          } else {
            return Center(child: Text(unknownFailureMessage));
          }
        },
      ),
    );
  }
}

// /////////////////////////////////////////////////////////////////////////

// class Booking extends Equatable {
//   final int? id;
//   final int? serviceId;
//   final Service? service;
//   final int? userId;
//   final User? user;
//   final BookingsStatuesEnum? bookingStateEnum;
//   final BookingMethodEnum? bookingMethodEnem;
//   final DateTime? bookingDate;
//   final String? note;
//   final bool? acceptedAllPolicies;
//   final bool isRating;
//   final DateTime? createdAt;

//   const Booking({
//     this.id,
//     this.serviceId,
//     this.service,
//     this.userId,
//     this.user,
//     this.bookingStateEnum,
//     this.bookingMethodEnem,
//     this.bookingDate,
//     this.note,
//     this.acceptedAllPolicies,
//     this.isRating = false,
//     this.createdAt,
//   });

//   @override
//   List<Object?> get props => [
//         id,
//         serviceId,
//         service,
//         userId,
//         user,
//         bookingStateEnum,
//         bookingMethodEnem,
//         bookingDate,
//         note,
//         acceptedAllPolicies,
//         isRating,
//         createdAt,
//       ];
// }
// ///////////////////////////////////////////////////////////////////////////

// class BookingModel extends Booking {
//   const BookingModel({
//     super.id,
//     super.serviceId,
//     super.service,
//     super.userId,
//     super.user,
//     super.bookingStateEnum,
//     super.bookingMethodEnem,
//     super.bookingDate,
//     super.note,
//     super.acceptedAllPolicies,
//     super.isRating = false,
//     super.createdAt,
//   });

//   factory BookingModel.fromJson(Map<String, dynamic> json) {
//     return BookingModel(
//       id: json['id'],
//       serviceId: json['serviceId'],
//       service: json['service'] != null
//           ? ServiceModel.fromJson(json['service'])
//           : null,
//       userId: json['userId'],
//       user: json['user'] != null ? UserModel.fromJson(json['user']) : null,
//       bookingStateEnum:
//           BookingsStatuesEnumExtension.fromValue(json['bookingState']),
//       bookingMethodEnem:
//           BookingMethodEnumExtension.fromValue(json['bookingMethod']),
//       bookingDate: DateTime.parse(json['bookingDate']),
//       // bookingDate: json['bookingDate'],
//       note: json['note'],
//       acceptedAllPolicies: json['acceptedAllPolicies'],
//       isRating: json['isRating'],
//       createdAt: DateTime.parse(json['createdAt']),
//     );
//   }
//   Map<String, dynamic> toJson() => {
//         "id": id,
//         'serviceId': serviceId,
//         'userId': userId,
//         'bookingState': bookingStateEnum!.value,
//         'bookingMethod': bookingMethodEnem!.value,
//         'bookingDate': bookingDate!.toIso8601String(),
//         'note': note,
//         'acceptedAllPolicies': acceptedAllPolicies,
//         'isRating': isRating,
//       };
// }

// //////////////////////////////////////////////////////////////////////////////

// abstract class BookingsRepository {
//   Future<Either<Failure, List<Booking>>> getBookingsByUserId(
//     int userId,
//     BookingsStatuesEnum? bookingState,
//   );
// }

// //////////////////////////////////////////////////////////////////////////////
// class GetBookingsByUserIdUsecase {
//   final BookingsRepository repository;

//   GetBookingsByUserIdUsecase(this.repository);

//   Future<Either<Failure, List<Booking>>> call(
//       int userId, BookingsStatuesEnum? bookingState) async {
//     return await repository.getBookingsByUserId(userId, bookingState);
//   }
// }
// //////////////////////////////////////////////////////////////////////////////

// class BookingsRepositoryImpl implements BookingsRepository {
//   final BookingsRemoteDataSource bookingsRemoteDataSource;
//   final NetworkInfo networkInfo;

//   BookingsRepositoryImpl({
//     required this.bookingsRemoteDataSource,
//     required this.networkInfo,
//   });

//   @override
//   Future<Either<Failure, List<Booking>>> getBookingsByUserId(
//       int userId, BookingsStatuesEnum? bookingState) async {
//     final userYes = false;
//     // if (await networkInfo.isConnected) {
//     if (userYes == true) {
//       try {
//         final remoteService = await bookingsRemoteDataSource
//             .getBookingsByUserId(userId, bookingState);
//         // return Right(remoteWallet);
//         if (remoteService.isEmpty) {
//           return Left(EmptyCacheFailure());
//         } else {
//           return Right(remoteService);
//         }
//       } on ServerException {
//         return Left(ServerFailure());
//       }
//     } else {
//       return Left(NoLoginFailure());
//     }
//     // } else {
//     //   return Left(OfflineFailure());
//     // }
//   }
// }

// //////////////////////////////////////////////////////////////////////////////
// abstract class BookingsRemoteDataSource {
//   Future<List<Booking>> getBookingsByUserId(
//       int userId, BookingsStatuesEnum? bookingState);
//   Future<List<Booking>> getBookingsByStoreId(
//       int storeId, BookingsStatuesEnum? bookingState);
//   Future<List<Booking>> getBookingsByServiceId(
//       int serviceId, BookingsStatuesEnum? bookingState);
//   Future<List<DateTime>> getBookingDateByServiceId(int serviceId);
//   Future<Booking> getBookingById(int id);
//   Future<int> addBooking(BookingModel bookingModel);
// }

// const String bookingsUrl = "Bookings/";

// class BookingsRemoteDataSourceImpl implements BookingsRemoteDataSource {
//   final http.Client client;

//   BookingsRemoteDataSourceImpl({required this.client});

//   @override
//   Future<List<Booking>> getBookingsByUserId(
//       int userId, BookingsStatuesEnum? bookingState) async {
//     final String url;
//     if (bookingState != null) {
//       url = "ByUserId/$userId?stateEnum=${bookingState.value}";
//     } else {
//       url = "ByUserId/$userId";
//     }
//     final response = await client.get(Uri.parse(baseUrl + bookingsUrl + url));
//     if (response.statusCode == 200) {
//       List jsonResponse = json.decode(response.body);
//       return jsonResponse.map((get) => BookingModel.fromJson(get)).toList();
//     } else {
//       throw ServerException();
//     }
//   }
// }
// //////////////////////////////////////////////////////////////////////////////

// class BookingsQueryBloc extends Bloc<BookingsQueryEvent, BookingsQueryState>
//     with AutoRefreshBloc<BookingsQueryEvent, BookingsQueryState> {
//   final GetBookingsByUserIdUsecase? getBookingsByUserIdUsecase;

//   BookingsQueryBloc({this.getBookingsByUserIdUsecase}) : super(InitialState()) {
//     setupAutoRefresh<BookingChangedEvent>();

//     on<GetBookingsByUserIdEvent>((event, emit) async {
//       emit(LoadingState());

//       final failureOrBookings =
//           await getBookingsByUserIdUsecase!(event.userId, event.bookingState);
//       emit(_mapFailureOrGetBookings(failureOrBookings));
//     });
//     /////////////////////////////// Refresh /////////////////////////////////
//     on<RefreshGetBookingsByUserIdEvent>((event, emit) async {
//       emit(LoadingState());

//       final failureOrBookings =
//           await getBookingsByUserIdUsecase!(event.userId, event.bookingState);
//       emit(_mapFailureOrGetBookings(failureOrBookings));
//     });
//   }

//   BookingsQueryState _mapFailureOrGetBookings(
//       Either<Failure, List<Booking>> either) {
//     return either.fold(
//       (failure) => ErrorState(message: failureToMessage(failure)),
//       (bookings) => LoadedState(bookings: bookings),
//     );
//   }
// }

// abstract class BookingsQueryEvent extends Equatable {
//   const BookingsQueryEvent();
//   @override
//   List<Object?> get props => [];
// }

// class GetBookingsByUserIdEvent extends BookingsQueryEvent {
//   final int userId;
//   final BookingsStatuesEnum? bookingState;
//   const GetBookingsByUserIdEvent({required this.userId, this.bookingState});

//   @override
//   List<Object?> get props => [userId, bookingState];
// }

// class RefreshGetBookingsByUserIdEvent extends BookingsQueryEvent {
//   final int userId;
//   final BookingsStatuesEnum? bookingState;
//   const RefreshGetBookingsByUserIdEvent(
//       {required this.userId, this.bookingState});

//   @override
//   List<Object?> get props => [userId, bookingState];
// }

// abstract class BookingsQueryState extends Equatable {
//   const BookingsQueryState();
//   @override
//   List<Object?> get props => [];
// }

// class InitialState extends BookingsQueryState {}

// class LoadingState extends BookingsQueryState {}

// class LoadedState extends BookingsQueryState {
//   final List<Booking> bookings;

//   const LoadedState({required this.bookings});

//   @override
//   List<Object?> get props => [bookings];
// }

// class ErrorState extends BookingsQueryState {
//   final String message;

//   const ErrorState({required this.message});

//   @override
//   List<Object?> get props => [message];
// }

// //////////////////////////////////////////////////////////////////////////////

// class ViewUserBookingsPage extends StatefulWidget {
//   const ViewUserBookingsPage({super.key});

//   @override
//   State<ViewUserBookingsPage> createState() => _ViewUserBookingsPageState();
// }

// class _ViewUserBookingsPageState extends State<ViewUserBookingsPage> {
//   @override
//   Widget build(BuildContext context) {
//     return DefaultTabController(
//       length: 7,
//       child: Directionality(
//         textDirection: TextDirection.rtl,
//         child: Scaffold(
//           appBar: AppBar(
//             toolbarHeight: 100,
//             flexibleSpace: Padding(
//               padding: const EdgeInsets.symmetric(horizontal: defaultPadding),
//               child: SearchForm(),
//             ),
//             bottom: PreferredSize(
//               preferredSize: Size.fromHeight(0),
//               child: TabBarBookingsStatuesWighets(),
//             ),
//           ),
//           body: TabBarViewBookingsStatuesWighets(
//             userId: 4,
//           ),
//         ),
//       ),
//     );
//   }
// }

// class TabBarBookingsStatuesWighets extends StatelessWidget {
//   const TabBarBookingsStatuesWighets({super.key});

//   @override
//   Widget build(BuildContext context) {
//     return TabBar(
//       padding: EdgeInsets.only(bottom: defaultPadding / 4),
//       isScrollable: true,
//       tabs: [
//         Text("الكل"),
//         Text("التحقق من الدفع"),
//         Text("حجز مبدئي"),
//         Text("حجز نهائي"),
//         Text("حجز ملغي"),
//         Text("حجز مرفوض"),
//         Text("حجز منتهي"),
//       ],
//     );
//   }
// }

// class TabBarViewBookingsStatuesWighets extends StatelessWidget {
//   final int? userId;
//   final int? storeId;
//   final int? serviceId;
//   const TabBarViewBookingsStatuesWighets({
//     super.key,
//     this.userId,
//     this.storeId,
//     this.serviceId,
//   });

//   @override
//   Widget build(BuildContext context) {
//     return TabBarView(
//       children: [
//         ViewListUserBookingsWidget(userId: userId!),
//         ViewListUserBookingsWidget(
//             userId: userId!, bookingsState: BookingsStatuesEnum.pendingPayment),
//         ViewListUserBookingsWidget(
//             userId: userId!, bookingsState: BookingsStatuesEnum.perliminary),
//         ViewListUserBookingsWidget(
//             userId: userId!, bookingsState: BookingsStatuesEnum.confirmed),
//         ViewListUserBookingsWidget(
//             userId: userId!, bookingsState: BookingsStatuesEnum.cancelled),
//         ViewListUserBookingsWidget(
//             userId: userId!, bookingsState: BookingsStatuesEnum.rejected),
//         ViewListUserBookingsWidget(
//             userId: userId!, bookingsState: BookingsStatuesEnum.completed),
//       ],
//     );
//   }
// }

// class ViewListUserBookingsWidget extends StatelessWidget {
//   final int userId;
//   final BookingsStatuesEnum? bookingsState;
//   const ViewListUserBookingsWidget({
//     super.key,
//     required this.userId,
//     this.bookingsState,
//   });

//   @override
//   Widget build(BuildContext context) {
//     return BlocProvider(
//       create: (context) => getIt<BookingsQueryBloc>()
//         ..addAndRemember(
//           GetBookingsByUserIdEvent(userId: userId, bookingState: bookingsState),
//         ),
//       child: BlocBuilder<BookingsQueryBloc, BookingsQueryState>(
//         builder: (context, state) {
//           if (state is LoadingState) {
//             return CiracleLoadingWidget();
//           } else if (state is LoadedState) {
//             return CustomRefresh(
//               onRefresh: () async {
//                 BlocProvider.of<BookingsQueryBloc>(context).add(
//                     RefreshGetBookingsByUserIdEvent(
//                         userId: userId, bookingState: bookingsState));
//               },
//               child: CustomScrollView(
//                 slivers: [
//                   SliverList(
//                     delegate: SliverChildBuilderDelegate(
//                       // semanticIndexOffset: 10,
//                       childCount: state.bookings.length,
//                       (context, index) {
//                         final booking = state.bookings[index];
//                         return Container(
//                           margin: EdgeInsets.symmetric(
//                             horizontal: defaultPadding,
//                             vertical: defaultPadding / 2,
//                           ),
//                           child: ViewUserBookingWighet(booking: booking),
//                         );
//                       },
//                     ),
//                   ),
//                 ],
//               ),
//             );
//           } else if (state is ErrorState) {
//             return Center(child: Text(state.message));
//           } else {
//             return CiracleLoadingWidget();
//           }
//         },
//       ),
//     );
//   }
// }

// class ViewUserBookingWighet extends StatelessWidget {
//   final Booking booking;
//   const ViewUserBookingWighet({required this.booking, super.key});

//   @override
//   Widget build(BuildContext context) {
//     return SecondaryContainer(
//       child: GestureDetector(
//         onTap: () {
//           context.pushTo(
//             viewBookingDetailsRoute,
//             extra:
//                 ViewBookingDetailsArgs(bookingId: booking.id!, forStore: false),
//           );
//         },
//         child: SizedBox(
//           height: 70,
//           child: Row(
//             spacing: defaultSpacing,
//             mainAxisAlignment: MainAxisAlignment.spaceBetween,
//             children: [
//               Row(
//                 spacing: defaultSpacing,
//                 crossAxisAlignment: CrossAxisAlignment.center,
//                 children: [
//                   ViewSingleImageServiceSquireWidget(
//                       serviceId: booking.service!.id!),
//                   Column(
//                     crossAxisAlignment: CrossAxisAlignment.start,
//                     mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                     children: [
//                       Text(booking.service!.store!.category!.name!,
//                           style: Theme.of(context).textTheme.displaySmall),
//                       Text(booking.service!.name!,
//                           style: Theme.of(context).textTheme.titleMedium),

//                       ViewStoreSmallWidget(
//                         storeId: booking.service!.store!.id!,
//                         storeName: booking.service!.store!.name!,
//                         storeLogo: booking.service!.store!.logo!,
//                       ),
//                     ],
//                   ),
//                 ],
//               ),
//               Column(
//                 mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                 crossAxisAlignment: CrossAxisAlignment.end,
//                 mainAxisSize: MainAxisSize.max,
//                 children: [
//                   ViewSmallBookingStateWidget(
//                     bookingsState: booking.bookingStateEnum!,
//                   ),
//                   Text(
//                       "${booking.bookingDate!.day} - ${booking.bookingDate!.month} - ${booking.bookingDate!.year}",
//                       style: Theme.of(context).textTheme.bodySmall),
//                 ],
//               ),
//             ],
//           ),
//         ),
//       ),
//     );
//   }
// }
