import 'package:dartz/dartz.dart';

import '../../../../../core/errors/failures.dart';
import '../entities/booking.dart';
import '../enums/bookings_statues_enum.dart';
import '../repositories/bookings_repository.dart';

class GetBookingsByUserIdUsecase {
  final BookingsRepository repository;

  GetBookingsByUserIdUsecase(this.repository);

  Future<Either<Failure, List<Booking>>> call(
      int userId, BookingsStatuesEnum? bookingState) async {
    return await repository.getBookingsByUserId(userId, bookingState);
  }
}

class GetBookingsByStoreIdUsecase {
  final BookingsRepository repository;

  const GetBookingsByStoreIdUsecase(this.repository);

  Future<Either<Failure, List<Booking>>> call(
      int storeId, BookingsStatuesEnum? bookingState) async {
    return await repository.getBookingsByStoreId(storeId, bookingState);
  }
}

class GetBookingsByServiceIdUsecase {
  final BookingsRepository repository;

  const GetBookingsByServiceIdUsecase(this.repository);

  Future<Either<Failure, List<Booking>>> call(
      int serviceId, BookingsStatuesEnum? bookingState) async {
    return await repository.getBookingsByServiceId(serviceId, bookingState);
  }
}

class GetBookingsDatesByServiceIdUsecase {
  final BookingsRepository repository;

  const GetBookingsDatesByServiceIdUsecase(this.repository);

  Future<Either<Failure, List<DateTime>>> call(int serviceId) async {
    return await repository.getBookingDateByServiceId(serviceId);
  }
}

class GetBookingByIdUsecase {
  final BookingsRepository repository;

  GetBookingByIdUsecase(this.repository);

  Future<Either<Failure, Booking>> call(int id) async {
    return await repository.getBookingById(id);
  }
}

class AddBookingUsecase {
  final BookingsRepository repository;

  AddBookingUsecase(this.repository);

  Future<Either<Failure, int>> call(Booking booking) async {
    return await repository.addBooking(booking);
  }
}
