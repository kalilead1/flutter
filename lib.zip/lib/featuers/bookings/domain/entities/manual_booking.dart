import 'package:equatable/equatable.dart';

class ManualBooking extends Equatable {
  final int? id;
  final int? bookingId;
  final String? customerName;
  final String? customerPhone;
  final bool isLogin;

  const ManualBooking({
    this.id,
    this.bookingId,
    this.customerName,
    this.customerPhone,
    this.isLogin = false,
  });

  @override
  List<Object?> get props => [
        id,
        bookingId,
        customerName,
        customerPhone,
        isLogin,
      ];
}
