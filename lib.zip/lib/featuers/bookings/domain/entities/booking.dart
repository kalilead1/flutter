import 'package:booking_v1/featuers/bookings/domain/enums/booking_method_enum.dart';
import 'package:booking_v1/featuers/bookings/domain/enums/bookings_statues_enum.dart';
import 'package:equatable/equatable.dart';

import '../../../auth/domain/entities/user.dart';
import '../../../services/domain/entities/service.dart';

class Booking extends Equatable {
  final int? id;
  final int? serviceId;
  final Service? service;
  final int? userId;
  final User? user;
  final BookingsStatuesEnum? bookingStateEnum;
  final BookingMethodEnum? bookingMethodEnem;
  final DateTime? bookingDate;
  final String? note;
  final bool? acceptedAllPolicies;
  final bool isRating;
  final DateTime? createdAt;

  const Booking({
    this.id,
    this.serviceId,
    this.service,
    this.userId,
    this.user,
    this.bookingStateEnum,
    this.bookingMethodEnem,
    this.bookingDate,
    this.note,
    this.acceptedAllPolicies,
    this.isRating = false,
    this.createdAt,
  });

  @override
  List<Object?> get props => [
        id,
        serviceId,
        service,
        userId,
        user,
        bookingStateEnum,
        bookingMethodEnem,
        bookingDate,
        note,
        acceptedAllPolicies,
        isRating,
        createdAt,
      ];
}
