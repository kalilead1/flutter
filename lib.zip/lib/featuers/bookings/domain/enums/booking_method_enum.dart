enum BookingMethodEnum {
  onlineBooking, // حجز الكتروني
  manualBooking, // حجز يدوي
}

extension BookingMethodEnumExtension on BookingMethodEnum {
  String get arabicName {
    switch (this) {
      case BookingMethodEnum.onlineBooking:
        return 'حجز الكتروني';
      case BookingMethodEnum.manualBooking:
        return 'حجز يدوي';
    }
  }

  int get value {
    switch (this) {
      case BookingMethodEnum.onlineBooking:
        return 1;
      case BookingMethodEnum.manualBooking:
        return 2;
    }
  }

  static BookingMethodEnum fromValue(int value) {
    switch (value) {
      case 1:
        return BookingMethodEnum.onlineBooking;
      case 2:
        return BookingMethodEnum.manualBooking;
      default:
        throw Exception('لا يوجد طريقة حجز');
    }
  }
}
