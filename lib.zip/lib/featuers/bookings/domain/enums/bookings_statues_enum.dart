import 'package:booking_v1/core/constants/colors.dart';
import 'package:flutter/material.dart';

enum BookingsStatuesEnum {
  pendingPayment, // التحقق من دفع العربون
  perliminary, // حجز مبدئي
  confirmed, // حجز نهائي
  cancelled, // حجز ملغي
  rejected, // حجز مرفوض
  completed, // حجز منتهي
}

extension BookingsStatuesEnumExtension on BookingsStatuesEnum {
  String get arabicName {
    switch (this) {
      case BookingsStatuesEnum.pendingPayment:
        return 'التحقق من الدفع';
      case BookingsStatuesEnum.perliminary:
        return 'حجز مبدئي';
      case BookingsStatuesEnum.confirmed:
        return 'حجز نهائي';
      case BookingsStatuesEnum.cancelled:
        return 'حجز ملغي';
      case BookingsStatuesEnum.rejected:
        return 'حجز مرفوض';
      case BookingsStatuesEnum.completed:
        return 'حجز منتهي';
    }
  }

  String get description {
    switch (this) {
      case BookingsStatuesEnum.pendingPayment:
        return 'جاري التحقق من الدفع، سيتم ابلاغك في اقرب وقت';
      case BookingsStatuesEnum.perliminary:
        return 'يجب دفع المبلغ المتبقي لتاكيد الحجز النهائي';
      case BookingsStatuesEnum.confirmed:
        return 'تم الحجز النهائي';
      case BookingsStatuesEnum.cancelled:
        return 'لقد تم الغاء الحجز';
      case BookingsStatuesEnum.rejected:
        return 'لقد قام مزود الخدمة برفض الحجز';
      case BookingsStatuesEnum.completed:
        return 'لقد انتهاء مدة الحجز المحددة';
    }
  }

  int get value {
    switch (this) {
      case BookingsStatuesEnum.pendingPayment:
        return 1;
      case BookingsStatuesEnum.perliminary:
        return 2;
      case BookingsStatuesEnum.confirmed:
        return 3;
      case BookingsStatuesEnum.cancelled:
        return 4;
      case BookingsStatuesEnum.rejected:
        return 5;
      case BookingsStatuesEnum.completed:
        return 6;
    }
  }

  static BookingsStatuesEnum fromValue(int value) {
    switch (value) {
      case 1:
        return BookingsStatuesEnum.pendingPayment;
      case 2:
        return BookingsStatuesEnum.perliminary;
      case 3:
        return BookingsStatuesEnum.confirmed;
      case 4:
        return BookingsStatuesEnum.cancelled;
      case 5:
        return BookingsStatuesEnum.rejected;
      case 6:
        return BookingsStatuesEnum.completed;
      default:
        throw Exception('لا يوجد حالة حجز');
    }
  }

  static BookingsStatuesEnum get(int value) {
    switch (value) {
      case 1:
        return BookingsStatuesEnum.pendingPayment;
      case 2:
        return BookingsStatuesEnum.perliminary;
      case 3:
        return BookingsStatuesEnum.confirmed;
      case 4:
        return BookingsStatuesEnum.cancelled;
      case 5:
        return BookingsStatuesEnum.rejected;
      case 6:
        return BookingsStatuesEnum.completed;
      default:
        throw Exception('لا يوجد حالة حجز');
    }
  }
}

Color getBookingStateBackgroundColor(
    BookingsStatuesEnum bookingsState, BuildContext context) {
  if (bookingsState == BookingsStatuesEnum.pendingPayment) {
    return warningColor.withOpacity(0.3);
  }
  if (bookingsState == BookingsStatuesEnum.perliminary ||
      bookingsState == BookingsStatuesEnum.confirmed) {
    return successColor.withOpacity(0.3);
  }
  if (bookingsState == BookingsStatuesEnum.rejected ||
      bookingsState == BookingsStatuesEnum.cancelled) {
    return errorColor.withOpacity(0.3);
  }
  if (bookingsState == BookingsStatuesEnum.completed) {
    return Theme.of(context).colorScheme.primary.withOpacity(0.3);
  } else {
    return Colors.purpleAccent.withOpacity(0.4);
  }
}

Color getBookingStateBorderColor(
    BookingsStatuesEnum bookingsState, BuildContext context) {
  if (bookingsState == BookingsStatuesEnum.pendingPayment) {
    return warningColor.withOpacity(0.6);
  }
  if (bookingsState == BookingsStatuesEnum.perliminary ||
      bookingsState == BookingsStatuesEnum.confirmed) {
    return successColor.withOpacity(0.6);
  }
  if (bookingsState == BookingsStatuesEnum.rejected ||
      bookingsState == BookingsStatuesEnum.cancelled) {
    return errorColor.withOpacity(0.6);
  }
  if (bookingsState == BookingsStatuesEnum.completed) {
    return Theme.of(context).colorScheme.primary.withOpacity(0.6);
  } else {
    return Colors.purpleAccent.withOpacity(0.7);
  }
}
// extension BookingsStatuesEnumExtension on BookingsStatuesEnum {
// String get arabicName {
//   switch (this) {
//     case BookingsStatuesEnum.pendingPayment:
//       return 'التحقق من الدفع';
//     case BookingsStatuesEnum.perliminary:
//       return 'حجز مبدئي';
//     case BookingsStatuesEnum.confirmed:
//       return 'حجز نهائي';
//     case BookingsStatuesEnum.cancelled:
//       return 'حجز ملغي';
//     case BookingsStatuesEnum.rejected:
//       return 'حجز مرفوض';
//     case BookingsStatuesEnum.completed:
//       return 'حجز منتهي';
//   }
// }

// int get value {
//   switch (this) {
//     case BookingsStatuesEnum.pendingPayment:
//       return 1;
//     case BookingsStatuesEnum.perliminary:
//       return 2;
//     case BookingsStatuesEnum.confirmed:
//       return 3;
//     case BookingsStatuesEnum.cancelled:
//       return 4;
//     case BookingsStatuesEnum.rejected:
//       return 5;
//     case BookingsStatuesEnum.completed:
//       return 6;
//   }
// }

//   // Color get color {
//   //   switch (this) {
//   //     case BookingsStatuesEnum.chachPayment:
//   //       return warningColor.withOpacity(0.3);
//   //     case BookingsStatuesEnum.initialBooking:
//   //       return successColor.withOpacity(0.3);
//   //     case BookingsStatuesEnum.finalBooking:
//   //       return successColor.withOpacity(0.3);
//   //     case BookingsStatuesEnum.cancelBooking:
//   //       return errorColor.withOpacity(0.3);
//   //     case BookingsStatuesEnum.rejectedBooking:
//   //       return errorColor.withOpacity(0.3);
//   //     case BookingsStatuesEnum.finishedBooking:
//   //       return Brightness.dark == true ? Colors.black: ;
//   //   }
//   // }
// }

// // BookingsStatuesEnum bookingsStatuesEnumFromInt(int va)

// الدالة لتحويل الرقم إلى النص العربي
// String getBookingStateNameByValue(int value) {
//   if (value == BookingsStatuesEnum.pendingPayment.value) {
//     return 'التحقق من الدفع';
//   }
//   if (value == BookingsStatuesEnum.perliminary.value) {
//     return 'حجز مبدئي';
//   }
//   if (value == BookingsStatuesEnum.confirmed.value) {
//     return 'حجز نهائي';
//   }
//   if (value == BookingsStatuesEnum.cancelled.value) {
//     return 'حجز ملغي';
//   }
//   if (value == BookingsStatuesEnum.rejected.value) {
//     return 'حجز مرفوض';
//   }
//   if (value == BookingsStatuesEnum.completed.value) {
//     return 'حجز منتهي';
//   } else {
//     return 'لا يوجد حالة حجز';
//   }
// }

// String getBookingStateNameByValue(int value) {
//   final type = BookingsStatuesEnum.values.firstWhere(
//     (type) => type.value == value,
//     orElse: () => throw Exception('لا يوجد حالة حجز'),
//   );
//   return type.arabicName;
// }

// الدالة لتحويل الرقم إلى النص العربي
// String getBookingStateNameByValue(int value) {
//   if (value == BookingsStatuesEnum.pendingPayment.value) {
//     return 'التحقق من الدفع';
//   }
//   if (value == BookingsStatuesEnum.perliminary.value) {
//     return 'حجز مبدئي';
//   } else {
//     return ;
//   }
// }
