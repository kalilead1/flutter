import 'package:dartz/dartz.dart';

import '../../../../core/errors/failures.dart';
import '../entities/booking.dart';
import '../enums/bookings_statues_enum.dart';

abstract class BookingsRepository {
  Future<Either<Failure, List<Booking>>> getBookingsByUserId(
    int userId,
    BookingsStatuesEnum? bookingState,
  );
  Future<Either<Failure, List<Booking>>> getBookingsByStoreId(
    int storeId,
    BookingsStatuesEnum? bookingState,
  );
  Future<Either<Failure, List<Booking>>> getBookingsByServiceId(
    int serviceId,
    BookingsStatuesEnum? bookingState,
  );
  Future<Either<Failure, List<DateTime>>> getBookingDateByServiceId(
      int serviceId);
  Future<Either<Failure, Booking>> getBookingById(int id);
  Future<Either<Failure, int>> addBooking(Booking booking);
}
