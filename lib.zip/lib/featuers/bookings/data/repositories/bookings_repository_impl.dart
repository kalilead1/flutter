import 'package:booking_v1/core/errors/exception.dart';
import 'package:booking_v1/core/errors/failures.dart';
import 'package:booking_v1/core/network/network_info.dart';
import 'package:dartz/dartz.dart';

import '../../domain/entities/booking.dart';
import '../../domain/enums/bookings_statues_enum.dart';
import '../../domain/repositories/bookings_repository.dart';
import '../datasources/bookings_remote_data_source.dart';
import '../models/booking_model.dart';

class BookingsRepositoryImpl implements BookingsRepository {
  final BookingsRemoteDataSource bookingsRemoteDataSource;
  final NetworkInfo networkInfo;

  BookingsRepositoryImpl({
    required this.bookingsRemoteDataSource,
    required this.networkInfo,
  });

  @override
  Future<Either<Failure, List<Booking>>> getBookingsByUserId(
      int userId, BookingsStatuesEnum? bookingState) async {
    final userYes = false;
    // if (await networkInfo.isConnected) {
    if (userYes == true) {
      try {
        final remoteService = await bookingsRemoteDataSource
            .getBookingsByUserId(userId, bookingState);
        // return Right(remoteWallet);
        if (remoteService.isEmpty) {
          return Left(EmptyCacheFailure());
        } else {
          return Right(remoteService);
        }
      } on ServerException {
        return Left(ServerFailure());
      }
    } else {
      return Left(NoLoginFailure());
    }
    // } else {
    //   return Left(OfflineFailure());
    // }
  }

  @override
  Future<Either<Failure, List<Booking>>> getBookingsByStoreId(
      int storeId, BookingsStatuesEnum? bookingState) async {
    // if (await networkInfo.isConnected) {
    try {
      final remoteService = await bookingsRemoteDataSource.getBookingsByStoreId(
          storeId, bookingState);
      if (remoteService.isEmpty) {
        return Left(EmptyCacheFailure());
      } else {
        return Right(remoteService);
      }
    } on ServerException {
      return Left(ServerFailure());
    }
    // } else {
    //   return Left(OfflineFailure());
    // }
  }

  @override
  Future<Either<Failure, List<Booking>>> getBookingsByServiceId(
      int serviceId, BookingsStatuesEnum? bookingState) async {
    // if (await networkInfo.isConnected) {
    try {
      final remoteService = await bookingsRemoteDataSource
          .getBookingsByServiceId(serviceId, bookingState);
      if (remoteService.isEmpty) {
        return Left(EmptyCacheFailure());
      } else {
        return Right(remoteService);
      }
    } on ServerException {
      return Left(ServerFailure());
    }
    // } else {
    //   return Left(OfflineFailure());
    // }
  }

  @override
  Future<Either<Failure, List<DateTime>>> getBookingDateByServiceId(
      int serviceId) async {
    // if (await networkInfo.isConnected) {
    try {
      final remoteService =
          await bookingsRemoteDataSource.getBookingDateByServiceId(serviceId);
      if (remoteService.isEmpty) {
        return Left(EmptyCacheFailure());
      } else {
        return Right(remoteService);
      }
    } on ServerException {
      return Left(ServerFailure());
    }
    // } else {
    //   return Left(OfflineFailure());
    // }
  }

  @override
  Future<Either<Failure, Booking>> getBookingById(int id) async {
    // if (await networkInfo.isConnected) {
    try {
      final remoteService = await bookingsRemoteDataSource.getBookingById(id);
      if (remoteService.props.isEmpty) {
        return Left(EmptyCacheFailure());
      } else {
        return Right(remoteService);
      }
    } on ServerException {
      return Left(ServerFailure());
    }
    // } else {
    //   return Left(OfflineFailure());
    // }
  }

  @override
  Future<Either<Failure, int>> addBooking(Booking booking) async {
    // if (await networkInfo.isConnected) {
    try {
      final data = BookingModel(
        id: 0,
        serviceId: booking.serviceId,
        userId: booking.userId,
        bookingStateEnum: booking.bookingStateEnum,
        bookingMethodEnem: booking.bookingMethodEnem,
        bookingDate: booking.bookingDate,
        note: booking.note,
        acceptedAllPolicies: booking.acceptedAllPolicies,
        isRating: booking.isRating,
      );
      final remoteStore = await bookingsRemoteDataSource.addBooking(data);
      return Right(remoteStore);
    } on ServerException {
      return Left(ServerFailure());
    }
    // } else {
    //   return Left(OfflineFailure());
    // }
  }
}
