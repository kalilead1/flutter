import 'dart:convert';

import 'package:booking_v1/featuers/bookings/data/models/booking_model.dart';
import 'package:booking_v1/featuers/bookings/domain/enums/bookings_statues_enum.dart';
import 'package:http/http.dart' as http;

import '../../../../core/constants/api.dart';
import '../../../../core/errors/exception.dart';
import '../../domain/entities/booking.dart';

abstract class BookingsRemoteDataSource {
  Future<List<Booking>> getBookingsByUserId(
      int userId, BookingsStatuesEnum? bookingState);
  Future<List<Booking>> getBookingsByStoreId(
      int storeId, BookingsStatuesEnum? bookingState);
  Future<List<Booking>> getBookingsByServiceId(
      int serviceId, BookingsStatuesEnum? bookingState);
  Future<List<DateTime>> getBookingDateByServiceId(int serviceId);
  Future<Booking> getBookingById(int id);
  Future<int> addBooking(BookingModel bookingModel);
}

const String bookingsUrl = "Bookings/";

class BookingsRemoteDataSourceImpl implements BookingsRemoteDataSource {
  final http.Client client;

  BookingsRemoteDataSourceImpl({required this.client});

  @override
  Future<List<Booking>> getBookingsByUserId(
      int userId, BookingsStatuesEnum? bookingState) async {
    final String url;
    if (bookingState != null) {
      url = "ByUserId/$userId?stateEnum=${bookingState.value}";
    } else {
      url = "ByUserId/$userId";
    }
    final response = await client.get(Uri.parse(baseUrl + bookingsUrl + url));
    if (response.statusCode == 200) {
      List jsonResponse = json.decode(response.body);
      return jsonResponse.map((get) => BookingModel.fromJson(get)).toList();
    } else {
      throw ServerException();
    }
  }

  @override
  Future<List<Booking>> getBookingsByStoreId(
      int storeId, BookingsStatuesEnum? bookingState) async {
    final String url;
    if (bookingState != null) {
      url = "ByStoreId/$storeId?stateEnum=${bookingState.value}";
    } else {
      url = "ByStoreId/$storeId";
    }
    final response = await client.get(
      Uri.parse(baseUrl + bookingsUrl + url),
    );
    if (response.statusCode == 200) {
      List jsonResponse = json.decode(response.body);
      return jsonResponse.map((get) => BookingModel.fromJson(get)).toList();
    } else {
      throw ServerException();
    }
  }

  @override
  Future<List<Booking>> getBookingsByServiceId(
      int serviceId, BookingsStatuesEnum? bookingState) async {
    final String url;
    if (bookingState != null) {
      url = "ByServiceId/$serviceId?stateEnum=${bookingState.value}";
    } else {
      url = "ByServiceId/$serviceId";
    }
    final response = await client.get(
      Uri.parse(baseUrl + bookingsUrl + url),
    );
    if (response.statusCode == 200) {
      List jsonResponse = json.decode(response.body);
      return jsonResponse.map((get) => BookingModel.fromJson(get)).toList();
    } else {
      throw ServerException();
    }
  }

  @override
  Future<List<DateTime>> getBookingDateByServiceId(int serviceId) async {
    final String url = "GetDateByServiceId/$serviceId";
    final response = await client.get(
      Uri.parse(baseUrl + bookingsUrl + url),
    );
    if (response.statusCode == 200) {
      List jsonResponse = json.decode(response.body);
      return jsonResponse.map((date) => DateTime.parse(date)).toList();
    } else {
      throw ServerException();
    }
  }

  @override
  Future<Booking> getBookingById(int id) async {
    final response =
        await client.get(Uri.parse(baseUrl + bookingsUrl + id.toString()));
    if (response.statusCode == 200) {
      return BookingModel.fromJson(json.decode(response.body));
    } else {
      throw ServerException();
    }
  }

  @override
  Future<int> addBooking(BookingModel bookingModel) async {
    final data = jsonEncode(bookingModel.toJson());
    final response = await client.post(Uri.parse(baseUrl + bookingsUrl),
        headers: {"Content-Type": "application/json"}, body: data);
    if (response.statusCode == 201 || response.statusCode == 200) {
      final responseBody = response.body;
      final data = json.decode(responseBody);
      return data['id'];
    } else {
      throw ServerException();
    }
  }
}
