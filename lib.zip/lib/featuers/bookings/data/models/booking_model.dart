import 'package:booking_v1/featuers/bookings/domain/entities/booking.dart';
import 'package:booking_v1/featuers/bookings/domain/enums/booking_method_enum.dart';
import 'package:booking_v1/featuers/bookings/domain/enums/bookings_statues_enum.dart';

import '../../../auth/data/models/user_model.dart';
import '../../../services/data/models/service_model.dart';

class BookingModel extends Booking {
  const BookingModel({
    super.id,
    super.serviceId,
    super.service,
    super.userId,
    super.user,
    super.bookingStateEnum,
    super.bookingMethodEnem,
    super.bookingDate,
    super.note,
    super.acceptedAllPolicies,
    super.isRating = false,
    super.createdAt,
  });

  factory BookingModel.fromJson(Map<String, dynamic> json) {
    return BookingModel(
      id: json['id'],
      serviceId: json['serviceId'],
      service: json['service'] != null
          ? ServiceModel.fromJson(json['service'])
          : null,
      userId: json['userId'],
      user: json['user'] != null ? UserModel.fromJson(json['user']) : null,
      bookingStateEnum:
          BookingsStatuesEnumExtension.fromValue(json['bookingState']),
      bookingMethodEnem:
          BookingMethodEnumExtension.fromValue(json['bookingMethod']),
      bookingDate: DateTime.parse(json['bookingDate']),
      // bookingDate: json['bookingDate'],
      note: json['note'],
      acceptedAllPolicies: json['acceptedAllPolicies'],
      isRating: json['isRating'],
      createdAt: DateTime.parse(json['createdAt']),
    );
  }
  Map<String, dynamic> toJson() => {
        "id": id,
        'serviceId': serviceId,
        'userId': userId,
        'bookingState': bookingStateEnum!.value,
        'bookingMethod': bookingMethodEnem!.value,
        'bookingDate': bookingDate!.toIso8601String(),
        'note': note,
        'acceptedAllPolicies': acceptedAllPolicies,
        'isRating': isRating,
      };
}
