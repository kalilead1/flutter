import 'package:booking_v1/featuers/bookings/domain/entities/manual_booking.dart';

class ManualBookingModel extends ManualBooking {
  const ManualBookingModel({
    super.id,
    super.bookingId,
    super.customerName,
    super.customerPhone,
    super.isLogin = false,
  });

  factory ManualBookingModel.fromJson(Map<String, dynamic> json) {
    return ManualBookingModel(
      id: json['id'],
      bookingId: json['bookingId'],
      customerName: json['customerName'],
      customerPhone: json['customerPhone'],
      isLogin: json['isLogin'],
    );
  }
}
