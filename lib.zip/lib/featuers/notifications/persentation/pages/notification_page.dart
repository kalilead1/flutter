import 'package:booking_v1/core/constants/strings.dart';
import 'package:booking_v1/core/routing/app_routes.dart';
import 'package:booking_v1/core/routing/router_extensions.dart';
import 'package:booking_v1/core/widgets/container_widgets.dart';
import 'package:flutter/material.dart';

class NotificationPage extends StatelessWidget {
  const NotificationPage({super.key});

  @override
  Widget build(BuildContext context) {
    DateTime dateTime = DateTime.now();
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: Text("الاشعارات")),
        body: Padding(
          padding: const EdgeInsets.all(defaultPadding),
          child: SecondaryContainer(
            paddingHorizontal: 0,
            paddingVertical: 10,
            child: ListTile(
              onTap: () {
                context.goTo(entryPointRoute, extra: 4);
              },
              leading: Icon(
                Icons.notifications,
                size: 30,
                color: Theme.of(context).colorScheme.primary,
              ),
              title: Text(
                "عنوان الاشعار",
                style: Theme.of(context).textTheme.displayMedium,
              ),
              subtitle: Text(
                "محتوى الاشعار",
                style: Theme.of(context).textTheme.labelSmall,
              ),
              dense: true,
              isThreeLine: true,
              trailing: Text(
                "${dateTime.year} - ${dateTime.month} - ${dateTime.day}",
              ),
            ),
          ),
        ),
      ),
    );
  }
}
