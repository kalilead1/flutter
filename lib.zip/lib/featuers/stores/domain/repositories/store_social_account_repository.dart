import 'package:dartz/dartz.dart';

import '../../../../core/errors/failures.dart';
import '../entities/store_social_account.dart';

abstract class StoreSocialAccountRepository {
  Future<Either<Failure, List<StoreSocialAccount>>> getStoreSocialAccount(
      int storeId);
  Future<Either<Failure, Unit>> addStoreSocialAccount(
      StoreSocialAccount storeSocialAccount);
  Future<Either<Failure, Unit>> deleteStoreSocialAccount(int id);
}
