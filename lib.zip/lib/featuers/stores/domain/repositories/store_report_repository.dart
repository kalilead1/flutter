import 'package:dartz/dartz.dart';

import '../../../../core/errors/failures.dart';
import '../entities/store_report.dart';

abstract class StoreReportRepository {
  Future<Either<Failure, Unit>> addStoreReport(StoreReport storeReport);
}
