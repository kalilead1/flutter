import 'package:dartz/dartz.dart';

import '../../../../core/errors/failures.dart';
import '../dtos/commands/add_store_dto.dart';
import '../entities/store.dart';

abstract class StoresRepository {
  Future<Either<Failure, List<Store>>> getAllStores();
  Future<Either<Failure, List<Store>>> getStoreByOwnerId(int ownerId);
  Future<Either<Failure, Store>> getStoreById(int id);
  Future<Either<Failure, Unit>> addStore(AddStoreDto addStore);
  Future<Either<Failure, Unit>> updateStore(int id, Store store);
  // Future<Either<Failure, Unit>> deleteStore(int id);
}
