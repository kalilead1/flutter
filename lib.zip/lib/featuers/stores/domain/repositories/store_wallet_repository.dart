import 'package:dartz/dartz.dart';

import '../../../../core/errors/failures.dart';
import '../entities/store_wallet.dart';

abstract class StoreWalletRepository {
  Future<Either<Failure, List<StoreWallet>>> getStoreWallets(int storeId);
  Future<Either<Failure, Unit>> addStoreWallet(StoreWallet storeWallet);
  Future<Either<Failure, Unit>> deleteStoreWallet(int id);
  // Future<Either<Failure, Unit>> updateStore(int id, Store store);
}
