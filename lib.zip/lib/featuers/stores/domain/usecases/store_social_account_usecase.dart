import 'package:dartz/dartz.dart';

import '../../../../core/errors/failures.dart';
import '../entities/store_social_account.dart';
import '../repositories/store_social_account_repository.dart';

class GetStoreSocialAccountsUsecase {
  final StoreSocialAccountRepository repository;

  GetStoreSocialAccountsUsecase(this.repository);

  Future<Either<Failure, List<StoreSocialAccount>>> call(int storeId) async {
    return await repository.getStoreSocialAccount(storeId);
  }
}

class AddStoreSocialAccountUsecase {
  final StoreSocialAccountRepository repository;

  AddStoreSocialAccountUsecase(this.repository);

  Future<Either<Failure, Unit>> call(
      StoreSocialAccount storeSocialAccount) async {
    return await repository.addStoreSocialAccount(storeSocialAccount);
  }
}

class DeleteStoreSocialAccountUsecase {
  final StoreSocialAccountRepository repository;

  DeleteStoreSocialAccountUsecase(this.repository);

  Future<Either<Failure, Unit>> call(int id) async {
    return await repository.deleteStoreSocialAccount(id);
  }
}
