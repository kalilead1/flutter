import 'package:dartz/dartz.dart';

import '../../../../core/errors/failures.dart';
import '../entities/store_wallet.dart';
import '../repositories/store_wallet_repository.dart';

class GetStoreWalletsUsecase {
  final StoreWalletRepository repository;

  GetStoreWalletsUsecase(this.repository);

  Future<Either<Failure, List<StoreWallet>>> call(int storeId) async {
    return await repository.getStoreWallets(storeId);
  }
}

class AddStoreWalletUsecase {
  final StoreWalletRepository repository;

  AddStoreWalletUsecase(this.repository);

  Future<Either<Failure, Unit>> call(StoreWallet storeWallet) async {
    return await repository.addStoreWallet(storeWallet);
  }
}

class DeleteStoreWalletUsecase {
  final StoreWalletRepository repository;

  DeleteStoreWalletUsecase(this.repository);

  Future<Either<Failure, Unit>> call(int storeWalletId) async {
    return await repository.deleteStoreWallet(storeWalletId);
  }
}
