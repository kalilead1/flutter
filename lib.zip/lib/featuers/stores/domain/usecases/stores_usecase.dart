import 'package:dartz/dartz.dart';

import '../../../../core/errors/failures.dart';
import '../dtos/commands/add_store_dto.dart';
import '../entities/store.dart';
import '../repositories/stores_repository.dart';

class GetAllStoresUsecase {
  final StoresRepository repository;

  GetAllStoresUsecase(this.repository);

  Future<Either<Failure, List<Store>>> call() async {
    return await repository.getAllStores();
  }
}

class GetStoreByIdUsecase {
  final StoresRepository repository;

  GetStoreByIdUsecase(this.repository);

  Future<Either<Failure, Store>> call(int id) async {
    return await repository.getStoreById(id);
  }
}

class GetStoreByOwnerIdUsecase {
  final StoresRepository repository;

  GetStoreByOwnerIdUsecase(this.repository);

  Future<Either<Failure, List<Store>>> call(int ownerId) async {
    return await repository.getStoreByOwnerId(ownerId);
  }
}

class AddStoreUsecase {
  final StoresRepository repository;

  AddStoreUsecase(this.repository);

  Future<Either<Failure, Unit>> call(AddStoreDto addStore) async {
    return await repository.addStore(addStore);
  }
}

class UpdateStoreUsecase {
  final StoresRepository repository;

  UpdateStoreUsecase(this.repository);

  Future<Either<Failure, Unit>> call(int id, Store store) async {
    return await repository.updateStore(id, store);
  }
}
