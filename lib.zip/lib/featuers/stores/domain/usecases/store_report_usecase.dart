import 'package:dartz/dartz.dart';

import '../../../../core/errors/failures.dart';
import '../entities/store_report.dart';
import '../repositories/store_report_repository.dart';

class AddStoreReportUsecase {
  final StoreReportRepository repository;

  AddStoreReportUsecase(this.repository);

  Future<Either<Failure, Unit>> call(StoreReport storeReport) async {
    return await repository.addStoreReport(storeReport);
  }
}
