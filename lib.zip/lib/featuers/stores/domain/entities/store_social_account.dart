import 'package:booking_v1/featuers/main/domain/entities/social_account.dart';
import 'package:equatable/equatable.dart';

import 'store.dart';

class StoreSocialAccount extends Equatable {
  final int? id;
  int? storeId;
  final Store? store;
  final int? socialAccountId;
  final SocialAccount? socialAccount;
  final String? url;

  StoreSocialAccount({
    this.id,
    this.storeId,
    this.store,
    this.socialAccountId,
    this.socialAccount,
    this.url,
  });

  @override
  List<Object?> get props =>
      [id, storeId, store, socialAccountId, socialAccount, url];
}
