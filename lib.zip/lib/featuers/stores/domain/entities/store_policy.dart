import 'package:equatable/equatable.dart';

import '../../../main/domain/entities/policy.dart';
import 'store.dart';

class StorePolicy extends Equatable {
  final int? id;
  final int? storeId;
  final Store? store;
  final int? policyId;
  final Policy? policy;

  const StorePolicy({
    this.id,
    this.storeId,
    this.store,
    this.policyId,
    this.policy,
  });

  @override
  List<Object?> get props => [id, storeId, store, policyId, policy];
}
