import 'package:booking_v1/featuers/main/domain/entities/directorate.dart';
import 'package:equatable/equatable.dart';

import '../../../main/domain/entities/category.dart';
import '../enums/store_state_enum.dart';
import 'store_social_account.dart';

class Store extends Equatable {
  final int? id;
  final String? name;
  final String? phone;
  final String? logo;

  final int? categoryId;
  final Category? category;
  final StoreStateEnum? stateEnum;
  final int? ownerId;
  final int? operatorId;

  final int? directorateId;
  final Directorate? directorate;
  final String? addressDetails;
  final String? locationCoordinates;

  final int visitorsCount;
  final bool isVerified;

  final List<StoreSocialAccount>? storeSocial;

  const Store({
    this.id,
    this.name,
    this.phone,
    this.logo,
    this.categoryId,
    this.category,
    this.stateEnum,
    this.ownerId,
    this.operatorId,
    this.directorateId,
    this.directorate,
    this.addressDetails,
    this.locationCoordinates,
    this.visitorsCount = 0,
    this.isVerified = false,
    this.storeSocial,
  });

  @override
  List<Object?> get props => [
        id,
        name,
        phone,
        logo,
        categoryId,
        category,
        stateEnum,
        ownerId,
        operatorId,
        directorateId,
        directorate,
        addressDetails,
        locationCoordinates,
        visitorsCount,
        isVerified,
        storeSocial,
      ];
}
