import 'package:equatable/equatable.dart';

import 'store.dart';

class StoreDocument extends Equatable {
  final int? id;
  int? storeId;
  final Store? store;
  final String? file;
  final String? documentType;

  StoreDocument({
    this.id,
    this.storeId,
    this.store,
    this.file,
    this.documentType,
  });

  @override
  List<Object?> get props => [id, storeId, store, file, documentType];
}
