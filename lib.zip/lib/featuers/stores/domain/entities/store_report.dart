import 'package:equatable/equatable.dart';

import '../enums/store_report_enum.dart';

class StoreReport extends Equatable {
  final int? id;
  final StoreReportEnum? reason;
  final String? comment;
  final int? storeId;

  const StoreReport({
    this.id,
    this.reason,
    this.comment,
    this.storeId,
  });

  @override
  List<Object?> get props => [
        id,
        reason,
        comment,
        storeId,
      ];
}
