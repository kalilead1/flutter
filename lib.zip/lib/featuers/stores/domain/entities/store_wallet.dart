import 'package:equatable/equatable.dart';

import '../../../main/domain/entities/wallet.dart';

class StoreWallet extends Equatable {
  final int? id;
  late int? storeId;
  final int? walletId;
  final Wallet? wallet;
  final int? accountNumber;

  StoreWallet({
    this.id,
    this.storeId,
    this.walletId,
    this.wallet,
    this.accountNumber,
  });

  @override
  List<Object?> get props => [id, storeId, walletId, wallet, accountNumber];
}
