import 'package:equatable/equatable.dart';

import 'store.dart';

class StoreOperator extends Equatable {
  final int? id;
  final int? storeId;
  final Store? store;
  final String? operatorName;
  final String? operatorPhone;
  final bool isLogin;

  const StoreOperator({
    this.id,
    this.storeId,
    this.store,
    this.operatorName,
    this.operatorPhone,
    this.isLogin = false,
  });

  @override
  List<Object?> get props =>
      [id, storeId, store, operatorName, operatorPhone, isLogin];
}
