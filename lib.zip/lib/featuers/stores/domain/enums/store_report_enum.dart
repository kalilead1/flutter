enum StoreReportEnum {
  untrustworthy, // غير موثوق
  impersonation, // انتحال
  offensive, // مسيء
  other, // اخر
}

extension StoreReportEnumExtension on StoreReportEnum {
  String get arabicName {
    switch (this) {
      case StoreReportEnum.untrustworthy:
        return 'احتيال';
      case StoreReportEnum.impersonation:
        return 'انتحال';
      case StoreReportEnum.offensive:
        return 'مسيء';
      case StoreReportEnum.other:
        return 'اخر';
    }
  }

  int get value {
    switch (this) {
      case StoreReportEnum.untrustworthy:
        return 1;
      case StoreReportEnum.impersonation:
        return 2;
      case StoreReportEnum.offensive:
        return 3;
      case StoreReportEnum.other:
        return 4;
    }
  }

  static StoreReportEnum fromValue(int value) {
    switch (value) {
      case 1:
        return StoreReportEnum.untrustworthy;
      case 2:
        return StoreReportEnum.impersonation;
      case 3:
        return StoreReportEnum.offensive;
      case 4:
        return StoreReportEnum.other;
      default:
        throw Exception('لا يوجد اي نوع من البلاغات');
    }
  }
}
