import 'package:flutter/material.dart';

import '../../../../core/constants/colors.dart';

enum StoreStateEnum {
  pendingVerification, // التحقق من طلب الانشاء
  active, // متاح
  rejected, // مرفوض
  underMaintenance, // تحت الصيانة
  closed, // مغلق
  banned, // محظور
}

extension StoreStateEnumExtension on StoreStateEnum {
  String get arabicName {
    switch (this) {
      case StoreStateEnum.pendingVerification:
        return 'التحقق من طلب الانشاء';
      case StoreStateEnum.active:
        return 'متاح';
      case StoreStateEnum.rejected:
        return 'مرفوض';
      case StoreStateEnum.underMaintenance:
        return 'تحت الصيانة';
      case StoreStateEnum.closed:
        return 'مغلق';
      case StoreStateEnum.banned:
        return 'محظور';
    }
  }

  int get value {
    switch (this) {
      case StoreStateEnum.pendingVerification:
        return 1;
      case StoreStateEnum.active:
        return 2;
      case StoreStateEnum.rejected:
        return 3;
      case StoreStateEnum.underMaintenance:
        return 4;
      case StoreStateEnum.closed:
        return 5;
      case StoreStateEnum.banned:
        return 6;
    }
  }

  static StoreStateEnum fromValue(int value) {
    switch (value) {
      case 1:
        return StoreStateEnum.pendingVerification;
      case 2:
        return StoreStateEnum.active;
      case 3:
        return StoreStateEnum.rejected;
      case 4:
        return StoreStateEnum.underMaintenance;
      case 5:
        return StoreStateEnum.closed;
      case 6:
        return StoreStateEnum.banned;
      default:
        throw Exception('لا يوجد حالة للمتجر');
    }
  }
}

Color getStoreStateBackgroundColorByValue(
    StoreStateEnum storeState, BuildContext context) {
  if (storeState == StoreStateEnum.pendingVerification ||
      storeState == StoreStateEnum.underMaintenance) {
    return warningColor.withOpacity(0.3);
  }
  if (storeState == StoreStateEnum.active) {
    return successColor.withOpacity(0.3);
  }
  if (storeState == StoreStateEnum.rejected ||
      storeState == StoreStateEnum.banned) {
    return errorColor.withOpacity(0.3);
  }
  if (storeState == StoreStateEnum.closed) {
    return Theme.of(context).colorScheme.tertiary.withOpacity(0.3);
  } else {
    return Colors.purpleAccent.withOpacity(0.4);
  }
}

Color getStoreStateBorderColorByValue(
    StoreStateEnum storeState, BuildContext context) {
  if (storeState == StoreStateEnum.pendingVerification ||
      storeState == StoreStateEnum.underMaintenance) {
    return warningColor.withOpacity(0.6);
  }
  if (storeState == StoreStateEnum.active) {
    return successColor.withOpacity(0.6);
  }
  if (storeState == StoreStateEnum.rejected ||
      storeState == StoreStateEnum.banned) {
    return errorColor.withOpacity(0.6);
  }
  if (storeState == StoreStateEnum.closed) {
    return Theme.of(context).colorScheme.tertiary.withOpacity(0.6);
  } else {
    return Colors.purpleAccent.withOpacity(0.7);
  }
}
