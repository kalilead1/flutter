import 'package:equatable/equatable.dart';

import '../../../../main/domain/enums/policy_type_enum.dart';

class GetStorePolicies extends Equatable {
  final int? id;
  final PolicyTypeEnum? policyTypeEnum;
  final String? description;

  const GetStorePolicies({this.id, this.policyTypeEnum, this.description});

  @override
  List<Object?> get props => [id, policyTypeEnum, description];
}
