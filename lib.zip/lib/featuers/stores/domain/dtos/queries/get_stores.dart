import 'package:booking_v1/featuers/stores/domain/enums/store_state_enum.dart';
import 'package:equatable/equatable.dart';

class GetStores extends Equatable {
  final int? id;
  final String? logo;
  final String? name;
  final String? categoryName;
  final StoreStateEnum? stateEnum;

  const GetStores({
    this.id,
    this.logo,
    this.name,
    this.categoryName,
    this.stateEnum,
  });

  @override
  List<Object?> get props => [
        id,
        logo,
        name,
        categoryName,
        stateEnum,
      ];
}
