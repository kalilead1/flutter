import 'package:equatable/equatable.dart';

class AddUpdateStorePolicy extends Equatable {
  final int? id;
  final int? storeId;
  final int? policyId;

  const AddUpdateStorePolicy({
    this.id,
    this.storeId,
    this.policyId,
  });

  @override
  List<Object?> get props => [id, storeId, policyId];
}
