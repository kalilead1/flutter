import 'package:booking_v1/featuers/stores/data/models/store_social_account_model.dart';
import 'package:booking_v1/featuers/stores/data/models/store_wallet_model.dart';
import 'package:equatable/equatable.dart';

class AddStoreDto extends Equatable {
  final String? name;
  final String? phone;
  final String? logo;

  final int? categoryId;
  final int? directorateId;
  final String? addressDetails;
  final String? locationCoordinates;

  final List<StoreSocialAccountModel>? storeSocials;
  final List<StoreWalletModel>? storeWallets;
  final List<String>? storeDocuments;

  const AddStoreDto({
    this.name,
    this.phone,
    this.logo,
    this.categoryId,
    this.directorateId,
    this.addressDetails,
    this.locationCoordinates,
    this.storeSocials,
    this.storeWallets,
    this.storeDocuments,
  });

  @override
  List<Object?> get props => [
        name,
        phone,
        logo,
        categoryId,
        directorateId,
        addressDetails,
        locationCoordinates,
        storeSocials,
        storeWallets,
        storeDocuments,
      ];
}
