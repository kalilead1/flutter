import 'package:equatable/equatable.dart';

class UpdateStoreLocalionDto extends Equatable {
  final int? id;
  final int? directorateId;
  final String? addressDetails;
  final String? locationCoordinates;

  const UpdateStoreLocalionDto({
    this.id,
    this.directorateId,
    this.addressDetails,
    this.locationCoordinates,
  });

  @override
  List<Object?> get props =>
      [id, directorateId, addressDetails, locationCoordinates];
}
