import 'package:equatable/equatable.dart';

class AddUpdateStoreWallet extends Equatable {
  final int? id;
  final int? storeId;
  final int? walletId;
  final int? accountNumber;

  const AddUpdateStoreWallet(
      {this.id, this.storeId, this.walletId, this.accountNumber});

  @override
  List<Object?> get props => [id, storeId, walletId, accountNumber];
}
