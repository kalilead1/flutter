import 'package:equatable/equatable.dart';

class AddUpdateStoreSocialAccount extends Equatable {
  final int? id;
  final int? storeId;
  final int? socialAccountId;
  final String? url;

  const AddUpdateStoreSocialAccount(
      {this.id, this.storeId, this.socialAccountId, this.url});

  @override
  List<Object?> get props => [id, storeId, socialAccountId, url];
}
