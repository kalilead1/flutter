import 'package:equatable/equatable.dart';

class UpdateStoreBaiscDto extends Equatable {
  final int? id;
  final String? logo;
  final String? name;
  final int? categoryId;
  final String? phone;

  const UpdateStoreBaiscDto({
    this.id,
    this.logo,
    this.name,
    this.categoryId,
    this.phone,
  });

  @override
  List<Object?> get props => [
        id,
        logo,
        name,
        categoryId,
        phone,
      ];
}
