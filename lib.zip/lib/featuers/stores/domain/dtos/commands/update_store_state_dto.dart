import 'package:booking_v1/featuers/stores/domain/enums/store_state_enum.dart';
import 'package:equatable/equatable.dart';

class UpdateStoreStateDto extends Equatable {
  final int? id;
  final StoreStateEnum? stateEnum;

  const UpdateStoreStateDto({this.id, this.stateEnum});

  @override
  List<Object?> get props => [id, stateEnum];
}
