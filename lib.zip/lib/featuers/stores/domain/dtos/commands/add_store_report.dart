import 'package:equatable/equatable.dart';

import '../../enums/store_report_enum.dart';

class AddStoreReport extends Equatable {
  final int? storeId;
  final StoreReportEnum? reason;
  final String? comment;

  const AddStoreReport({
    this.storeId,
    this.reason,
    this.comment,
  });

  @override
  List<Object?> get props => [
        storeId,
        reason,
        comment,
      ];
}
