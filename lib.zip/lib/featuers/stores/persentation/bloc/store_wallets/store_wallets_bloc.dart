import 'package:booking_v1/core/errors/failures.dart';
import 'package:booking_v1/core/helpers/failure_to_message.dart';
import 'package:dartz/dartz.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../../../../core/app_events_bus/app_event.dart';
import '../../../../../core/app_events_bus/app_event_bus.dart';
import '../../../../../core/app_events_bus/auto_refresh_bloc.dart';
import '../../../../../core/routing/navigation_service.dart';
import '../../../domain/entities/store_wallet.dart';
import '../../../domain/usecases/store_wallet_usecase.dart';
import 'store_wallets_event.dart';
import 'store_wallets_state.dart';

class StoreWalletsBloc extends Bloc<StoreWalletsEvent, StoreWalletsState>
    with AutoRefreshBloc<StoreWalletsEvent, StoreWalletsState> {
  final GetStoreWalletsUsecase? getStoreWalletsUsecase;
  final AddStoreWalletUsecase? addStoreWalletUsecase;
  final DeleteStoreWalletUsecase? deleteStoreWalletUsecase;

  StoreWalletsBloc({
    this.getStoreWalletsUsecase,
    this.addStoreWalletUsecase,
    this.deleteStoreWalletUsecase,
  }) : super(StoreWalletsInitialState()) {
    setupAutoRefresh<StoreChangedEvent>();
    on<GetStoreWalletsByStoreIdEvent>((event, emit) async {
      emit(LoadingStoreWalletsState());

      final failureOrStoreWallets =
          await getStoreWalletsUsecase!(event.storeId);
      emit(_mapFailureOrGetStoreWallets(failureOrStoreWallets));
    });
    on<AddStoreWalletEvent>((event, emit) async {
      emit(LoadingStoreWalletsState());

      final failureOrAddStoreWallet =
          await addStoreWalletUsecase!(event.storeWallet);
      failureOrAddStoreWallet.fold(
        (failure) =>
            emit(ErrorStoreWalletsState(message: failureToMessage(failure))),
        (unit) {
          SuccessfullyAddStoreWalletsState();
          AppEventBus.instance.fire(StoreChangedEvent());
        },
      );
    });
    on<DeleteStoreWalletEvent>((event, emit) async {
      emit(LoadingStoreWalletsState());

      final failureOrDeleteStoreWallet =
          await deleteStoreWalletUsecase!(event.storeWalletId);
      failureOrDeleteStoreWallet.fold(
        (failure) =>
            emit(ErrorStoreWalletsState(message: failureToMessage(failure))),
        (unit) {
          SuccessfullyDeleteStoreWalletsState();
          AppEventBus.instance.fire(StoreChangedEvent());
          NavigationService.pop();
        },
      );
    });
  }

  StoreWalletsState _mapFailureOrGetStoreWallets(
      Either<Failure, List<StoreWallet>> either) {
    return either.fold(
      (failure) => ErrorStoreWalletsState(message: failureToMessage(failure)),
      (storeWallets) => LoadedStoreWalletsState(storeWallets: storeWallets),
    );
  }
}
