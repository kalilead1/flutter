import 'package:booking_v1/featuers/stores/domain/entities/store_wallet.dart';
import 'package:equatable/equatable.dart';

abstract class StoreWalletsState extends Equatable {
  const StoreWalletsState();
  @override
  List<Object?> get props => [];
}

class StoreWalletsInitialState extends StoreWalletsState {}

class LoadingStoreWalletsState extends StoreWalletsState {}

class LoadedStoreWalletsState extends StoreWalletsState {
  final List<StoreWallet> storeWallets;

  const LoadedStoreWalletsState({required this.storeWallets});

  @override
  List<Object?> get props => [storeWallets];
}

class ErrorStoreWalletsState extends StoreWalletsState {
  final String message;

  const ErrorStoreWalletsState({required this.message});

  @override
  List<Object?> get props => [message];
}

class SuccessfullyAddStoreWalletsState extends StoreWalletsState {}

class SuccessfullyDeleteStoreWalletsState extends StoreWalletsState {}
