import 'package:booking_v1/featuers/stores/domain/entities/store_wallet.dart';
import 'package:equatable/equatable.dart';

abstract class StoreWalletsEvent extends Equatable {
  const StoreWalletsEvent();
  @override
  List<Object?> get props => [];
}

class GetStoreWalletsByStoreIdEvent extends StoreWalletsEvent {
  final int storeId;
  const GetStoreWalletsByStoreIdEvent({required this.storeId});

  @override
  List<Object?> get props => [storeId];
}

class AddStoreWalletEvent extends StoreWalletsEvent {
  final StoreWallet storeWallet;
  const AddStoreWalletEvent({required this.storeWallet});

  @override
  List<Object?> get props => [storeWallet];
}

class DeleteStoreWalletEvent extends StoreWalletsEvent {
  final int storeWalletId;
  const DeleteStoreWalletEvent({required this.storeWalletId});

  @override
  List<Object?> get props => [storeWalletId];
}
