import 'package:booking_v1/featuers/stores/domain/entities/store_social_account.dart';
import 'package:equatable/equatable.dart';

abstract class StoreSocialAccountsState extends Equatable {
  const StoreSocialAccountsState();
  @override
  List<Object?> get props => [];
}

class StoreSocialInitialState extends StoreSocialAccountsState {}

class LoadingStoreSocialState extends StoreSocialAccountsState {}

class LoadedStoreSocialsState extends StoreSocialAccountsState {
  final List<StoreSocialAccount> storeSocials;

  const LoadedStoreSocialsState({required this.storeSocials});

  @override
  List<Object?> get props => [storeSocials];
}

class ErrorStoreSocialState extends StoreSocialAccountsState {
  final String message;

  const ErrorStoreSocialState({required this.message});

  @override
  List<Object?> get props => [message];
}

class SuccessfullyStoreSocialState extends StoreSocialAccountsState {
  final String message;

  const SuccessfullyStoreSocialState({required this.message});

  @override
  List<Object?> get props => [message];
}

// class SuccessfullyDeleteStoreSocialState extends StoreSocialAccountsState {}
