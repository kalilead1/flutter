import 'package:equatable/equatable.dart';

import '../../../domain/entities/store_social_account.dart';

abstract class StoreSocialAccountsEvent extends Equatable {
  const StoreSocialAccountsEvent();
  @override
  List<Object?> get props => [];
}

class GetStoreSocialsByStoreIdEvent extends StoreSocialAccountsEvent {
  final int storeId;
  const GetStoreSocialsByStoreIdEvent({required this.storeId});

  @override
  List<Object?> get props => [storeId];
}

class AddStoreSocialEvent extends StoreSocialAccountsEvent {
  final StoreSocialAccount storeSocial;
  const AddStoreSocialEvent({required this.storeSocial});

  @override
  List<Object?> get props => [storeSocial];
}

class DeleteStoreSocialEvent extends StoreSocialAccountsEvent {
  final int storeSocialId;
  const DeleteStoreSocialEvent({required this.storeSocialId});

  @override
  List<Object?> get props => [storeSocialId];
}
