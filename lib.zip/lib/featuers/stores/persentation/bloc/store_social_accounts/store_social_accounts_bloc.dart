import 'package:booking_v1/core/errors/failures.dart';
import 'package:booking_v1/core/helpers/failure_to_message.dart';
import 'package:booking_v1/featuers/stores/domain/usecases/store_social_account_usecase.dart';
import 'package:dartz/dartz.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../../../../core/app_events_bus/app_event.dart';
import '../../../../../core/app_events_bus/app_event_bus.dart';
import '../../../../../core/app_events_bus/auto_refresh_bloc.dart';
import '../../../../../core/routing/navigation_service.dart';
import '../../../domain/entities/store_social_account.dart';
import 'store_social_accounts_event.dart';
import 'store_social_accounts_state.dart';

class StoreSocialAccountsBloc
    extends Bloc<StoreSocialAccountsEvent, StoreSocialAccountsState>
    with AutoRefreshBloc<StoreSocialAccountsEvent, StoreSocialAccountsState> {
  final GetStoreSocialAccountsUsecase? getStoreSocialUsecase;
  final AddStoreSocialAccountUsecase? addStoreSocialUsecase;
  final DeleteStoreSocialAccountUsecase? deleteStoreSocialUsecase;

  StoreSocialAccountsBloc({
    this.getStoreSocialUsecase,
    this.addStoreSocialUsecase,
    this.deleteStoreSocialUsecase,
  }) : super(StoreSocialInitialState()) {
    setupAutoRefresh<StoreChangedEvent>();
    on<GetStoreSocialsByStoreIdEvent>((event, emit) async {
      emit(LoadingStoreSocialState());

      final failureOrStoreSocials = await getStoreSocialUsecase!(event.storeId);
      emit(_mapFailureOrGetStoreSocials(failureOrStoreSocials));
    });
    on<AddStoreSocialEvent>((event, emit) async {
      emit(LoadingStoreSocialState());

      final failureOrAddStoreSocial =
          await addStoreSocialUsecase!(event.storeSocial);
      failureOrAddStoreSocial.fold(
        (failure) =>
            emit(ErrorStoreSocialState(message: failureToMessage(failure))),
        (unit) {
          SuccessfullyStoreSocialState(message: "تم اضافة حساب تواصل بنجاح");
          AppEventBus.instance.fire(StoreChangedEvent());
        },
      );
    });
    on<DeleteStoreSocialEvent>((event, emit) async {
      emit(LoadingStoreSocialState());

      final failureOrDeleteStoreSocial =
          await deleteStoreSocialUsecase!(event.storeSocialId);
      failureOrDeleteStoreSocial.fold(
        (failure) =>
            emit(ErrorStoreSocialState(message: failureToMessage(failure))),
        (unit) {
          SuccessfullyStoreSocialState(message: "تم حذف حساب تواصل بنجاح");
          AppEventBus.instance.fire(StoreChangedEvent());
          NavigationService.pop();
        },
      );
    });
  }

  StoreSocialAccountsState _mapFailureOrGetStoreSocials(
      Either<Failure, List<StoreSocialAccount>> either) {
    return either.fold(
      (failure) => ErrorStoreSocialState(message: failureToMessage(failure)),
      (storeSocials) => LoadedStoreSocialsState(storeSocials: storeSocials),
    );
  }
}
