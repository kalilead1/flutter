import 'package:equatable/equatable.dart';

abstract class StoreReportState extends Equatable {
  const StoreReportState();
  @override
  List<Object?> get props => [];
}

class InitialState extends StoreReportState {}

class LoadingState extends StoreReportState {}

class SuccessfullyAddedState extends StoreReportState {
  final String message;

  const SuccessfullyAddedState({required this.message});

  @override
  List<Object?> get props => [message];
}

class ErrorAddedState extends StoreReportState {
  final String message;

  const ErrorAddedState({required this.message});

  @override
  List<Object?> get props => [message];
}
