import 'package:flutter_bloc/flutter_bloc.dart';

import '../../../../../core/helpers/failure_to_message.dart';
import '../../../../../core/routing/navigation_service.dart';
import '../../../domain/usecases/store_report_usecase.dart';
import 'store_report_event.dart';
import 'store_report_state.dart';

class StoreReportBloc extends Bloc<StoreReportEvent, StoreReportState> {
  final AddStoreReportUsecase? addStoreReportUsecase;

  StoreReportBloc({this.addStoreReportUsecase}) : super(InitialState()) {
    on<AddStoreReportEvent>((event, emit) async {
      emit(LoadingState());

      final failureOrSuccess = await addStoreReportUsecase!(event.storeReport);
      failureOrSuccess.fold(
        (failure) => emit(ErrorAddedState(message: failureToMessage(failure))),
        (unit) {
          emit(SuccessfullyAddedState(message: "تم الابلاغ عن المتجر بنجاح"));
          NavigationService.pop();
        },
      );
    });
    on<CancelAddedEvent>((event, emit) async {
      NavigationService.pop();
    });
  }
}
