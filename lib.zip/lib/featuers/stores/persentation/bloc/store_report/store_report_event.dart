import 'package:equatable/equatable.dart';

import '../../../domain/entities/store_report.dart';

abstract class StoreReportEvent extends Equatable {
  const StoreReportEvent();
  @override
  List<Object?> get props => [];
}

class CancelAddedEvent extends StoreReportEvent {}

class AddStoreReportEvent extends StoreReportEvent {
  final StoreReport storeReport;

  const AddStoreReportEvent({required this.storeReport});

  @override
  List<Object?> get props => [storeReport];
}
