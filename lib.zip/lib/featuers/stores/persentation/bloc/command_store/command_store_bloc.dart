import 'dart:io';

import 'package:booking_v1/featuers/stores/data/models/store_social_account_model.dart';
import 'package:booking_v1/featuers/stores/data/models/store_wallet_model.dart';
import 'package:booking_v1/featuers/stores/domain/dtos/commands/add_store_dto.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../../../../core/app_events_bus/app_event.dart';
import '../../../../../core/app_events_bus/app_event_bus.dart';
import '../../../../../core/helpers/failure_to_message.dart';
import '../../../../../core/routing/app_routes.dart';
import '../../../../../core/routing/navigation_service.dart';
import '../../../domain/usecases/stores_usecase.dart';
import '../../pages/args/add_pages_args.dart';
import 'command_store_event.dart';
import 'command_store_state.dart';

class CommandStoreBloc extends Bloc<CommandStoreEvent, CommandStoreState> {
  final AddStoreUsecase? addNewStoreUsecase;

  String? name;
  String? phone;
  String? logo;
  int? categoryId;
  int? directorateId;
  String? addressDetails;
  String? locationCoordinates;
  List<StoreSocialAccountModel> _storeSocials = [];
  List<StoreWalletModel> _storeWallets = [];
  List<File> _storeDocuments = [];

  CommandStoreBloc({
    required this.addNewStoreUsecase,
  }) : super(CommandStoreInitialState()) {
    on<AddStoreBasicInfoEvent>((event, emit) async {
      emit(LoadingCommandStoreState());
      name = event.name;
      phone = event.phone;
      logo = event.logo;
      categoryId = event.categoryId;
      // _store = event.store;
      emit(_storeState());
      NavigationService.push(addUpdateStoreLocationRoute,
          extra: AddUpdateStoreBaiscAndLocationArgs());
    });
    on<AddStoreLocationEvent>((event, emit) async {
      emit(LoadingCommandStoreState());
      directorateId = event.directorateId;
      addressDetails = event.addressDetails;
      locationCoordinates = event.locationCoordinates;
      // _store = event.store;
      emit(_storeState());
      NavigationService.push(addStoreSocialRoute);
    });
    on<AddStoreSocialEvent>((event, emit) async {
      emit(LoadingCommandStoreState());
      _storeSocials = event.storeSocialAccounts;

      emit(_storeState());
      NavigationService.push(addStoreWalletRoute);
    });
    on<AddStoreWalletEvent>((event, emit) async {
      emit(LoadingCommandStoreState());
      _storeWallets = event.storeWallets;

      emit(_storeState());
      NavigationService.push(addStoreDocumentRoute);
    });
    on<AddStoreDocumentEvent>((event, emit) async {
      emit(LoadingCommandStoreState());
      _storeDocuments = event.storeDocuments;

      emit(_storeState());
      NavigationService.push(addStoreApprovalPoliticsRoute);
    });
    on<AddApprovalOfPoliticsEvent>((event, emit) async {
      emit(LoadingCommandStoreState());
      emit(_storeState());
      NavigationService.push(confirmAddStoreRoute);
    });
    on<SubmitStoreEvent>((event, emit) async {
      emit(LoadingCommandStoreState());

      List<String> allDocuments = [];
      for (var document in _storeDocuments) {
        allDocuments.add(document.path);
      }

      final store = AddStoreDto(
        name: name,
        phone: phone,
        logo: logo,
        categoryId: categoryId,
        directorateId: directorateId,
        addressDetails: addressDetails,
        locationCoordinates: locationCoordinates,
        storeDocuments: allDocuments,
        storeSocials: _storeSocials,
        storeWallets: _storeWallets,
      );
      final failureOrAddStore = await addNewStoreUsecase!(store);
      failureOrAddStore.fold(
        (failure) => emit(ErrorStoreState(message: failureToMessage(failure))),
        (storeId) {
          AppEventBus.instance.fire(StoreChangedEvent());
          emit(SuccessfullyStoreState(message: ""));
          NavigationService.popUntil(storeOwnerRoute);
        },
      );
    });
    on<CancelAddStoreEvent>((event, emit) async {
      NavigationService.popUntil(storeOwnerRoute);
    });
  }

  CommandStoreState _storeState() {
    return EditingAddStoreState(
      name: name,
      phone: phone,
      logo: logo,
      categoryId: categoryId,
      directorateId: directorateId,
      addressDetails: addressDetails,
      locationCoordinates: locationCoordinates,
      socialAccounts: _storeSocials,
      storeWallets: _storeWallets,
      storeDocuments: _storeDocuments,
    );
  }
}
