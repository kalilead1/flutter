import 'dart:io';

import 'package:booking_v1/featuers/stores/data/models/store_social_account_model.dart';
import 'package:booking_v1/featuers/stores/data/models/store_wallet_model.dart';
import 'package:equatable/equatable.dart';

abstract class CommandStoreEvent extends Equatable {
  const CommandStoreEvent();
  @override
  List<Object?> get props => [];
}

class AddStoreBasicInfoEvent extends CommandStoreEvent {
  final String name;
  final String phone;
  final String logo;
  final int categoryId;

  const AddStoreBasicInfoEvent({
    required this.name,
    required this.phone,
    required this.logo,
    required this.categoryId,
  });

  @override
  List<Object?> get props => [name, phone, logo, categoryId];
}

class AddStoreLocationEvent extends CommandStoreEvent {
  final int directorateId;
  final String addressDetails;
  final String locationCoordinates;

  const AddStoreLocationEvent({
    required this.directorateId,
    required this.addressDetails,
    required this.locationCoordinates,
  });

  @override
  List<Object?> get props =>
      [directorateId, addressDetails, locationCoordinates];
}

class AddStoreSocialEvent extends CommandStoreEvent {
  final List<StoreSocialAccountModel> storeSocialAccounts;
  const AddStoreSocialEvent({required this.storeSocialAccounts});

  @override
  List<Object?> get props => [storeSocialAccounts];
}

class AddStoreWalletEvent extends CommandStoreEvent {
  final List<StoreWalletModel> storeWallets;
  const AddStoreWalletEvent({required this.storeWallets});

  @override
  List<Object?> get props => [storeWallets];
}

class AddStoreDocumentEvent extends CommandStoreEvent {
  final List<File> storeDocuments;
  const AddStoreDocumentEvent({required this.storeDocuments});

  @override
  List<Object?> get props => [storeDocuments];
}

class AddApprovalOfPoliticsEvent extends CommandStoreEvent {}

class SubmitStoreEvent extends CommandStoreEvent {}

class CancelAddStoreEvent extends CommandStoreEvent {}
