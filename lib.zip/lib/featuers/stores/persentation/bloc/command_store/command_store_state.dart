import 'dart:io';

import 'package:booking_v1/featuers/stores/data/models/store_social_account_model.dart';
import 'package:booking_v1/featuers/stores/data/models/store_wallet_model.dart';
import 'package:equatable/equatable.dart';

abstract class CommandStoreState extends Equatable {
  const CommandStoreState();
  @override
  List<Object?> get props => [];
}

class CommandStoreInitialState extends CommandStoreState {}

class LoadingCommandStoreState extends CommandStoreState {}

class EditingAddStoreState extends CommandStoreState {
  final String? name;
  final String? phone;
  final String? logo;
  final int? categoryId;
  final int? directorateId;
  final String? addressDetails;
  final String? locationCoordinates;
  final List<StoreSocialAccountModel> socialAccounts;
  final List<StoreWalletModel> storeWallets;
  final List<File> storeDocuments;

  const EditingAddStoreState({
    this.name,
    this.phone,
    this.logo,
    this.categoryId,
    this.directorateId,
    this.addressDetails,
    this.locationCoordinates,
    this.socialAccounts = const [],
    this.storeWallets = const [],
    this.storeDocuments = const [],
  });

  @override
  List<Object?> get props => [
        name,
        phone,
        logo,
        categoryId,
        directorateId,
        addressDetails,
        locationCoordinates,
        socialAccounts,
        storeWallets,
        storeDocuments,
      ];
}

class SuccessfullyStoreState extends CommandStoreState {
  final String message;

  const SuccessfullyStoreState({required this.message});

  @override
  List<Object?> get props => [message];
}

class ErrorStoreState extends CommandStoreState {
  final String message;

  const ErrorStoreState({required this.message});

  @override
  List<Object?> get props => [message];
}
