import 'package:booking_v1/core/errors/failures.dart';
import 'package:booking_v1/core/helpers/failure_to_message.dart';
import 'package:dartz/dartz.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../../../../core/app_events_bus/app_event.dart';
import '../../../../../core/app_events_bus/auto_refresh_bloc.dart';
import '../../../domain/entities/store.dart';
import '../../../domain/usecases/store_social_account_usecase.dart';
import '../../../domain/usecases/stores_usecase.dart';
import 'stores_event.dart';
import 'stores_state.dart';

class StoresBloc extends Bloc<StoresEvent, StoresState>
    with AutoRefreshBloc<StoresEvent, StoresState> {
  final GetAllStoresUsecase? getAllStoresUsecase;
  final GetStoreByIdUsecase? getStoreByIdUsecase;
  final GetStoreByOwnerIdUsecase? getStoreByOwnerIdUsecase;
  final GetStoreSocialAccountsUsecase? getStoreSocialAccountUsecase;

  StoresBloc({
    this.getAllStoresUsecase,
    this.getStoreByIdUsecase,
    this.getStoreByOwnerIdUsecase,
    this.getStoreSocialAccountUsecase,
  }) : super(StoresInitialState()) {
    setupAutoRefresh<StoreChangedEvent>();

    on<GetAllStoresEvent>((event, emit) async {
      emit(LoadingStoresState());

      final failureOrStores = await getAllStoresUsecase!();
      emit(_mapFailureOrGetAllStores(failureOrStores));
    });
    on<RefreshAllStoresEvent>((event, emit) async {
      emit(LoadingStoresState());

      final failureOrStores = await getAllStoresUsecase!();
      emit(_mapFailureOrGetAllStores(failureOrStores));
    });
    on<GetStoreByIdEvent>((event, emit) async {
      emit(LoadingStoresState());

      final failureOrGetStoreById = await getStoreByIdUsecase!(event.storeId);
      emit(_mapFailureOGetStoreById(failureOrGetStoreById));
    });
    on<RefreshGetStoreByIdEvent>((event, emit) async {
      emit(LoadingStoresState());

      final failureOrGetStoreById = await getStoreByIdUsecase!(event.storeId);
      emit(_mapFailureOGetStoreById(failureOrGetStoreById));
    });
    on<GetStoreByOwnerIdEvent>((event, emit) async {
      emit(LoadingStoresState());

      final failureOrGetStoreById =
          await getStoreByOwnerIdUsecase!(event.ownerId);
      emit(_mapFailureOrGetAllStores(failureOrGetStoreById));
    });
    on<RefreshGetStoreByOwnerIdEvent>((event, emit) async {
      emit(LoadingStoresState());

      final failureOrGetStoreById =
          await getStoreByOwnerIdUsecase!(event.ownerId);
      emit(_mapFailureOrGetAllStores(failureOrGetStoreById));
    });
  }

  StoresState _mapFailureOrGetAllStores(Either<Failure, List<Store>> either) {
    return either.fold(
      (failure) => ErrorStoresState(message: failureToMessage(failure)),
      (stores) => LoadedStoresState(stores: stores),
    );
  }

  StoresState _mapFailureOGetStoreById(Either<Failure, Store> either) {
    return either.fold(
      (failure) => ErrorStoresState(message: failureToMessage(failure)),
      (store) => LoadedStoreByIdState(store: store),
    );
  }
}
