import 'package:equatable/equatable.dart';

abstract class StoresEvent extends Equatable {
  const StoresEvent();
  @override
  List<Object?> get props => [];
}

class GetAllStoresEvent extends StoresEvent {}

class GetStoreByIdEvent extends StoresEvent {
  final int storeId;
  const GetStoreByIdEvent({required this.storeId});

  @override
  List<Object?> get props => [storeId];
}

// class GetStoreSocialAccountEvent extends StoresEvent {
//   final int storeId;
//   const GetStoreSocialAccountEvent({required this.storeId});

//   @override
//   List<Object?> get props => [storeId];
// }

// class GetAllStoreByEvent extends StoresEvent {}

class GetStoreByOwnerIdEvent extends StoresEvent {
  final int ownerId;
  const GetStoreByOwnerIdEvent({required this.ownerId});

  @override
  List<Object?> get props => [ownerId];
}

class RefreshAllStoresEvent extends StoresEvent {}

class RefreshGetStoreByIdEvent extends StoresEvent {
  final int storeId;
  const RefreshGetStoreByIdEvent({required this.storeId});

  @override
  List<Object?> get props => [storeId];
}

class RefreshGetStoreByOwnerIdEvent extends StoresEvent {
  final int ownerId;
  const RefreshGetStoreByOwnerIdEvent({required this.ownerId});

  @override
  List<Object?> get props => [ownerId];
}
