import 'package:booking_v1/featuers/stores/domain/entities/store_social_account.dart';
import 'package:equatable/equatable.dart';

import '../../../domain/entities/store.dart';

abstract class StoresState extends Equatable {
  const StoresState();
  @override
  List<Object?> get props => [];
}

class StoresInitialState extends StoresState {}

class LoadingStoresState extends StoresState {}

class LoadedStoresState extends StoresState {
  final List<Store> stores;

  const LoadedStoresState({required this.stores});

  @override
  List<Object?> get props => [stores];
}

// class LoadedStoreSocialAccountState extends StoresState {
//   final List<StoreSocialAccount> storeSocial;

//   const LoadedStoreSocialAccountState({required this.storeSocial});

//   @override
//   List<Object?> get props => [storeSocial];
// }

class LoadedStoreByIdState extends StoresState {
  final Store store;
  final List<StoreSocialAccount>? storeSocial;

  const LoadedStoreByIdState({required this.store, this.storeSocial});

  @override
  List<Object?> get props => [store, storeSocial];
}

class ErrorStoresState extends StoresState {
  final String message;

  const ErrorStoresState({required this.message});

  @override
  List<Object?> get props => [message];
}
