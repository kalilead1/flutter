import 'package:flutter/material.dart';

import '../../../../../core/constants/strings.dart';
import '../../../../../core/widgets/container_widgets.dart';
import '../../../domain/entities/store_social_account.dart';

class StoreSocialMediaWidget extends StatelessWidget {
  final int? storeId;
  final List<StoreSocialAccount>? storeSocials;
  const StoreSocialMediaWidget(
      {super.key, required this.storeId, this.storeSocials});

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Padding(
        padding: const EdgeInsets.all(defaultPadding),
        child: Scaffold(
          appBar: PreferredSize(
            preferredSize: Size.fromHeight(90),
            child: AppBar(
              leading: IconButton(
                onPressed: () {
                  Navigator.pop(context);
                },
                icon: Icon(Icons.close),
              ),
              // foregroundColor: Theme.of(context).colorScheme.primary,
              title: Text("حسابات التواصل"),
              centerTitle: true,
            ),
          ),
          body: ListView.separated(
            itemBuilder: (context, index) {
              final storeSocial = storeSocials![index];
              return SecondaryContainer(
                paddingHorizontal: 0,
                paddingVertical: 0,
                child: ListTile(
                  leading: Icon(
                    storeSocial.socialAccountId == 1
                        ? Icons.facebook
                        : storeSocial.socialAccountId == 2
                            ? Icons.telegram
                            : storeSocial.socialAccountId == 3
                                ? Icons.insert_chart_outlined_outlined
                                : Icons.flourescent_rounded,
                  ),
                  title: Text(
                    storeSocial.socialAccount!.name.toString(),
                    style: Theme.of(context).textTheme.titleMedium,
                  ),
                  trailing: Icon(Icons.chevron_right),
                ),
              );
            },
            separatorBuilder: (context, index) {
              return SizedBox(height: defaultSpacing);
            },
            itemCount: storeSocials!.length,
          ),
        ),
      ),
    );
  }
}
