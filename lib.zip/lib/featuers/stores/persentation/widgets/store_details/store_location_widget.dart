import 'package:flutter/material.dart';

import '../../../../../core/constants/strings.dart';
import '../../../../../core/widgets/botton_widghts.dart';
import '../../../../../core/widgets/container_widgets.dart';

class StoreLocationWidget extends StatelessWidget {
  final String? city, region, street, addressDetails, locationCoordinates;
  const StoreLocationWidget({
    super.key,
    this.city,
    this.region,
    this.street,
    this.addressDetails,
    this.locationCoordinates,
  });

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Padding(
        padding: const EdgeInsets.all(defaultPadding),
        child: Scaffold(
          appBar: PreferredSize(
            preferredSize: Size.fromHeight(90),
            child: AppBar(
              leading: IconButton(
                onPressed: () {
                  Navigator.pop(context);
                },
                icon: Icon(Icons.close),
              ),
              title: Text("موقع المتجر"),
              centerTitle: true,
            ),
          ),
          body: Column(
            spacing: defaultSpacing,
            children: [
              SecondaryContainer(
                paddingHorizontal: 20,
                paddingVertical: 12,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Column(
                      children: [
                        Text(
                          "$city",
                          style: Theme.of(context).textTheme.titleMedium,
                        ),
                        Text(
                          "المدينة",
                          style: Theme.of(context).textTheme.bodySmall,
                        )
                      ],
                    ),
                    Column(
                      children: [
                        Text(
                          "$region",
                          style: Theme.of(context).textTheme.titleMedium,
                        ),
                        Text(
                          "المديرية",
                          style: Theme.of(context).textTheme.bodySmall,
                        )
                      ],
                    ),
                    Column(
                      children: [
                        Text(
                          street ?? "لا يوجد",
                          style: Theme.of(context).textTheme.titleMedium,
                        ),
                        Text(
                          "المنطقة",
                          style: Theme.of(context).textTheme.bodySmall,
                        )
                      ],
                    ),
                  ],
                ),
              ),
              SecondaryContainer(
                paddingHorizontal: 20,
                paddingVertical: 12,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "الموقع التفصيلي",
                      style: Theme.of(context).textTheme.bodySmall,
                    ),
                    Text(
                      // "الموقع التفصيلي الموقع التفصيلي الموقع التفصيلي الموقع التفصيلي الموقع التفصيلي",
                      "$locationCoordinates",
                      style: Theme.of(context).textTheme.titleMedium,
                    ),
                  ],
                ),
              ),
              Expanded(child: SizedBox()),
              SecondaryElevatedButton(
                  onPressed: () {}, text: "الموقع على خرايط قوقل")
            ],
          ),
        ),
      ),
    );
  }
}
