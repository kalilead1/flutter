import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../../../../dependency_injection/initial.dart';
import '../../../../bookings/persentation/bloc/bookings_query/bookings_query_bloc.dart';
import '../../../../bookings/persentation/bloc/bookings_query/bookings_query_event.dart';
import '../../../../bookings/persentation/bloc/bookings_query/bookings_query_state.dart';
import '../../../../services/persentation/bloc/services/services_bloc.dart';
import '../../../../services/persentation/bloc/services/services_event.dart';
import '../../../../services/persentation/bloc/services/services_state.dart';

class GetCountBookingsWidget extends StatelessWidget {
  final int storeId;
  const GetCountBookingsWidget({super.key, required this.storeId});

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (context) => getIt<BookingsQueryBloc>()
        ..addAndRemember(
          GetBookingsByStoreIdEvent(storeId: storeId),
        ),
      child: BlocBuilder<BookingsQueryBloc, BookingsQueryState>(
        builder: (context, state) {
          if (state is LoadedState) {
            return Text(state.bookings.length.toString(),
                style: Theme.of(context).textTheme.displayLarge);
          }
          return Text("0", style: Theme.of(context).textTheme.displayLarge);
        },
      ),
    );
  }
}

class GetCountServicesWidget extends StatelessWidget {
  final int storeId;
  const GetCountServicesWidget({super.key, required this.storeId});

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (context) => getIt<ServicesBloc>()
        ..addAndRemember(GetServiceByStoreIdEvent(storeId: storeId)),
      child: BlocBuilder<ServicesBloc, ServicesState>(
        builder: (context, state) {
          if (state is LoadedServicesState) {
            return Text(state.services.length.toString(),
                style: Theme.of(context).textTheme.displayLarge);
          }
          return Text("0", style: Theme.of(context).textTheme.displayLarge);
        },
      ),
    );
  }
}

// int testGetCountBookingsWidget() {
//   final t = getIt<BookingsRemoteDataSource>();

//   final tt =
//        t.getBookingsByStoreId(69, BookingsStatuesEnum.pendingPayment);
//   int x = 0;
//   tt
//   return x;
// }
