import 'package:booking_v1/core/widgets/view_image_ciracle_widget.dart';
import 'package:flutter/material.dart';

class ViewStoreHeaderWidget extends StatelessWidget {
  final String? storeId;
  final String? storeName;
  final String? storeLogo;
  final String? categoryName;
  const ViewStoreHeaderWidget({
    super.key,
    this.storeId,
    this.storeName,
    this.storeLogo,
    this.categoryName,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      constraints: BoxConstraints(minWidth: MediaQuery.of(context).size.width),
      decoration: BoxDecoration(
        image: DecorationImage(
          image: AssetImage(
            Theme.of(context).brightness == Brightness.light
                ? "assets/images/LightBackgroundStore.png"
                : "assets/images/DarkBackgroundStore.png",
          ),
          fit: BoxFit.cover,
        ),
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          storeLogo != null
              ? ViewImageCiracleWidget(
                  imageURL: storeLogo!,
                  size: 110,
                )
              : const SizedBox(),

          SizedBox(height: 10),
          Text("ID: $storeId", style: Theme.of(context).textTheme.labelSmall),
          Text("$storeName", style: Theme.of(context).textTheme.titleLarge),
          Text("$categoryName",
              style: Theme.of(context).textTheme.displaySmall),

          // categoryId != null
          //     ? ViewCategorySecondaryWidget(categoryId: categoryId!)
          //     : const SizedBox(),
          // Text("الفئة", style: Theme.of(context).textTheme.displaySmall),
          SizedBox(height: 10),
        ],
      ),
    );
  }
}
