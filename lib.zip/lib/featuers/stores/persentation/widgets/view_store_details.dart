// import 'package:flutter/material.dart';

// class ViewStoreDetails {
//   Future s(BuildContext context) {
//     return showModalBottomSheet(
//       context: context,
//       builder: (context) {
//         re
//       },
//     );
//   }
// }
