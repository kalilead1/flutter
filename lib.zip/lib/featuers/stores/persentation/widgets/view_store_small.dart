import 'package:booking_v1/core/routing/router_extensions.dart';
import 'package:booking_v1/core/widgets/urls_widget.dart';
import 'package:booking_v1/dependency_injection/initial.dart';
import 'package:booking_v1/featuers/stores/persentation/bloc/stores/stores_bloc.dart';
import 'package:booking_v1/featuers/stores/persentation/bloc/stores/stores_event.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_svg/svg.dart';

import '../../../../core/constants/api.dart';
import '../../../../core/constants/strings.dart';
import '../../../../core/routing/app_routes.dart';
import '../../../../core/widgets/container_widgets.dart';
import '../../../../core/widgets/view_image_ciracle_widget.dart';
import '../bloc/stores/stores_state.dart';

class ViewStoreSmallWidget extends StatelessWidget {
  final int storeId;
  final String storeLogo;
  final String storeName;
  final String? storeCity;
  final String? storeDirectorateName;
  const ViewStoreSmallWidget({
    super.key,
    required this.storeId,
    required this.storeLogo,
    required this.storeName,
    this.storeCity,
    this.storeDirectorateName,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        context.pushTo(storeDetailsRoute, extra: storeId);
      },
      child: Row(
        spacing: defaultSpacing / 3,
        mainAxisAlignment: MainAxisAlignment.start,
        children: [
          ViewImageCiracleWidget(
            imageURL: baseUrlStoreImagesFolder + storeLogo,
            size: 22,
          ),
          Text(
            storeName,
            style: Theme.of(context).textTheme.bodySmall,
          ),
          if (storeCity != null) ...[
            CircleAvatar(
              radius: 2,
              backgroundColor:
                  Theme.of(context).colorScheme.tertiary.withOpacity(0.7),
            ),
            Text(
              storeCity!,
              style: Theme.of(context).textTheme.bodySmall,
              softWrap: true,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            )
          ],

          // SizedBox(),
          storeDirectorateName != null
              ? Text(
                  storeDirectorateName!,
                  style: Theme.of(context).textTheme.bodySmall,
                )
              : SizedBox(),
        ],
      ),
    );
  }
}

class ViewStoreMedium extends StatelessWidget {
  final int storeId;
  const ViewStoreMedium({super.key, required this.storeId});

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (context) =>
          getIt<StoresBloc>()..add(GetStoreByIdEvent(storeId: storeId)),
      child: BlocBuilder<StoresBloc, StoresState>(
        builder: (context, state) {
          if (state is LoadedStoreByIdState) {
            final store = state.store;
            return SecondaryContainer(
              paddingHorizontal: 0,
              paddingVertical: 0,
              child: ListTile(
                contentPadding: EdgeInsets.only(right: defaultPadding),
                onTap: () {
                  context.pushTo(storeDetailsRoute, extra: store.id);
                },
                leading: ViewImageCiracleWidget(
                  imageURL: store.logo != null
                      ? baseUrlStoreImagesFolder + store.logo!
                      : baseUrlStoreImagesFolder,
                  size: 40,
                ),
                title: Text(
                  store.name.toString(),
                  style: Theme.of(context).textTheme.titleMedium,
                ),
                // subtitle: Text(
                //   "الموقع",
                //   style: Theme.of(context).textTheme.bodyMedium,
                // ),
                trailing: Wrap(
                  children: [
                    IconButton(
                      onPressed: () {
                        Urls.urlMessage(store.phone!);
                      },
                      icon: Icon(Icons.message_rounded),
                    ),
                    IconButton(
                      onPressed: () {
                        Urls.urlPhone(store.phone!);
                      },
                      icon: Icon(Icons.phone),
                    ),
                  ],
                ),
              ),
            );
          }
          return SecondaryContainer(
            paddingHorizontal: 0,
            paddingVertical: 0,
            child: ListTile(
              contentPadding: EdgeInsets.only(right: defaultPadding),
              // dense: true,
              leading: SvgPicture.asset(
                alignment: Alignment.centerLeft,
                "assets/logos/logo4.svg",
                colorFilter: ColorFilter.mode(
                  Theme.of(context).colorScheme.tertiary.withValues(alpha: 0.4),
                  BlendMode.srcIn,
                ),
                height: 26,
              ),
              // title: Text(
              //   store.name.toString(),
              //   style: Theme.of(context).textTheme.titleMedium,
              // ),

              trailing: Wrap(
                children: [
                  IconButton(
                    onPressed: () {},
                    icon: Icon(Icons.message_rounded),
                  ),
                  IconButton(
                    onPressed: () {},
                    icon: Icon(Icons.phone),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}
