import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';

import '../../../../core/constants/strings.dart';
import '../../../../core/widgets/text_widgets.dart';

class ViewPopularStores extends StatefulWidget {
  const ViewPopularStores({super.key});

  @override
  State<ViewPopularStores> createState() => _ViewPopularStoresState();
}

class _ViewPopularStoresState extends State<ViewPopularStores> {
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 0),
      child: Column(
        spacing: defaultSpacing / 3,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(),
          PrimaryTitle(
            title: "المتاجر الرائيجة",
            onTap: () {
              return SizedBox();
            },
          ),

          SizedBox(
            height: 100,
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              itemCount: 8,
              itemBuilder: (context, index) {
                return Container(
                  margin: EdgeInsets.symmetric(horizontal: 4),
                  child: Column(
                    children: [
                      Stack(
                        children: [
                          Container(
                            decoration: BoxDecoration(
                              color: Theme.of(context).colorScheme.secondary,
                              border: Border.all(
                                color: Theme.of(context).colorScheme.primary,
                                width: 2,
                              ),
                              shape: BoxShape.circle,
                            ),
                            child: CircleAvatar(
                              radius: 34,
                              child: Center(
                                child: SvgPicture.asset(
                                  "assets/logos/logo4.svg",
                                  colorFilter: ColorFilter.mode(
                                    Theme.of(context)
                                        .colorScheme
                                        .tertiary
                                        .withOpacity(0.20),
                                    BlendMode.srcIn,
                                  ),
                                  height: 30,
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            bottom: double.minPositive,
                            right: 9,
                            width: 55,
                            child: Container(
                              decoration: BoxDecoration(
                                color: Theme.of(context).colorScheme.primary,
                                borderRadius:
                                    BorderRadius.circular(defaultBorderRadious),
                              ),
                              child: Text(
                                textAlign: TextAlign.center,
                                "الفئة $index",
                                // style: Theme.of(context).textTheme.titleSmall,
                                style: TextStyle(
                                  fontSize: 12,
                                  color: Colors.white,
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                      Text(
                        "اسم المتجر",
                        style: Theme.of(context).textTheme.titleSmall,
                      ),
                    ],
                  ),
                );
              },
            ),
          )

          // CustomScrollView(
          //   // scrollDirection: Axis.horizontal,
          //   slivers: [
          //     SliverList(
          //       delegate: SliverChildBuilderDelegate(
          //         (context, index) {
          //           return Container(
          //             margin: const EdgeInsets.all(12),
          //             height: 100,
          //             color: Colors.orange.shade200,
          //             child: Center(child: Text("متجر $index")),
          //           );
          //         },
          //         childCount: 7,
          //       ),
          //     ),
          //   ],
          // ),
        ],
      ),
    );
  }
}
