import 'package:booking_v1/featuers/main/domain/entities/wallet.dart';
import 'package:booking_v1/featuers/main/persentation/widgets/selections/selection_wallet_widget_test.dart';
import 'package:booking_v1/featuers/stores/data/models/store_wallet_model.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../../../../../core/constants/strings.dart';
import '../../../../../core/widgets/botton_widghts.dart';
import '../../../../../core/widgets/input_widgets.dart';
import '../../../domain/entities/store_wallet.dart';

class StoreWalletForm extends StatefulWidget {
  final List<int> excludedWalletIds;
  final Function(StoreWallet)? onSaved;
  const StoreWalletForm({
    super.key,
    required this.excludedWalletIds,
    this.onSaved,
  });

  @override
  State<StoreWalletForm> createState() => _StoreWalletFormState();
}

class _StoreWalletFormState extends State<StoreWalletForm> {
  final keyForm = GlobalKey<FormState>();
  Wallet? wallet;
  TextEditingController walletAccountController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Form(
        key: keyForm,
        child: Column(
          spacing: defaultSpacing,
          children: [
            SelectionWalletWidgetTest(
              onSelected: (value) {
                wallet = value;
              },
              excludedWalletIds: widget.excludedWalletIds,
            ),
            CustomInputFieldWidget(
              label: "رقم الحساب",
              textController: walletAccountController,
              textInputType: TextInputType.number,
            ),
            SizedBox(),
            PrimaryElevatedButton(
              onPressed: () {
                if (keyForm.currentState!.validate()) {
                  final storeWallet = StoreWallet(
                    // id: ,
                    accountNumber: int.tryParse(walletAccountController.text),
                    walletId: wallet!.id,
                    wallet: wallet,
                  );
                  widget.onSaved != null ? widget.onSaved!(storeWallet) : null;
                  // storeWalletList?.add(storeWallet);
                  // Navigator.pop(context);
                  context.pop();
                }
              },
              text: "حفظ",
            )
          ],
        ),
      ),
    );
  }
}

void addStoreWalletDialog({
  required BuildContext context,
  Function(StoreWallet)? onSaved,
  required List<int> excludedWalletIds,
}) {
  showDialog(
    context: context,
    builder: (context) {
      return Padding(
        padding: const EdgeInsets.symmetric(horizontal: 1),
        child: Dialog(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(defaultBorderRadious),
          ),
          backgroundColor: Theme.of(context).scaffoldBackgroundColor,
          insetPadding: EdgeInsets.all(defaultPadding),
          child: Padding(
            padding: EdgeInsets.all(defaultPadding),
            child: Column(
              spacing: defaultSpacing * 2,
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  "اضافة محفظة",
                  style: Theme.of(context).textTheme.titleLarge,
                ),
                StoreWalletForm(
                  onSaved: onSaved,
                  excludedWalletIds: excludedWalletIds,
                ),
              ],
            ),
          ),
        ),
      );
    },
  );
}

////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////
class StoreWalletFormTest extends StatefulWidget {
  final List<int> excludedWalletIds;
  final Function(StoreWalletModel)? onSaved;
  const StoreWalletFormTest({
    super.key,
    required this.excludedWalletIds,
    this.onSaved,
  });

  @override
  State<StoreWalletFormTest> createState() => _StoreWalletFormTestState();
}

class _StoreWalletFormTestState extends State<StoreWalletFormTest> {
  final keyForm = GlobalKey<FormState>();
  Wallet? wallet;
  TextEditingController walletAccountController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Form(
        key: keyForm,
        child: Column(
          spacing: defaultSpacing,
          children: [
            SelectionWalletWidgetTest(
              onSelected: (value) {
                wallet = value;
              },
              excludedWalletIds: widget.excludedWalletIds,
            ),
            CustomInputFieldWidget(
              label: "رقم الحساب",
              textController: walletAccountController,
              textInputType: TextInputType.number,
            ),
            SizedBox(),
            PrimaryElevatedButton(
              onPressed: () {
                if (keyForm.currentState!.validate()) {
                  final storeWallet = StoreWalletModel(
                    // id: ,
                    accountNumber: int.tryParse(walletAccountController.text),
                    walletId: wallet!.id,
                    wallet: wallet,
                  );
                  widget.onSaved != null ? widget.onSaved!(storeWallet) : null;
                  // storeWalletList?.add(storeWallet);
                  // Navigator.pop(context);
                  context.pop();
                }
              },
              text: "حفظ",
            )
          ],
        ),
      ),
    );
  }
}

void addStoreWalletDialogTest({
  required BuildContext context,
  Function(StoreWalletModel)? onSaved,
  required List<int> excludedWalletIds,
}) {
  showDialog(
    context: context,
    builder: (context) {
      return Padding(
        padding: const EdgeInsets.symmetric(horizontal: 1),
        child: Dialog(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(defaultBorderRadious),
          ),
          backgroundColor: Theme.of(context).scaffoldBackgroundColor,
          insetPadding: EdgeInsets.all(defaultPadding),
          child: Padding(
            padding: EdgeInsets.all(defaultPadding),
            child: Column(
              spacing: defaultSpacing * 2,
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  "اضافة محفظة",
                  style: Theme.of(context).textTheme.titleLarge,
                ),
                StoreWalletFormTest(
                  onSaved: onSaved,
                  excludedWalletIds: excludedWalletIds,
                ),
              ],
            ),
          ),
        ),
      );
    },
  );
}
