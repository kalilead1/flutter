import 'package:booking_v1/featuers/main/domain/entities/social_account.dart';
import 'package:booking_v1/featuers/stores/data/models/store_social_account_model.dart';
import 'package:booking_v1/featuers/stores/domain/entities/store_social_account.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../../../../../core/constants/strings.dart';
import '../../../../../core/widgets/botton_widghts.dart';
import '../../../../../core/widgets/input_widgets.dart';
import '../../../../main/persentation/widgets/selections/selection_social_account_widget.dart';

class StoreSocialAccountForm extends StatefulWidget {
  final List<int> excludedSocailIds;
  final Function(StoreSocialAccount)? onSaved;
  const StoreSocialAccountForm({
    super.key,
    required this.excludedSocailIds,
    this.onSaved,
  });

  @override
  State<StoreSocialAccountForm> createState() => _StoreSocialAccountFormState();
}

class _StoreSocialAccountFormState extends State<StoreSocialAccountForm> {
  final keyForm = GlobalKey<FormState>();
  SocialAccount? selectedSocial;
  // TextEditingController walletIdController = TextEditingController();
  TextEditingController socialAccountController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Form(
        key: keyForm,
        child: Column(
          spacing: defaultSpacing,
          children: [
            SelectionSocialAccountWidget(
              onSelected: (value) {
                selectedSocial = value;
              },
              excludedSocialIds: widget.excludedSocailIds,
            ),
            CustomInputFieldWidget(
              label: "رابط الحساب",
              textController: socialAccountController,
              textInputType: TextInputType.url,
            ),
            SizedBox(),
            PrimaryElevatedButton(
              onPressed: () {
                if (keyForm.currentState!.validate()) {
                  final storeSocialAccount = StoreSocialAccount(
                    // id: ,
                    url: socialAccountController.text,
                    socialAccountId: selectedSocial!.id,
                    socialAccount: selectedSocial,
                  );
                  widget.onSaved != null
                      ? widget.onSaved!(storeSocialAccount)
                      : null;
                  context.pop();
                }
              },
              text: "حفظ",
            )
          ],
        ),
      ),
    );
  }
}

// class StoreSocialAccountForm extends StatelessWidget {
//   final List<int> excludedSocailIds;
//   final Function(StoreSocialAccount)? onSaved;
//   const StoreSocialAccountForm({
//     super.key,
//     required this.excludedSocailIds,
//     this.onSaved,
//   });

//   @override
//   Widget build(BuildContext context) {
//   final keyForm = GlobalKey<FormState>();
//   SocialAccount? selectedSocial;
//   // TextEditingController walletIdController = TextEditingController();
//   TextEditingController socialAccountController = TextEditingController();
//   return Directionality(
//     textDirection: TextDirection.rtl,
//     child: Form(
//       key: keyForm,
//       child: Column(
//         spacing: defaultSpacing,
//         children: [
//           SelectionSocialAccountWidget(
//             onSelected: (value) {
//               selectedSocial = value;
//             },
//             excludedSocialIds: excludedSocailIds,
//           ),
//           CustomInputFieldWidget(
//             label: "رابط الحساب",
//             textController: socialAccountController,
//             textInputType: TextInputType.url,
//           ),
//           SizedBox(),
//           PrimaryElevatedButton(
//             onPressed: () {
//               if (keyForm.currentState!.validate()) {
//                 final storeSocialAccount = StoreSocialAccount(
//                   // id: ,
//                   url: socialAccountController.text,
//                   socialAccountId: selectedSocial!.id,
//                   socialAccount: selectedSocial,
//                 );
//                 onSaved != null ? onSaved!(storeSocialAccount) : null;
//                 context.pop();
//               }
//             },
//             text: "حفظ",
//           )
//         ],
//       ),
//     ),
//   );
// }
// }

void addStoreSocialAccountDialog({
  required BuildContext context,
  Function(StoreSocialAccount)? onSaved,
  required List<int> excludedSocialIds,
}) {
  showDialog(
    context: context,
    builder: (context) {
      return Padding(
        padding: const EdgeInsets.symmetric(horizontal: 1),
        child: Dialog(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(defaultBorderRadious),
          ),
          backgroundColor: Theme.of(context).scaffoldBackgroundColor,
          insetPadding: EdgeInsets.all(defaultPadding),
          child: Padding(
            padding: EdgeInsets.all(defaultPadding),
            child: Column(
              spacing: defaultSpacing * 2,
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  "اضافة حساب تواصل ${excludedSocialIds.length}",
                  style: Theme.of(context).textTheme.titleLarge,
                ),
                StoreSocialAccountForm(
                  onSaved: onSaved,
                  excludedSocailIds: excludedSocialIds,
                ),
              ],
            ),
          ),
        ),
      );
    },
  );
}

////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////
class StoreSocialAccountFormTest extends StatefulWidget {
  final List<int> excludedSocailIds;
  final Function(StoreSocialAccountModel)? onSaved;
  const StoreSocialAccountFormTest({
    super.key,
    required this.excludedSocailIds,
    this.onSaved,
  });

  @override
  State<StoreSocialAccountFormTest> createState() =>
      _StoreSocialAccountFormTestState();
}

class _StoreSocialAccountFormTestState
    extends State<StoreSocialAccountFormTest> {
  final keyForm = GlobalKey<FormState>();
  SocialAccount? selectedSocial;
  // TextEditingController walletIdController = TextEditingController();
  TextEditingController socialAccountController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Form(
        key: keyForm,
        child: Column(
          spacing: defaultSpacing,
          children: [
            SelectionSocialAccountWidget(
              onSelected: (value) {
                selectedSocial = value;
              },
              excludedSocialIds: widget.excludedSocailIds,
            ),
            CustomInputFieldWidget(
              label: "رابط الحساب",
              textController: socialAccountController,
              textInputType: TextInputType.url,
            ),
            SizedBox(),
            PrimaryElevatedButton(
              onPressed: () {
                if (keyForm.currentState!.validate()) {
                  final storeSocialAccount = StoreSocialAccountModel(
                    // id: ,
                    url: socialAccountController.text,
                    socialAccountId: selectedSocial!.id,
                    socialAccount: selectedSocial,
                  );
                  widget.onSaved != null
                      ? widget.onSaved!(storeSocialAccount)
                      : null;
                  context.pop();
                }
              },
              text: "حفظ",
            )
          ],
        ),
      ),
    );
  }
}

void addStoreSocialAccountDialogTest({
  required BuildContext context,
  Function(StoreSocialAccountModel)? onSaved,
  required List<int> excludedSocialIds,
}) {
  showDialog(
    context: context,
    builder: (context) {
      return Padding(
        padding: const EdgeInsets.symmetric(horizontal: 1),
        child: Dialog(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(defaultBorderRadious),
          ),
          backgroundColor: Theme.of(context).scaffoldBackgroundColor,
          insetPadding: EdgeInsets.all(defaultPadding),
          child: Padding(
            padding: EdgeInsets.all(defaultPadding),
            child: Column(
              spacing: defaultSpacing * 2,
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  "اضافة حساب تواصل ${excludedSocialIds.length}",
                  style: Theme.of(context).textTheme.titleLarge,
                ),
                StoreSocialAccountFormTest(
                  onSaved: onSaved,
                  excludedSocailIds: excludedSocialIds,
                ),
              ],
            ),
          ),
        ),
      );
    },
  );
}
