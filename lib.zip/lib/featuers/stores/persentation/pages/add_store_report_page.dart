import 'package:booking_v1/core/constants/colors.dart';
import 'package:booking_v1/core/constants/strings.dart';
import 'package:booking_v1/core/widgets/container_widgets.dart';
import 'package:booking_v1/core/widgets/input_widgets.dart';
import 'package:booking_v1/core/widgets/view_image_ciracle_widget.dart';
import 'package:booking_v1/featuers/stores/persentation/bloc/store_report/store_report_event.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:go_router/go_router.dart';

import '../../../../core/constants/api.dart';
import '../../../../core/widgets/bottom_items.dart';
import '../../../../core/widgets/botton_widghts.dart';
import '../../../../core/widgets/snack_bar_widgets.dart';
import '../../domain/entities/store.dart';
import '../../domain/entities/store_report.dart';
import '../../domain/enums/store_report_enum.dart';
import '../bloc/store_report/store_report_bloc.dart';
import '../bloc/store_report/store_report_state.dart';

class AddStoreReportPage extends StatefulWidget {
  final Store store;
  const AddStoreReportPage({super.key, required this.store});

  @override
  State<AddStoreReportPage> createState() => _AddStoreReportPageState();
}

class _AddStoreReportPageState extends State<AddStoreReportPage> {
  StoreReportEnum? _selectedReportType;
  final TextEditingController _messageController = TextEditingController();
  final _formKey = GlobalKey<FormState>();

  void _submitReport() {
    if (_formKey.currentState!.validate()) {
      if (_selectedReportType == null) {
        showSnackBarError(context: context, error: 'الرجاء اختيار نوع البلاغ');
      } else {
        final data = StoreReport(
          comment: _messageController.text,
          reason: _selectedReportType,
          storeId: widget.store.id,
        );
        context
            .read<StoreReportBloc>()
            .add(AddStoreReportEvent(storeReport: data));
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl, // دعم العربية
      child: Scaffold(
        appBar: AppBar(title: const Text('البلاغ عن متجر')),
        body: SingleChildScrollView(
          child: BlocConsumer<StoreReportBloc, StoreReportState>(
            listener: (context, state) {
              if (state is SuccessfullyAddedState) {
                return showSnackBarSuccess(
                    context: context, success: state.message);
              } else if (state is ErrorAddedState) {
                return showSnackBarError(
                    context: context, error: state.message);
              }
            },
            builder: (context, state) {
              if (state is LoadingState) {
                return Center(child: CircularProgressIndicator());
              }
              return Padding(
                padding: const EdgeInsets.all(defaultPadding),
                child: Form(
                  key: _formKey,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // عرض معرف المتجر
                      Text(
                        "هل تريد الابلاغ على هذا المتجر؟",
                        style: TextStyle(color: errorColor),
                      ),
                      SizedBox(height: 5),
                      Container(
                        padding: const EdgeInsets.symmetric(vertical: 6),
                        decoration: BoxDecoration(
                          color: errorColor.withValues(alpha: 0.25),
                          border: Border.all(color: errorColor),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: ListTile(
                          // dense: true,
                          leading: ViewImageCiracleWidget(
                            imageURL:
                                baseUrlStoreImagesFolder + widget.store.logo!,
                            size: 50,
                          ),
                          title: Text(
                            widget.store.name.toString(),
                            style: Theme.of(context).textTheme.titleMedium,
                          ),
                          subtitle: Text(
                            widget.store.category!.name.toString(),
                            style: Theme.of(context).textTheme.displaySmall,
                          ),
                        ),
                      ),

                      const SizedBox(height: 24),

                      // عنوان نوع البلاغ
                      Text(
                        'نوع البلاغ',
                        style: Theme.of(context).textTheme.titleLarge,
                      ),

                      const SizedBox(height: 15),

                      // قائمة أنواع البلاغات - استخدام arabicName من الامتداد
                      SecondaryContainer(
                          paddingVertical: 2,
                          child: Column(
                            children: [
                              ...StoreReportEnum.values.map((type) {
                                return RadioListTile<StoreReportEnum>(
                                  dense: true,
                                  title: Text(
                                      type.arabicName), // استخدام arabicName
                                  value: type,
                                  groupValue: _selectedReportType,
                                  onChanged: (value) {
                                    setState(() {
                                      _selectedReportType = value;
                                    });
                                  },
                                  activeColor:
                                      Theme.of(context).colorScheme.primary,
                                  contentPadding: EdgeInsets.zero,
                                );
                              }).toList(),
                            ],
                          )),

                      const SizedBox(height: 20),

                      CustomInputFieldWidget(
                        label: "تفاصيل البلاغ",
                        textController: _messageController,
                        maxLength: 150,
                        minLines: 1,
                        maxLines: 4,
                        textInputType: TextInputType.name,
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
        ),
        bottomNavigationBar: TwoBottomItems(
          child1: PrimaryElevatedButton(
            onPressed: () {
              _submitReport();
            },
            text: "تأكيد البلاغ",
          ),
          child2: SecondaryElevatedButton(
            onPressed: () {
              context.pop();
            },
            text: "الغاء",
          ),
        ),
      ),
    );
  }
}
