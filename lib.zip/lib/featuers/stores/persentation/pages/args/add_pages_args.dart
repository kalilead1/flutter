import '../../../domain/entities/store.dart';
import '../../../domain/entities/store_social_account.dart';
import '../../../domain/entities/store_wallet.dart';

class AddUpdateStoreBaiscAndLocationArgs {
  final Store? store;
  final bool isUpdateStore;

  AddUpdateStoreBaiscAndLocationArgs({this.store, this.isUpdateStore = false});
}

class AddUpdateStoreSocialAccountArgs {
  final List<StoreSocialAccount>? storeSocials;
  final bool isUpdateStore;

  AddUpdateStoreSocialAccountArgs(
      {this.storeSocials, this.isUpdateStore = false});
}

class AddUpdateStoreWalletsArgs {
  final List<StoreWallet>? storeWallets;
  final bool isUpdateStore;

  AddUpdateStoreWalletsArgs({this.storeWallets, this.isUpdateStore = false});
}
