import 'package:booking_v1/core/widgets/dialog_widgets.dart';
import 'package:booking_v1/dependency_injection/initial.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:go_router/go_router.dart';

import '../../../../../core/constants/colors.dart';
import '../../../../../core/constants/strings.dart';
import '../../../../../core/widgets/bottom_items.dart';
import '../../../../../core/widgets/botton_widghts.dart';
import '../../../../../core/widgets/container_widgets.dart';
import '../../../../../core/widgets/custom_steps_add_widget.dart';
import '../../../../../core/widgets/snack_bar_widgets.dart';
import '../../../domain/entities/store_social_account.dart';
import '../../bloc/store_social_accounts/store_social_accounts_bloc.dart';
import '../../bloc/store_social_accounts/store_social_accounts_event.dart';
import '../../bloc/store_social_accounts/store_social_accounts_state.dart';
import '../../widgets/forms/store_social_account_form.dart';

class UpdateStoreSocialAccountPage extends StatefulWidget {
  final int storeId;
  const UpdateStoreSocialAccountPage({super.key, required this.storeId});

  @override
  State<UpdateStoreSocialAccountPage> createState() =>
      _UpdateStoreSocialAccountPageState();
}

class _UpdateStoreSocialAccountPageState
    extends State<UpdateStoreSocialAccountPage> {
  List<int> usedSocialIds = [];

  late final StoreSocialAccountsBloc _accountsBloc;

  @override
  void initState() {
    _accountsBloc = getIt<StoreSocialAccountsBloc>();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (context) => _accountsBloc
        ..addAndRemember(
            GetStoreSocialsByStoreIdEvent(storeId: widget.storeId)),
      child: Directionality(
        textDirection: TextDirection.rtl,
        child: Scaffold(
          appBar: AppBar(
            title: Text("تعديل متجر"),
          ),
          body: Padding(
            padding: const EdgeInsets.all(defaultPadding),
            child: Column(
              spacing: defaultSpacing,
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  "حسابات تواصل الاجتماعية",
                  style: Theme.of(context).textTheme.displayLarge,
                ),
                Row(
                  spacing: 6,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    CustomContainerStepsAddWidget(),
                  ],
                ),
                SizedBox(),
                SecondaryElevatedButton(
                  onPressed: () {
                    addStoreSocialAccountDialog(
                      context: context,
                      excludedSocialIds: usedSocialIds,
                      onSaved: (p0) {
                        setState(() {
                          final storeSocial = StoreSocialAccount(
                            url: p0.url,
                            socialAccountId: p0.socialAccountId,
                            storeId: widget.storeId,
                          );

                          _accountsBloc.add(
                              AddStoreSocialEvent(storeSocial: storeSocial));
                        });
                      },
                    );
                  },
                  text: "اضافة حساب تواصل",
                ),
                SizedBox(),
                BlocConsumer<StoreSocialAccountsBloc, StoreSocialAccountsState>(
                  listener: (context, state) {
                    if (state is SuccessfullyStoreSocialState) {
                      return showSnackBarSuccess(
                          context: context, success: state.message);
                    } else if (state is ErrorStoreSocialState) {
                      return showSnackBarError(
                          context: context, error: state.message);
                    }
                  },
                  builder: (context, state) {
                    if (state is LoadingStoreSocialState) {
                      return Expanded(
                          child: Center(child: CircularProgressIndicator()));
                    } else if (state is ErrorStoreSocialState) {
                      if (state.message == emptyCacheFailureMessage) {
                        return Expanded(
                            child: Center(
                                child: Text("لا يوجد اي حسابات تواصل لمتجرك")));
                      }
                      return Expanded(
                          child: Center(child: Text(state.message)));
                    } else if (state is LoadedStoreSocialsState) {
                      usedSocialIds.clear();
                      for (var socialId in state.storeSocials) {
                        usedSocialIds.add(socialId.socialAccountId!);
                      }
                      // return Center(child: Text("data"));
                      return Expanded(
                        child: ListView.separated(
                          itemCount: state.storeSocials.length,
                          separatorBuilder: (context, index) {
                            return SizedBox(height: defaultSpacing);
                          },
                          itemBuilder: (context, index) {
                            final storeSocial = state.storeSocials[index];
                            return SecondaryContainer(
                              paddingHorizontal: 0,
                              paddingVertical: 0,
                              child: ListTile(
                                leading: CircleAvatar(
                                  radius: 25,
                                  backgroundColor: Theme.of(context)
                                      .colorScheme
                                      .primaryContainer,
                                  child: Icon(
                                    Icons.connect_without_contact,
                                    color: Theme.of(context)
                                        .colorScheme
                                        .tertiary
                                        .withValues(alpha: 0.6),
                                  ),
                                ),
                                title: Text(
                                    storeSocial.socialAccount!.name.toString()),
                                subtitle: Text(storeSocial.url.toString()),
                                trailing: IconButton(
                                  onPressed: () {
                                    AppDialog.showCustomDialog(
                                      title: "حذف حساب التواصل",
                                      content:
                                          "هل انت متاكد من حذف حساب التواصل ${storeSocial.socialAccount!.name}",
                                      context: context,
                                      childAction: PrimaryElevatedButton(
                                          onPressed: () {
                                            _accountsBloc.add(
                                                DeleteStoreSocialEvent(
                                                    storeSocialId:
                                                        storeSocial.id!));
                                          },
                                          text: "تاكيد الحذف"),
                                    );
                                  },
                                  icon: Icon(
                                    Icons.delete,
                                    color: errorColor,
                                  ),
                                ),
                              ),
                            );
                          },
                        ),
                      );
                    } else {
                      return Expanded(
                          child: Center(child: Text("خطاء غير متوقع")));
                    }
                  },
                ),
              ],
            ),
          ),
          bottomNavigationBar: TwoBottomItems(
            child1: SecondaryElevatedButton(
              onPressed: () {
                context.pop();
              },
              text: "الغاء",
            ),
          ),
        ),
      ),
    );
  }
}
