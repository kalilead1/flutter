import 'package:booking_v1/core/widgets/dialog_widgets.dart';
import 'package:booking_v1/dependency_injection/initial.dart';
import 'package:booking_v1/featuers/stores/persentation/bloc/store_wallets/store_wallets_bloc.dart';
import 'package:booking_v1/featuers/stores/persentation/bloc/store_wallets/store_wallets_event.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:go_router/go_router.dart';

import '../../../../../core/constants/colors.dart';
import '../../../../../core/constants/strings.dart';
import '../../../../../core/widgets/bottom_items.dart';
import '../../../../../core/widgets/botton_widghts.dart';
import '../../../../../core/widgets/container_widgets.dart';
import '../../../../../core/widgets/custom_steps_add_widget.dart';
import '../../../../../core/widgets/snack_bar_widgets.dart';
import '../../../domain/entities/store_wallet.dart';
import '../../bloc/store_wallets/store_wallets_state.dart';
import '../../widgets/forms/store_wallet_form.dart';

class UpdateStoreWalletsPage extends StatefulWidget {
  final int storeId;
  const UpdateStoreWalletsPage({super.key, required this.storeId});

  @override
  State<UpdateStoreWalletsPage> createState() => _UpdateStoreWalletsPageState();
}

class _UpdateStoreWalletsPageState extends State<UpdateStoreWalletsPage> {
  // StoreWallet? storeWallet;
  List<int> walletIds = [];

  // @override
  // void initState() {
  //   // storeWalletList = widget.storeWallets!;
  //   super.initState();
  // }

  // void validateFormThenAddOrUpdateStore() {
  //   // BlocProvider and use update store event
  //   if (storeWallet != null) {
  //     context
  //         .read<StoreWalletsBloc>()
  //         .add(AddStoreWalletEvent(storeWallet: storeWallet!));
  //   }
  // }

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (context) => getIt<StoreWalletsBloc>()
        ..addAndRemember(
            GetStoreWalletsByStoreIdEvent(storeId: widget.storeId)),
      child: Directionality(
        textDirection: TextDirection.rtl,
        child: Scaffold(
          appBar: AppBar(
            title: Text("تعديل متجر"),
          ),
          body: Padding(
            padding: const EdgeInsets.all(defaultPadding),
            child: Column(
              spacing: defaultSpacing,
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  "محافظ المتجر",
                  style: Theme.of(context).textTheme.displayLarge,
                ),
                Row(
                  spacing: 6,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    CustomContainerStepsAddWidget(),
                  ],
                ),
                SizedBox(),
                SecondaryElevatedButton(
                  onPressed: () {
                    addStoreWalletDialog(
                      context: context,
                      excludedWalletIds: walletIds,
                      onSaved: (p0) {
                        setState(() {
                          final storeWallet = StoreWallet(
                            accountNumber: p0.accountNumber,
                            walletId: p0.walletId,
                            storeId: widget.storeId,
                          );

                          context.read<StoreWalletsBloc>().add(
                              AddStoreWalletEvent(storeWallet: storeWallet));
                          // validateFormThenAddOrUpdateStore();
                        });
                      },
                    );
                  },
                  text: "اضافة محفظة",
                ),
                SizedBox(),
                BlocConsumer<StoreWalletsBloc, StoreWalletsState>(
                  listener: (context, state) {
                    if (state is SuccessfullyAddStoreWalletsState) {
                      return showSnackBarSuccess(
                          context: context,
                          success: "تم اضافة محفظة جديدة بنجاح");
                    } else if (state is SuccessfullyDeleteStoreWalletsState) {
                      return showSnackBarSuccess(
                          context: context, success: "تم حذف المحفظة بنجاح");
                    } else if (state is ErrorStoreWalletsState) {
                      return showSnackBarError(
                          context: context, error: state.message);
                    }
                  },
                  builder: (context, state) {
                    if (state is LoadingStoreWalletsState) {
                      return Expanded(
                          child: Center(child: CircularProgressIndicator()));
                    } else if (state is ErrorStoreWalletsState) {
                      if (state.message == emptyCacheFailureMessage) {
                        return Expanded(
                            child:
                                Center(child: Text("لا يوجد اي محفظة لمتجرك")));
                      }
                      return Expanded(
                          child: Center(child: Text("خطاء غير متوقع")));
                    } else if (state is LoadedStoreWalletsState) {
                      walletIds.clear();
                      for (var walletId in state.storeWallets) {
                        walletIds.add(walletId.walletId!);
                      }
                      // return Center(child: Text("data"));
                      return Expanded(
                        child: ListView.separated(
                          itemCount: state.storeWallets.length,
                          separatorBuilder: (context, index) {
                            return SizedBox(height: defaultSpacing);
                          },
                          itemBuilder: (context, index) {
                            final sw = state.storeWallets[index];
                            return SecondaryContainer(
                              paddingHorizontal: 0,
                              paddingVertical: 0,
                              child: ListTile(
                                leading: CircleAvatar(
                                  radius: 25,
                                  backgroundColor: Theme.of(context)
                                      .colorScheme
                                      .primaryContainer,
                                  child: Icon(
                                    Icons.wallet,
                                    color: Theme.of(context)
                                        .colorScheme
                                        .tertiary
                                        .withValues(alpha: 0.6),
                                  ),
                                ),
                                title: Text(sw.wallet!.name.toString()),
                                subtitle: Text(sw.accountNumber.toString()),
                                trailing: IconButton(
                                  onPressed: () {
                                    AppDialog.showCustomDialog(
                                      title: "حذف محفظة",
                                      content:
                                          "هل انت متاكد من حذف محفظة ${sw.wallet!.name}",
                                      context: context,
                                      childAction: PrimaryElevatedButton(
                                          onPressed: () {
                                            context
                                                .read<StoreWalletsBloc>()
                                                .add(DeleteStoreWalletEvent(
                                                    storeWalletId: sw.id!));
                                          },
                                          text: "تاكيد الحذف"),
                                    );
                                  },
                                  icon: Icon(
                                    Icons.delete,
                                    color: errorColor,
                                  ),
                                ),
                              ),
                            );
                          },
                        ),
                      );
                    } else {
                      return Expanded(
                          child: Center(child: Text("خطاء غير متوقع")));
                    }
                  },
                ),
              ],
            ),
          ),
          bottomNavigationBar: TwoBottomItems(
            child1: SecondaryElevatedButton(
              onPressed: () {
                context.pop();
              },
              text: "الغاء",
            ),
          ),
        ),
      ),
    );
  }
}
