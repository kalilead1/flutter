import 'package:booking_v1/featuers/stores/data/models/store_social_account_model.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../../../../core/constants/colors.dart';
import '../../../../../core/constants/strings.dart';
import '../../../../../core/widgets/bottom_items.dart';
import '../../../../../core/widgets/botton_widghts.dart';
import '../../../../../core/widgets/container_widgets.dart';
import '../../../../../core/widgets/custom_steps_add_widget.dart';
import '../../../../main/domain/entities/social_account.dart';
import '../../bloc/command_store/command_store_bloc.dart';
import '../../bloc/command_store/command_store_event.dart';
import '../../widgets/forms/store_social_account_form.dart';

class AddStoreSocialAccountPage extends StatefulWidget {
  const AddStoreSocialAccountPage({super.key});

  @override
  State<AddStoreSocialAccountPage> createState() =>
      _AddStoreSocialAccountPageState();
}

class _AddStoreSocialAccountPageState extends State<AddStoreSocialAccountPage> {
  List<StoreSocialAccountModel> storeSocialAccountList = [];
  List<int> get usedSocialAccountIds => storeSocialAccountList
      .where((e) => e.socialAccountId != null)
      .map((e) => e.socialAccountId!)
      .toList();

  SocialAccount? socialAccount;
  void validateFormThenAddOrUpdateStore() {
    // BlocProvider and use update store event
    if (storeSocialAccountList.isNotEmpty) {
      context.read<CommandStoreBloc>().add(
          AddStoreSocialEvent(storeSocialAccounts: storeSocialAccountList));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          title: Text("اضافة متجر"),
        ),
        body: Padding(
          padding: EdgeInsets.all(defaultPadding),
          child: Column(
            spacing: defaultSpacing,
            children: [
              Text(
                "حسابات تواصل الاجتماعية",
                style: Theme.of(context).textTheme.displayLarge,
              ),
              Row(
                spacing: 6,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  CustomCircleStepsAddWidget(),
                  CustomCircleStepsAddWidget(),
                  CustomContainerStepsAddWidget(),
                  CustomCircleStepsAddWidget(),
                  CustomCircleStepsAddWidget(),
                  CustomCircleStepsAddWidget(),
                  CustomCircleStepsAddWidget(),
                ],
              ),
              SizedBox(),
              SecondaryElevatedButton(
                onPressed: () {
                  addStoreSocialAccountDialogTest(
                    context: context,
                    excludedSocialIds: usedSocialAccountIds,
                    onSaved: (p0) {
                      setState(() {
                        storeSocialAccountList.add(p0);
                      });
                    },
                  );
                },
                text: "اضافة حساب",
              ),
              SizedBox(),
              storeSocialAccountList.isNotEmpty
                  ? Expanded(
                      child: ListView.separated(
                        itemCount: storeSocialAccountList.length,
                        separatorBuilder: (context, index) {
                          return SizedBox(height: defaultSpacing);
                        },
                        itemBuilder: (context, index) {
                          final sw = storeSocialAccountList[index];
                          return SecondaryContainer(
                            paddingHorizontal: 0,
                            paddingVertical: 0,
                            child: ListTile(
                              leading: CircleAvatar(
                                radius: 25,
                                backgroundColor: Theme.of(context)
                                    .colorScheme
                                    .primaryContainer,
                                child: Icon(
                                  Icons.connect_without_contact,
                                  color: Theme.of(context)
                                      .colorScheme
                                      .tertiary
                                      .withValues(alpha: 0.6),
                                ),
                              ),
                              title: Text(sw.socialAccount!.name.toString()),
                              subtitle: Text(sw.url.toString()),
                              trailing: IconButton(
                                onPressed: () {
                                  setState(() {
                                    storeSocialAccountList.removeAt(index);
                                  });
                                },
                                icon: Icon(
                                  Icons.delete,
                                  color: errorColor,
                                ),
                              ),
                            ),
                          );
                        },
                      ),
                    )
                  : Expanded(
                      child: Center(
                          child: Text("يجب اضافة حسابات تواصل الاجتماعية"))),
            ],
          ),
        ),
        bottomNavigationBar: TwoBottomItems(
          child1: PrimaryElevatedButton(
            onPressed: () {
              validateFormThenAddOrUpdateStore();
            },
            text: "التالي",
          ),
          child2: SecondaryElevatedButton(
            onPressed: () {
              context.read<CommandStoreBloc>().add(CancelAddStoreEvent());
            },
            text: "الغاء",
          ),
        ),
      ),
    );
  }
}
