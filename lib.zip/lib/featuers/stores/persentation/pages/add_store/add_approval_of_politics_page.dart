import 'package:booking_v1/featuers/stores/persentation/bloc/command_store/command_store_event.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../../../../core/constants/strings.dart';
import '../../../../../core/widgets/bottom_items.dart';
import '../../../../../core/widgets/botton_widghts.dart';
import '../../../../../core/widgets/container_widgets.dart';
import '../../../../../core/widgets/custom_steps_add_widget.dart';
import '../../../../../core/widgets/snack_bar_widgets.dart';
import '../../bloc/command_store/command_store_bloc.dart';

class AddApprovalOfPoliticsPage extends StatefulWidget {
  const AddApprovalOfPoliticsPage({super.key});

  @override
  State<AddApprovalOfPoliticsPage> createState() =>
      _AddApprovalOfPoliticsPageState();
}

class _AddApprovalOfPoliticsPageState extends State<AddApprovalOfPoliticsPage> {
  bool approvalOfPolitics = false;
  void validateFormThenAddStore() {
    // BlocProvider and use update store event
    if (approvalOfPolitics) {
      context.read<CommandStoreBloc>().add(AddApprovalOfPoliticsEvent());
    } else {
      showSnackBarError(
          context: context, error: "يجب الموافقة على سياسة التطبيق");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          title: Text("اضافة متجر"),
        ),
        body: Padding(
          padding: EdgeInsets.all(defaultPadding),
          child: Column(
            spacing: defaultSpacing,
            children: [
              Text(
                "سياسة التطبيق",
                style: Theme.of(context).textTheme.displayLarge,
              ),
              Row(
                spacing: 6,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  CustomCircleStepsAddWidget(),
                  CustomCircleStepsAddWidget(),
                  CustomCircleStepsAddWidget(),
                  CustomCircleStepsAddWidget(),
                  CustomCircleStepsAddWidget(),
                  CustomContainerStepsAddWidget(),
                  CustomCircleStepsAddWidget(),
                ],
              ),
              SizedBox(height: 10),
              SecondaryContainer(
                paddingHorizontal: 0,
                paddingVertical: 0,
                child: Directionality(
                  textDirection: TextDirection.rtl,
                  child: CheckboxListTile(
                    selectedTileColor:
                        Theme.of(context).colorScheme.primary.withOpacity(0.20),
                    dense: true,
                    value: approvalOfPolitics,
                    title: Text(
                      "هل توافق على سياسة التطبيق؟",
                      style: Theme.of(context).textTheme.titleSmall,
                    ),
                    subtitle: Text(
                      "عرض سياسة التطبيق",
                      style: Theme.of(context).textTheme.displaySmall,
                    ),
                    onChanged: (value) {
                      setState(() {
                        approvalOfPolitics = !approvalOfPolitics;
                      });
                    },
                  ),
                ),
              ),
            ],
          ),
        ),
        bottomNavigationBar: TwoBottomItems(
          child1: PrimaryElevatedButton(
            onPressed: () {
              validateFormThenAddStore();
            },
            text: "التالي",
          ),
          child2: SecondaryElevatedButton(
            onPressed: () {
              context.read<CommandStoreBloc>().add(CancelAddStoreEvent());
            },
            text: "الغاء",
          ),
        ),
      ),
    );
  }
}
