import 'package:booking_v1/featuers/stores/data/models/store_wallet_model.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../../../../core/constants/colors.dart';
import '../../../../../core/constants/strings.dart';
import '../../../../../core/widgets/bottom_items.dart';
import '../../../../../core/widgets/botton_widghts.dart';
import '../../../../../core/widgets/container_widgets.dart';
import '../../../../../core/widgets/custom_steps_add_widget.dart';
import '../../bloc/command_store/command_store_bloc.dart';
import '../../bloc/command_store/command_store_event.dart';
import '../../widgets/forms/store_wallet_form.dart';

class AddStoreWalletsPage extends StatefulWidget {
  const AddStoreWalletsPage({super.key});

  @override
  State<AddStoreWalletsPage> createState() => _AddStoreWalletsPageState();
}

class _AddStoreWalletsPageState extends State<AddStoreWalletsPage> {
  List<StoreWalletModel> storeWalletList = [];
  List<int> get usedWalletIds => storeWalletList
      .where((e) => e.walletId != null)
      .map((e) => e.walletId!)
      .toList();

  void validateFormThenAddOrUpdateStore() {
    // BlocProvider and use update store event
    if (storeWalletList.isNotEmpty) {
      context
          .read<CommandStoreBloc>()
          .add(AddStoreWalletEvent(storeWallets: storeWalletList));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          title: Text("اضافة متجر"),
        ),
        body: Padding(
          padding: EdgeInsets.all(defaultPadding),
          child: Column(
            spacing: defaultSpacing,
            children: [
              Text(
                "محافظ المتجر",
                style: Theme.of(context).textTheme.displayLarge,
              ),
              Row(
                spacing: 6,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  CustomCircleStepsAddWidget(),
                  CustomCircleStepsAddWidget(),
                  CustomCircleStepsAddWidget(),
                  CustomContainerStepsAddWidget(),
                  CustomCircleStepsAddWidget(),
                  CustomCircleStepsAddWidget(),
                  CustomCircleStepsAddWidget(),
                ],
              ),
              SizedBox(),
              SecondaryElevatedButton(
                onPressed: () {
                  addStoreWalletDialogTest(
                    context: context,
                    excludedWalletIds: usedWalletIds,
                    onSaved: (p0) {
                      setState(() {
                        storeWalletList.add(p0);
                      });
                    },
                  );
                },
                text: "اضافة محفظة",
              ),
              SizedBox(),
              storeWalletList.isNotEmpty
                  ? Expanded(
                      child: ListView.separated(
                        itemCount: storeWalletList.length,
                        separatorBuilder: (context, index) {
                          return SizedBox(height: defaultSpacing);
                        },
                        itemBuilder: (context, index) {
                          final sw = storeWalletList[index];
                          return SecondaryContainer(
                            paddingHorizontal: 0,
                            paddingVertical: 0,
                            child: ListTile(
                              leading: CircleAvatar(
                                radius: 25,
                                backgroundColor: Theme.of(context)
                                    .colorScheme
                                    .primaryContainer,
                                child: Icon(
                                  Icons.wallet,
                                  color: Theme.of(context)
                                      .colorScheme
                                      .tertiary
                                      .withValues(alpha: 0.6),
                                ),
                              ),
                              title: Text(sw.wallet!.name.toString()),
                              subtitle: Text(sw.accountNumber.toString()),
                              trailing: IconButton(
                                onPressed: () {
                                  setState(() {
                                    storeWalletList.removeAt(index);
                                  });
                                },
                                icon: Icon(
                                  Icons.delete,
                                  color: errorColor,
                                ),
                              ),
                            ),
                          );
                        },
                      ),
                    )
                  : Expanded(child: Center(child: Text("يجب اضافة محفظة"))),
            ],
          ),
        ),
        bottomNavigationBar: TwoBottomItems(
          child1: PrimaryElevatedButton(
            onPressed: () {
              validateFormThenAddOrUpdateStore();
            },
            text: "التالي",
          ),
          child2: SecondaryElevatedButton(
            onPressed: () {
              context.read<CommandStoreBloc>().add(CancelAddStoreEvent());
            },
            text: "الغاء",
          ),
        ),
      ),
    );
  }
}
