import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../../../../core/constants/strings.dart';
import '../../../../../core/widgets/bottom_items.dart';
import '../../../../../core/widgets/botton_widghts.dart';
import '../../../../../core/widgets/ciracle_loading_widget.dart';
import '../../../../../core/widgets/custom_steps_add_widget.dart';
import '../../../../../core/widgets/snack_bar_widgets.dart';
import '../../bloc/command_store/command_store_bloc.dart';
import '../../bloc/command_store/command_store_event.dart';
import '../../bloc/command_store/command_store_state.dart';

class ConfirmAddStorePage extends StatelessWidget {
  const ConfirmAddStorePage({super.key});

  @override
  Widget build(BuildContext context) {
    String? storeName;
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: Text("اضافة متجر")),
        body: Padding(
          padding: EdgeInsets.all(defaultPadding),
          child: BlocConsumer<CommandStoreBloc, CommandStoreState>(
            listener: (context, state) {
              if (state is SuccessfullyStoreState) {
                return showSnackBarSuccess(
                    context: context,
                    success: "تم اضافة متجر باسم $storeName بنجاح");
              } else if (state is ErrorStoreState) {
                return showSnackBarError(
                    context: context, error: state.message);
              }
            },
            builder: (context, state) {
              if (state is LoadingCommandStoreState) {
                return CiracleLoadingWidget();
              } else if (state is EditingAddStoreState) {
                storeName = state.name;
                return Column(
                  spacing: defaultSpacing,
                  children: [
                    Text(
                      "تاكيد انشاء متجر",
                      style: Theme.of(context).textTheme.displayLarge,
                    ),
                    Row(
                      spacing: 6,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        CustomCircleStepsAddWidget(),
                        CustomCircleStepsAddWidget(),
                        CustomCircleStepsAddWidget(),
                        CustomCircleStepsAddWidget(),
                        CustomCircleStepsAddWidget(),
                        CustomCircleStepsAddWidget(),
                        CustomContainerStepsAddWidget(),
                      ],
                    ),
                    SizedBox(height: 50),
                    Text(
                      "هل تريد انشاء متجر باسم؟",
                      style: Theme.of(context).textTheme.bodyLarge,
                    ),
                    Text(
                      state.name ?? "non",
                      style: Theme.of(context).textTheme.titleLarge,
                    ),
                    state.storeWallets.isNotEmpty
                        ? Expanded(
                            child: ListView.builder(
                              itemCount: state.storeWallets.length,
                              itemBuilder: (context, index) {
                                final w = state.storeWallets[index];
                                return ListTile(
                                  title: Text(w.walletId.toString()),
                                  subtitle: Text(w.accountNumber.toString()),
                                );
                              },
                            ),
                          )
                        : SizedBox()
                  ],
                );
              } else {
                return Center(
                  child: Text("nooon"),
                );
              }
            },
          ),
        ),
        bottomNavigationBar: TwoBottomItems(
          child1: PrimaryElevatedButton(
            onPressed: () {
              context.read<CommandStoreBloc>().add(SubmitStoreEvent());
              // BlocProvider.of<AddStoreBloc>(context).add(SubmitStoreEvent());
            },
            text: "انشاء",
          ),
          child2: SecondaryElevatedButton(
            onPressed: () {
              context.read<CommandStoreBloc>().add(CancelAddStoreEvent());
              // BlocProvider.of<AddStoreBloc>(context).add(CancelAddStoreEvent());
            },
            text: "الغاء",
          ),
        ),
      ),
    );
  }
}
