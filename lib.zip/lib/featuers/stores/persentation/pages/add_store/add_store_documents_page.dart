import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../../../../core/constants/strings.dart';
import '../../../../../core/widgets/bottom_items.dart';
import '../../../../../core/widgets/botton_widghts.dart';
import '../../../../../core/widgets/custom_steps_add_widget.dart';
import '../../../../../core/widgets/image_picker/widgets/multi_uploader_widget.dart';
import '../../../../../core/widgets/snack_bar_widgets.dart';
import '../../../domain/entities/store_document.dart';
import '../../bloc/command_store/command_store_bloc.dart';
import '../../bloc/command_store/command_store_event.dart';

class AddStoreDocumentsPage extends StatefulWidget {
  const AddStoreDocumentsPage({super.key});

  @override
  State<AddStoreDocumentsPage> createState() => _AddStoreDocumentsPageState();
}

class _AddStoreDocumentsPageState extends State<AddStoreDocumentsPage> {
  List<StoreDocument> storeDocumentsList = [];
  List<File> storeDocumentsFilesList = [];

  void validateFormThenAddStore() {
    // BlocProvider and use update store event
    if (storeDocumentsFilesList.isNotEmpty) {
      if (storeDocumentsFilesList.length <= 3) {
        showSnackBarWarning(
            context: context, warning: "يجب ادخال اكثر من 3 وثائق للمتجر");
      } else {
        context.read<CommandStoreBloc>().add(
            AddStoreDocumentEvent(storeDocuments: storeDocumentsFilesList));
      }
    } else {
      showSnackBarError(context: context, error: "يجب ادخال وثائق المتجر");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          title: Text("اضافة متجر"),
        ),
        body: Padding(
          padding: EdgeInsets.all(defaultPadding),
          child: Column(
            spacing: defaultSpacing,
            children: [
              Text(
                "وثائق المتجر",
                style: Theme.of(context).textTheme.displayLarge,
              ),
              Row(
                spacing: 6,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  CustomCircleStepsAddWidget(),
                  CustomCircleStepsAddWidget(),
                  CustomCircleStepsAddWidget(),
                  CustomCircleStepsAddWidget(),
                  CustomContainerStepsAddWidget(),
                  CustomCircleStepsAddWidget(),
                  CustomCircleStepsAddWidget(),
                ],
              ),
              SizedBox(height: 10),
              Text(
                "يجب رفع ملفات وصور التي توثق متجرك الحقيقي.",
                style: Theme.of(context).textTheme.bodyLarge,
              ),
              MultiUploaderWidget(
                // addButtonLabel: "رفع وثائق السجل التجاري",
                maxItems: 5,
                onChanged: (value) {
                  setState(() {
                    storeDocumentsFilesList = value;
                  });
                },
              ),

              // ImageUploaderWidghet(
              //   addButtonLabel: "رفع صور للسند التجاري",
              //   maxImages: 3,
              // ),
              // ImageUploaderWidghet(
              //   addButtonLabel: "رفع صور للختم التجاري",
              //   maxImages: 3,
              // ),
            ],
          ),
        ),
        bottomNavigationBar: TwoBottomItems(
          child1: PrimaryElevatedButton(
            onPressed: () {
              validateFormThenAddStore();
            },
            text: "التالي",
          ),
          child2: SecondaryElevatedButton(
            onPressed: () {
              context.read<CommandStoreBloc>().add(CancelAddStoreEvent());
              // BlocProvider.of<AddStoreBloc>(context).add(CancelAddStoreEvent());
            },
            text: "الغاء",
          ),
        ),
      ),
    );
  }
}
