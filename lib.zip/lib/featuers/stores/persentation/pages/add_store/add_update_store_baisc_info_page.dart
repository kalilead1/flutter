import 'package:booking_v1/core/routing/navigation_service.dart';
import 'package:booking_v1/core/widgets/snack_bar_widgets.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:go_router/go_router.dart';

import '../../../../../core/constants/api.dart';
import '../../../../../core/constants/strings.dart';
import '../../../../../core/widgets/bottom_items.dart';
import '../../../../../core/widgets/botton_widghts.dart';
import '../../../../../core/widgets/custom_steps_add_widget.dart';
import '../../../../../core/widgets/image_picker/widgets/single_image_picker_widget.dart';
import '../../../../../core/widgets/input_widgets.dart';
import '../../../../main/persentation/widgets/selections/selection_category_widget.dart';
import '../../../domain/entities/store.dart';
import '../../bloc/command_store/command_store_bloc.dart';
import '../../bloc/command_store/command_store_event.dart';

class AddUpdateStoreBaiscInfoPage extends StatefulWidget {
  final Store? store;
  final bool isUpdateStore;
  const AddUpdateStoreBaiscInfoPage(
      {super.key, this.store, required this.isUpdateStore});

  @override
  State<AddUpdateStoreBaiscInfoPage> createState() =>
      _AddUpdateStoreBaiscInfoPageState();
}

class _AddUpdateStoreBaiscInfoPageState
    extends State<AddUpdateStoreBaiscInfoPage> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController _storeNameController = TextEditingController();
  // final TextEditingController _storeCategoryIdController =
  //     TextEditingController();
  int? categoryId;
  final TextEditingController _storephoneController = TextEditingController();
  String? newImage;
  String? initialImage;

  @override
  void initState() {
    if (widget.isUpdateStore) {
      _storeNameController.text = widget.store!.name!;
      categoryId = widget.store!.categoryId!;
      _storephoneController.text = widget.store!.phone!;
      initialImage = baseUrlStoreImagesFolder + widget.store!.logo!;
    } else {
      // _storeNameController.text = widget.store!.name!;
      // _storeCategoryIdController.text = widget.store!.categoryId!.toString();
      // _storephoneController.text = widget.store!.phone!;
    }
    super.initState();
  }

  void validateFormThenAddOrUpdateStore() {
    final isValidateForm = _formKey.currentState!.validate();
    if (isValidateForm) {
      final store = Store(
        id: widget.isUpdateStore ? widget.store!.id : 0,
        name: _storeNameController.text,
        categoryId: categoryId,
        phone: _storephoneController.text,
        logo: newImage,
      );

      if (widget.isUpdateStore) {
        // BlocProvider and use update store event
        showModalBottomSheet(
          context: context,
          builder: (context) => Padding(
            padding: EdgeInsets.all(defaultPadding),
            child: ListView(
              children: [
                Text(store.id.toString()),
                Text(store.name!),
                Text(store.categoryId.toString()),
                Text(store.phone!),
              ],
            ),
          ),
        );
      } else {
        // BlocProvider and use update store event

        if (newImage != null) {
          context.read<CommandStoreBloc>().add(AddStoreBasicInfoEvent(
                name: _storeNameController.text,
                categoryId: categoryId!,
                phone: _storephoneController.text,
                logo: newImage!,
              ));
          // BlocProvider.of<AddStoreBloc>(context)
          //     .add(EditingAddStoreState(store: store));
        } else {
          showSnackBarWarning(
              context: context, warning: "يجب ادخال شعار لمتجرك");
        }
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          title: Text(widget.isUpdateStore ? "تعديل متجر" : "اضافة متجر"),
        ),
        body: SingleChildScrollView(
          child: Padding(
            padding: EdgeInsets.all(defaultPadding),
            child: Form(
              key: _formKey,
              // autovalidateMode: AutovalidateMode.onUserInteraction,
              child: Column(
                spacing: defaultSpacing,
                children: [
                  Text(
                    "معلومات المتجر الاساسية",
                    style: Theme.of(context).textTheme.displayLarge,
                  ),
                  Row(
                    spacing: 6,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      CustomContainerStepsAddWidget(),
                      widget.isUpdateStore
                          ? SizedBox()
                          : CustomCircleStepsAddWidget(),
                      widget.isUpdateStore
                          ? SizedBox()
                          : CustomCircleStepsAddWidget(),
                      widget.isUpdateStore
                          ? SizedBox()
                          : CustomCircleStepsAddWidget(),
                      widget.isUpdateStore
                          ? SizedBox()
                          : CustomCircleStepsAddWidget(),
                      widget.isUpdateStore
                          ? SizedBox()
                          : CustomCircleStepsAddWidget(),
                      widget.isUpdateStore
                          ? SizedBox()
                          : CustomCircleStepsAddWidget(),
                    ],
                  ),
                  SizedBox(height: 20),
                  // SingleImagePicker(label: "شعار المتجر"),

                  SingleImagePicker(
                    initialImage: widget.isUpdateStore ? initialImage : null,
                    label: "شعار المتجر",
                    onChanged: (value) {
                      setState(() {
                        initialImage = null;
                        newImage = value!.path;
                      });
                    },
                  ),
                  Text(NavigationService.cru.length.toString()),
                  CustomInputFieldWidget(
                    label: "اسم المتجر",
                    textController: _storeNameController,
                    minLines: 1,
                    maxLines: 1,
                    maxLength: 30,
                  ),

                  SelectionCategoriesWidget(
                    onSelected: (value) {
                      setState(() {
                        categoryId = value;
                      });
                    },
                  ),
                  Text(categoryId.toString()),
                  // CustomInputFieldWidget(
                  //   label: "رقم المتجر",
                  //   textController: _storephoneController,
                  //   textInputType: TextInputType.number,
                  // ),
                  InputPhoneNumberWidget(
                    label: "رقم المتجر",
                    textController: _storephoneController,
                  ),
                ],
              ),
            ),
          ),
        ),
        bottomNavigationBar: TwoBottomItems(
          child1: PrimaryElevatedButton(
            onPressed: () {
              validateFormThenAddOrUpdateStore();
            },
            text: widget.isUpdateStore ? "حفظ التعديل" : "التالي",
          ),
          child2: SecondaryElevatedButton(
            onPressed: () {
              if (widget.isUpdateStore) {
                context.pop();
              } else {
                context.read<CommandStoreBloc>().add(CancelAddStoreEvent());
                //  BlocProvider.of<AddStoreBloc>(context).add(CancelAddStoreEvent());
              }
            },
            text: "الغاء",
          ),
        ),
      ),
    );
  }
}
