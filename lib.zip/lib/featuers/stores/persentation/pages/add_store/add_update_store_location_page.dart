import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:go_router/go_router.dart';

import '../../../../../core/constants/strings.dart';
import '../../../../../core/widgets/bottom_items.dart';
import '../../../../../core/widgets/botton_widghts.dart';
import '../../../../../core/widgets/custom_steps_add_widget.dart';
import '../../../../../core/widgets/input_widgets.dart';
import '../../../../main/data/repositories/directorates_repository_impl.dart';
import '../../../../main/persentation/widgets/selections/selection_city_widget.dart';
import '../../../../main/persentation/widgets/selections/selection_directorate_widget.dart';
import '../../../domain/entities/store.dart';
import '../../bloc/command_store/command_store_bloc.dart';
import '../../bloc/command_store/command_store_event.dart';

class AddUpdateStoreLocationPage extends StatefulWidget {
  final Store? store;
  final bool isUpdateStore;
  const AddUpdateStoreLocationPage(
      {super.key, this.store, required this.isUpdateStore});

  @override
  State<AddUpdateStoreLocationPage> createState() =>
      _AddUpdateStoreLocationPageState();
}

class _AddUpdateStoreLocationPageState
    extends State<AddUpdateStoreLocationPage> {
  final _formKey = GlobalKey<FormState>();
  // final TextEditingController _storeCityIdController = TextEditingController();
  int? cityId;
  int? directorateId;
  // final TextEditingController _storeDirectorateIdController =
  //     TextEditingController();
  final TextEditingController _storeAddressDetailsController =
      TextEditingController();
  final TextEditingController _storeLocationCoordinatesController =
      TextEditingController();
  // Store storeData = Store(id: 0);

  @override
  void initState() {
    if (widget.isUpdateStore) {
      directorateId = widget.store!.directorateId;
      _storeAddressDetailsController.text = widget.store!.addressDetails!;
      _storeLocationCoordinatesController.text =
          widget.store!.locationCoordinates!;
    } else {
      // storeData = widget.store!;
      // _storeNameController.text = widget.store!.name!;
      // _storeCategoryIdController.text = widget.store!.categoryId!.toString();
      // _storephoneController.text = widget.store!.phone!;
    }
    super.initState();
  }

  void validateFormThenAddOrUpdateStore() {
    final isValidateForm = _formKey.currentState!.validate();
    if (isValidateForm) {
      final store = Store(
        // id: widget.store!.id,
        // name: widget.store!.name,
        // categoryId: widget.store!.categoryId,
        // phone: widget.store!.phone,
        directorateId: directorateId,
        addressDetails: _storeAddressDetailsController.text,
        locationCoordinates: _storeLocationCoordinatesController.text,
        // logo: widget.store!.logo,
        // logo: null,
        // operatorId: null,
        // ownerId: null,
        // stateEnum: StoreStateEnum.active,
        // visitorsCount: null,
      );

      if (widget.isUpdateStore) {
        // BlocProvider and use update store event
        showModalBottomSheet(
          context: context,
          builder: (context) => Padding(
            padding: EdgeInsets.all(defaultPadding),
            child: ListView(
              children: [
                Text(store.id.toString()),
                Text(store.name!),
                Text(store.categoryId.toString()),
                Text(store.phone!),
                Text(store.id.toString()),
                Text(store.directorateId.toString()),
                Text(store.addressDetails!),
                Text(store.locationCoordinates!),
              ],
            ),
          ),
        );
      } else {
        // BlocProvider and use update store event
        // Navigator.push(
        //     context,
        //     MaterialPageRoute(
        //       builder: (context) => AddOrUpdateStoreSocialAccountPage(
        //           store: store, isUpdateStore: false),
        //     ));
        // showModalBottomSheet(
        //   context: context,
        //   builder: (context) => Padding(
        //     padding: EdgeInsets.all(defaultPadding),
        //     child: ListView(
        //       children: [
        //         Text(store.id.toString()),
        //         Text(store.name!),
        //         Text(store.logo!),

        //         // Text(store.categoryId.toString()),
        //         // Text(store.phone!),
        //         // Text(store.id.toString()),
        //         // Text(store.directorateId.toString()),
        //         // Text(store.addressDetails!),
        //         // Text(store.locationCoordinates!),
        //       ],
        //     ),
        //   ),
        // );
        context.read<CommandStoreBloc>().add(AddStoreLocationEvent(
              directorateId: directorateId!,
              addressDetails: _storeAddressDetailsController.text,
              locationCoordinates: _storeLocationCoordinatesController.text,
            ));
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          title: Text(widget.isUpdateStore ? "تعديل متجر" : "اضافة متجر"),
        ),
        body: Padding(
          padding: EdgeInsets.all(defaultPadding),
          child: Form(
            key: _formKey,
            child: Column(
              spacing: defaultSpacing,
              children: [
                Text(
                  "موقع المتجر",
                  style: Theme.of(context).textTheme.displayLarge,
                ),
                Row(
                  spacing: 6,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    widget.isUpdateStore
                        ? SizedBox()
                        : CustomCircleStepsAddWidget(),
                    CustomContainerStepsAddWidget(),
                    widget.isUpdateStore
                        ? SizedBox()
                        : CustomCircleStepsAddWidget(),
                    widget.isUpdateStore
                        ? SizedBox()
                        : CustomCircleStepsAddWidget(),
                    widget.isUpdateStore
                        ? SizedBox()
                        : CustomCircleStepsAddWidget(),
                    widget.isUpdateStore
                        ? SizedBox()
                        : CustomCircleStepsAddWidget(),
                    widget.isUpdateStore
                        ? SizedBox()
                        : CustomCircleStepsAddWidget(),
                  ],
                ),
                SizedBox(height: 20),
                Row(
                  spacing: defaultSpacing,
                  children: [
                    Expanded(
                      child: SelectionCityWidget(
                        onSelected: (value) {
                          setState(() {
                            cityId = value;
                            cacheDirectoratesList = [];
                            // _directorateEditingController.text = '';
                          });
                        },
                      ),
                    ),
                    Expanded(
                      child: SelectionDirectorateWidget(
                        cityId: cityId,
                        onSelected: (value) {
                          final temp = cityId;
                          if (temp != cityId) {
                            setState(() {
                              directorateId = value;
                              cityId = null;
                            });
                          }
                          setState(() {
                            directorateId = value;
                          });
                        },
                      ),
                    ),
                  ],
                ),
                CustomInputFieldWidget(
                  label: "الموقع التفصيلي",
                  textController: _storeAddressDetailsController,
                  minLines: 1,
                  // maxLines: 1,
                  maxLength: 80,
                ),
                CustomInputFieldWidget(
                  label: "رابط المتجر على خرايط قوقل",
                  textController: _storeLocationCoordinatesController,
                  textInputType: TextInputType.url,
                  minLines: 1,
                  maxLines: 1,
                ),
              ],
            ),
          ),
        ),
        bottomNavigationBar: TwoBottomItems(
          child1: PrimaryElevatedButton(
            onPressed: () {
              validateFormThenAddOrUpdateStore();
            },
            text: widget.isUpdateStore ? "حفظ التعديل" : "التالي",
          ),
          child2: SecondaryElevatedButton(
            onPressed: () {
              if (widget.isUpdateStore) {
                context.pop();
              } else {
                context.read<CommandStoreBloc>().add(CancelAddStoreEvent());
              }
            },
            text: "الغاء",
          ),
        ),
      ),
    );
  }
}
