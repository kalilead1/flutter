import 'package:booking_v1/core/constants/strings.dart';
import 'package:booking_v1/core/routing/app_routes.dart';
import 'package:booking_v1/core/routing/router_extensions.dart';
import 'package:booking_v1/core/widgets/container_widgets.dart';
import 'package:booking_v1/core/widgets/share_link_widget.dart';
import 'package:booking_v1/dependency_injection/initial.dart';
import 'package:booking_v1/featuers/stores/persentation/bloc/stores/stores_bloc.dart';
import 'package:booking_v1/featuers/stores/persentation/bloc/stores/stores_event.dart';
import 'package:booking_v1/featuers/stores/persentation/bloc/stores/stores_state.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../../../core/constants/api.dart';
import '../../../../core/widgets/ciracle_loading_widget.dart';
import '../../../../core/widgets/urls_widget.dart';
import '../../../../tests/loading_test.dart';
import '../../../services/persentation/widgets/view_service_widget.dart';
import '../../domain/entities/store.dart';
import '../widgets/store_details/store_location_widget.dart';
import '../widgets/store_details/store_social_media_widget.dart';
import '../widgets/store_details/view_store_header_widget.dart';

// class ViewStoreDetailsPage extends StatefulWidget {
//   const ViewStoreDetailsPage({super.key});

//   @override
//   State<ViewStoreDetailsPage> createState() => _ViewStoreDetailsPageState();
// }

// class _ViewStoreDetailsPageState extends State<ViewStoreDetailsPage> {
//   @override
//   Widget build(BuildContext context) {
//     return Directionality(
//       textDirection: TextDirection.rtl,
//       child: Scaffold(
//         body: CustomScrollView(
//           slivers: [
//             SliverAppBar(
//               pinned: true,
//               title: Text("data"),
//               expandedHeight: 200,
//             ),
//             SliverAppBar(
//               automaticallyImplyLeading: false,
//               toolbarHeight: 200,
//               flexibleSpace: Container(
//                 decoration: BoxDecoration(
//                   image: DecorationImage(
//                     image: AssetImage(
//                       Theme.of(context).brightness == Brightness.light
//                           ? "assets/images/LightBackgroundStore.png"
//                           : "assets/images/DarkBackgroundStore.png",
//                     ),
//                     fit: BoxFit.contain,
//                   ),
//                 ),
//                 child: Column(
//                   mainAxisAlignment: MainAxisAlignment.center,
//                   children: [
//                     Container(
//                       decoration: BoxDecoration(
//                         color: Theme.of(context).colorScheme.secondary,
//                         border: Border.all(
//                           color: Theme.of(context).colorScheme.primary,
//                           width: 2,
//                         ),
//                         shape: BoxShape.circle,
//                       ),
//                       child: CircleAvatar(
//                         radius: 50,
//                         child: Center(
//                           child: SvgPicture.asset(
//                             "assets/logos/logo4.svg",
//                             colorFilter: ColorFilter.mode(
//                               Theme.of(context)
//                                   .colorScheme
//                                   .tertiary
//                                   .withOpacity(0.20),
//                               BlendMode.srcIn,
//                             ),
//                             height: 30,
//                           ),
//                         ),
//                       ),
//                     ),
//                   ],
//                 ),
//               ),
//             ),
//             SliverFillRemaining()
//           ],
//         ),
//       ),
//     );
//   }
// }

class ViewStoreDetailsPage extends StatefulWidget {
  final int storeId;
  const ViewStoreDetailsPage({super.key, required this.storeId});

  @override
  State<ViewStoreDetailsPage> createState() => _ViewStoreDetailsPageState();
}

class _ViewStoreDetailsPageState extends State<ViewStoreDetailsPage> {
  late double expandedHeight = 210;
  late double collapsedHeight = kToolbarHeight;
  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (context) => getIt<StoresBloc>()
        ..addAndRemember(GetStoreByIdEvent(storeId: widget.storeId)),
      child: Directionality(
        textDirection: TextDirection.rtl,
        child: Scaffold(
          body: BlocBuilder<StoresBloc, StoresState>(
            builder: (context, state) {
              if (state is LoadingStoresState) {
                return CiracleLoadingWidget();
              } else if (state is ErrorStoresState) {
                return SecondaryContainer(
                    child: Center(
                  child: Text(state.message),
                ));
              } else if (state is LoadedStoreByIdState) {
                final store = state.store;
                return CustomRefresh(
                  onRefresh: () async {
                    BlocProvider.of<StoresBloc>(context)
                        .add(RefreshGetStoreByIdEvent(storeId: widget.storeId));
                  },
                  child: CustomScrollView(
                    slivers: [
                      SliverAppBar(
                        pinned: true,
                        // surfaceTintColor: Colors.blue,
                        expandedHeight: expandedHeight,
                        actions: [_popupMenuButtonWidget(store)],
                        flexibleSpace: LayoutBuilder(
                          builder: (context, constraints) {
                            double currentHeight = constraints.biggest.height;

                            bool isCollapsed =
                                currentHeight <= collapsedHeight + 40;
                            return FlexibleSpaceBar(
                              title: isCollapsed
                                  ? Text(
                                      store.name.toString(),
                                      style: Theme.of(context)
                                          .textTheme
                                          .titleLarge,
                                    )
                                  : null,
                              collapseMode: CollapseMode.parallax,
                              background: Container(
                                margin: EdgeInsets.only(top: 60),
                                child: ViewStoreHeaderWidget(
                                  storeName: store.name,
                                  storeId: store.id.toString(),
                                  storeLogo:
                                      baseUrlStoreImagesFolder + store.logo!,
                                  // categoryId: store.categoryId,
                                  categoryName: store.category!.name,
                                ),
                              ),
                            );
                          },
                        ),
                      ),
                      SliverToBoxAdapter(
                        child: Padding(
                          padding: EdgeInsets.all(defaultPadding),
                          child: PrimaryContainer(
                            paddingVertical: defaultPadding / 2 + 2,
                            child: Row(
                              spacing: defaultSpacing,
                              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                              children: [
                                _button(
                                  icon:
                                      Icons.switch_access_shortcut_add_rounded,
                                  text: "التواصل ..",
                                  onTap: () {
                                    showModalBottomSheet(
                                        scrollControlDisabledMaxHeightRatio:
                                            0.45,
                                        context: context,
                                        builder: (context) =>
                                            StoreSocialMediaWidget(
                                              storeId: store.id!,
                                              storeSocials: store.storeSocial,
                                            ));
                                  },
                                ),
                                _button(
                                  icon: Icons.location_on_rounded,
                                  text:
                                      store.directorate!.city!.name.toString(),
                                  onTap: () {
                                    showModalBottomSheet(
                                        scrollControlDisabledMaxHeightRatio:
                                            0.48,
                                        context: context,
                                        builder: (context) =>
                                            StoreLocationWidget(
                                              city:
                                                  store.directorate!.city!.name,
                                              region: store.directorate!.name,
                                              addressDetails:
                                                  store.addressDetails,
                                              locationCoordinates:
                                                  store.locationCoordinates,
                                            ));
                                  },
                                ),
                                _button(
                                  icon: Icons.chat_rounded,
                                  text: "مراسلة",
                                  onTap: () {
                                    Urls.urlMessage(store.phone!);
                                  },
                                ),
                                _button(
                                  icon: Icons.call,
                                  text: "اتصال",
                                  onTap: () {
                                    Urls.urlPhone(store.phone!);
                                  },
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                      SliverList(
                        delegate: SliverChildBuilderDelegate(
                          // semanticIndexOffset: 10,
                          childCount: 10,
                          (context, index) {
                            return Container(
                              margin: EdgeInsets.symmetric(
                                horizontal: defaultPadding,
                                vertical: defaultPadding / 2,
                              ),
                              child: ViewServiceHorizontal(),
                            );
                          },
                        ),
                      ),
                      SliverFillRemaining(
                        child: Center(
                          child: Text("data"),
                        ),
                      ),
                    ],
                  ),
                );
              }
              return CiracleLoadingWidget();
            },
          ),
        ),
      ),
    );
  }

  Widget _popupMenuButtonWidget(Store store) {
    return PopupMenuButton(
      icon: Icon(Icons.more_vert),

      // لون الخلفية
      color: Theme.of(context).colorScheme.primaryContainer,

      // مكان ظهور القائمة (تحت الزر)
      offset: Offset(10, 40), // يظهر تحت الزر بمسافة 40 بكسل

      // شكل القائمة
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(10),
      ),

      // ارتفاع كل عنصر
      elevation: 4,

      // عناصر القائمة
      itemBuilder: (BuildContext context) => [
        PopupMenuItem(
          onTap: () => ShareLink.shareStore(store.id!),
          child: Directionality(
            textDirection: TextDirection.rtl,
            child: Row(
              children: [
                Icon(Icons.share),
                SizedBox(width: 12),
                Text('مشاركة'),
              ],
            ),
          ),
        ),
        PopupMenuItem(
          onTap: () => context.pushTo(addStoreReportRoute, extra: store),
          child: Directionality(
            textDirection: TextDirection.rtl,
            child: Row(
              children: [
                Icon(Icons.flag, color: Colors.redAccent),
                SizedBox(width: 12),
                Text(
                  'ابلاغ',
                  style: TextStyle(color: Colors.redAccent),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _button({
    required IconData icon,
    required String text,
    required void Function() onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        mainAxisAlignment: MainAxisAlignment.center,
        spacing: defaultSpacing / 3,
        children: [
          CircleAvatar(
            radius: 25,
            backgroundColor: Theme.of(context).colorScheme.primary,
            child: Icon(
              icon,
              color: Colors.white,
            ),
          ),
          Text(
            text,
            style: Theme.of(context).textTheme.titleSmall,
          )
        ],
      ),
    );
  }
}
