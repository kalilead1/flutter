import 'package:booking_v1/core/constants/strings.dart';
import 'package:booking_v1/core/routing/app_routes.dart';
import 'package:booking_v1/core/routing/router_extensions.dart';
import 'package:booking_v1/core/widgets/bottom_items.dart';
import 'package:booking_v1/core/widgets/botton_widghts.dart';
import 'package:booking_v1/core/widgets/ciracle_loading_widget.dart';
import 'package:booking_v1/core/widgets/container_widgets.dart';
import 'package:booking_v1/core/widgets/view_image_ciracle_widget.dart';
import 'package:booking_v1/dependency_injection/initial.dart';
import 'package:booking_v1/featuers/stores/persentation/bloc/stores/stores_bloc.dart';
import 'package:booking_v1/featuers/stores/persentation/bloc/stores/stores_event.dart';
import 'package:booking_v1/featuers/stores/persentation/bloc/stores/stores_state.dart';
import 'package:booking_v1/featuers/stores/persentation/pages/args/add_pages_args.dart';
import 'package:booking_v1/tests/loading_test.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../../../core/constants/api.dart';
import '../../domain/enums/store_state_enum.dart';

class StoresOwnerPage extends StatelessWidget {
  final int ownerId;
  const StoresOwnerPage({required this.ownerId, super.key});

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (context) => getIt<StoresBloc>()
        ..addAndRemember(GetStoreByOwnerIdEvent(ownerId: ownerId)),
      child: Directionality(
        textDirection: TextDirection.rtl,
        child: Scaffold(
          appBar: AppBar(
            title: Text("متاجري"),
          ),
          body: Padding(
              padding: EdgeInsets.all(defaultPadding),
              child: BlocBuilder<StoresBloc, StoresState>(
                builder: (context, state) {
                  if (state is LoadingStoresState) {
                    return CiracleLoadingWidget();
                  } else if (state is ErrorStoresState) {
                    return SecondaryContainer(
                        child: Center(
                      child: Text(state.message),
                    ));
                  } else if (state is LoadedStoresState) {
                    return CustomRefresh(
                      onRefresh: () async {
                        BlocProvider.of<StoresBloc>(context).add(
                            RefreshGetStoreByOwnerIdEvent(ownerId: ownerId));
                      },
                      child: ListView.separated(
                        separatorBuilder: (context, index) {
                          return SizedBox(
                            height: 10,
                          );
                        },
                        itemCount: state.stores.length,
                        itemBuilder: (context, index) {
                          final store = state.stores[index];
                          return SecondaryContainer(
                            paddingHorizontal: 0,
                            paddingVertical: 0,
                            child: ListTile(
                              onTap: () {
                                // if (store.stateEnum == StoreStateEnum.active) {
                                //   context.pushTo(storeSettingRoute,
                                //       extra: store.id);
                                // } else {
                                //   showSnackBarWarning(
                                //       context: context,
                                //       warning: "لا يمكن الدخول للمتجر");
                                // }
                                context.pushTo(storeSettingRoute,
                                    extra: store.id);
                              },
                              leading: ViewImageCiracleWidget(
                                imageURL:
                                    baseUrlStoreImagesFolder + store.logo!,
                                size: 50,
                              ),
                              title: Text(
                                "${store.name}",
                                style: Theme.of(context).textTheme.titleMedium,
                              ),
                              subtitle: Text(
                                "${store.category!.name}",
                                style: Theme.of(context).textTheme.displaySmall,
                              ),
                              // subtitle: ViewCategorySecondaryWidget(
                              //     categoryId: store.categoryId!),
                              trailing: Container(
                                padding: EdgeInsets.symmetric(
                                    horizontal: defaultPadding / 2),
                                decoration: BoxDecoration(
                                  color: getStoreStateBackgroundColorByValue(
                                      store.stateEnum!, context),
                                  border: Border.all(
                                      color: getStoreStateBorderColorByValue(
                                          store.stateEnum!, context)),
                                  borderRadius: BorderRadius.circular(
                                      defaultBorderRadious),
                                ),
                                child: Text(store.stateEnum!.arabicName),
                              ),
                            ),
                          );
                        },
                      ),
                    );
                  } else {
                    return CiracleLoadingWidget();
                  }
                },
              )),
          bottomNavigationBar: TwoBottomItems(
            child1: PrimaryElevatedButton(
              onPressed: () {
                context.pushTo(addUpdateStoreBaiscRoute,
                    extra: AddUpdateStoreBaiscAndLocationArgs());
              },
              text: "اضافة متجر",
            ),
          ),
        ),
      ),
    );
  }
}
