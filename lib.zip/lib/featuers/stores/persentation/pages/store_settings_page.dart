import 'package:booking_v1/core/constants/strings.dart';
import 'package:booking_v1/core/routing/router_extensions.dart';
import 'package:booking_v1/core/widgets/botton_widghts.dart';
import 'package:booking_v1/core/widgets/container_widgets.dart';
import 'package:booking_v1/core/widgets/share_link_widget.dart';
import 'package:booking_v1/dependency_injection/initial.dart';
import 'package:booking_v1/featuers/stores/persentation/bloc/stores/stores_bloc.dart';
import 'package:booking_v1/featuers/stores/persentation/bloc/stores/stores_event.dart';
import 'package:booking_v1/featuers/stores/persentation/bloc/stores/stores_state.dart';
import 'package:booking_v1/featuers/stores/persentation/pages/args/add_pages_args.dart';
import 'package:booking_v1/tests/loading_test.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../../../core/constants/api.dart';
import '../../../../core/routing/app_routes.dart';
import '../../../../core/widgets/ciracle_loading_widget.dart';
import '../widgets/store_details/count_bookings_and_services_widget.dart';
import '../widgets/store_details/view_store_header_widget.dart';
// import 'package:flutter_svg/svg.dart';

// import '../../../../core/widgets/icon_svg_widget.dart';
// import '../../../main/persentation/widghets/view_category_small_widget.dart';

class StoreSettingsPage extends StatelessWidget {
  final int storeId;
  const StoreSettingsPage({required this.storeId, super.key});

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (context) => getIt<StoresBloc>()
        ..addAndRemember(GetStoreByIdEvent(storeId: storeId)),
      child: Directionality(
        textDirection: TextDirection.rtl,
        child: Scaffold(
          appBar: AppBar(
            actions: [
              ShareStoreIconWidget(storeId: storeId),
            ],
          ),
          body: BlocBuilder<StoresBloc, StoresState>(
            builder: (context, state) {
              if (state is LoadingStoresState) {
                return CiracleLoadingWidget();
              } else if (state is ErrorStoresState) {
                return SecondaryContainer(
                    child: Center(
                  child: Text(state.message),
                ));
              } else if (state is LoadedStoreByIdState) {
                final store = state.store;
                return CustomRefresh(
                  onRefresh: () async {
                    BlocProvider.of<StoresBloc>(context)
                        .add(RefreshGetStoreByIdEvent(storeId: storeId));
                  },
                  child: SingleChildScrollView(
                    child: Padding(
                      padding: EdgeInsets.only(
                        left: defaultPadding,
                        right: defaultPadding,
                        bottom: defaultPadding,
                      ),
                      child: Column(
                        spacing: defaultSpacing,
                        children: [
                          ViewStoreHeaderWidget(
                            storeName: state.store.name,
                            storeId: state.store.id.toString(),
                            storeLogo:
                                baseUrlStoreImagesFolder + state.store.logo!,
                            categoryName: state.store.category!.name,
                          ),
                          PrimaryContainer(
                            paddingVertical: 15,
                            paddingHorizontal: 35,
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Column(
                                  children: [
                                    Text(
                                      "${store.visitorsCount}",
                                      style: Theme.of(context)
                                          .textTheme
                                          .displayLarge,
                                    ),
                                    Text(
                                      "الزيارات",
                                      style: Theme.of(context)
                                          .textTheme
                                          .bodyMedium,
                                    )
                                  ],
                                ),
                                Column(
                                  children: [
                                    GetCountBookingsWidget(storeId: store.id!),
                                    // Text(
                                    //   "${testGetCountBookingsWidget().runtimeType}",
                                    //   style: Theme.of(context)
                                    //       .textTheme
                                    //       .displayLarge,
                                    // ),
                                    Text(
                                      "الحجوزات",
                                      style: Theme.of(context)
                                          .textTheme
                                          .bodyMedium,
                                    )
                                  ],
                                ),
                                Column(
                                  children: [
                                    GetCountServicesWidget(storeId: store.id!),
                                    Text(
                                      "الخدمات",
                                      style: Theme.of(context)
                                          .textTheme
                                          .bodyMedium,
                                    )
                                  ],
                                ),
                              ],
                            ),
                          ),
                          SecondaryContainer(
                            paddingHorizontal: 0,
                            paddingVertical: 0,
                            child: Column(
                              children: [
                                _listTile(
                                  context: context,
                                  icon: Icons.library_books,
                                  title: "تقرير العمليات",
                                  onTap: () {},
                                ),
                                _listTile(
                                  context: context,
                                  icon: Icons.storefront_outlined,
                                  title: "الخدمات",
                                  onTap: () {
                                    context.pushTo(serviceOwnerRoute,
                                        extra: store.id);
                                  },
                                ),
                                _listTile(
                                  context: context,
                                  icon: Icons.local_grocery_store_rounded,
                                  title: "الحجوزات",
                                  onTap: () {
                                    context.pushTo(viewStoreBookingsRoute,
                                        extra: store.id);
                                  },
                                ),
                              ],
                            ),
                          ),
                          SecondaryContainer(
                            paddingHorizontal: 0,
                            paddingVertical: 0,
                            child: Column(
                              children: [
                                _listTile(
                                  context: context,
                                  icon: Icons.library_books,
                                  title: "المعلومات التجارية",
                                  onTap: () {
                                    context.pushTo(addUpdateStoreBaiscRoute,
                                        extra:
                                            AddUpdateStoreBaiscAndLocationArgs(
                                          isUpdateStore: true,
                                          store: store,
                                        ));
                                  },
                                ),
                                _listTile(
                                  context: context,
                                  icon: Icons.location_on,
                                  title: "الموقع",
                                  onTap: () {
                                    context.pushTo(addUpdateStoreBaiscRoute,
                                        extra:
                                            AddUpdateStoreBaiscAndLocationArgs(
                                          isUpdateStore: true,
                                          store: store,
                                        ));
                                  },
                                ),
                                _listTile(
                                  context: context,
                                  icon: Icons.wallet,
                                  title: "المحافظ",
                                  onTap: () {
                                    context.pushTo(updateStoreWalletRoute,
                                        extra: store.id);
                                  },
                                ),
                                // _listTile(
                                //   context: context,
                                //   icon: Icons.library_books,
                                //   title: "المشغل",
                                //   onTap: () {},
                                // ),
                                _listTile(
                                  context: context,
                                  icon: Icons.web_stories_outlined,
                                  title: "حسابات التواصل",
                                  onTap: () {
                                    context.pushTo(updateStoreSocialRoute,
                                        extra: store.id);
                                  },
                                ),
                                _listTile(
                                  context: context,
                                  icon: Icons.store,
                                  title: "حالة المتجر",
                                  onTap: () {},
                                ),
                              ],
                            ),
                          ),
                          PrimaryElevatedButton(
                              onPressed: () {}, text: "عرض المتجر")
                        ],
                      ),
                    ),
                  ),
                );
              } else {
                return CiracleLoadingWidget();
              }
            },
          ),
        ),
      ),
    );
  }

  ListTile _listTile(
      {required BuildContext context,
      required IconData icon,
      required String title,
      required Function() onTap}) {
    return ListTile(
      leading: Icon(
        icon,
        color: Theme.of(context).colorScheme.primary,
      ),
      title: Text(
        title,
        style: Theme.of(context).textTheme.titleMedium,
      ),
      trailing: Icon(Icons.chevron_right),
      onTap: onTap,
      splashColor: Theme.of(context).colorScheme.primary.withOpacity(0.20),
      dense: true,
    );
  }
}
