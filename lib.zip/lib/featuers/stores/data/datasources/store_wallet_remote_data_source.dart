import 'dart:convert';

import 'package:dartz/dartz.dart';
import 'package:http/http.dart' as http;

import '../../../../core/constants/api.dart';
import '../../../../core/errors/exception.dart';
import '../../domain/entities/store_wallet.dart';
import '../models/store_wallet_model.dart';

abstract class StoreWalletRemoteDataSource {
  Future<List<StoreWallet>> getStoreWallets(int storeId);
  Future<Unit> addStoreWallet(StoreWalletModel storeWalletModel);
  Future<Unit> deleteStoreWallet(int storeWalletId);
}

const String storeWalletUrl = "StoreWallets/";

class StoreWalletRemoteDataSourceImpl implements StoreWalletRemoteDataSource {
  final http.Client client;

  StoreWalletRemoteDataSourceImpl({required this.client});

  @override
  Future<List<StoreWallet>> getStoreWallets(int storeId) async {
    final String url = "ByStoreId/$storeId";
    final response =
        await client.get(Uri.parse(baseUrl + storeWalletUrl + url));
    if (response.statusCode == 200 ||
        response.statusCode == 201 ||
        response.statusCode == 204) {
      List jsonResponse = json.decode(response.body) as List;
      return jsonResponse.map((get) => StoreWalletModel.fromJson(get)).toList();
      // return json.decode(response.body) as List;
    } else {
      throw ServerException();
    }
  }

  @override
  Future<Unit> addStoreWallet(StoreWalletModel storeWalletModel) async {
    final data = jsonEncode(storeWalletModel.toJson());
    final response = await client.post(Uri.parse(baseUrl + storeWalletUrl),
        headers: {"Content-Type": "application/json"}, body: data);
    if (response.statusCode == 201) {
      return Future.value(unit);
    } else {
      throw ServerException();
    }
  }

  @override
  Future<Unit> deleteStoreWallet(int storeWalletId) async {
    final walletId = "$storeWalletId/";
    final response = await client.delete(
        Uri.parse(baseUrl + storeWalletUrl + walletId),
        headers: {"Content-Type": "application/json"});
    if (response.statusCode == 201 || response.statusCode == 204) {
      return Future.value(unit);
    } else {
      throw ServerException();
    }
  }
}
