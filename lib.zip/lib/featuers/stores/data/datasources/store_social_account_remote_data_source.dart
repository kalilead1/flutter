import 'dart:convert';

import 'package:dartz/dartz.dart';
import 'package:http/http.dart' as http;

import '../../../../core/constants/api.dart';
import '../../../../core/errors/exception.dart';
import '../../domain/entities/store_social_account.dart';
import '../models/store_social_account_model.dart';

abstract class StoreSocialAccountRemoteDataSource {
  Future<List<StoreSocialAccount>> getStoreSocialAccount(int storeId);
  Future<Unit> addStoreSocialAccount(
      StoreSocialAccountModel storeSocialAccountModel);
  Future<Unit> deleteStoreSocialAccount(int id);
}

const String storeSocialAccountUrl = "StoreSocialAccounts/";

class StoreSocialAccountRemoteDataSourceImpl
    implements StoreSocialAccountRemoteDataSource {
  final http.Client client;

  StoreSocialAccountRemoteDataSourceImpl({required this.client});

  @override
  Future<List<StoreSocialAccount>> getStoreSocialAccount(int storeId) async {
    final String url = "GetStoreSocial/";
    final response = await client.get(
        Uri.parse(baseUrl + storeSocialAccountUrl + url + storeId.toString()));
    if (response.statusCode == 200) {
      List jsonResponse = json.decode(response.body) as List;
      return jsonResponse
          .map((get) => StoreSocialAccountModel.fromJson(get))
          .toList();
      // return json.decode(response.body) as List;
    } else {
      throw ServerException();
    }
  }

  @override
  Future<Unit> addStoreSocialAccount(
      StoreSocialAccountModel storeSocialAccountModel) async {
    final data = jsonEncode(storeSocialAccountModel.toJson());
    final response = await client.post(
        Uri.parse(baseUrl + storeSocialAccountUrl),
        headers: {"Content-Type": "application/json"},
        body: data);
    if (response.statusCode == 201) {
      return Future.value(unit);
    } else {
      throw ServerException();
    }
  }

  @override
  Future<Unit> deleteStoreSocialAccount(int id) async {
    final socialAccountId = "$id/";
    final response = await client.delete(
        Uri.parse(baseUrl + storeSocialAccountUrl + socialAccountId),
        headers: {"Content-Type": "application/json"});
    if (response.statusCode == 201 || response.statusCode == 204) {
      return Future.value(unit);
    } else {
      throw ServerException();
    }
  }
}
