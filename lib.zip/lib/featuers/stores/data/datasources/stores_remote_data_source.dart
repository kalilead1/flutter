import 'dart:convert';

import 'package:booking_v1/featuers/stores/domain/dtos/commands/add_store_dto.dart';
import 'package:dartz/dartz.dart';
import 'package:http/http.dart' as http;

import '../../../../core/constants/api.dart';
import '../../../../core/errors/exception.dart';
import '../../domain/entities/store.dart';
import '../models/store_model.dart';

abstract class StoresRemoteDataSource {
  Future<List<Store>> getAllStores();
  Future<List<Store>> getStoreByOwnerId(int ownerId);
  Future<Store> getStoreById(int id);
  Future<Unit> addStore(AddStoreDto addStore);
  Future<Unit> updateStore(int id, Store store);
}

const String storetUrl = "Stores/";

class StoresRemoteDataSourceImpl implements StoresRemoteDataSource {
  final http.Client client;

  StoresRemoteDataSourceImpl({required this.client});

  @override
  Future<List<Store>> getAllStores() async {
    final response = await client.get(Uri.parse(baseUrl + storetUrl));
    if (response.statusCode == 200) {
      List jsonResponse = json.decode(response.body) as List;
      return jsonResponse.map((get) => StoreModel.fromJson(get)).toList();
      // return json.decode(response.body) as List;
    } else {
      throw ServerException();
    }
  }

  @override
  Future<List<Store>> getStoreByOwnerId(int ownerId) async {
    final String url = "OwnerId/";
    final response = await client
        .get(Uri.parse(baseUrl + storetUrl + url + ownerId.toString()));
    if (response.statusCode == 200) {
      List jsonResponse = json.decode(response.body) as List;
      return jsonResponse.map((get) => StoreModel.fromJson(get)).toList();
      // return json.decode(response.body) as List;
    } else {
      throw ServerException();
    }
  }

  @override
  Future<Store> getStoreById(int id) async {
    final response =
        await client.get(Uri.parse(baseUrl + storetUrl + id.toString()));
    if (response.statusCode == 200) {
      return StoreModel.fromJson(json.decode(response.body));
      // return json.decode(response.body);
    } else {
      throw ServerException();
    }
  }

  @override
  Future<Unit> addStore(AddStoreDto addStore) async {
    String url = "AddStore";
    var request =
        http.MultipartRequest('POST', Uri.parse(baseUrl + storetUrl + url));
    request.fields['name'] = addStore.name.toString();
    request.fields['phone'] = addStore.phone.toString();
    request.fields['categoryId'] = addStore.categoryId.toString();
    request.fields['directorateId'] = addStore.directorateId.toString();
    request.fields['addressDetails'] = addStore.addressDetails.toString();
    request.fields['locationCoordinates'] =
        addStore.locationCoordinates.toString();

    if (addStore.logo != null) {
      request.files
          .add(await http.MultipartFile.fromPath("logo", addStore.logo!));
    }

    for (int i = 0; i < addStore.storeWallets!.length; i++) {
      request.fields['storeWallets[$i].walletId'] =
          addStore.storeWallets![i].walletId.toString();
      request.fields['storeWallets[$i].accountNumber'] =
          addStore.storeWallets![i].accountNumber.toString();
    }
    for (int i = 0; i < addStore.storeSocials!.length; i++) {
      request.fields['storeSocialAccounts[$i].socialAccountId'] =
          addStore.storeSocials![i].socialAccountId.toString();
      request.fields['storeSocialAccounts[$i].url'] =
          addStore.storeSocials![i].url.toString();
    }

    for (var document in addStore.storeDocuments!) {
      request.files
          .add(await http.MultipartFile.fromPath("storeDocuments", document));
    }

    final response = await request.send();
    if (response.statusCode == 200 || response.statusCode == 201) {
      return Future.value(unit);
    } else {
      throw ServerException();
    }
  }

  @override
  Future<Unit> updateStore(int id, Store store) async {
    throw UnimplementedError();
  }

  // @override
  // Future<Unit> deleteWallet(int id) {
  //   throw UnimplementedError();
  // }
}
