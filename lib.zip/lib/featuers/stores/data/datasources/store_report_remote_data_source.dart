import 'dart:convert';

import 'package:dartz/dartz.dart';
import 'package:http/http.dart' as http;

import '../../../../core/constants/api.dart';
import '../../../../core/errors/exception.dart';
import '../models/store_report_model.dart';

abstract class StoreReportRemoteDataSource {
  Future<Unit> addStoreReport(StoreReportModel storeReport);
}

const String storeReportUrl = "StoreReport/";

class StoreReportRemoteDataSourceImpl implements StoreReportRemoteDataSource {
  final http.Client client;

  StoreReportRemoteDataSourceImpl({required this.client});

  @override
  Future<Unit> addStoreReport(StoreReportModel storeReport) async {
    final data = jsonEncode(storeReport.toJson());
    final response = await client.post(Uri.parse(baseUrl + storeReportUrl),
        headers: {"Content-Type": "application/json"}, body: data);
    if (response.statusCode == 201 || response.statusCode == 200) {
      return Future.value(unit);
    } else {
      throw ServerException();
    }
  }
}
