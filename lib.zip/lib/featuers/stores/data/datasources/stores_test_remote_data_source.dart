import 'dart:convert';

import 'package:booking_v1/featuers/stores/data/models/dto/commands/add_store_dto_model.dart';
import 'package:booking_v1/featuers/stores/data/models/dto/commands/add_store_report_model.dart';
import 'package:booking_v1/featuers/stores/data/models/dto/commands/add_update_store_social_account_model.dart';
import 'package:booking_v1/featuers/stores/data/models/dto/commands/add_update_store_wallet_model.dart';
import 'package:booking_v1/featuers/stores/data/models/dto/commands/update_store_baisc_dto_model.dart';
import 'package:booking_v1/featuers/stores/data/models/dto/commands/update_store_localion_dto_model.dart';
import 'package:booking_v1/featuers/stores/data/models/dto/commands/update_store_state_dto_model.dart';
import 'package:booking_v1/featuers/stores/data/models/dto/queries/get_store_details_for_provider.dart';
import 'package:booking_v1/featuers/stores/data/models/dto/queries/get_store_details_for_provider_model.dart';
import 'package:booking_v1/featuers/stores/data/models/dto/queries/get_store_details_for_user_model.dart';
import 'package:booking_v1/featuers/stores/data/models/dto/queries/get_store_social_accounts_model.dart';
import 'package:booking_v1/featuers/stores/data/models/dto/queries/get_store_wallets_model.dart';
import 'package:booking_v1/featuers/stores/data/models/dto/queries/get_stores_model.dart';
import 'package:booking_v1/featuers/stores/domain/dtos/commands/add_store_dto.dart';
import 'package:booking_v1/featuers/stores/domain/dtos/queries/get_store_details_for_user.dart';
import 'package:booking_v1/featuers/stores/domain/dtos/queries/get_store_social_accounts.dart';
import 'package:booking_v1/featuers/stores/domain/dtos/queries/get_store_wallets.dart';
import 'package:booking_v1/featuers/stores/domain/dtos/queries/get_stores.dart';
import 'package:dartz/dartz.dart';
import 'package:http/http.dart' as http;

import '../../../../core/constants/api.dart';
import '../../../../core/errors/exception.dart';

abstract class StoresTestRemoteDataSource {
  ///////////////////////////////////////////////////////////////////////////
  ///////////////////////////// commands ////////////////////////////////////
  ///////////////////////////////////////////////////////////////////////////
  Future<Unit> addStore(AddStoreDtoModel addStore);
  Future<Unit> updateStoreBaisc(UpdateStoreBaiscDtoModel updateStoreBaisc);
  Future<Unit> updateStoreGloable(
      UpdateStoreLocalionDtoModel updateStoreGloable);
  Future<Unit> updateStoreState(UpdateStoreStateDtoModel updateStoreState);

  ///
  Future<Unit> addStoreWallet(AddUpdateStoreWalletModel storeWallet);
  Future<Unit> deleteStoreWallet(int storeWalletId);

  ///
  Future<Unit> addStoreSocialAccount(
      AddUpdateStoreSocialAccountModel addSocial);
  Future<Unit> deleteStoreSocialAccount(int storeSocialAccountId);

  ///
  Future<Unit> addStoreReport(AddStoreReportModel storeReport);

  ///////////////////////////////////////////////////////////////////////////
  ////////////////////////////// queries ////////////////////////////////////
  ///////////////////////////////////////////////////////////////////////////
  Future<List<GetStores>> getStoresVerifer();
  Future<List<GetStores>> getStoresByCategory(int? categoryId);
  Future<List<GetStores>> getStoresByUser(int userId);
  Future<GetStoreDetailsForUser> getStoreDetailsForUser(int storeId);
  Future<GetStoreDetailsForProvider> getStoreDetailsForProvider(int storeId);

  ///
  Future<List<GetStoreWallets>> getStoreWallets(int storeId);
  Future<List<GetStoreSocialAccounts>> getStoreSocialAccounts(int storeId);
}

const String storetUrl = "Stores/";

class StoresTestRemoteDataSourceImpl implements StoresTestRemoteDataSource {
  final http.Client client;

  StoresTestRemoteDataSourceImpl({required this.client});
  ///////////////////////////////////////////////////////////////////////////
  ///////////////////////////// commands ////////////////////////////////////
  ///////////////////////////////////////////////////////////////////////////
  @override
  Future<Unit> addStore(AddStoreDto addStore) async {
    String url = "AddStore";
    var request =
        http.MultipartRequest('POST', Uri.parse(baseUrl + storetUrl + url));
    request.fields['name'] = addStore.name.toString();
    request.fields['phone'] = addStore.phone.toString();
    request.fields['categoryId'] = addStore.categoryId.toString();
    request.fields['directorateId'] = addStore.directorateId.toString();
    request.fields['addressDetails'] = addStore.addressDetails.toString();
    request.fields['locationCoordinates'] =
        addStore.locationCoordinates.toString();

    if (addStore.logo != null) {
      request.files
          .add(await http.MultipartFile.fromPath("logo", addStore.logo!));
    }

    for (int i = 0; i < addStore.storeWallets!.length; i++) {
      request.fields['storeWallets[$i].walletId'] =
          addStore.storeWallets![i].walletId.toString();
      request.fields['storeWallets[$i].accountNumber'] =
          addStore.storeWallets![i].accountNumber.toString();
    }
    for (int i = 0; i < addStore.storeSocials!.length; i++) {
      request.fields['storeSocialAccounts[$i].socialAccountId'] =
          addStore.storeSocials![i].socialAccountId.toString();
      request.fields['storeSocialAccounts[$i].url'] =
          addStore.storeSocials![i].url.toString();
    }

    for (var document in addStore.storeDocuments!) {
      request.files
          .add(await http.MultipartFile.fromPath("storeDocuments", document));
    }

    final response = await request.send();
    if (response.statusCode == 200 || response.statusCode == 201) {
      return Future.value(unit);
    } else {
      throw ServerException();
    }
  }

///////////////////////////////////////////////////////////////////////////
  ////////////////////////////// queries ////////////////////////////////////
  ///////////////////////////////////////////////////////////////////////////
  @override
  Future<List<GetStores>> getStoresVerifer() async {
    final response = await client.get(Uri.parse(baseUrl + storetUrl));
    if (response.statusCode == 200) {
      List jsonResponse = json.decode(response.body) as List;
      return jsonResponse.map((get) => GetStoresModel.fromJson(get)).toList();
    } else {
      throw ServerException();
    }
  }

  @override
  Future<List<GetStores>> getStoresByCategory(int? categoryId) async {
    final response = await client.get(Uri.parse(baseUrl + storetUrl));
    if (response.statusCode == 200) {
      List jsonResponse = json.decode(response.body) as List;
      return jsonResponse.map((get) => GetStoresModel.fromJson(get)).toList();
    } else {
      throw ServerException();
    }
  }

  @override
  Future<List<GetStores>> getStoresByUser(int userId) async {
    final response = await client.get(Uri.parse(baseUrl + storetUrl));
    if (response.statusCode == 200) {
      List jsonResponse = json.decode(response.body) as List;
      return jsonResponse.map((get) => GetStoresModel.fromJson(get)).toList();
    } else {
      throw ServerException();
    }
  }

  @override
  Future<GetStoreDetailsForUser> getStoreDetailsForUser(int storeId) async {
    final response =
        await client.get(Uri.parse(baseUrl + storetUrl + id.toString()));
    if (response.statusCode == 200) {
      return GetStoreDetailsForUserModel.fromJson(json.decode(response.body));
    } else {
      throw ServerException();
    }
  }

  @override
  Future<GetStoreDetailsForProvider> getStoreDetailsForProvider(
      int storeId) async {
    final response =
        await client.get(Uri.parse(baseUrl + storetUrl + id.toString()));
    if (response.statusCode == 200) {
      return GetStoreDetailsForProviderModel.fromJson(
          json.decode(response.body));
    } else {
      throw ServerException();
    }
  }

  ///

  @override
  Future<List<GetStoreWallets>> getStoreWallets(int storeId) async {
    final response = await client.get(Uri.parse(baseUrl + storetUrl));
    if (response.statusCode == 200) {
      List jsonResponse = json.decode(response.body) as List;
      return jsonResponse
          .map((get) => GetStoreWalletsModel.fromJson(get))
          .toList();
    } else {
      throw ServerException();
    }
  }

  @override
  Future<List<GetStoreSocialAccounts>> getStoreSocialAccounts(
      int storeId) async {
    final response = await client.get(Uri.parse(baseUrl + storetUrl));
    if (response.statusCode == 200) {
      List jsonResponse = json.decode(response.body) as List;
      return jsonResponse
          .map((get) => GetStoreSocialAccountsModel.fromJson(get))
          .toList();
    } else {
      throw ServerException();
    }
  }

  @override
  Future<Unit> addStoreReport(AddStoreReportModel storeReport) {
    // TODO: implement addStoreReport
    throw UnimplementedError();
  }

  @override
  Future<Unit> addStoreSocialAccount(
      AddUpdateStoreSocialAccountModel addSocial) {
    // TODO: implement addStoreSocialAccount
    throw UnimplementedError();
  }

  @override
  Future<Unit> addStoreWallet(AddUpdateStoreWalletModel storeWallet) {
    // TODO: implement addStoreWallet
    throw UnimplementedError();
  }

  @override
  Future<Unit> deleteStoreSocialAccount(int storeSocialAccountId) {
    // TODO: implement deleteStoreSocialAccount
    throw UnimplementedError();
  }

  @override
  Future<Unit> deleteStoreWallet(int storeWalletId) {
    // TODO: implement deleteStoreWallet
    throw UnimplementedError();
  }

  @override
  Future<Unit> updateStoreBaisc(UpdateStoreBaiscDtoModel updateStoreBaisc) {
    // TODO: implement updateStoreBaisc
    throw UnimplementedError();
  }

  @override
  Future<Unit> updateStoreGloable(
      UpdateStoreLocalionDtoModel updateStoreGloable) {
    // TODO: implement updateStoreGloable
    throw UnimplementedError();
  }

  @override
  Future<Unit> updateStoreState(UpdateStoreStateDtoModel updateStoreState) {
    // TODO: implement updateStoreState
    throw UnimplementedError();
  }
}
