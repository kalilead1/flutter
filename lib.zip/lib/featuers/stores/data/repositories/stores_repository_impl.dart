import 'package:booking_v1/core/errors/exception.dart';
import 'package:booking_v1/core/errors/failures.dart';
import 'package:booking_v1/core/network/network_info.dart';
import 'package:booking_v1/featuers/stores/domain/repositories/stores_repository.dart';
import 'package:dartz/dartz.dart';

import '../../domain/dtos/commands/add_store_dto.dart';
import '../../domain/entities/store.dart';
import '../datasources/store_social_account_remote_data_source.dart';
import '../datasources/stores_remote_data_source.dart';

class StoresRepositoryImpl implements StoresRepository {
  final StoresRemoteDataSource remoteDataSource;
  final StoreSocialAccountRemoteDataSource storeSocialRemoteDataSource;
  final NetworkInfo networkInfo;

  StoresRepositoryImpl({
    required this.remoteDataSource,
    required this.storeSocialRemoteDataSource,
    required this.networkInfo,
  });

  @override
  Future<Either<Failure, List<Store>>> getAllStores() async {
    // if (await networkInfo.isConnected) {
    try {
      final remoteStore = await remoteDataSource.getAllStores();
      // final remoteCategory =
      //     await categoriesRemoteDataSource.getAllCategories();
      // final categoryMap = {
      //   for (var c in remoteCategory) c['id']: CategoryModel.fromJson(c)
      // };
      // final storeData = remoteStore.map<Store>((e) {
      //   final category = categoryMap[e["categoryId"]]!;
      //   return StoreModel.fromJson(e, category);
      // }).toList();
      if (remoteStore.isEmpty) {
        return Left(EmptyCacheFailure());
      } else {
        return Right(remoteStore);
      }
    } on ServerException {
      return Left(ServerFailure());
    }
    // } else {
    //   return Left(OfflineFailure());
    // }
  }

  @override
  Future<Either<Failure, List<Store>>> getStoreByOwnerId(int ownerId) async {
    // if (await networkInfo.isConnected) {
    try {
      final remoteStore = await remoteDataSource.getStoreByOwnerId(ownerId);
      if (remoteStore.isEmpty) {
        return Left(EmptyCacheFailure());
      } else {
        return Right(remoteStore);
      }
    } on ServerException {
      return Left(ServerFailure());
    }
    // } else {
    //   return Left(OfflineFailure());
    // }
  }

  @override
  Future<Either<Failure, Store>> getStoreById(int id) async {
    // if (await networkInfo.isConnected) {
    try {
      final remoteStore = await remoteDataSource.getStoreById(id);
      final storeSocial = await storeSocialRemoteDataSource
          .getStoreSocialAccount(remoteStore.id!);

      final data = Store(
        id: remoteStore.id,
        name: remoteStore.name,
        phone: remoteStore.phone,
        logo: remoteStore.logo,
        categoryId: remoteStore.categoryId,
        category: remoteStore.category,
        stateEnum: remoteStore.stateEnum,
        ownerId: remoteStore.ownerId,
        operatorId: remoteStore.operatorId,
        directorateId: remoteStore.directorateId,
        directorate: remoteStore.directorate,
        addressDetails: remoteStore.addressDetails,
        locationCoordinates: remoteStore.locationCoordinates,
        // visitorsCount: remoteStore.visitorsCount,
        isVerified: remoteStore.isVerified,
        storeSocial: storeSocial,
      );
      if (remoteStore.props.isEmpty) {
        return Left(EmptyCacheFailure());
      } else {
        return Right(data);
      }
    } on ServerException {
      return Left(ServerFailure());
    }
    // } else {
    //   return Left(OfflineFailure());
    // }
  }

  @override
  Future<Either<Failure, Unit>> addStore(AddStoreDto addStore) async {
    try {
      final remoteStore = await remoteDataSource.addStore(addStore);
      return Right(remoteStore);
    } on ServerException {
      return Left(ServerFailure());
    }
  }

  @override
  Future<Either<Failure, Unit>> updateStore(int id, Store store) async {
    throw UnimplementedError();
  }

  // @override
  // Future<Either<Failure, Unit>> deleteStore(int id) {
  //   throw UnimplementedError();
  // }
}
