import 'package:dartz/dartz.dart';

import '../../../../core/errors/exception.dart';
import '../../../../core/errors/failures.dart';
import '../../../../core/network/network_info.dart';
import '../../domain/entities/store_wallet.dart';
import '../../domain/repositories/store_wallet_repository.dart';
import '../datasources/store_wallet_remote_data_source.dart';
import '../models/store_wallet_model.dart';

class StoreWalletRepositoryImpl implements StoreWalletRepository {
  final StoreWalletRemoteDataSource remoteDataSource;
  final NetworkInfo networkInfo;

  StoreWalletRepositoryImpl({
    required this.remoteDataSource,
    required this.networkInfo,
  });

  @override
  Future<Either<Failure, List<StoreWallet>>> getStoreWallets(
      int storeId) async {
    // if (await networkInfo.isConnected) {
    try {
      final remoteStore = await remoteDataSource.getStoreWallets(storeId);

      if (remoteStore.isEmpty) {
        return Left(EmptyCacheFailure());
      } else {
        return Right(remoteStore);
      }
    } on ServerException {
      return Left(ServerFailure());
    }
    // } else {
    //   return Left(OfflineFailure());
    // }
  }

  @override
  Future<Either<Failure, Unit>> addStoreWallet(StoreWallet storeWallet) async {
    try {
      final data = StoreWalletModel(
        id: 0,
        storeId: storeWallet.storeId,
        walletId: storeWallet.walletId,
        accountNumber: storeWallet.accountNumber,
      );
      final remoteStore = await remoteDataSource.addStoreWallet(data);
      return Right(remoteStore);
    } on ServerException {
      return Left(ServerFailure());
    }
  }

  @override
  Future<Either<Failure, Unit>> deleteStoreWallet(int storeWalletId) async {
    try {
      final remoteStore =
          await remoteDataSource.deleteStoreWallet(storeWalletId);
      return Right(remoteStore);
    } on ServerException {
      return Left(ServerFailure());
    }
  }
}
