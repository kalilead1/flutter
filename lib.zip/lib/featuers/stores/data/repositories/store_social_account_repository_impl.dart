import 'package:dartz/dartz.dart';

import '../../../../core/errors/exception.dart';
import '../../../../core/errors/failures.dart';
import '../../../../core/network/network_info.dart';
import '../../domain/entities/store_social_account.dart';
import '../../domain/repositories/store_social_account_repository.dart';
import '../datasources/store_social_account_remote_data_source.dart';
import '../models/store_social_account_model.dart';

class StoreSocialAccountRepositoryImpl implements StoreSocialAccountRepository {
  final StoreSocialAccountRemoteDataSource remoteDataSource;
  final NetworkInfo networkInfo;

  StoreSocialAccountRepositoryImpl({
    required this.remoteDataSource,
    required this.networkInfo,
  });

  @override
  Future<Either<Failure, List<StoreSocialAccount>>> getStoreSocialAccount(
      int storeId) async {
    // if (await networkInfo.isConnected) {
    try {
      final remoteStore = await remoteDataSource.getStoreSocialAccount(storeId);

      if (remoteStore.isEmpty) {
        return Left(EmptyCacheFailure());
      } else {
        return Right(remoteStore);
      }
    } on ServerException {
      return Left(ServerFailure());
    }
    // } else {
    //   return Left(OfflineFailure());
    // }
  }

  @override
  Future<Either<Failure, Unit>> addStoreSocialAccount(
      StoreSocialAccount storeSocialAccount) async {
    try {
      final data = StoreSocialAccountModel(
        id: 0,
        socialAccountId: storeSocialAccount.socialAccountId,
        storeId: storeSocialAccount.storeId,
        url: storeSocialAccount.url,
      );
      final remoteStore = await remoteDataSource.addStoreSocialAccount(data);
      return Right(remoteStore);
    } on ServerException {
      return Left(ServerFailure());
    }
  }

  @override
  Future<Either<Failure, Unit>> deleteStoreSocialAccount(int id) async {
    try {
      final remoteStore = await remoteDataSource.deleteStoreSocialAccount(id);
      return Right(remoteStore);
    } on ServerException {
      return Left(ServerFailure());
    }
  }
}
