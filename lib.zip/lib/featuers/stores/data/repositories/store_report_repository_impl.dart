import 'package:dartz/dartz.dart';

import '../../../../core/errors/exception.dart';
import '../../../../core/errors/failures.dart';
import '../../../../core/network/network_info.dart';
import '../../domain/entities/store_report.dart';
import '../../domain/repositories/store_report_repository.dart';
import '../datasources/store_report_remote_data_source.dart';
import '../models/store_report_model.dart';

class StoreReportRepositoryImpl implements StoreReportRepository {
  final StoreReportRemoteDataSource remoteDataSource;
  final NetworkInfo networkInfo;

  StoreReportRepositoryImpl({
    required this.remoteDataSource,
    required this.networkInfo,
  });

  @override
  Future<Either<Failure, Unit>> addStoreReport(StoreReport storeReport) async {
    try {
      final data = StoreReportModel(
        id: 0,
        reason: storeReport.reason,
        comment: storeReport.comment,
        storeId: storeReport.storeId,
      );
      final remoteStore = await remoteDataSource.addStoreReport(data);
      return Right(remoteStore);
    } on ServerException {
      return Left(ServerFailure());
    }
  }
}
