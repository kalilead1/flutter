import 'package:booking_v1/featuers/stores/domain/entities/store_document.dart';

import 'store_model.dart';

class StoreDocumentModel extends StoreDocument {
  StoreDocumentModel({
    super.id,
    super.storeId,
    super.store,
    super.file,
    super.documentType,
  });

  factory StoreDocumentModel.fromJson(Map<String, dynamic> json) {
    return StoreDocumentModel(
      id: json['id'],
      storeId: json['storeId'],
      store: json['store'] != null ? StoreModel.fromJson(json['store']) : null,
      file: json['file'],
      documentType: json['documentType'],
    );
  }
}
