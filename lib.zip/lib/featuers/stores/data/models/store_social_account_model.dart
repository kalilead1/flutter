import 'package:booking_v1/featuers/stores/domain/entities/store_social_account.dart';

import '../../../main/data/models/social_account_model.dart';
import 'store_model.dart';

class StoreSocialAccountModel extends StoreSocialAccount {
  StoreSocialAccountModel({
    super.id,
    super.storeId,
    super.store,
    super.socialAccountId,
    super.socialAccount,
    super.url,
  });

  factory StoreSocialAccountModel.fromJson(Map<String, dynamic> json) {
    return StoreSocialAccountModel(
      id: json['id'],
      storeId: json['storeId'],
      store: json['store'] != null ? StoreModel.fromJson(json['store']) : null,
      socialAccountId: json['socialAccountId'],
      socialAccount: json['socialAccount'] != null
          ? SocialAccountModel.fromJson(json['socialAccount'])
          : null,
      url: json['url'],
    );
  }

  // factory StoreSocialAccountModel.toJson(Map<String, dynamic> json) {
  //   return StoreSocialAccountModel(
  //     id: json['id'],
  //     storeId: json['storeId'],
  //     socialAccountId: json['socialAccountId'],
  //     url: json['url'],
  //   );
  // }

  Map<String, dynamic> toJson() => {
        // "id": id,
        'storeId': storeId,
        'socialAccountId': socialAccountId,
        'url': url,
      };
}
