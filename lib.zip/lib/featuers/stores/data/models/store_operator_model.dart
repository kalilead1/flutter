import 'package:booking_v1/featuers/stores/domain/entities/store_operator.dart';

import 'store_model.dart';

class StoreOperatorModel extends StoreOperator {
  const StoreOperatorModel({
    super.id,
    super.storeId,
    super.store,
    super.operatorName,
    super.operatorPhone,
    super.isLogin,
  });

  factory StoreOperatorModel.fromJson(Map<String, dynamic> json) {
    return StoreOperatorModel(
      id: json['id'],
      storeId: json['storeId'],
      store: json['store'] != null ? StoreModel.fromJson(json['store']) : null,
      operatorName: json['operatorName'],
      operatorPhone: json['operatorPhone'],
      isLogin: json['isLogin'],
    );
  }
}
