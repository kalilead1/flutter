import 'package:booking_v1/featuers/main/data/models/category_model.dart';
import 'package:booking_v1/featuers/main/data/models/directorate_model.dart';

import '../../domain/entities/store.dart';
import '../../domain/enums/store_state_enum.dart';

class StoreModel extends Store {
  const StoreModel({
    super.id,
    super.name,
    super.phone,
    super.logo,
    super.categoryId,
    super.category,
    super.stateEnum,
    super.ownerId,
    super.operatorId,
    super.directorateId,
    super.directorate,
    super.addressDetails,
    super.locationCoordinates,
    super.visitorsCount,
    super.isVerified,
  });

  factory StoreModel.fromJson(Map<String, dynamic> json) {
    return StoreModel(
      id: json['id'],
      name: json['name'],
      phone: json['phone'],
      logo: json['logo'],
      categoryId: json['categoryId'],
      category: json['category'] != null
          ? CategoryModel.fromJson(json['category'])
          : null,
      stateEnum: StoreStateEnumExtension.fromValue(json['storeState']),
      ownerId: json['ownerId'],
      operatorId: json['operatorId'],
      directorateId: json['directorateId'],
      directorate: json['directorate'] != null
          ? DirectorateModel.fromJson(json['directorate'])
          : null,
      addressDetails: json['addressDetails'],
      locationCoordinates: json['locationCoordinates'],
      visitorsCount: json['visitorsCount'],
      isVerified: json['isVerified'],
    );
  }
}
