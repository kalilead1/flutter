import 'package:booking_v1/featuers/stores/domain/dtos/commands/add_store_report.dart';
import 'package:booking_v1/featuers/stores/domain/enums/store_report_enum.dart';

class AddStoreReportModel extends AddStoreReport {
  const AddStoreReportModel({
    super.storeId,
    super.reason,
    super.comment,
  });

  Map<String, dynamic> toJson() => {
        'storeId': storeId,
        'reason': reason!.value,
        'comment': comment,
      };
}
