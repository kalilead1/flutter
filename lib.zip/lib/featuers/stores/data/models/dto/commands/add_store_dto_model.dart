import 'package:booking_v1/featuers/stores/domain/dtos/commands/add_store_dto.dart';

class AddStoreDtoModel extends AddStoreDto {
  const AddStoreDtoModel({
    super.name,
    super.phone,
    super.logo,
    super.categoryId,
    super.directorateId,
    super.addressDetails,
    super.locationCoordinates,
    super.storeWallets,
    super.storeSocials,
    super.storeDocuments,
  });
}
