import '../../../../domain/dtos/commands/update_store_baisc_dto.dart';

class UpdateStoreBaiscDtoModel extends UpdateStoreBaiscDto {
  const UpdateStoreBaiscDtoModel({
    super.id,
    super.logo,
    super.name,
    super.categoryId,
    super.phone,
  });

  @override
  List<Object?> get props => [
        id,
        logo,
        name,
        categoryId,
        phone,
      ];

  Map<String, dynamic> toJson() => {
        "id": id,
        'logo': logo,
        'name': name,
        'categoryId': categoryId,
        'phone': phone,
      };
}
