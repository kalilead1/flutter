import '../../../../domain/dtos/commands/update_store_state_dto.dart';

class UpdateStoreStateDtoModel extends UpdateStoreStateDto {
  const UpdateStoreStateDtoModel({super.id, super.stateEnum});

  @override
  List<Object?> get props => [id, stateEnum];

  Map<String, dynamic> toJson() => {
        "id": id,
        'stateEnum': stateEnum,
      };
}
