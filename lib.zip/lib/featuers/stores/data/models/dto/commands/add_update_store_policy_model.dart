import '../../../../domain/dtos/commands/add_update_store_policy.dart';

class AddUpdateStorePolicyModel extends AddUpdateStorePolicy {
  const AddUpdateStorePolicyModel({
    super.id,
    super.storeId,
    super.policyId,
  });

  Map<String, dynamic> toJson() => {
        "id": id,
        'storeId': storeId,
        'policyId': policyId,
      };
}
