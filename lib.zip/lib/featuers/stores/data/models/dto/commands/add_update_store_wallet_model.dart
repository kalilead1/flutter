import 'package:booking_v1/featuers/stores/domain/dtos/commands/add_update_store_wallet.dart';

class AddUpdateStoreWalletModel extends AddUpdateStoreWallet {
  const AddUpdateStoreWalletModel({
    super.id,
    super.storeId,
    super.walletId,
    super.accountNumber,
  });

  Map<String, dynamic> toJson() => {
        "id": id,
        'storeId': storeId,
        'walletId': walletId,
        'accountNumber': accountNumber,
      };
}
