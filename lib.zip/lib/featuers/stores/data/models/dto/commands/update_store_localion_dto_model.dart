import '../../../../domain/dtos/commands/update_store_localion_dto.dart';

class UpdateStoreLocalionDtoModel extends UpdateStoreLocalionDto {
  const UpdateStoreLocalionDtoModel({
    super.id,
    super.directorateId,
    super.addressDetails,
    super.locationCoordinates,
  });

  @override
  List<Object?> get props =>
      [id, directorateId, addressDetails, locationCoordinates];

  Map<String, dynamic> toJson() => {
        "id": id,
        'directorateId': directorateId,
        'addressDetails': addressDetails,
        'locationCoordinates': locationCoordinates,
      };
}
