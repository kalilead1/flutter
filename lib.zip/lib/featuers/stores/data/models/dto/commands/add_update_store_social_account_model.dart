import 'package:booking_v1/featuers/stores/domain/dtos/commands/add_update_store_social_account.dart';

class AddUpdateStoreSocialAccountModel extends AddUpdateStoreSocialAccount {
  const AddUpdateStoreSocialAccountModel({
    super.id,
    super.storeId,
    super.socialAccountId,
    super.url,
  });

  Map<String, dynamic> toJson() => {
        "id": id,
        'storeId': storeId,
        'socialAccountId': socialAccountId,
        'url': url,
      };
}
