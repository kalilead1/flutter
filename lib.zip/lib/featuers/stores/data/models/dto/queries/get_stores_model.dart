import 'package:booking_v1/featuers/stores/domain/dtos/queries/get_stores.dart';

class GetStoresModel extends GetStores {
  const GetStoresModel({
    super.id,
    super.logo,
    super.name,
    super.categoryName,
  });

  factory GetStoresModel.fromJson(Map<String, dynamic> json) {
    return GetStoresModel(
      id: json['id'],
      name: json['name'],
      logo: json['logo'],
      categoryName: json['categoryName'],
    );
  }
}
