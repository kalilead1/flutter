import 'package:booking_v1/featuers/stores/domain/dtos/queries/get_store_wallets.dart';

class GetStoreWalletsModel extends GetStoreWallets {
  const GetStoreWalletsModel({super.id, super.walletName, super.walletAccount});

  factory GetStoreWalletsModel.fromJson(Map<String, dynamic> json) {
    return GetStoreWalletsModel(
      id: json['id'],
      walletName: json['walletName'],
      walletAccount: json['walletAccount'],
    );
  }
}
