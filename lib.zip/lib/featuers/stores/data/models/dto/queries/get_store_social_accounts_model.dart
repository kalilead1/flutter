import 'package:booking_v1/featuers/stores/domain/dtos/queries/get_store_social_accounts.dart';

class GetStoreSocialAccountsModel extends GetStoreSocialAccounts {
  const GetStoreSocialAccountsModel(
      {super.id, super.socialName, super.socialUrl});

  factory GetStoreSocialAccountsModel.fromJson(Map<String, dynamic> json) {
    return GetStoreSocialAccountsModel(
      id: json['id'],
      socialName: json['socialName'],
      socialUrl: json['socialUrl'],
    );
  }
}
