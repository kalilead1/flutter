import 'package:booking_v1/featuers/stores/domain/dtos/queries/get_store_details_for_user.dart';
import 'package:booking_v1/featuers/stores/domain/enums/store_state_enum.dart';

class GetStoreDetailsForUserModel extends GetStoreDetailsForUser {
  const GetStoreDetailsForUserModel({
    super.id,
    super.name,
    super.phone,
    super.logo,
    super.categoryName,
    super.stateEnum,

    ///
    super.cityName,
    super.directorateName,
    super.addressDetails,
    super.locationCoordinates,
  });

  factory GetStoreDetailsForUserModel.fromJson(Map<String, dynamic> json) {
    return GetStoreDetailsForUserModel(
      id: json['id'],
      name: json['name'],
      phone: json['phone'],
      logo: json['logo'],
      categoryName: json['categoryName'],
      stateEnum: StoreStateEnumExtension.fromValue(json['storeState']),

      ///
      cityName: json['cityName'],
      directorateName: json['directorateName'],
      addressDetails: json['addressDetails'],
      locationCoordinates: json['locationCoordinates'],
    );
  }
}
