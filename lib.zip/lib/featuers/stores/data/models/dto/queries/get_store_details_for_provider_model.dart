import 'package:booking_v1/featuers/stores/data/models/dto/queries/get_store_details_for_provider.dart';
import 'package:booking_v1/featuers/stores/domain/enums/store_state_enum.dart';

class GetStoreDetailsForProviderModel extends GetStoreDetailsForProvider {
  const GetStoreDetailsForProviderModel({
    super.id,
    super.name,
    super.phone,
    super.logo,
    super.categoryName,
    super.stateEnum,

    ///
    super.cityId,
    super.directorateId,
    super.addressDetails,
    super.locationCoordinates,

    ///
    super.countBookings,
    super.countServices,
    super.visitorsCount,
    super.isVerified,
  });

  factory GetStoreDetailsForProviderModel.fromJson(Map<String, dynamic> json) {
    return GetStoreDetailsForProviderModel(
      id: json['id'],
      name: json['name'],
      phone: json['phone'],
      logo: json['logo'],
      categoryName: json['categoryName'],
      stateEnum: StoreStateEnumExtension.fromValue(json['storeState']),

      ///
      cityId: json['cityId'],
      directorateId: json['directorateId'],
      addressDetails: json['addressDetails'],
      locationCoordinates: json['locationCoordinates'],

      ///
      countBookings: json['countBookings'],
      countServices: json['countServices'],
      visitorsCount: json['visitorsCount'],
      isVerified: json['isVerified'],
    );
  }
}
