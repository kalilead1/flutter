import 'package:booking_v1/featuers/main/domain/enums/policy_type_enum.dart';
import 'package:booking_v1/featuers/stores/domain/dtos/queries/get_store_policies.dart';

class GetStorePoliciesModel extends GetStorePolicies {
  const GetStorePoliciesModel(
      {super.id, super.policyTypeEnum, super.description});

  factory GetStorePoliciesModel.fromJson(Map<String, dynamic> json) {
    return GetStorePoliciesModel(
      id: json['id'],
      policyTypeEnum: PolicyTypeEnumExtension.fromValue(json['policyTypeEnum']),
      description: json['description'],
    );
  }
}
