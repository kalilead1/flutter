import '../../domain/entities/store_report.dart';
import '../../domain/enums/store_report_enum.dart';

class StoreReportModel extends StoreReport {
  const StoreReportModel({
    super.id,
    super.reason,
    super.comment,
    super.storeId,
    // super.userId,
  });

  factory StoreReportModel.fromJson(Map<String, dynamic> json) {
    return StoreReportModel(
      id: json['id'],
      comment: json['comment'],
      reason: StoreReportEnumExtension.fromValue(json['reason']),
      storeId: json['storeId'],
      // userId: json['userId'],
    );
  }
  Map<String, dynamic> toJson() => {
        // "id": id,
        'reason': reason!.value,
        'comment': comment,
        'storeId': storeId,
        // 'userId': userId
      };
}
