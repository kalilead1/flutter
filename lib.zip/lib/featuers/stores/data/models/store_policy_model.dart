import 'package:booking_v1/featuers/stores/domain/entities/store_policy.dart';

import '../../../main/data/models/policy_model.dart';
import 'store_model.dart';

class StorePolicyModel extends StorePolicy {
  const StorePolicyModel({
    super.id,
    super.storeId,
    super.store,
    super.policyId,
    super.policy,
  });

  factory StorePolicyModel.fromJson(Map<String, dynamic> json) {
    return StorePolicyModel(
      id: json['id'],
      storeId: json['storeId'],
      store: json['store'] != null ? StoreModel.fromJson(json['store']) : null,
      policyId: json['policyId'],
      policy:
          json['policy'] != null ? PolicyModel.fromJson(json['policy']) : null,
    );
  }
}
