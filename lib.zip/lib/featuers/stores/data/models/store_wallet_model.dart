import 'package:booking_v1/featuers/main/data/models/wallet_model.dart';
import 'package:booking_v1/featuers/stores/domain/entities/store_wallet.dart';

class StoreWalletModel extends StoreWallet {
  StoreWalletModel({
    super.id,
    super.storeId,
    super.walletId,
    super.wallet,
    super.accountNumber,
  });

  factory StoreWalletModel.fromJson(Map<String, dynamic> json) {
    return StoreWalletModel(
      id: json['id'],
      storeId: json['storeId'],
      walletId: json['walletId'],
      wallet:
          json['wallet'] != null ? WalletModel.fromJson(json['wallet']) : null,
      accountNumber: json['accountNumber'],
    );
  }
  Map<String, dynamic> toJson() => {
        // "id": id,
        'storeId': storeId,
        'walletId': walletId,
        'accountNumber': accountNumber,
      };
}
