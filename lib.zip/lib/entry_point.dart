import 'package:booking_v1/core/routing/app_routes.dart';
import 'package:booking_v1/core/routing/router_extensions.dart';
import 'package:flutter/material.dart';
import 'package:booking_v1/featuers/main/persentation/pages/home_page.dart';
import 'package:booking_v1/featuers/main/persentation/pages/my_booking_page.dart';
import 'package:booking_v1/featuers/main/persentation/pages/settings_page.dart';
import 'package:flutter_svg/svg.dart';

import 'core/widgets/icon_svg_widget.dart';

class EntryPoint extends StatefulWidget {
  final int index;
  const EntryPoint({super.key, required this.index});

  @override
  State<EntryPoint> createState() => _EntryPointState();
}

class _EntryPointState extends State<EntryPoint> {
  late int _selectedIndex;

  @override
  void initState() {
    // if()
    super.initState();
    // widget.index != null ? _selectedIndex = widget.index! : _selectedIndex = 0;
    _selectedIndex = widget.index;
  }

  final List<Widget> _page = [
    HomePage(),
    // ViewServiceTestPage(),
    // Favorites(),
    // Search(),
    // BottonsTest(),
    MyBookingPage(),
    MyBookingPage(),
    MyBookingPage(),
    SettingsPage()
  ];
  void _onItemsTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    SvgPicture svgIcon(String src, {Color? color}) {
      return SvgPicture.asset(
        src,
        height: 22,
        colorFilter: ColorFilter.mode(
          Theme.of(context).brightness == Brightness.light
              ? color ?? Color(0xFFC5D3DF)
              : color ?? Color(0xFF707C86),
          BlendMode.srcIn,
        ),
      );
    }

    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          title: Text(
            "مرحبا علي",
            style: TextStyle(fontSize: 22),
          ),
          actions: [
            IconButton(
              onPressed: () {
                context.pushTo(notificationRoute);
                // showModalBottomSheet(
                //   context: context,
                //   builder: (_) {
                //     return ChangeTheme2();
                //   },
                // );
              },
              // icon: Icon(Icons.notifications_active),
              icon: IconSvg(
                iconName: "Bell",
                size: 24,
              ),
            )
          ],
        ),
        body: _page[_selectedIndex],
        bottomNavigationBar: Container(
          height: 65,
          decoration: BoxDecoration(
              color: Theme.of(context).scaffoldBackgroundColor,
              borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(13), topRight: Radius.circular(13)),
              boxShadow: [
                BoxShadow(
                  // color: Color.fromARGB(20, 0, 0, 0),
                  color:
                      Theme.of(context).colorScheme.secondary.withOpacity(0.90),
                  spreadRadius: 2,
                  blurRadius: 4,
                )
              ]),
          child: BottomNavigationBar(
            // type: BottomNavigationBarType.fixed,
            elevation: 0,
            items: [
              BottomNavigationBarItem(
                icon: svgIcon("assets/icons/home.svg"),
                activeIcon: svgIcon("assets/icons/home.svg",
                    color: Theme.of(context).colorScheme.primary),
                // icon: Icon(
                //   Icons.home,
                //   size: 30,
                // ),
                label: "الصفحة الرئيسية",
                backgroundColor: Colors.transparent,
              ),
              BottomNavigationBarItem(
                icon: svgIcon("assets/icons/Heart Icon_2.svg"),
                activeIcon: svgIcon("assets/icons/Heart Icon_2.svg",
                    color: Theme.of(context).colorScheme.primary),
                label: "المفضلة",
                backgroundColor: Colors.transparent,
              ),
              BottomNavigationBarItem(
                // icon: Icon(
                //   Icons.search,
                //   size: 30,
                // ),
                icon: svgIcon("assets/icons/Search Icon.svg"),
                activeIcon: svgIcon("assets/icons/Search Icon.svg",
                    color: Theme.of(context).colorScheme.primary),
                label: "البحث",
                backgroundColor: Colors.transparent,
              ),
              BottomNavigationBarItem(
                icon: Icon(
                  Icons.article,
                  size: 30,
                ),
                label: "حجوزاتي",
                backgroundColor: Colors.transparent,
              ),
              BottomNavigationBarItem(
                icon: Icon(
                  Icons.settings_suggest_rounded,
                  size: 30,
                ),
                label: "الاعدادات",
                backgroundColor: Colors.transparent,
              ),
            ],
            currentIndex: _selectedIndex,
            onTap: _onItemsTapped,
          ),
        ),
      ),
    );
  }
}
